# Grok Build

The xAI `grok` TUI is Claude-Code-compatible.
Verified initially on 2026-06-29 with 0.2.73, slash submission on 2026-07-03 with 0.2.82, effort on 2026-07-13 with 0.2.99, exit on 2026-07-19 with 0.2.103, and folder trust, the training opt-in, and unsent composer delivery on 2026-09-24 with 1.0.41.
Launch shape: `grok --always-approve "$(cat <brief>)"`.

## Operating facts

| Fact | Value |
|---|---|
| Busy state | The last rendered-tail fallback, isolated to Grok pending a semantic source: ASCII mid-turn `Ctrl+c:cancel`, absent from idle bar `Shift+Tab:mode │ Ctrl+.:shortcuts`, never the locale-fragile braille spinner. |
| Exit | `/exit` prints `Resume this session with: grok --resume <session-id>`; fallback is `Ctrl+Q` twice within 1000ms, `Ctrl+D` quits in VS Code-family terminals, and `Ctrl+C` interrupts. |
| Interrupt | Single `Ctrl+C`; Escape only focuses scrollback. |
| Skill | `/<skill>`, for example `/no-mistakes`, with end-to-end user-skill discovery, invocation, and real `no-mistakes axi run` evidence; the popup may consume Enter and fill an argument placeholder, requiring a real second Enter. |
| Autonomy | `--always-approve`, footer `· always-approve`, verified unattended; `--permission-mode bypassPermissions` is stronger equivalent. |
| Marker | `GROK_AGENT=1` on child or tool processes in 0.2.73 and no `CLAUDECODE`; a 1.0.0 hook instead had `GROK_HOOK_EVENT`, `GROK_HOOK_NAME`, `GROK_SESSION_ID`, and `GROK_WORKSPACE_ROOT` without `GROK_AGENT`, so ancestry guarantees identity. |
| Resume | `grok --resume <session-id>`, or `grok -c` / `--continue` for cwd latest; `--fork-session` creates a new id. |
| Model | `--model <model>`; discover current account models with `grok models`. |
| Effort | `--reasoning-effort <low\|medium\|high>`, alias `--effort`; version 0.2.99 rejects `xhigh` and `max` with `use one of: high, medium, low`; `references/common/model-and-effort.md` owns fallback and unsupported-value handling. |

Reliable Grok rules must account for hook markers as well as the child fast path.
`../../../docs/turnend-guard.md` under "Harness integrations" owns the marker contract.

## Submission and startup

Slash autocomplete can turn the first Enter into selection plus an argument hint, including `/no-mistakes`'s optional task argument or `/compact compaction instructions`, without submission.
The shared classifier keeps that text pending, and retry sends the second Enter on both verified backends; Herdr may also prove a turn through native state.

On 2026-07-03 two Grok 0.2.82 Herdr workers left `/no-mistakes` typed for minutes while send returned success.
Old Herdr logic treated any pane delta as submission, including popup closure and placeholder fill.
Tmux and Herdr now route captures through `../../../bin/fm-composer-lib.sh`, which classifies real text on every proven content row.
`../../../docs/herdr-backend.md` owns the boundary and `../../../tests/fm-backend-herdr.test.sh` covers it.

On 2026-09-24, on the first dispatches after Grok was added to this fleet, a steer landed in the Grok 1.0.41 composer unsent.
The pane showed `Enter:send now` and the text stayed pending.
Verify delivery by peeking at the pane rather than trusting the send result, on anything time-critical to this harness.
A hold that silently does not arrive is the worst message to lose.

The "Run Grok Build in a project directory?" picker appears only outside a project, such as home, Desktop, Downloads, or `/tmp`.
The spawn starts in the isolated git root, so that picker stays absent and needs no key.
For unavoidable non-project launch, `[hints] project_picker_disabled = true` in `~/.grok/config.toml` suppresses the picker.
The project picker and the folder-trust gate are separate dialogs.
On 2026-09-24, on those same first dispatches, Grok 1.0.41 rendered a folder-trust gate in a linked git worktree.
The dialog printed the primary checkout path, because a linked worktree's git root resolves to the main one, so the text reads exactly like a worktree-isolation violation when isolation is intact.
Check the worker's real location with `/proc/<pid>/cwd`, never the path the dialog prints.
Answer the gate with the key path's Enter (`../../../bin/fm-send.sh <target> --key Enter`).
`../../../bin/fm-send.sh` carries only Escape, Enter, and C-c, and a literal `y` has no sanctioned route.
On 2026-09-24 Grok 1.0.41 persisted that answer to `~/.grok/trusted_folders.toml`, keyed by the path the dialog prints.
That is the same store `../../../bin/fm-spawn.sh` deliberately does not write and calls a high-blast-radius write.
In a linked worktree the trust therefore lands on the primary checkout, not the disposable copy, and it persists for every later Grok run there.
This silently enables Grok project hooks for that checkout.
Answering the gate is nonetheless the sanctioned route, because `../../../bin/fm-send.sh` has no other way to clear it.
It is a knowing exception to the store-avoidance stance, not an oversight, so expect the new entry to appear in that file.

## Training opt-in

On 2026-09-24, on the first dispatches after Grok was added to this fleet, Grok 1.0.41 offered "Help improve Grok".
That opt-in retains prompts, traces, and metrics for training.
It is off by default and must be left off.
This fleet writes customer-facing privacy statements saying customer data and audio are not used for training, and sending our own prompts and traces to a provider for training while publishing that is not a trade to make silently.

## Composer

Fresh placeholder `Type a message...` uses dark 24-bit TRUECOLOR, not SGR-2.
`fm_composer_strip_ghost` in `../../../bin/fm-composer-lib.sh` drops dim or faint and truecolor below `FM_COMPOSER_GHOST_LUMA_MAX`, default 128.
On Grok 0.2.93, real input `38;2;224;222;244` measured about 225 luminance, while borders and placeholder ranged from `38;2;50;47;70` through `38;2;110;106;134`, about 51-110, and were dropped.
The truecolor rule assumes the fleet's dark theme; SGR-2 is theme-independent.
Coverage is `../../../tests/fm-composer-ghost.test.sh` and `../../../tests/fm-backend-herdr.test.sh`.

Tmux `#{cursor_y}` may point at the pristine composer's bottom border.
The shared classifier locates the full box and all content rows, so border cursor and multi-row composers require no adapter offsets.

## Worker turn-end hook

Grok fires `Stop` each turn.
Project hooks require folder trust in `~/.grok/trusted_folders.toml`, which the spawn does not edit, though answering the folder-trust gate above writes it; global `~/.grok/hooks/` is always trusted.
The spawn installs guarded global `fm-turn-end.json` and `fm-turn-end.sh`.
They act only when workspace `.fm-grok-turnend` matches the registry under `~/.grok/hooks/fm-turn-end.d/`, then touch the task's `state/<id>.turn-ended` through always-set `GROK_WORKSPACE_ROOT`, which equals the worktree.
This stays outside the worktree, needs no trust grant, and writes only Firstmate files.
`../../../bin/fm-teardown.sh` removes the gitignored pointer before pooling.
Secondmates skip it because idle is healthy and ordinary stale-pane detection does not apply.

## Primary integration

Verified on 2026-07-28 with 0.2.112 and genuine pre-native 0.2.73.
`.grok/hooks/fm-primary-turnend-guard.json` invokes `../../../bin/fm-turnend-guard-grok.sh`.
The exact running Stop payload selects same-process continuation on 0.2.112; 0.2.73 omits that capability and needs one guarded `grok --resume`.
`../../../docs/turnend-guard.md` owns adaptive and malformed-input behavior.

Grok also loads Claude project settings, so Claude entries for Grok-covered events stand down under `GROK_AGENT` or `GROK_HOOK_EVENT`; that owner records the exact set and why `GROK_SESSION_ID` is excluded.
Project-local hooks require launch-time `--trust`; without it the guard steps aside and `../../../bin/fm-guard.sh` is the next-command alarm.
Watcher supervision remains tracked background notification around `../../../bin/fm-watch-arm.sh`, not Pi-style extension ownership.
In a home with `config/supervision-host` and no `config/supervision-host-off` the session-start block renders that background call as `../../../bin/fm-supervision-host.sh park`, with Claude's print mode as its headless engine; [`supervision-host.md`](../../../../../docs/supervision-host.md) owns the host.
PreToolUse blocks directly, but every `$VAR` in a hook command needs inline `:-default` or Grok refuses the hook.
