// Firstmate primary watcher bridge for Pi.
//
// Session-generation ownership (stated once here):
// Pi emits session_shutdown for ordinary same-process replacements (/new, /resume,
// /fork, reload) as well as terminal quit. This extension binds one generation per
// session activation. Only the active live generation may start, stop, rearm, or
// clear the arm child. Replacement shutdown publishes a generation-bound handoff
// phase but retains its established child until the next owning session_start (or
// fresh factory bind) publishes a distinct active generation and commits the
// tracked replacement arm without a model turn. A replacement handoff carries
// actionable closes that were still pending delivery; its durable state lives at
// state/extensions/pi-primary-watch/session-replacement-actionable.json.
// Terminal quit leaves the final generation stopped so late callbacks cannot rearm.
// Stale callbacks from a prior generation are no-ops against the active replacement.
//
// Delivery versus consumption (stated once here):
// Each actionable close restores continuity in one generation-owned pump,
// independently of serialized wake delivery. Delivery uses that close token's
// captured restoration outcome; branch settlement never holds the arm owner.
// A main follow-up is delivered once Pi accepts it (sendUserMessage resolves).
// The successor pipeline never waits for the model to read it: a follow-up
// queued while main is streaming joins the running run without ever raising
// before_agent_start, so waiting on that event stalls every later close.
// Consumption is tracked only so a replacement can replay a follow-up Pi had
// not consumed. An idle main consumes at a prompt-bearing before_agent_start;
// a streaming main consumes at the user message_start carrying the exact wake
// text. A no-prompt custom trigger cannot consume it, even with equal content.
// Either user boundary finishes the pending record, and a still-unconsumed
// record rides the replacement handoff.
//
// Postures (stated once here; docs/pi-supervision-branch.md "Postures"):
// the away-posture record state/.afk-contract is read as a file at every
// routing decision, never inferred from chat. While it exists every
// actionable row is offered to the branch as eligible and main is offered
// nothing the branch can take; a wake the branch declines or cannot take
// (a broken branch, an unresolvable or corrupt queue) and every
// watcher-failure alarm still reach main exactly as attended, because only
// main can repair supervision itself. Nothing else about delivery or
// consumption changes.
import { spawn, spawnSync, type ChildProcess } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI, Theme } from "@earendil-works/pi-coding-agent";
import { Box, Container, Text, type Component } from "@earendil-works/pi-tui";
import { Type } from "typebox";
import { registerFirstmateTool } from "./lib/fm-native-contract.ts";
import {
  afkPostureRecordPresent,
  branchOfferForWake,
  createBranchDispatchOffer,
  FM_BRANCH_DISPATCH_EVENT,
} from "./lib/fm-branch-dispatch.ts";
import {
  type CalmPresentationState,
  calmTranscriptClassIsVisible,
  FIRSTMATE_CALM_PRESENTATION_EVENT,
} from "./lib/fm-calm-visibility.ts";
import { encodeFirstmateOperationalInput } from "./lib/fm-operational-input.ts";

type ArmResult = {
  ok: boolean;
  message: string;
};

type LockOwnership = "owned" | "missing" | "other";

type CloseClassification = {
  kind: "actionable" | "failure";
  message: string;
};

type PendingActionableClose = {
  version: 1;
  token: string;
  message: string;
  predecessorArmPid: string;
  delivered?: true;
};

type ReplacementActionableHandoff = {
  version: 2;
  pending: PendingActionableClose[];
};

type WatchToolShellState = {
  shell?: Box;
  call?: Component;
  result?: Component;
};

type WatchToolRenderContext = {
  isError: boolean;
  isPartial: boolean;
};

type UnconsumedWake = {
  content: string;
  pending: PendingActionableClose;
};

type ActionableRestoration = {
  failure: string;
  recovery?: { generation: string; watcherPid: string };
  // The handling handoff is confirmed inside the continuity operation, while
  // this close's own successor is still the live arm. A later successor
  // replacing that arm must not turn this close's delivery into a false
  // restoration failure, so the delivery reads this cached outcome instead of
  // confirming a token that may since have been superseded.
  confirmation?: { ok: boolean; detail: string; superseded?: boolean };
};

type SessionGeneration = {
  id: number;
  stopping: boolean;
  replacement: boolean;
  child: ChildProcess | null;
  retryTimer: ReturnType<typeof setTimeout> | null;
  cleanupTimer: ReturnType<typeof setTimeout> | null;
  retryFailures: number;
  restoring: Promise<void> | null;
  delivering: boolean;
  restorations: Map<string, ActionableRestoration>;
  seq: number;
  pendingActionables: PendingActionableClose[];
  cleanupFailure: string;
  // Main follow-ups Pi has accepted but not yet consumed, by pending token.
  // Never cleared at shutdown: a delivery continuation that runs after the
  // replacement began reads it to tell a main-queued wake (replayed) from a
  // branch-handled one (finished).
  unconsumedWakes: Map<string, UnconsumedWake>;
  // A verified successor's failure during restoration keeps its bounded retry
  // once that continuity operation finishes, independently of wake delivery.
  // The guard names the operation that held the close: the retry belongs to
  // the operation that was in flight when the close arrived, so the
  // restoration settles it and the delivery settles it, and neither takes the
  // other's.
  deferredClose: { message: string; predecessorArmPid: string; guard: "restore" | "delivery" } | null;
};

function refreshWatchToolShell(
  state: WatchToolShellState,
  theme: Theme,
  context: WatchToolRenderContext,
): Box {
  const background = context.isPartial
    ? (text: string) => theme.bg("toolPendingBg", text)
    : context.isError
      ? (text: string) => theme.bg("toolErrorBg", text)
      : (text: string) => theme.bg("toolSuccessBg", text);
  const shell = state.shell ?? new Box(1, 1, background);
  state.shell = shell;
  shell.setBgFn(background);
  shell.clear();
  if (state.call) shell.addChild(state.call);
  if (state.result) shell.addChild(state.result);
  return shell;
}

const extensionFile = fileURLToPath(import.meta.url);
const extensionDir = dirname(extensionFile);
const root = resolve(extensionDir, "../..");
const fmHome = process.env.FM_HOME || process.env.FM_ROOT_OVERRIDE || root;
const fmRoot = process.env.FM_ROOT_OVERRIDE || root;
const state = process.env.FM_STATE_OVERRIDE || `${fmHome}/state`;
const config = process.env.FM_CONFIG_OVERRIDE || `${fmHome}/config`;
const armScript = `${fmRoot}/bin/fm-watch-arm.sh`;
const marker = `${state}/.pi-watch-extension-loaded`;
const handoffDir = `${state}/extensions/pi-primary-watch`;
const actionableHandoff = `${handoffDir}/session-replacement-actionable.json`;
const extensionLog = `${state}/.watch-extension.log`;
const extensionLogMaxLines = extensionLogKeepLines();
const extensionVersion = `sha256:${createHash("sha256").update(readFileSync(extensionFile)).digest("hex")}`;
const retryBaseMs = positiveInteger("FM_WATCH_REARM_RETRY_BASE_MS", 250);
const retryMaxMs = positiveInteger("FM_WATCH_REARM_RETRY_MAX_MS", 4000);
const retryLimit = positiveInteger("FM_WATCH_REARM_RETRY_LIMIT", 5);
// 35s on Windows so the budget stays above arm's MSYS confirm default (30s in
// bin/fm-watch-arm.sh): a slow but successful Git Bash cold start must not be
// SIGTERMed mid-confirmation. Conditioned on win32 so other platforms keep 12s.
const armReadyTimeoutMs = positiveInteger(
  "FM_PI_ARM_READY_TIMEOUT_MS",
  process.platform === "win32" ? 35000 : 12000,
);
const armRetireTimeoutMs = positiveInteger("FM_WATCH_ARM_RETIRE_TIMEOUT_MS", 1000);
const repairOnlyHint = "call fm_watch_arm_pi again only after a later notification says the cycle is missing, failed, or unhealthy";
const shuttingDownMessage = "watcher: not armed - Pi session is shutting down";

let nextHandoffId = 0;
let activeGeneration: SessionGeneration | null = null;
let replacementHandoff: PendingActionableClose[] | null = null;
type ReplacementActionableReceiver = (pending: PendingActionableClose) => void;
type ActionableDeliveryClaim = {
  owner: SessionGeneration;
  settlement: Promise<"delivered" | "failed">;
};
type ReplacementCoordinator = {
  receiver: ReplacementActionableReceiver | null;
  pending: PendingActionableClose[];
  nextTokenId: number;
  nextGenerationId: number;
  deliveries: Map<string, ActionableDeliveryClaim>;
};
type ReplacementCoordinatorGlobal = typeof globalThis & {
  __firstmatePiWatchReplacements?: Map<string, ReplacementCoordinator>;
};
const replacementCoordinatorGlobal = globalThis as ReplacementCoordinatorGlobal;
const replacementCoordinators = replacementCoordinatorGlobal.__firstmatePiWatchReplacements ??= new Map<string, ReplacementCoordinator>();
function replacementCoordinatorFor(handoff: string): ReplacementCoordinator {
  const existing = replacementCoordinators.get(handoff);
  if (existing) return existing;
  const created: ReplacementCoordinator = {
    receiver: null,
    pending: [],
    nextTokenId: 0,
    nextGenerationId: 0,
    deliveries: new Map(),
  };
  replacementCoordinators.set(handoff, created);
  return created;
}
const replacementCoordinator = replacementCoordinatorFor(actionableHandoff);
const armReadiness = new WeakMap<ChildProcess, Promise<boolean>>();
const armClose = new WeakMap<ChildProcess, Promise<void>>();
const retiringGenerations = new Set<SessionGeneration>();
// Children the extension itself asked to exit; their close is not a failure
// of the successor and never earns a deferred retry.
const armRetired = new WeakSet<ChildProcess>();
const armRecovery = new WeakMap<ChildProcess, { generation: string; watcherPid: string }>();
const armPendingActionable = new WeakMap<ChildProcess, PendingActionableClose>();

function positiveInteger(name: string, fallback: number): number {
  const value = Number(process.env[name]);
  if (!Number.isFinite(value) || value <= 0) return fallback;
  return Math.floor(value);
}

// Opt-in bound for the extension diagnostic log: only a positive
// FM_WATCH_EXTENSION_LOG_KEEP_LINES enables logging, so the default run
// writes nothing. Unset, empty, non-numeric, zero, and negative values
// disable the log entirely instead of falling back to a silent default.
function extensionLogKeepLines(): number {
  const raw = process.env.FM_WATCH_EXTENSION_LOG_KEEP_LINES;
  if (raw === undefined || raw.trim() === "") return 0;
  const value = Math.floor(Number(raw));
  if (!Number.isFinite(value) || value <= 0) return 0;
  return value;
}

function parentPid(pid: string): string {
  const result = spawnSync("ps", ["-o", "ppid=", "-p", pid], { encoding: "utf8" });
  if (result.status !== 0) return "";
  return result.stdout.trim();
}

function pidAlive(pid: string): boolean {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

// An arm child whose process is gone but whose close event has not fired yet
// (stdio pipes still held) must not keep the single-flight slot: neither a
// repair call nor a scheduled retry would start anything until that close
// finally fires. Callers that gate on slot occupancy use this instead of
// owner.child so both paths can always recover.

function liveArmChild(owner: SessionGeneration): ChildProcess | null {
  const child = owner.child;
  if (!child) return null;
  if (child.exitCode !== null || child.signalCode !== null) return null;
  const pid = child.pid;
  if (pid === undefined || !pidAlive(String(pid))) return null;
  return child;
}

// The session lock names a local pid or, on Windows, a tagged `win:<pid>`
// (fm_session_pid_valid in bin/fm-session-lock-lib.sh owns that shape). Native
// Node on Windows sees Windows pids directly, so a tagged holder is compared
// and probed by its digits. Any other value is no usable identity, "".
function lockHolderPid(lockPid: string): string {
  const tagged = process.platform === "win32" ? /^win:([0-9]+)$/.exec(lockPid) : null;
  const pid = tagged ? tagged[1] : lockPid;
  return /^[0-9]+$/.test(pid) && pid !== "1" ? pid : "";
}

function lockOwnership(): LockOwnership {
  let lockPid = "";
  try {
    lockPid = readFileSync(`${state}/.lock`, "utf8").trim();
  } catch {
    return "missing";
  }
  const holderPid = lockHolderPid(lockPid);
  if (!holderPid) return "other";
  let pid = String(process.pid);
  for (let i = 0; i < 8; i += 1) {
    if (pid === holderPid) return "owned";
    pid = parentPid(pid);
    if (!pid || pid === "1") break;
  }
  return pidAlive(holderPid) ? "other" : "missing";
}

// A Pi command started from inside the live session, such as the `pi --help`
// capability probe in bin/fm-spawn.sh, auto-loads this extension too and passes
// lockOwnership() through the same ancestor walk. Its pid dies at once, so the
// marker must keep naming the live session above it (#5202). Pid equality with
// the lock is not required because a wrapper such as pi-signed may hold the lock
// while the extension host runs as its child.
function markerNamesLiveAncestor(): boolean {
  let markerPid = "";
  try {
    markerPid = readFileSync(marker, "utf8").split(/\r?\n/)[1] ?? "";
  } catch {
    return false;
  }
  if (!/^[0-9]+$/.test(markerPid) || markerPid === String(process.pid) || !pidAlive(markerPid)) {
    return false;
  }
  let pid = String(process.pid);
  for (let i = 0; i < 8; i += 1) {
    pid = parentPid(pid);
    if (!pid || pid === "1") return false;
    if (pid === markerPid) return true;
  }
  return false;
}

function publishGenerationOwner(generation: SessionGeneration, phase: "active" | "handoff"): void {
  if (lockOwnership() === "other" || markerNamesLiveAncestor()) return;
  mkdirSync(state, { recursive: true });
  const temporary = `${marker}.tmp-${process.pid}-${generation.id}`;
  writeFileSync(
    temporary,
    `${extensionVersion}\n${process.pid}\ngeneration=${generation.id} phase=${phase}\n`,
    { mode: 0o600 },
  );
  renameSync(temporary, marker);
}

function retireGenerationOwner(generation: SessionGeneration, replacement: boolean): void {
  let lines: string[];
  try {
    lines = readFileSync(marker, "utf8").trimEnd().split(/\r?\n/);
  } catch {
    return;
  }
  if (
    lines[0] !== extensionVersion ||
    lines[1] !== String(process.pid) ||
    lines[2] !== `generation=${generation.id} phase=active`
  ) return;
  if (replacement) {
    publishGenerationOwner(generation, "handoff");
    return;
  }
  try {
    unlinkSync(marker);
  } catch (error) {
    if (nodeErrorCode(error) !== "ENOENT") throw error;
  }
}

function actionableLine(output: string): string {
  const lines = output.split(/\r?\n/);
  return lines.find((line) => /^(signal:|stale:|check:|heartbeat($|:))/.test(line)) || "";
}

function completedActionableLine(output: string): string {
  const newline = output.lastIndexOf("\n");
  return newline < 0 ? "" : actionableLine(output.slice(0, newline + 1));
}

// The text Pi carries in a user message_start: sendUserMessage wraps a string
// as one text part, so the joined text parts equal the sent content.
function userMessageText(content: unknown): string {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  const parts: string[] = [];
  for (const part of content) {
    if (
      typeof part === "object" && part !== null &&
      (part as { type?: unknown }).type === "text" &&
      typeof (part as { text?: unknown }).text === "string"
    ) {
      parts.push((part as { text: string }).text);
    }
  }
  return parts.join("\n");
}

function nodeErrorCode(error: unknown): string {
  return typeof error === "object" && error !== null && "code" in error
    ? String((error as { code?: unknown }).code ?? "")
    : "";
}

// Bounded diagnostic record for restore attempts, readiness timeouts, and
// handling-confirmation targets and results. Opt-in through
// FM_WATCH_EXTENSION_LOG_KEEP_LINES and off by default: a disabled log
// returns before touching the filesystem, so it never creates its file.
// Purely observational: a logging failure never changes supervision
// behavior. docs/watcher-continuity.md owns what the arm layer already
// records; this file is the extension side.
function appendExtensionLog(detail: string): void {
  if (extensionLogMaxLines <= 0) return;
  try {
    mkdirSync(state, { recursive: true });
    const cleaned = detail.replace(/[\r\n\t]+/g, " ").slice(0, 512);
    const line = `${new Date().toISOString()} pid=${process.pid} ${cleaned}`;
    let previous = "";
    try {
      previous = readFileSync(extensionLog, "utf8");
    } catch (error) {
      if (nodeErrorCode(error) !== "ENOENT") return;
    }
    const joined = `${previous}${previous === "" || previous.endsWith("\n") ? "" : "\n"}${line}\n`;
    const kept = joined.split("\n").slice(-(extensionLogMaxLines + 1)).join("\n");
    const temporary = `${extensionLog}.tmp-${process.pid}`;
    writeFileSync(temporary, kept, { mode: 0o600 });
    renameSync(temporary, extensionLog);
  } catch {
    // Diagnostic only: never fail supervision for observability.
  }
}

function createPendingActionable(message: string, predecessorArmPid: string): PendingActionableClose {
  return {
    version: 1,
    token: `${process.pid}-${Date.now()}-${++replacementCoordinator.nextTokenId}`,
    message,
    predecessorArmPid,
  };
}

function validatePendingActionable(value: unknown): PendingActionableClose {
  if (
    typeof value !== "object" || value === null ||
    (value as { version?: unknown }).version !== 1 ||
    typeof (value as { token?: unknown }).token !== "string" ||
    !/^[0-9]+-[0-9]+-[0-9]+$/.test((value as { token: string }).token) ||
    typeof (value as { message?: unknown }).message !== "string" ||
    !actionableLine((value as { message: string }).message) ||
    typeof (value as { predecessorArmPid?: unknown }).predecessorArmPid !== "string" ||
    !/^[0-9]*$/.test((value as { predecessorArmPid: string }).predecessorArmPid) ||
    ((value as { delivered?: unknown }).delivered !== undefined &&
      (value as { delivered?: unknown }).delivered !== true)
  ) {
    throw new Error(`invalid Pi replacement actionable handoff at ${actionableHandoff}`);
  }
  return value as PendingActionableClose;
}

function validateReplacementHandoff(value: unknown): PendingActionableClose[] {
  if (
    typeof value !== "object" || value === null ||
    (value as { version?: unknown }).version !== 2 ||
    !Array.isArray((value as { pending?: unknown }).pending) ||
    (value as { pending: unknown[] }).pending.length === 0
  ) {
    throw new Error(`invalid Pi replacement actionable handoff at ${actionableHandoff}`);
  }
  const pending = (value as { pending: unknown[] }).pending.map(validatePendingActionable);
  if (new Set(pending.map((item) => item.token)).size !== pending.length) {
    throw new Error(`invalid Pi replacement actionable handoff at ${actionableHandoff}`);
  }
  return pending;
}

function writeReplacementHandoff(pending: PendingActionableClose[]): void {
  replacementHandoff = [...pending];
  mkdirSync(handoffDir, { recursive: true });
  const temporary = `${actionableHandoff}.tmp-${process.pid}-${++nextHandoffId}`;
  const handoff: ReplacementActionableHandoff = { version: 2, pending };
  try {
    writeFileSync(temporary, `${JSON.stringify(handoff)}\n`, { mode: 0o600 });
    renameSync(temporary, actionableHandoff);
  } catch (error) {
    try {
      unlinkSync(temporary);
    } catch {
      // Preserve the original handoff publication error.
    }
    throw error;
  }
}

function persistReplacementHandoff(pending: PendingActionableClose[]): void {
  if (pending.length === 0) return;
  writeReplacementHandoff(pending);
}

function loadReplacementHandoff(): PendingActionableClose[] {
  try {
    const pending = validateReplacementHandoff(JSON.parse(readFileSync(actionableHandoff, "utf8")));
    replacementHandoff = pending;
    return [...pending];
  } catch (error) {
    if (nodeErrorCode(error) === "ENOENT") {
      replacementHandoff = null;
      return [];
    }
    throw error;
  }
}

function mergeReplacementHandoff(pending: PendingActionableClose): void {
  let stored: PendingActionableClose[] = [];
  try {
    stored = validateReplacementHandoff(JSON.parse(readFileSync(actionableHandoff, "utf8")));
  } catch (error) {
    if (nodeErrorCode(error) !== "ENOENT") throw error;
  }
  if (!stored.some((item) => item.token === pending.token)) stored.push(pending);
  writeReplacementHandoff(stored);
}

function clearReplacementHandoff(pending: PendingActionableClose): void {
  try {
    const stored = validateReplacementHandoff(JSON.parse(readFileSync(actionableHandoff, "utf8")));
    const remaining = stored.filter((item) => item.token !== pending.token);
    if (remaining.length === stored.length) return;
    if (remaining.length > 0) {
      writeReplacementHandoff(remaining);
    } else {
      replacementHandoff = null;
      unlinkSync(actionableHandoff);
    }
  } catch (error) {
    if (nodeErrorCode(error) !== "ENOENT") throw error;
  }
}

function classifyClose(stdout: string, stderr: string, code: number | null, signal: NodeJS.Signals | null): CloseClassification {
  const combined = `${stdout}\n${stderr}`.trim();
  const reason = actionableLine(combined);
  if (reason) return { kind: "actionable", message: reason };
  const healthy = combined.split(/\r?\n/).find((line) => /^watcher: healthy\b/.test(line));
  if (healthy) {
    return {
      kind: "failure",
      message: `watcher: FAILED - Pi extension arm child found an external healthy watcher instead of owning wake delivery\n${healthy}`,
    };
  }
  const failed = combined.split(/\r?\n/).find((line) => /^watcher: FAILED/.test(line));
  if (failed) return { kind: "failure", message: failed };
  if (signal) {
    return {
      kind: "failure",
      message: `watcher: FAILED - Pi extension arm child ended from ${signal}${combined ? `\n${combined}` : ""}`,
    };
  }
  if (code && code !== 0) {
    return {
      kind: "failure",
      message: `watcher: FAILED - fm-watch-arm.sh exited ${code}${combined ? `\n${combined}` : ""}`,
    };
  }
  return {
    kind: "failure",
    message: "watcher: FAILED - Pi extension arm cycle ended without an actionable reason",
  };
}

function createGeneration(): SessionGeneration {
  return {
    id: ++replacementCoordinator.nextGenerationId,
    stopping: false,
    replacement: false,
    child: null,
    retryTimer: null,
    cleanupTimer: null,
    retryFailures: 0,
    restoring: null,
    delivering: false,
    restorations: new Map(),
    seq: 0,
    pendingActionables: [],
    cleanupFailure: "",
    unconsumedWakes: new Map(),
    deferredClose: null,
  };
}

function activateGeneration(generation: SessionGeneration): void {
  activeGeneration = generation;
}

function generationIsLive(generation: SessionGeneration): boolean {
  return activeGeneration === generation && !generation.stopping;
}

function relinquishGeneration(generation: SessionGeneration): void {
  generation.stopping = true;
  if (generation.retryTimer) clearTimeout(generation.retryTimer);
  if (generation.cleanupTimer) clearTimeout(generation.cleanupTimer);
  generation.retryTimer = null;
  generation.cleanupTimer = null;
  if (generation.child) retiringGenerations.add(generation);
}

function stopGeneration(generation: SessionGeneration): ChildProcess | null {
  relinquishGeneration(generation);
  const child = generation.child;
  if (child) child.kill("SIGTERM");
  generation.child = null;
  retiringGenerations.delete(generation);
  return child;
}

async function waitForGenerationChildClose(armChild: ChildProcess | null): Promise<void> {
  if (!armChild) return;
  const closed = armClose.get(armChild);
  if (!closed) return;
  await new Promise<void>((resolveWait) => {
    const timer = setTimeout(resolveWait, armRetireTimeoutMs);
    void closed.then(() => {
      clearTimeout(timer);
      resolveWait();
    });
  });
}

async function stopSessionGeneration(generation: SessionGeneration, replacement: boolean): Promise<void> {
  generation.replacement = replacement;
  retireGenerationOwner(generation, replacement);
  if (!replacement) {
    const child = stopGeneration(generation);
    await waitForGenerationChildClose(child);
    return;
  }

  // A same-process replacement has not proved its successor yet. Keep this
  // generation's established arm child alive while transferring delivery and
  // retry responsibility. The replacement's --restart arm retires it only
  // after the new generation has committed its own tracked child.
  relinquishGeneration(generation);
  const observed = generation.child ? armPendingActionable.get(generation.child) : undefined;
  if (observed && !generation.pendingActionables.some((item) => item.token === observed.token)) {
    generation.pendingActionables.push(observed);
  }
  if (generation.pendingActionables.length === 0) return;
  try {
    persistReplacementHandoff(generation.pendingActionables);
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    for (const pending of generation.pendingActionables) {
      if (replacementCoordinator.pending.some((item) => item.token === pending.token)) continue;
      replacementCoordinator.pending.push({
        ...pending,
        message: `${pending.message}\n\nwatcher: FAILED - Pi extension could not persist a replacement-session actionable wake\n${detail}`,
      });
    }
  }
}

const cleanupOnProcessExit = () => {
  for (const generation of retiringGenerations) stopGeneration(generation);
  if (activeGeneration) stopGeneration(activeGeneration);
};
process.once("exit", cleanupOnProcessExit);

export default function (pi: ExtensionAPI) {
  let generation = createGeneration();
  activateGeneration(generation);

  let calmPresentation: CalmPresentationState = {
    active: false,
    stockExportRendering: false,
  };
  pi.events?.on?.(FIRSTMATE_CALM_PRESENTATION_EVENT, (data) => {
    const next = data as Partial<CalmPresentationState>;
    calmPresentation = {
      active: next.active === true,
      stockExportRendering: next.stockExportRendering === true,
    };
  });
  const calmHides = (itemClass: Parameters<typeof calmTranscriptClassIsVisible>[0]): boolean =>
    calmPresentation.active &&
    !calmPresentation.stockExportRendering &&
    !calmTranscriptClassIsVisible(itemClass);

  async function sendWake(
    owner: SessionGeneration,
    message: string,
    pending?: PendingActionableClose,
  ): Promise<boolean> {
    if (!generationIsLive(owner)) return false;
    const content = encodeFirstmateOperationalInput(
      "watcher",
      `FIRSTMATE WATCHER WAKE: ${message}\n\nRun bin/fm-wake-drain.sh first and handle the queued wake. Watcher continuity is extension-owned.`,
    );
    if (pending) owner.unconsumedWakes.set(pending.token, { content, pending });
    try {
      await pi.sendUserMessage(content, { deliverAs: "followUp" });
    } catch (error) {
      if (pending) owner.unconsumedWakes.delete(pending.token);
      throw error;
    }
    // Accepted by Pi. A generation replaced while Pi was accepting it may
    // have lost the follow-up with the old session, so report it undelivered
    // and let the replacement replay the still-pending record.
    return generationIsLive(owner);
  }

  // Pi consumed a main follow-up: an idle main at before_agent_start, a
  // streaming main at the user message_start that joins the running run.
  function consumeWake(owner: SessionGeneration, text: string): void {
    for (const [token, wake] of owner.unconsumedWakes) {
      if (wake.content !== text) continue;
      owner.unconsumedWakes.delete(token);
      wake.pending.delivered = true;
      try {
        finishPendingActionable(owner, wake.pending);
      } catch (error) {
        surfaceCleanupFailure(owner, error);
        schedulePendingCleanup(owner);
      }
      return;
    }
  }

  function confirmHandlingDelivery(recovery: { generation: string; watcherPid: string }): {
    ok: boolean;
    detail: string;
    superseded?: boolean;
  } {
    try {
      const result = spawnSync(
        "bash",
        [armScript, "--handling-delivered", recovery.generation, "--watcher-pid", recovery.watcherPid],
        {
          cwd: fmRoot,
          encoding: "utf8",
          env: { ...process.env, FM_HOME: fmHome, FM_STATE_OVERRIDE: state, FM_ROOT_OVERRIDE: fmRoot },
        },
      );
      if (result.status === 0) return { ok: true, detail: "" };
      if (result.status === 3) {
        // The marker advanced past this restoration's generation mid-restore,
        // so a newer pipeline owns the episode now: superseded, not rejected.
        return { ok: false, detail: "", superseded: true };
      }
      const stderr = (result.stderr || "").trim();
      return {
        ok: false,
        detail: `watcher: FAILED - handling delivery confirmation was rejected (status=${result.status ?? "none"} generation=${recovery.generation} watcherPid=${recovery.watcherPid})${stderr ? `\n${stderr}` : ""}`,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        ok: false,
        detail: `watcher: FAILED - handling delivery confirmation could not be executed (generation=${recovery.generation} watcherPid=${recovery.watcherPid})\n${message}`,
      };
    }
  }

  function confirmHandlingDeliveryWithRetry(
    recovery: { generation: string; watcherPid: string },
  ): { ok: boolean; detail: string; superseded?: boolean } {
    // Confirm the restoration's own recovery token, never a fresh snapshot of
    // the current arm child: a successor replaced during the restore window
    // must not turn this delivery into a false rejection, and a retry must
    // not retire a newer healthy watcher.
    const first = confirmHandlingDelivery(recovery);
    if (first.ok || first.superseded) return first;
    return confirmHandlingDelivery(recovery);
  }

  function offerWakeToBranch(message: string): Promise<void> | null {
    // lib/fm-branch-dispatch.ts owns the offer rule for one close, shared with
    // the supervision host off Pi (bin/fm-branch-dispatch.mjs offer).
    const { scope, heartbeat, eligible, awayOnly } = branchOfferForWake(state, message, afkPostureRecordPresent(state));
    const offer = createBranchDispatchOffer(message, scope.projects, heartbeat, eligible, awayOnly);
    pi.events?.emit?.(FM_BRANCH_DISPATCH_EVENT, offer);
    return offer.accepted ? offer.settlement : null;
  }

  async function deliverActionableWake(
    owner: SessionGeneration,
    message: string,
    repairFailed: boolean,
    pending: PendingActionableClose,
    restoration?: ActionableRestoration,
  ): Promise<boolean> {
    if (!generationIsLive(owner)) return false;
    const recovery = restoration?.recovery;
    if (recovery) {
      // The confirmation ran inside the continuity operation, right after this
      // close's own successor became the live arm. A successor that replaced
      // it afterwards is a newer owner of the same episode, never a rejection
      // of this close, so the cached outcome decides and the stale token is
      // never re-confirmed here.
      const confirmed = restoration?.confirmation ?? confirmHandlingDeliveryWithRetry(recovery);
      appendExtensionLog(
        `confirm generation=${recovery.generation} watcherPid=${recovery.watcherPid} result=${confirmed.ok ? "confirmed" : confirmed.superseded ? "superseded" : "rejected"}`,
      );
      // A superseded result means a newer pipeline owns this episode now: it
      // routes like a confirmed delivery below, with no failure appended, and
      // retires nothing.
      if (!confirmed.ok && !confirmed.superseded) {
        await retireFailedRecovery(owner, recovery);
        return await sendWake(owner, `${message}\n\n${confirmed.detail}`, pending);
      }
    }
    if (!repairFailed) {
      const branchDelivery = offerWakeToBranch(message);
      if (branchDelivery) {
        try {
          await branchDelivery;
          return true;
        } catch {}
      }
    }
    return await sendWake(owner, message, pending);
  }

  function surfaceFailure(owner: SessionGeneration, message: string): void {
    void sendWake(owner, message).catch(() => {
      // Pi owns delivery errors; continuity restoration never waits on prompting.
    });
  }

  function enqueuePendingActionable(
    owner: SessionGeneration,
    pending: PendingActionableClose,
  ): void {
    if (owner.pendingActionables.some((item) => item.token === pending.token)) return;
    owner.pendingActionables.push(pending);
    if (owner.stopping && owner.replacement) {
      let replacementPending = pending;
      try {
        mergeReplacementHandoff(pending);
      } catch (error) {
        const detail = error instanceof Error ? error.message : String(error);
        replacementPending = {
          ...pending,
          message: `${pending.message}\n\nwatcher: FAILED - Pi extension could not persist a late replacement-session actionable wake\n${detail}`,
        };
      }
      if (replacementCoordinator.receiver) {
        replacementCoordinator.receiver(replacementPending);
      } else if (replacementPending !== pending) {
        replacementCoordinator.pending.push(replacementPending);
      }
    }
  }

  function finishPendingActionable(owner: SessionGeneration, pending: PendingActionableClose): void {
    clearReplacementHandoff(pending);
    const index = owner.pendingActionables.findIndex((item) => item.token === pending.token);
    if (index >= 0) owner.pendingActionables.splice(index, 1);
    owner.restorations.delete(pending.token);
    owner.cleanupFailure = "";
  }

  function surfaceCleanupFailure(
    owner: SessionGeneration,
    error: unknown,
  ): void {
    const detail = error instanceof Error ? error.message : String(error);
    if (owner.cleanupFailure === detail) return;
    owner.cleanupFailure = detail;
    surfaceFailure(owner, `watcher: FAILED - Pi extension could not clear a delivered replacement-session actionable wake\n${detail}`);
  }

  function schedulePendingCleanup(owner: SessionGeneration): void {
    if (!generationIsLive(owner) || owner.cleanupTimer) return;
    const timer = setTimeout(() => {
      if (owner.cleanupTimer === timer) owner.cleanupTimer = null;
      void processPendingActionables(owner);
    }, retryDelay(1));
    timer.unref();
    owner.cleanupTimer = timer;
  }

  function restorePendingActionables(owner: SessionGeneration): Promise<void> {
    if (!generationIsLive(owner)) return Promise.resolve();
    if (owner.restoring) return owner.restoring;
    // Publish this pump before it restores anything. The pump used to be
    // published after its first await, so a second pump could start in that
    // window and the two would restore the same owner at once.
    let openGate: () => void = () => {};
    const gate = new Promise<void>((resolveGate) => {
      openGate = resolveGate;
    });
    const restoring = (async () => {
      await gate;
      while (generationIsLive(owner)) {
        const pending = owner.pendingActionables.find((item) =>
          !item.delivered && !owner.unconsumedWakes.has(item.token) && !owner.restorations.has(item.token),
        );
        if (!pending) return;
        owner.deferredClose = null;
        const restoration = await restoreAfterActionableClose(owner, pending.predecessorArmPid);
        if (!generationIsLive(owner)) return;
        owner.restorations.set(pending.token, restoration);
        void processPendingActionables(owner);
      }
    })();
    owner.restoring = restoring;
    openGate();
    void restoring.catch((error) => {
      const detail = error instanceof Error ? error.message : String(error);
      surfaceFailure(owner, `watcher: FAILED - Pi extension could not restore an actionable wake\n${detail}`);
    }).finally(() => {
      if (owner.restoring === restoring) owner.restoring = null;
      if (!generationIsLive(owner)) return;
      const deferred = owner.deferredClose;
      if (deferred && deferred.guard === "restore") owner.deferredClose = null;
      if (deferred && deferred.guard === "restore" && !liveArmChild(owner) && !owner.retryTimer) {
        scheduleRetry(owner, deferred.message, deferred.predecessorArmPid);
      }
    });
    return restoring;
  }

  // Confirmation can name an arm superseded by a later close. Join the
  // continuity operation, then recheck its exact identity before retirement;
  // this never retires a newer child or holds continuity on branch settlement.
  async function retireFailedRecovery(
    owner: SessionGeneration,
    recovery: { generation: string; watcherPid: string },
  ): Promise<void> {
    await restorePendingActionables(owner);
    if (!generationIsLive(owner)) return;
    const current = owner.child;
    const currentRecovery = current ? armRecovery.get(current) : undefined;
    if (
      current &&
      currentRecovery?.watcherPid === recovery.watcherPid &&
      currentRecovery?.generation === recovery.generation &&
      !pidAlive(recovery.watcherPid)
    ) {
      appendExtensionLog(`retire pid=${recovery.watcherPid} reason=confirm-failure`);
      await retireArm(current);
    }
  }

  async function processPendingActionables(owner: SessionGeneration): Promise<void> {
    void restorePendingActionables(owner);
    if (!generationIsLive(owner) || owner.delivering || owner.pendingActionables.length === 0) return;
    owner.delivering = true;
    const attemptedCleanup = new Set<string>();
    try {
      while (generationIsLive(owner) && owner.pendingActionables.length > 0) {
        for (const delivered of owner.pendingActionables.filter((item) => item.delivered && !attemptedCleanup.has(item.token))) {
          attemptedCleanup.add(delivered.token);
          try {
            finishPendingActionable(owner, delivered);
          } catch (error) {
            surfaceCleanupFailure(owner, error);
          }
        }
        // A record Pi has accepted but not consumed is neither redelivered
        // nor finished here: consumption finishes it, replacement replays it.
        const pending = owner.pendingActionables.find(
          (item) => !item.delivered && !owner.unconsumedWakes.has(item.token),
        );
        if (!pending) break;
        const restoration = owner.restorations.get(pending.token);
        if (!restoration) break;
        const existingClaim = replacementCoordinator.deliveries.get(pending.token);
        if (existingClaim && existingClaim.owner !== owner) {
          const settlement = await existingClaim.settlement;
          if (!generationIsLive(owner)) return;
          if (settlement === "delivered") {
            pending.delivered = true;
            continue;
          }
          if (replacementCoordinator.deliveries.get(pending.token) === existingClaim) {
            replacementCoordinator.deliveries.delete(pending.token);
          }
        }
        let settleClaim: (settlement: "delivered" | "failed") => void = () => {};
        const settlement = new Promise<"delivered" | "failed">((resolveSettlement) => {
          settleClaim = resolveSettlement;
        });
        const deliveryClaim = { owner, settlement };
        replacementCoordinator.deliveries.set(pending.token, deliveryClaim);
        const releaseClaim = (): void => {
          if (replacementCoordinator.deliveries.get(pending.token) === deliveryClaim) {
            replacementCoordinator.deliveries.delete(pending.token);
          }
        };
        try {
          if (!generationIsLive(owner)) {
            settleClaim("failed");
            releaseClaim();
            return;
          }
          const message = restoration.failure ? `${pending.message}\n\n${restoration.failure}` : pending.message;
          const delivered = await deliverActionableWake(owner, message, Boolean(restoration.failure), pending, restoration);
          if (!delivered) {
            settleClaim("failed");
            releaseClaim();
            return;
          }
          const awaitingConsumption = owner.unconsumedWakes.has(pending.token);
          if (awaitingConsumption && !generationIsLive(owner)) {
            // Pi accepted the follow-up, then the session was replaced before
            // this continuation ran: the shutdown persisted the still-pending
            // record, so a replacement waiting on this claim must replay it.
            settleClaim("failed");
            releaseClaim();
            return;
          }
          settleClaim("delivered");
          if (!awaitingConsumption) {
            // The branch handled it, or Pi consumed it before this ran.
            pending.delivered = true;
            try {
              finishPendingActionable(owner, pending);
            } catch (error) {
              surfaceCleanupFailure(owner, error);
            }
          }
          releaseClaim();
        } catch (error) {
          settleClaim("failed");
          releaseClaim();
          throw error;
        }
      }
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      surfaceFailure(owner, `watcher: FAILED - Pi extension could not deliver an actionable wake\n${detail}`);
    } finally {
      if (generationIsLive(owner)) {
        owner.delivering = false;
        if (owner.pendingActionables.some((pending) => pending.delivered)) schedulePendingCleanup(owner);
        // A close that arrived while the continuity operation held the guard
        // keeps its bounded retry. The retry belongs to the operation that held
        // the guard when the close arrived, so this path acts only on a close
        // recorded under its own "delivery" guard and the restoration's
        // settlement acts on a "restore" one. The recorded close is consumed
        // here, so exactly one of the two paths schedules it.
        const deferred = owner.deferredClose;
        if (deferred && deferred.guard === "delivery") owner.deferredClose = null;
        if (deferred && deferred.guard === "delivery" && !liveArmChild(owner) && !owner.retryTimer) {
          scheduleRetry(owner, deferred.message, deferred.predecessorArmPid);
        }
      }
    }
  }

  const receiveReplacementActionable: ReplacementActionableReceiver = (pending) => {
    if (!generationIsLive(generation)) return;
    enqueuePendingActionable(generation, pending);
    void processPendingActionables(generation);
  };

  function retryDelay(attempt: number): number {
    return Math.min(retryMaxMs, retryBaseMs * 2 ** Math.max(0, attempt - 1));
  }

  function waitForRetry(attempt: number): Promise<void> {
    return new Promise((resolveRetry) => {
      const timer = setTimeout(resolveRetry, retryDelay(attempt));
      timer.unref();
    });
  }

  function waitForReadiness(armChild: ChildProcess): Promise<boolean> {
    const readiness = armReadiness.get(armChild);
    if (!readiness) return Promise.resolve(false);
    return new Promise((resolveReady) => {
      const timer = setTimeout(() => resolveReady(false), armReadyTimeoutMs);
      timer.unref();
      void readiness.then((ready) => {
        clearTimeout(timer);
        resolveReady(ready);
      });
    });
  }

  async function retireArm(armChild: ChildProcess | null): Promise<boolean> {
    if (!armChild) return true;
    armRetired.add(armChild);
    armChild.kill("SIGTERM");
    const closed = armClose.get(armChild);
    if (!closed) return false;
    return new Promise((resolveRetired) => {
      const timer = setTimeout(() => resolveRetired(false), armRetireTimeoutMs);
      timer.unref();
      void closed.then(() => {
        clearTimeout(timer);
        resolveRetired(true);
      });
    });
  }

  async function restoreAfterActionableClose(owner: SessionGeneration, predecessorArmPid: string): Promise<ActionableRestoration> {
    let failure = "";
    for (let attempt = 0; attempt <= retryLimit; attempt += 1) {
      if (!generationIsLive(owner)) return { failure: "" };
      const replacement = startArm(owner, predecessorArmPid);
      const successorChild = owner.child;
      appendExtensionLog(
        `restore attempt=${attempt} predecessor=${predecessorArmPid || "none"} start=${replacement.ok ? `ok pid=${successorChild?.pid ?? "none"}` : "failed"}`,
      );
      const ready = Boolean(replacement.ok && successorChild && await waitForReadiness(successorChild));
      if (ready && successorChild && liveArmChild(owner) === successorChild) {
        const recovery = armRecovery.get(successorChild);
        // Confirm the handling handoff here, inside the continuity operation,
        // while this close's own successor is still the live arm. A successor
        // that replaces it later owns the same episode, and a delivery-time
        // confirmation of the replaced token would read that healthy newer
        // watcher as a restoration failure.
        const confirmation = recovery ? confirmHandlingDeliveryWithRetry(recovery) : undefined;
        return { failure: "", recovery, confirmation };
      }
      if (replacement.ok) {
        if (ready) {
          appendExtensionLog(`restore attempt=${attempt} readiness=dead pid=${successorChild?.pid ?? "none"}`);
          failure = "watcher: FAILED - Pi extension could not verify a live successor watcher";
        } else {
          appendExtensionLog(`restore attempt=${attempt} readiness=timeout pid=${successorChild?.pid ?? "none"}`);
          failure = "watcher: FAILED - Pi extension could not verify a ready successor watcher";
          if (!(await retireArm(successorChild))) {
            return {
              failure: `${failure}\nwatcher: FAILED - Pi extension could not restore watcher continuity because the unready successor arm did not exit within ${armRetireTimeoutMs}ms`,
            };
          }
        }
      } else {
        failure = /(?:read-only|no live session)/.test(replacement.message)
          ? `watcher: FAILED - Pi extension cannot restore continuity because this session no longer owns the lock\n${replacement.message}`
          : `watcher: FAILED - Pi extension could not start the successor watcher cycle\n${replacement.message}`;
        if (/(?:read-only|no live session)/.test(replacement.message)) break;
      }
      if (attempt === retryLimit) break;
      await waitForRetry(attempt + 1);
    }
    appendExtensionLog(`restore exhausted attempts=${retryLimit + 1} outcome=hand-to-main`);
    return { failure: `${failure}\nwatcher: FAILED - Pi extension could not restore watcher continuity after ${retryLimit} retries` };
  }

  function scheduleRetry(owner: SessionGeneration, message: string, predecessorArmPid: string): void {
    if (!generationIsLive(owner) || liveArmChild(owner) || owner.retryTimer) return;
    const ownership = lockOwnership();
    if (ownership !== "owned") {
      surfaceFailure(owner, `watcher: FAILED - Pi extension cannot restore continuity because this session no longer owns the lock\n${message}`);
      return;
    }
    owner.retryFailures += 1;
    if (owner.retryFailures > retryLimit) {
      surfaceFailure(owner, `watcher: FAILED - Pi extension could not restore watcher continuity after ${retryLimit} retries\n${message}`);
      return;
    }
    const timer = setTimeout(() => {
      if (owner.retryTimer === timer) owner.retryTimer = null;
      if (!generationIsLive(owner)) return;
      const result = startArm(owner, predecessorArmPid);
      if (!result.ok) {
        surfaceFailure(owner, `watcher: FAILED - Pi extension could not launch a continuity retry\n${result.message}`);
      }
    }, retryDelay(owner.retryFailures));
    timer.unref();
    owner.retryTimer = timer;
  }

  function startArm(owner: SessionGeneration, predecessorArmPid = ""): ArmResult {
    if (!generationIsLive(owner)) return { ok: false, message: shuttingDownMessage };
    const ownership = lockOwnership();
    if (ownership === "other") return { ok: false, message: "watcher: read-only - session lock is held by another firstmate session" };
    if (ownership === "missing") {
      return {
        ok: false,
        message: "watcher: not armed - no live session holds the lock; run bin/fm-session-start.sh to reclaim it, then call fm_watch_arm_pi to re-arm",
      };
    }
    publishGenerationOwner(owner, "active");
    if (liveArmChild(owner)) {
      return {
        ok: true,
        message: `watcher: unchanged - Pi extension already owns an arm child; no manual re-arm needed; ${repairOnlyHint}`,
      };
    }
    if (owner.retryTimer) {
      return {
        ok: true,
        message: `watcher: unchanged - Pi extension already owns a scheduled continuity retry; no manual re-arm needed; ${repairOnlyHint}`,
      };
    }
    const id = ++owner.seq;
    const env = {
      ...process.env,
      FM_HOME: fmHome,
      FM_ROOT_OVERRIDE: fmRoot,
      FM_CONFIG_OVERRIDE: config,
      FM_WATCH_ARM_SCRIPT: armScript,
      FM_WATCH_PREDECESSOR_ARM_PID: predecessorArmPid,
    };
    const armChild = spawn("bash", ["-lc", "config_dir=\"${FM_CONFIG_OVERRIDE:-$FM_HOME/config}\"; [ -f \"$config_dir/x-mode.env\" ] && . \"$config_dir/x-mode.env\"; exec \"$FM_WATCH_ARM_SCRIPT\" --restart"], {
      cwd: fmRoot,
      env,
      stdio: ["ignore", "pipe", "pipe"],
    });
    owner.child = armChild;
    let stdout = "";
    let stderr = "";
    let settled = false;
    let readinessSettled = false;
    let verified = false;
    let resolveReadiness: (ready: boolean) => void = () => {};
    let resolveClosed: () => void = () => {};
    const readiness = new Promise<boolean>((resolveReady) => {
      resolveReadiness = resolveReady;
    });
    armReadiness.set(armChild, readiness);
    const closed = new Promise<void>((resolveClosedChild) => {
      resolveClosed = resolveClosedChild;
    });
    armClose.set(armChild, closed);
    const settleReadiness = (ready: boolean): void => {
      if (readinessSettled) return;
      readinessSettled = true;
      verified = ready;
      resolveReadiness(ready);
    };
    const observeEstablishedArm = (): void => {
      const combined = `${stdout}\n${stderr}`;
      const recovery = combined.match(/^watcher: started pid=([0-9]+).* recovery-generation=([A-Za-z0-9._-]+)$/m);
      if (recovery) armRecovery.set(armChild, { watcherPid: recovery[1], generation: recovery[2] });
      if (/^watcher: (?:started|attached)\b/m.test(combined)) {
        settleReadiness(true);
      }
      const reason = completedActionableLine(stdout) || completedActionableLine(stderr);
      if (reason && !armPendingActionable.has(armChild)) {
        const pending = createPendingActionable(reason, String(armChild.pid ?? ""));
        armPendingActionable.set(armChild, pending);
        // `exit` can precede the final stdout/stderr data events. If that exit
        // provisionally classified a partial buffer as a failure, replace its
        // scheduled retry with the actionable restoration path once the full
        // line arrives.
        if (settled) {
          enqueuePendingActionable(owner, pending);
          if (!generationIsLive(owner)) return;
          if (owner.retryTimer) {
            clearTimeout(owner.retryTimer);
            owner.retryTimer = null;
          }
          owner.retryFailures = 0;
          void processPendingActionables(owner);
        }
      }
    };
    const releaseChild = (): void => {
      if (owner.child === armChild) owner.child = null;
      if (!owner.child) retiringGenerations.delete(owner);
    };
    armChild.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
      observeEstablishedArm();
    });
    armChild.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
      observeEstablishedArm();
    });
    const finishArm = (code: number | null, signal: NodeJS.Signals | null): void => {
      if (settled) return;
      settled = true;
      resolveClosed();
      settleReadiness(false);
      releaseChild();
      const classification = classifyClose(stdout, stderr, code, signal);
      const predecessor = String(armChild.pid ?? "");
      if (classification.kind === "actionable") {
        const pending = armPendingActionable.get(armChild) ?? createPendingActionable(classification.message, predecessor);
        enqueuePendingActionable(owner, pending);
        if (!generationIsLive(owner)) return;
        owner.retryFailures = 0;
        void processPendingActionables(owner);
        return;
      }
      if (!generationIsLive(owner)) return;
      if (owner.restoring || owner.delivering) {
        // An operation holds the guard: a continuity restoration or a wake
        // delivery. A verified successor that closes under it keeps its
        // bounded retry for the end of that operation; an unready child's
        // close belongs to the restore that started it.
        if (verified && !armRetired.has(armChild)) {
          owner.deferredClose = {
            message: classification.message,
            predecessorArmPid: predecessor,
            guard: owner.restoring ? "restore" : "delivery",
          };
        }
        return;
      }
      scheduleRetry(owner, classification.message, predecessor);
    };
    armChild.on("close", finishArm);
    armChild.on("exit", (code: number | null, signal: NodeJS.Signals | null) => {
      setImmediate(() => finishArm(code, signal));
    });
    armChild.on("error", (error: Error) => {
      if (settled) return;
      settled = true;
      resolveClosed();
      settleReadiness(false);
      releaseChild();
      if (!generationIsLive(owner)) return;
      if (owner.restoring || owner.delivering) return;
      scheduleRetry(owner, `watcher: FAILED - Pi extension arm child ${id} failed: ${error.message}`, String(armChild.pid ?? ""));
    });
    return {
      ok: true,
      message: `watcher: started Pi extension arm child ${id}; future ordinary re-arms are automatic; ${repairOnlyHint}`,
    };
  }

  function activateOwnedWatch(owner: SessionGeneration): ArmResult {
    if (!generationIsLive(owner)) return { ok: false, message: shuttingDownMessage };
    if (lockOwnership() !== "owned") return startArm(owner);
    replacementCoordinator.receiver = receiveReplacementActionable;
    let pending: PendingActionableClose[] = [];
    let loadFailure = "";
    try {
      pending = loadReplacementHandoff();
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      loadFailure = `watcher: FAILED - Pi extension could not load a replacement-session actionable wake\n${detail}`;
    }
    const inProcessPending = replacementCoordinator.pending.splice(0);
    for (const actionable of [...pending, ...inProcessPending]) {
      enqueuePendingActionable(owner, actionable);
    }
    if (owner.pendingActionables.length > 0) {
      if (loadFailure) surfaceFailure(owner, loadFailure);
      const armResult = startArm(owner, owner.pendingActionables[0].predecessorArmPid);
      if (!armResult.ok) {
        surfaceFailure(owner, `watcher: FAILED - Pi extension could not arm before replacement wake delivery\n${armResult.message}`);
      }
      void processPendingActionables(owner);
      return armResult;
    }
    const result = startArm(owner);
    if (loadFailure) surfaceFailure(owner, `${loadFailure}\n${result.message}`);
    return result;
  }

  pi.on?.("before_agent_start", (event) => {
    // A custom message cannot consume a pending user wake, even with equal text.
    if (!("prompt" in event)) return;
    consumeWake(generation, event.prompt);
  });
  pi.on?.("message_start", (event) => {
    if (event.message.role !== "user") return;
    consumeWake(generation, userMessageText(event.message.content));
  });

  pi.on?.("session_start", async () => {
    if (generation.stopping) generation = createGeneration();
    activateGeneration(generation);
    if (lockOwnership() !== "owned") return;
    activateOwnedWatch(generation);
  });
  pi.on?.("session_shutdown", async (event) => {
    const replacement = event.reason === "reload" || event.reason === "new" || event.reason === "resume" || event.reason === "fork";
    if (replacementCoordinator.receiver === receiveReplacementActionable) replacementCoordinator.receiver = null;
    await stopSessionGeneration(generation, replacement);
  });

  pi.registerCommand?.("fm-watch-arm-pi", {
    description: "Arm firstmate watcher supervision through the Pi extension instead of foreground bash.",
    handler: async (_args, ctx) => {
      const result = activateOwnedWatch(generation);
      ctx.ui.notify(result.message, result.ok ? "info" : "warning");
    },
  });

  registerFirstmateTool(pi, {
    name: "fm_watch_arm_pi",
    label: "Arm firstmate watcher",
    description: "Start the first required Pi watcher cycle, or repair one only after a notification says the cycle is missing, failed, or unhealthy. Do not call after ordinary work or ordinary notifications; the Pi extension re-arms automatically. Never run bin/fm-watch-arm.sh through bash.",
    promptSnippet: "Start the first required Pi watcher cycle or repair a cycle reported missing, failed, or unhealthy; ordinary re-arming is automatic.",
    promptGuidelines: [
      "Call fm_watch_arm_pi only for the first required cycle or after a notification says the cycle is missing, failed, or unhealthy. Do not call it after ordinary work, turn completion, or ordinary signal, stale, check, or heartbeat handling because the Pi extension owns re-arming. Never run bin/fm-watch-arm.sh through bash.",
    ],
    parameters: Type.Object({}),
    renderShell: "self",
    renderCall: (_args, theme, context) => {
      if (calmHides("assistant-tool-call")) return new Container();
      if (calmPresentation.stockExportRendering) {
        return new Text(theme.fg("toolTitle", theme.bold("fm_watch_arm_pi")), 0, 0);
      }
      const state = context.state as WatchToolShellState;
      state.call = new Text(theme.fg("toolTitle", theme.bold("fm_watch_arm_pi")), 0, 0);
      return refreshWatchToolShell(state, theme, context);
    },
    renderResult: (result, _options, theme, context) => {
      if (calmHides("tool-result")) return new Container();
      const output = result.content
        .filter((item) => item.type === "text")
        .map((item) => item.text)
        .join("\n");
      if (calmPresentation.stockExportRendering) {
        return new Text(theme.fg("toolOutput", output), 0, 0);
      }
      const state = context.state as WatchToolShellState;
      state.result = output
        ? new Text(theme.fg("toolOutput", output), 0, 0)
        : new Container();
      refreshWatchToolShell(state, theme, context);
      return new Container();
    },
    execute: async () => {
      const result = activateOwnedWatch(generation);
      return {
        content: [{ type: "text", text: result.message }],
        details: result,
      };
    },
  });

  // Pi loads project extensions before the first model turn can run the locked
  // session-start command. Publish this generation while the lock is absent so
  // that command can distinguish a loaded extension from a missing one; a
  // foreign live lock still suppresses publication.
  publishGenerationOwner(generation, "active");
}
