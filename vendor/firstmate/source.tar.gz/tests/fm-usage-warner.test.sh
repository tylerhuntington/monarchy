#!/usr/bin/env bash
# Tests for bin/fm-usage-warner.sh, the opt-in local Claude usage threshold
# warner.
#
# This is a warner, not a viewer: every case here proves it stays silent
# except at a genuine new threshold crossing, and never touches a real
# account, a real Notification Center, or a real credential. quota-axi and
# osascript are both fixtures under the test's own fakebin, and no case ever
# passes --allow-keychain-prompt or any credential-refreshing flag - the
# script itself never does either, which test_check_never_requests_a_refresh
# verifies by capturing the exact quota-axi invocation.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

WARNER="$ROOT/bin/fm-usage-warner.sh"
TMP_ROOT=$(fm_test_tmproot fm-usage-warner)
BASE_PATH=${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}

# arm is macOS-only. Its threshold gate runs before any platform-specific file
# handling, so that refusal case uses a uname stub reporting Darwin and stays
# meaningful on a Linux CI runner. The cases that write the shim go through the
# BSD stat helpers the real macOS host provides, so they run only on Darwin.
DARWIN_BIN="$TMP_ROOT/darwin-bin"
mkdir -p "$DARWIN_BIN"
printf '#!/bin/sh\necho Darwin\n' > "$DARWIN_BIN/uname"
chmod +x "$DARWIN_BIN/uname"

make_home() {
  local name=$1 home
  home="$TMP_ROOT/$name"
  mkdir -p "$home/state" "$home/config"
  printf '%s\n' "$home"
}

# fake_quota_axi <dir> <window-json...>: a quota-axi stub returning one
# provider row (schema 5) whose windows are exactly the given
# '{"id":"...","percentUsed":N}' fragments, and logging its own argv so a case
# can assert the read never asked for a credential refresh.
fake_quota_axi() {
  local dir=$1
  shift
  local windows
  windows=$(IFS=,; printf '%s' "$*")
  mkdir -p "$dir"
  cat > "$dir/quota-axi" <<EOF
#!/usr/bin/env bash
printf '%s\n' "\$*" >> "\$QUOTA_AXI_ARGV_LOG"
cat <<'JSON'
{"generatedAt":"t","schemaVersion":5,"providers":[{"provider":"claude","label":"Claude","source":"oauth","plan":"team","account":{"accountId":"x","email":"a@b.c","organization":"o","identityStatus":"verified"},"windows":[$windows],"attempts":[],"state":{"status":"fresh","stale":false,"refreshedAt":"t","sourcesTried":[]},"quotaSemantics":{"status":"known","description":"d","effectiveAvailability":[{"scope":"all_models","status":"known","effectivePercentRemaining":0,"boundedBy":["five_hour"],"limitingWindowIds":["five_hour"],"runway":{"status":"through_reset"}}]}}]}
JSON
EOF
  chmod +x "$dir/quota-axi"
}

# fake_quota_axi_schema6 <dir> <default-percent> <other-percent>: a quota-axi
# stub returning a schema-6 snapshot in which the claude provider has two
# account rows. The "default" row's five_hour window sits at <default-percent>
# and a second account's at <other-percent>, so a case can prove the warner
# compares the default lane rather than whichever row happens to come first.
fake_quota_axi_schema6() {
  local dir=$1 default_pct=$2 other_pct=$3
  mkdir -p "$dir"
  row() {
    printf '{"provider":"claude","accountKey":"%s","label":"Claude","source":"oauth","plan":"team","account":{"accountId":"%s","email":"%s@b.c","organization":"o","identityStatus":"verified"},"windows":[{"id":"five_hour","percentUsed":%s}],"attempts":[],"state":{"status":"fresh","stale":false,"refreshedAt":"t","sourcesTried":[]},"quotaSemantics":{"status":"known","description":"d","effectiveAvailability":[{"scope":"all_models","status":"known","effectivePercentRemaining":0,"boundedBy":["five_hour"],"limitingWindowIds":["five_hour"],"runway":{"status":"through_reset"}}]}}' \
      "$1" "$1" "$1" "$2"
  }
  cat > "$dir/quota-axi" <<EOF
#!/usr/bin/env bash
printf '%s\n' "\$*" >> "\$QUOTA_AXI_ARGV_LOG"
cat <<'JSON'
{"generatedAt":"t","schemaVersion":6,"providers":[$(row other "$other_pct"),$(row default "$default_pct")]}
JSON
EOF
  unset -f row
  chmod +x "$dir/quota-axi"
}

fake_osascript_recorder() {
  local dir=$1 log=$2
  mkdir -p "$dir"
  cat > "$dir/osascript" <<EOF
#!/usr/bin/env bash
printf '%s\n' "\$*" >> "$log"
EOF
  chmod +x "$dir/osascript"
}

# run_check <home> <fakebin>: runs `check` with the fixture PATH first, real
# ambient PATH after (so real jq resolves), and stdin closed so nothing can
# ever block on an inherited terminal.
run_check() {
  local home=$1 fakebin=$2
  [ -e "$fakebin/osascript" ] || fake_osascript_recorder "$fakebin" /dev/null
  PATH="$fakebin:$PATH" FM_HOME="$home" QUOTA_AXI_ARGV_LOG="$fakebin/.argv-log" \
    "$WARNER" check </dev/null
}

test_help_and_usage() {
  local out rc=0
  out=$("$WARNER" --help 2>&1) || rc=$?
  expect_code 0 "$rc" "--help must exit 0"
  assert_contains "$out" "check" "--help lists the check action"
  assert_contains "$out" "arm" "--help lists the arm action"
  assert_contains "$out" "disarm" "--help lists the disarm action"
  rc=0
  out=$("$WARNER" bogus 2>&1) || rc=$?
  expect_code 2 "$rc" "unknown action must exit 2"
  assert_contains "$out" "unknown action" "unknown action is refused loudly"
  pass "fm-usage-warner: help and usage plumbing"
}

test_unconfigured_home_stays_silent() {
  local home fakebin out rc=0
  home=$(make_home unconfigured)
  fakebin="$TMP_ROOT/unconfigured/fakebin"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":99}'
  : > "$fakebin/.argv-log"
  out=$(run_check "$home" "$fakebin" 2>&1) || rc=$?
  expect_code 0 "$rc" "unconfigured check must still exit 0"
  [ -z "$out" ] || fail "an unconfigured home must stay completely silent: $out"
  assert_absent "$home/state/.usage-warner" "an unconfigured check must never write a de-dupe record"
  [ ! -s "$fakebin/.argv-log" ] || fail "an unconfigured home must never call quota-axi at all"
  pass "fm-usage-warner: an unconfigured home sees no behaviour change"
}

test_config_parses_comments_whitespace_and_model_ids() {
  local home fakebin out
  home=$(make_home config-parsing)
  fakebin="$TMP_ROOT/config-parsing/fakebin"
  printf '%s\n' \
    '# a comment line' \
    '   ' \
    '  five_hour:80  ' \
    'seven_day:90' \
    'model:fable:50' \
    'bad-no-colon' \
    'seven_day:not-a-number' \
    'seven_day:0' \
    'seven_day:101' \
    > "$home/config/usage-warner"
  # five_hour crosses (85>=80): proves a directive survives leading/trailing
  # whitespace. seven_day stays at 50, below its one valid threshold of 90;
  # if any of the three malformed seven_day directives above it had leaked
  # past validation - especially seven_day:0, which would match any
  # percentUsed - it would show up here too. model:fable crosses (60>=50):
  # proves the id/percent split lands on the LAST colon, not the first.
  fake_quota_axi "$fakebin" \
    '{"id":"five_hour","percentUsed":85}' \
    '{"id":"seven_day","percentUsed":50}' \
    '{"id":"model:fable","percentUsed":60}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 85%" "a directive survives surrounding whitespace"
  assert_contains "$out" "model:fable at 60%" "a colon-containing window id splits on the LAST colon"
  assert_not_contains "$out" "seven_day" "malformed duplicate directives (no colon, non-numeric, out-of-range) never leak a usable threshold"
  pass "fm-usage-warner: config parsing keeps only valid directives, including colon-containing ids"
}

test_check_crosses_notifies_stays_quiet_then_rearms() {
  local home fakebin notify_log out
  home=$(make_home lifecycle)
  fakebin="$TMP_ROOT/lifecycle/fakebin"
  notify_log="$TMP_ROOT/lifecycle/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'five_hour:80\n' > "$home/config/usage-warner"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":90}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 90% (>=80%)" "a fresh crossing is reported"
  assert_grep "Firstmate: Claude usage" "$notify_log" "a fresh crossing posts one osascript notification"

  : > "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":95}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "staying above threshold must stay quiet: $out"
  [ ! -s "$notify_log" ] || fail "staying above threshold must not notify again"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":50}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "dropping back below threshold must stay quiet (it only re-arms): $out"

  : > "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":85}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 85% (>=80%)" "crossing again after dropping below must notify again"
  assert_grep "Firstmate: Claude usage" "$notify_log" "the re-crossing posts a fresh notification"
  pass "fm-usage-warner: edge-triggered de-dupe crosses once, stays quiet, and re-arms on drop"
}

test_check_tiered_thresholds_on_one_window_each_warn() {
  local home fakebin notify_log out
  home=$(make_home tiered)
  fakebin="$TMP_ROOT/tiered/fakebin"
  notify_log="$TMP_ROOT/tiered/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'five_hour:80\nfive_hour:95\n' > "$home/config/usage-warner"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":85}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 85% (>=80%)" "the lower tier warns at its own crossing"
  assert_not_contains "$out" ">=95%" "the higher tier stays quiet below its threshold"

  : > "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":96}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 96% (>=95%)" "the higher tier warns on its own later crossing"
  assert_not_contains "$out" ">=80%" "the already-reported lower tier stays quiet"
  assert_grep "Firstmate: Claude usage" "$notify_log" "the higher-tier crossing posts a notification"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":97}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "staying above both tiers must stay quiet: $out"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":90}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "dropping below only the higher tier must stay quiet: $out"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":96}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 96% (>=95%)" "the higher tier re-arms after reading back below it"
  assert_not_contains "$out" ">=80%" "the lower tier never re-armed, so it stays quiet"
  pass "fm-usage-warner: tiered thresholds on one window each warn on their own crossing"
}

test_check_reads_a_v1_record_without_rewarning() {
  local home fakebin notify_log out
  home=$(make_home v1-record)
  fakebin="$TMP_ROOT/v1-record/fakebin"
  notify_log="$TMP_ROOT/v1-record/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'five_hour:80\nfive_hour:95\n' > "$home/config/usage-warner"
  printf '%s\n' fm-usage-warner-v1 'reported=usage-warner: five_hour at 85% (>=80%)' \
    notified-begin five_hour notified-end > "$home/state/.usage-warner"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":88}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "a window already reported under a v1 record must not warn again: $out"
  [ ! -s "$notify_log" ] || fail "a v1 record must not cause a second notification"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":96}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 96% (>=95%)" "after migrating a v1 record, a new higher-tier crossing still warns"
  assert_not_contains "$out" ">=80%" "the migrated lower tier stays quiet"
  pass "fm-usage-warner: a v1 de-dupe record is read without crashing or re-warning"
}

test_check_batches_multiple_crossings_into_one_notification() {
  local home fakebin notify_log out
  home=$(make_home batch)
  fakebin="$TMP_ROOT/batch/fakebin"
  notify_log="$TMP_ROOT/batch/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'five_hour:80\nseven_day:90\n' > "$home/config/usage-warner"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":92}' '{"id":"seven_day","percentUsed":97}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 92%" "the batched line names the first crossing"
  assert_contains "$out" "seven_day at 97%" "the batched line names the second crossing"
  local notify_count
  notify_count=$(grep -c . "$notify_log" || true)
  [ "$notify_count" -eq 1 ] || fail "two crossings in one read must post exactly one notification, got $notify_count"
  pass "fm-usage-warner: multiple crossings in one read batch into a single notification"
}

test_check_ignores_a_window_the_account_does_not_return() {
  local home fakebin out
  home=$(make_home missing-window)
  fakebin="$TMP_ROOT/missing-window/fakebin"
  printf 'model:sonnet:50\n' > "$home/config/usage-warner"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":99}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "a configured window id the account never returns must stay silent: $out"
  pass "fm-usage-warner: a configured but absent window id is silently skipped"
}

test_check_absent_window_keeps_its_crossing_recorded() {
  local home fakebin notify_log out
  home=$(make_home absent-window)
  fakebin="$TMP_ROOT/absent-window/fakebin"
  notify_log="$TMP_ROOT/absent-window/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'model:opus:80\n' > "$home/config/usage-warner"

  fake_quota_axi "$fakebin" '{"id":"model:opus","percentUsed":85}'
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "model:opus at 85% (>=80%)" "the first crossing is reported"

  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":10}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "a read that omits the window must stay quiet: $out"

  : > "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"model:opus","percentUsed":86}'
  out=$(run_check "$home" "$fakebin")
  [ -z "$out" ] || fail "a window absent from one read is not a below-threshold reading, so it must not re-warn: $out"
  [ ! -s "$notify_log" ] || fail "an absent window must not cause a second notification"
  pass "fm-usage-warner: a window missing from one read keeps its crossing recorded"
}

test_check_never_requests_a_refresh() {
  local home fakebin out argv
  home=$(make_home no-refresh)
  fakebin="$TMP_ROOT/no-refresh/fakebin"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":10}'
  : > "$fakebin/.argv-log"
  run_check "$home" "$fakebin" >/dev/null
  argv=$(cat "$fakebin/.argv-log")
  assert_contains "$argv" "--no-credential-refresh" "every read passes --no-credential-refresh"
  assert_not_contains "$argv" "--allow-keychain-prompt" "the warner must never request a keychain prompt"
  pass "fm-usage-warner: the read is always strictly read-only"
}

test_schema6_snapshot_reads_the_default_account_lane() {
  local home fakebin out
  home=$(make_home schema6)
  fakebin="$TMP_ROOT/schema6/fakebin"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  # The default lane is over the threshold; the other account row is not, and
  # it is listed first, so reading either the wrong row or simply the first one
  # would stay silent here.
  fake_quota_axi_schema6 "$fakebin" 90 10
  : > "$fakebin/.argv-log"
  out=$(run_check "$home" "$fakebin")
  assert_contains "$out" "five_hour at 90%" \
    "a schema-6 snapshot must be read through the default account row"
  pass "fm-usage-warner: a schema-6 snapshot resolves the default account lane"
}

test_quota_axi_missing_is_reported_once() {
  local home fakebin out1 out2
  home=$(make_home no-quota-axi)
  fakebin=$(fm_test_base_path_sans "$BASE_PATH" quota-axi)
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  out1=$(FM_HOME="$home" PATH="$fakebin" "$WARNER" check </dev/null 2>&1)
  assert_contains "$out1" "quota-axi is not installed" "a missing quota-axi is reported by name"
  out2=$(FM_HOME="$home" PATH="$fakebin" "$WARNER" check </dev/null 2>&1)
  [ -z "$out2" ] || fail "a repeated identical failure must stay silent: $out2"
  pass "fm-usage-warner: a missing quota-axi is reported once until it changes"
}

test_jq_missing_is_reported() {
  local home fakebin out
  home=$(make_home no-jq)
  fakebin=$(fm_test_base_path_sans "$BASE_PATH" jq)
  local qfake="$TMP_ROOT/no-jq/qbin"
  fake_quota_axi "$qfake" '{"id":"five_hour","percentUsed":10}'
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  out=$(FM_HOME="$home" PATH="$qfake:$fakebin" "$WARNER" check </dev/null 2>&1)
  assert_contains "$out" "jq is not installed" "a missing jq is reported by name"
  pass "fm-usage-warner: a missing jq is reported by name"
}

test_malformed_quota_axi_output_is_reported() {
  local home fakebin out
  home=$(make_home malformed)
  fakebin="$TMP_ROOT/malformed/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/quota-axi" <<'EOF'
#!/usr/bin/env bash
printf '%s\n' 'not json at all'
EOF
  chmod +x "$fakebin/quota-axi"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  out=$(run_check "$home" "$fakebin" 2>&1)
  assert_contains "$out" "unexpected response shape" "an unparsable quota-axi response is reported, not silently swallowed"
  pass "fm-usage-warner: a malformed quota-axi response is reported"
}

test_slow_quota_axi_is_reported_as_a_timeout() {
  local home fakebin out
  home=$(make_home slow)
  fakebin="$TMP_ROOT/slow/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/quota-axi" <<'EOF'
#!/usr/bin/env bash
sleep 60
EOF
  chmod +x "$fakebin/quota-axi"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  out=$(run_check "$home" "$fakebin" 2>&1)
  assert_contains "$out" "did not finish within the 10s budget" "a hung read is bounded and reported, not left to hang the watcher"
  pass "fm-usage-warner: a slow read is bounded and reported as a timeout"
}

test_read_bound_fits_a_lowered_check_timeout() {
  local home fakebin out start elapsed
  home=$(make_home low-check-timeout)
  fakebin="$TMP_ROOT/low-check-timeout/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/quota-axi" <<'EOF'
#!/usr/bin/env bash
sleep 60
EOF
  chmod +x "$fakebin/quota-axi"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  start=$(date +%s)
  out=$(FM_CHECK_TIMEOUT=6 PATH="$fakebin:$PATH" FM_HOME="$home" "$WARNER" check </dev/null 2>&1)
  elapsed=$(( $(date +%s) - start ))
  [ "$elapsed" -lt 6 ] || fail "the read must end inside a lowered watcher bound, took ${elapsed}s"
  assert_contains "$out" "did not finish within the 3s budget" "the read bound is cut to fit FM_CHECK_TIMEOUT"
  pass "fm-usage-warner: the read bound is cut to fit a lowered FM_CHECK_TIMEOUT"
}

test_no_room_for_a_read_is_recorded_as_not_measured() {
  local home fakebin out rc=0 start elapsed
  home=$(make_home no-room)
  fakebin="$TMP_ROOT/no-room/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/quota-axi" <<'EOF'
#!/usr/bin/env bash
sleep 60
EOF
  chmod +x "$fakebin/quota-axi"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  start=$(date +%s)
  out=$(FM_CHECK_TIMEOUT=2 PATH="$fakebin:$PATH" FM_HOME="$home" "$WARNER" check </dev/null 2>&1) || rc=$?
  elapsed=$(( $(date +%s) - start ))
  expect_code 0 "$rc" "a watcher bound too small for a read must not fail the check"
  [ "$elapsed" -lt 2 ] || fail "a skipped read must return inside the watcher bound, took ${elapsed}s"
  assert_contains "$out" "not measured" "a skipped read is reported as not measured"
  assert_contains "$(cat "$home/state/.usage-warner")" "not measured" "the de-dupe record keeps the not-measured report"
  pass "fm-usage-warner: a watcher bound with no room for a read is recorded as not measured"
}

test_unconfigured_invocation_ignores_unused_environment() {
  local home out rc=0
  home=$(make_home unused-env)
  out=$(FM_USAGE_WARNER_TIMEOUT_SECS=0 FM_CHECK_TIMEOUT=bogus FM_HOME="$home" "$WARNER" check </dev/null 2>&1) || rc=$?
  expect_code 0 "$rc" "an unconfigured check must not fail on environment it does not use"
  [ -z "$out" ] || fail "an unconfigured check must stay silent whatever the environment: $out"
  rc=0
  out=$(FM_USAGE_WARNER_TIMEOUT_SECS=0 FM_CHECK_TIMEOUT=bogus "$WARNER" --help 2>&1) || rc=$?
  expect_code 0 "$rc" "--help must not fail on environment it does not use"
  pass "fm-usage-warner: an unconfigured invocation never fails on unused environment"
}

test_arm_refuses_without_a_configured_threshold() {
  local home out rc=0
  home=$(make_home arm-unconfigured)
  out=$(PATH="$DARWIN_BIN:$PATH" FM_HOME="$home" "$WARNER" arm 2>&1) || rc=$?
  expect_code 1 "$rc" "arm without a threshold must fail"
  assert_contains "$out" "no threshold configured" "arm names the reason it refused"
  assert_absent "$home/state/usage-warner.check.sh" "a refused arm must not leave a shim behind"
  pass "fm-usage-warner: arm refuses without a configured threshold, mirroring the opt-in gate"
}

test_arm_refuses_on_a_non_macos_platform() {
  local home fakebin out rc=0
  home=$(make_home arm-linux)
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  fakebin=$(fm_test_base_path_sans "$BASE_PATH" uname)
  mkdir -p "$TMP_ROOT/arm-linux/unamebin"
  printf '#!/bin/sh\necho Linux\n' > "$TMP_ROOT/arm-linux/unamebin/uname"
  chmod +x "$TMP_ROOT/arm-linux/unamebin/uname"
  out=$(FM_HOME="$home" PATH="$TMP_ROOT/arm-linux/unamebin:$fakebin" "$WARNER" arm 2>&1) || rc=$?
  expect_code 1 "$rc" "arm on a non-macOS platform must fail"
  assert_contains "$out" "only available on macOS" "arm names why it refused on a non-macOS platform"
  pass "fm-usage-warner: arm refuses on a platform with no Notification Center path"
}

test_arm_writes_and_binds_the_check_and_disarm_removes_it() {
  local home out
  home=$(make_home arm-ok)
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  out=$(FM_HOME="$home" "$WARNER" arm 2>&1) || fail "arm must succeed: $out"
  assert_contains "$out" "armed: state/usage-warner.check.sh" "arm names the shim it wrote"
  assert_present "$home/state/usage-warner.check.sh" "arm writes the check shim"
  assert_present "$home/state/usage-warner.check-trust" "arm registers a trust binding"
  [ "$(stat -c %a "$home/state/usage-warner.check.sh" 2>/dev/null || stat -f %Lp "$home/state/usage-warner.check.sh")" = 700 ] \
    || fail "the shim must be mode 700"

  out=$(FM_HOME="$home" "$WARNER" disarm 2>&1)
  assert_contains "$out" "disarmed: state/usage-warner.check.sh" "disarm names the shim it removed"
  assert_absent "$home/state/usage-warner.check.sh" "disarm removes the shim"
  assert_absent "$home/state/usage-warner.check-trust" "disarm removes the trust binding"
  assert_absent "$home/state/.usage-warner" "disarm removes the de-dupe record"
  pass "fm-usage-warner: arm writes a bound shim the watcher can run, disarm removes it cleanly"
}

test_arm_refuses_a_symlink_at_the_shim_path() {
  local home target out rc=0
  home=$(make_home arm-symlink)
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  target="$TMP_ROOT/arm-symlink/elsewhere"
  mkdir -p "$(dirname "$target")"
  printf '#!/usr/bin/env bash\n' > "$target"
  ln -s "$target" "$home/state/usage-warner.check.sh"
  out=$(FM_HOME="$home" "$WARNER" arm 2>&1) || rc=$?
  expect_code 1 "$rc" "arm must refuse a symlink at the shim path"
  assert_contains "$out" "could not write" "arm reports the shim write failure"
  assert_absent "$home/state/usage-warner.check-trust" "no trust binding is left behind by a refused arm"
  [ -f "$target" ] || fail "arm must never write through the symlink to its target"
  pass "fm-usage-warner: arm refuses a symlink at the shim path instead of following it"
}

test_armed_shim_runs_a_real_check() {
  local home fakebin notify_log out
  home=$(make_home arm-integration)
  fakebin="$TMP_ROOT/arm-integration/fakebin"
  notify_log="$TMP_ROOT/arm-integration/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":92}'
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  FM_HOME="$home" "$WARNER" arm >/dev/null 2>&1 || fail "arm must succeed"
  out=$(PATH="$fakebin:$PATH" "$home/state/usage-warner.check.sh" </dev/null)
  assert_contains "$out" "five_hour at 92%" "the armed shim, run the way the watcher runs it, performs a real check"
  pass "fm-usage-warner: the armed shim is exactly what the watcher would dispatch"
}

test_check_repeated_directive_reports_once() {
  local home fakebin notify_log out
  home=$(make_home repeated-directive)
  fakebin="$TMP_ROOT/repeated-directive/fakebin"
  notify_log="$TMP_ROOT/repeated-directive/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  printf 'five_hour:80\nfive_hour:80\n' > "$home/config/usage-warner"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":85}'
  out=$(run_check "$home" "$fakebin")
  [ "$out" = "usage-warner: five_hour at 85% (>=80%)" ] \
    || fail "a repeated directive must report its one crossing once: $out"
  [ "$(grep -c "five_hour at 85%" "$notify_log")" = 1 ] \
    || fail "a repeated directive must post one notification naming the crossing once"
  pass "fm-usage-warner: a repeated directive reports its crossing once"
}

# Two callers overlap: the first check is held inside a slow read when the
# second starts. Only one of them may warn for the single crossing.
test_overlapping_checks_warn_once() {
  local home fakebin notify_log first_out second_out pid _
  home=$(make_home overlap)
  fakebin="$TMP_ROOT/overlap/fakebin"
  notify_log="$TMP_ROOT/overlap/notify.log"
  : > "$notify_log"
  fake_osascript_recorder "$fakebin" "$notify_log"
  fake_quota_axi "$fakebin" '{"id":"five_hour","percentUsed":90}'
  mv "$fakebin/quota-axi" "$fakebin/quota-axi.real"
  cat > "$fakebin/quota-axi" <<EOF
#!/usr/bin/env bash
: > "$fakebin/.started"
sleep 2
exec "$fakebin/quota-axi.real" "\$@"
EOF
  chmod +x "$fakebin/quota-axi"
  printf 'five_hour:80\n' > "$home/config/usage-warner"
  run_check "$home" "$fakebin" > "$TMP_ROOT/overlap/first.out" &
  pid=$!
  for _ in $(seq 1 50); do
    [ -e "$fakebin/.started" ] && break
    sleep 0.1
  done
  [ -e "$fakebin/.started" ] || fail "the first check never reached its read"
  second_out=$(run_check "$home" "$fakebin")
  wait "$pid"
  first_out=$(cat "$TMP_ROOT/overlap/first.out")
  [ -z "$second_out" ] || fail "a check overlapping a running one must stay quiet: $second_out"
  assert_contains "$first_out" "five_hour at 90% (>=80%)" "the running check still reports the crossing"
  [ "$(grep -c "Firstmate: Claude usage" "$notify_log")" = 1 ] \
    || fail "overlapping checks must post exactly one notification for one crossing"
  pass "fm-usage-warner: overlapping checks warn once for one crossing"
}

test_help_and_usage
test_unconfigured_home_stays_silent
test_config_parses_comments_whitespace_and_model_ids
test_check_crosses_notifies_stays_quiet_then_rearms
test_check_tiered_thresholds_on_one_window_each_warn
test_check_reads_a_v1_record_without_rewarning
test_check_batches_multiple_crossings_into_one_notification
test_check_repeated_directive_reports_once
test_overlapping_checks_warn_once
test_check_ignores_a_window_the_account_does_not_return
test_check_absent_window_keeps_its_crossing_recorded
test_check_never_requests_a_refresh
test_schema6_snapshot_reads_the_default_account_lane
test_quota_axi_missing_is_reported_once
test_jq_missing_is_reported
test_malformed_quota_axi_output_is_reported
test_slow_quota_axi_is_reported_as_a_timeout
test_read_bound_fits_a_lowered_check_timeout
test_no_room_for_a_read_is_recorded_as_not_measured
test_unconfigured_invocation_ignores_unused_environment
test_arm_refuses_without_a_configured_threshold
test_arm_refuses_on_a_non_macos_platform
if [ "$(uname)" = Darwin ]; then
  test_arm_writes_and_binds_the_check_and_disarm_removes_it
  test_arm_refuses_a_symlink_at_the_shim_path
  test_armed_shim_runs_a_real_check
else
  printf 'ok - fm-usage-warner: shim-writing arm cases are macOS-only; skipping on %s\n' "$(uname)"
fi
