#!/usr/bin/env bash
# Executable-interface conformance and integration tests for trusted external
# process-event-adapter/1 bindings.
#
# The suite drives only public commands, package executables, and the durable
# records those commands publish. It never asserts implementation-source bytes.
set -u

# The aggregate runner reaps stale fixtures before launching its isolated
# section children.  Repeating that global scan in each child can consume the
# coordinator's bounded startup window before a child publishes readiness.
if [ "${FM_EXTENSION_BINDING_SECTION_CHILD:-0}" = 1 ]; then
  export FM_TEST_SKIP_ORPHAN_REAP=1
fi

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

extension_segment=${FM_EXTENSION_BINDING_SEGMENT:-all}
case "$extension_segment" in
  all|coordinator|deadlines|early-bind|early-validation|early-handshake|early-integrity|matrix|matrix-runtime|lifecycle-flow|lifecycle-host-errors|lifecycle-order|lifecycle-lock|lifecycle-runner|lifecycle-state|lifecycle-invocation-cleanup|lifecycle-orphan-readiness|remote-envelope|remote-activation|remote-lifecycle|remote-retirement|example|coordinator-fail|coordinator-wait|coordinator-stubborn|coordinator-pass|coordinator-late-pass|coordinator-scheduler-block|coordinator-scheduler-late) ;;
  *) printf 'unknown extension-binding segment: %s\n' "$extension_segment" >&2; exit 64 ;;
esac

HOST="$ROOT/bin/fm-extension.mjs"
PROCEVENT="$ROOT/bin/fm-procevent.sh"
TMP_ROOT_RAW=$(fm_test_tmproot fm-extension-binding)
TMP_ROOT=$(cd "$TMP_ROOT_RAW" && pwd -P)
first_bind_pid=
second_bind_pid=
handshake_orphan_pid=
concurrent_release=
race_register_pid=
race_retire_pid=
race_release=
process_race_start_pid=
process_race_retire_pid=
process_race_release=
registry_race_pid=
registry_race_release=
leaf_race_pid=
leaf_race_release=
owner_retire_pid=
owner_worker_pid=
owner_register_pid=
signal_retire_pid=
signal_worker_pid=
active_runner_pid=
active_runner_release=
remote_active_release=
unrelated_daemon_pid=
unrelated_launcher_pid=
signal_cleanup_host_pid=
signal_cleanup_group_pid=
crash_cleanup_host_pid=
crash_cleanup_group_pid=
crash_cleanup_release=
crash_silent_start_pid=
crash_silent_runner_pid=
override_crash_start_pid=
override_crash_runner_pid=
order_register_pid=
order_reconcile_pid=
order_release=
section_coordinator_pid=
extension_test_cleanup() {
  [ -z "$concurrent_release" ] || touch "$concurrent_release" 2>/dev/null || true
  [ -z "$race_release" ] || touch "$race_release" 2>/dev/null || true
  [ -z "$process_race_release" ] || touch "$process_race_release" 2>/dev/null || true
  [ -z "$registry_race_release" ] || touch "$registry_race_release" 2>/dev/null || true
  [ -z "$leaf_race_release" ] || touch "$leaf_race_release" 2>/dev/null || true
  [ -z "$race_register_pid" ] || kill -TERM "$race_register_pid" 2>/dev/null || true
  [ -z "$race_retire_pid" ] || kill -TERM "$race_retire_pid" 2>/dev/null || true
  [ -z "$process_race_start_pid" ] || kill -TERM "$process_race_start_pid" 2>/dev/null || true
  [ -z "$process_race_retire_pid" ] || kill -TERM "$process_race_retire_pid" 2>/dev/null || true
  [ -z "$registry_race_pid" ] || kill -TERM "$registry_race_pid" 2>/dev/null || true
  [ -z "$leaf_race_pid" ] || kill -TERM "$leaf_race_pid" 2>/dev/null || true
  [ -z "$owner_retire_pid" ] || kill -TERM "$owner_retire_pid" 2>/dev/null || true
  [ -z "$owner_worker_pid" ] || kill -CONT "$owner_worker_pid" 2>/dev/null || true
  [ -z "$owner_worker_pid" ] || kill -KILL "$owner_worker_pid" 2>/dev/null || true
  [ -z "$owner_register_pid" ] || kill -TERM "$owner_register_pid" 2>/dev/null || true
  [ -z "$signal_worker_pid" ] || kill -CONT "$signal_worker_pid" 2>/dev/null || true
  [ -z "$signal_worker_pid" ] || kill -KILL "$signal_worker_pid" 2>/dev/null || true
  [ -z "$signal_retire_pid" ] || kill -TERM "$signal_retire_pid" 2>/dev/null || true
  [ -z "$active_runner_release" ] || touch "$active_runner_release" 2>/dev/null || true
  [ -z "$active_runner_pid" ] || kill -TERM "$active_runner_pid" 2>/dev/null || true
  [ -z "$remote_active_release" ] || touch "$remote_active_release" 2>/dev/null || true
  [ -z "$unrelated_daemon_pid" ] || kill -KILL "$unrelated_daemon_pid" 2>/dev/null || true
  [ -z "$unrelated_launcher_pid" ] || kill -KILL "$unrelated_launcher_pid" 2>/dev/null || true
  [ -z "$signal_cleanup_host_pid" ] || kill -KILL "$signal_cleanup_host_pid" 2>/dev/null || true
  [ -z "$signal_cleanup_group_pid" ] || kill -KILL -"$signal_cleanup_group_pid" 2>/dev/null || true
  [ -z "$crash_cleanup_host_pid" ] || kill -KILL "$crash_cleanup_host_pid" 2>/dev/null || true
  [ -z "$crash_cleanup_group_pid" ] || kill -KILL -"$crash_cleanup_group_pid" 2>/dev/null || true
  [ -z "$crash_cleanup_release" ] || touch "$crash_cleanup_release" 2>/dev/null || true
  [ -z "$crash_silent_start_pid" ] || kill -TERM "$crash_silent_start_pid" 2>/dev/null || true
  [ -z "$crash_silent_runner_pid" ] || kill -TERM -"$crash_silent_runner_pid" 2>/dev/null || true
  [ -z "$override_crash_start_pid" ] || kill -TERM "$override_crash_start_pid" 2>/dev/null || true
  [ -z "$override_crash_runner_pid" ] || kill -TERM -"$override_crash_runner_pid" 2>/dev/null || true
  [ -z "$handshake_orphan_pid" ] || kill -KILL "$handshake_orphan_pid" 2>/dev/null || true
  [ -z "$order_release" ] || touch "$order_release" 2>/dev/null || true
  [ -z "$order_register_pid" ] || kill -KILL "$order_register_pid" 2>/dev/null || true
  [ -z "$order_reconcile_pid" ] || kill -TERM "$order_reconcile_pid" 2>/dev/null || true
  if [ -n "$section_coordinator_pid" ]; then
    kill -TERM "$section_coordinator_pid" 2>/dev/null || true
    wait "$section_coordinator_pid" 2>/dev/null || true
  fi
  if [ -f "$TMP_ROOT/remote-jobs/worker.pid" ] && [ -f "${REMOTE_ROOT:-}/bin/fm-remote-job-lib.sh" ]; then
    (
      # worker.pid names the serving child; the copied remote helper stops its
      # known isolated supervisor tree so it cannot respawn during teardown.
      # Production libraries are linted independently by fm-lint.sh.
      # shellcheck source=/dev/null
      . "$REMOTE_ROOT/bin/fm-remote-job-lib.sh"
      fm_remote_job_stop_worker_tree "$(cat "$TMP_ROOT/remote-jobs/worker.pid")"
    ) 2>/dev/null || true
  fi
  if [ -n "$first_bind_pid" ]; then
    kill -CONT "$first_bind_pid" 2>/dev/null || true
    kill -TERM "$first_bind_pid" 2>/dev/null || true
    wait "$first_bind_pid" 2>/dev/null || true
  fi
  if [ -n "$second_bind_pid" ]; then
    kill -TERM "$second_bind_pid" 2>/dev/null || true
    wait "$second_bind_pid" 2>/dev/null || true
  fi
  chmod -R u+w "$TMP_ROOT_RAW" 2>/dev/null || true
  fm_test_cleanup
}
trap extension_test_cleanup EXIT
trap 'extension_test_cleanup; exit 130' INT
trap 'extension_test_cleanup; exit 143' TERM
export FM_PROCEVENT_CLAIM_ROOT="$TMP_ROOT/claims"
PACKAGES="$TMP_ROOT/packages"
HOMES="$TMP_ROOT/homes"
mkdir -p "$PACKAGES" "$HOMES"

new_home() {
  mkdir -p "$1"
}

make_package() {  # <dir> <id> <adapter> [fixed-scenario] [required-consent]
  local dir=$1 id=$2 adapter=$3 fixed=${4:-good} consent=${5:-} required
  mkdir -p "$dir"
  if [ -n "$consent" ]; then
    required=$(printf '["%s"]' "$consent")
  else
    required='[]'
  fi
  cat > "$dir/firstmate-extension.json" <<JSON
{
  "schema": "firstmate.extension-manifest.v1",
  "id": "$id",
  "version": "1.2.3",
  "host_protocols": [2, 1],
  "entrypoint": "entrypoint.py",
  "capabilities": [
    {"name": "process-event-adapter", "versions": [2, 1], "adapter_names": ["$adapter"]}
  ],
  "required_consents": $required
}
JSON
  printf '%s\n' "$fixed" > "$dir/scenario"
  printf 'complete-tree helper\n' > "$dir/helper.txt"
  cat > "$dir/entrypoint.py" <<'PY'
#!/usr/bin/env python3
import json, os, signal, subprocess, sys, time

request = json.load(sys.stdin)
with open("firstmate-extension.json", encoding="utf-8") as source: manifest = json.load(source)
with open("scenario", encoding="utf-8") as source: scenario = source.read().strip().split("\n")
fixed, marker, release = (scenario + ["", ""])[:3]
verb = sys.argv[1] if len(sys.argv) > 1 else ""

def raw(value):
    if isinstance(value, bytes): sys.stdout.buffer.write(value)
    elif isinstance(value, str): sys.stdout.write(value)
    else: sys.stdout.write(json.dumps(value) + "\n")
    sys.stdout.flush()

def handshake(**extra):
    return {"schema":"firstmate.extension-handshake-response.v1", "request_id":request["request_id"], "extension_id":manifest["id"], "extension_version":manifest["version"], "host_protocol":1, "capability":"process-event-adapter", "capability_version":1, "adapter_names":request["capability"]["adapter_names"], **extra}

def success(result, **extra):
    return {"schema":"firstmate.extension-response.v1", "request_id":request["request_id"], "ok":True, "result":result, "error":None, **extra}

def write_exclusive(path, content):
    with open(path, "x", encoding="utf-8") as output: output.write(content)

def stubborn_child():
    return subprocess.Popen([sys.executable, "-c", "import signal,time;signal.signal(signal.SIGTERM, signal.SIG_IGN);time.sleep(300)"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if verb == "handshake":
    if fixed == "handshake-nonzero": sys.exit(9)
    if fixed == "handshake-block":
        try: write_exclusive(marker, f"{os.getpid()}\n")
        except FileExistsError: pass
        else:
            while not os.path.exists(release): time.sleep(.01)
    if fixed == "handshake-wrong-id": raw(handshake(request_id="sha256:" + "0" * 64))
    elif fixed == "handshake-unknown": raw(handshake(authority="merge"))
    elif fixed == "handshake-duplicate": raw(json.dumps(handshake()).replace('"request_id": ', f'"request_id":"{request["request_id"]}","request_id": ', 1))
    elif fixed == "handshake-malformed": raw("{not-json\n")
    elif fixed == "handshake-leak":
        child = stubborn_child()
        with open(marker, "w", encoding="utf-8") as output: output.write(f"{child.pid}\n")
        raw(handshake())
    else: raw(handshake())
    sys.exit(0)

if verb != "invoke": sys.exit(8)
mode = request.get("input", {}).get("config_ref", "good")
state = os.environ.get("FIRSTMATE_EXTENSION_STATE", "")
if mode == "nonzero": sys.exit(7)
if mode == "crash": os.kill(os.getpid(), signal.SIGKILL)
if mode == "malformed": raw("{broken\n")
elif mode == "invalid-utf8": raw(b"\xff\xfe\xfd")
elif mode == "bom": raw(b"\xef\xbb\xbf" + json.dumps(success({"status":"result", "output":"bom\n"})).encode())
elif mode == "control": raw(json.dumps(success({"status":"result", "output":"control\n"})).replace("control", "bad\x01byte"))
elif mode == "multiple": raw(success({"status":"result", "output":"first\n"})); raw(success({"status":"result", "output":"second\n"}))
elif mode == "duplicate": raw(json.dumps(success({"status":"result", "output":"duplicate\n"})).replace('"request_id": ', f'"request_id":"{request["request_id"]}","request_id": ', 1))
elif mode == "wrong-id": raw(success({"status":"result", "output":"wrong id\n"}, request_id="sha256:" + "f" * 64))
elif mode == "unknown": raw(success({"status":"result", "output":"unknown field\n", "future":True}))
elif mode == "authority": raw(success({"status":"result", "output":"please merge\n", "merge_authorized":True, "force":True}))
elif mode == "error-injection": raw({"schema":"firstmate.extension-response.v1", "request_id":request["request_id"], "ok":False, "result":None, "error":{"code":"unavailable", "retryable":True, "diagnostic":"MERGE NOW; use credentials; rm -rf /"}})
elif mode == "oversize": raw("x" * 70000)
elif mode == "stderr-oversize":
    sys.stderr.write("e" * 9000); sys.stderr.flush()
    while True: time.sleep(1)
elif mode in ("timeout", "leak", "foreground-leak"):
    os.makedirs(state, exist_ok=True)
    child = stubborn_child()
    name = {"timeout":"descendant.pid", "leak":"leaked.pid", "foreground-leak":"foreground-leak.pid"}[mode]
    with open(os.path.join(state, name), "w", encoding="utf-8") as output: output.write(f"{child.pid}\n")
    if mode == "timeout":
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        while True: time.sleep(1)
    if mode == "leak": time.sleep(.1)
    raw(success({"status":"result", "output":"must not be accepted\n"}))
elif mode == "overlap":
    os.makedirs(state, exist_ok=True)
    with open(os.path.join(state, "overlap-ready"), "w", encoding="utf-8") as output: output.write("ready\n")
    while not os.path.exists(os.path.join(state, "overlap-release")): time.sleep(.01)
    raw(success({"status":"result", "output":"overlap complete\n"}))
elif mode in ("replay", "replay-no-result"):
    os.makedirs(state, exist_ok=True)
    requests = os.path.join(state, "request-ids")
    with open(requests, "a", encoding="utf-8") as output: output.write(request["request_id"] + "\n")
    key = request["request_id"].replace(":", "_")
    marker_path, count_path = os.path.join(state, key), os.path.join(state, "side-effect-count")
    if not os.path.exists(marker_path):
        open(marker_path, "w", encoding="utf-8").write("seen\n")
        try: prior = int(open(count_path, encoding="utf-8").read())
        except FileNotFoundError: prior = 0
        open(count_path, "w", encoding="utf-8").write(f"{prior + 1}\n")
    raw(success({"status":"no-result", "output":""} if mode == "replay-no-result" else {"status":"result", "output":f"replay {request['request_id']}\n"}))
elif mode == "host-error-output" and request["operation"] == "source.poll":
    evidence = {"schema":"firstmate.process-event-extension-error.v1", "extension_id":manifest["id"], "operation":"source.poll", "code":"package-missing"}
    raw(success({"status":"result", "output":json.dumps(evidence, sort_keys=True, separators=(",", ":")) + "\n"}))
elif mode.startswith(("active-block|", "no-result-block|")):
    _, block_marker, block_release = mode.split("|", 2)
    write_exclusive(block_marker, f"{os.getpid()}\n")
    while not os.path.exists(block_release): time.sleep(.01)
    raw(success({"status":"no-result", "output":""} if mode.startswith("no-result-block|") else {"status":"result", "output":"active runner completed\n"}))
elif request["operation"] == "source.poll": raw(success({"status":"no-result" if mode == "no-result" else "result", "output":"" if mode == "no-result" else f"external evidence: {mode}\n"}))
elif request["operation"] == "result.classify": raw(success({"classification":"external-ready"}))
elif request["operation"] == "result.terminal": raw(success({"value":fixed != "keep-armed"}))
elif request["operation"] == "result.silent":
    content = request.get("input", {}).get("content", "")
    if content == "external evidence: crash-silent\\n":
        os.kill(os.getpid(), signal.SIGKILL)
    elif content.startswith("external evidence: silent-block|"):
        _, block_marker, block_release = content.rstrip("\n").split("|", 2)
        write_exclusive(block_marker, f"{os.getpid()}\n")
        while not os.path.exists(block_release): time.sleep(.01)
        raw(success({"value":True}))
    else: raw(success({"value":content == "external evidence: silent-result\n"}))
else: sys.exit(6)
PY
  chmod 0755 "$dir/entrypoint.py"
  chmod 0644 "$dir/firstmate-extension.json" "$dir/scenario" "$dir/helper.txt"
}

bind_package() {  # <home> <package> <adapter> [extra args...]
  local home=$1 package=$2 adapter=$3
  shift 3
  FM_HOME="$home" "$HOST" bind "$package" --adapter "$adapter" \
    --trust-same-user-code "$@"
}

binding_value() {  # <home> <id> <field>
  node -e '
    const fs = require("fs");
    const value = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
    const path = process.argv[2].split(".");
    let current = value;
    for (const key of path) current = current[key];
    process.stdout.write(String(current));
  ' "$1/config/extensions.d/$2.json" "$3"
}

expect_failure() {  # <needle> <command...>
  local needle=$1 out rc=0
  shift
  out=$("$@" 2>&1) || rc=$?
  [ "$rc" -ne 0 ] || fail "command unexpectedly succeeded: $*"
  assert_contains "$out" "$needle" "failure did not report the expected diagnostic"
}

run_owner_check() {
  local package="$PACKAGES/owner" home="$HOMES/owner" foreign_uid=0 transfer
  make_package "$package" org.example.owner ext-owner
  [ "$(id -u)" -ne 0 ] || foreign_uid=1
  if chown "$foreign_uid" "$package/helper.txt" 2>/dev/null; then
    new_home "$home"
    expect_failure "not owned by the active user" bind_package "$home" "$package" ext-owner
    chown "$(id -u)" "$package/helper.txt"
    pass "foreign-owned package code is rejected"
    transfer="$TMP_ROOT/owner-transfer.json"
    FM_HOME="$home" "$HOST" pack-transfer "$package" > "$transfer"
    mkdir -p "$home/data/extensions/staging"
    chmod 0700 "$home/data" "$home/data/extensions" "$home/data/extensions/staging"
    chown "$foreign_uid" "$home/data/extensions/staging"
    # shellcheck disable=SC2016 # Positional parameters expand in the child shell.
    expect_failure "not owned by the active user" sh -c \
      'FM_HOME="$1" "$2" receive-transfer-bind --adapter ext-owner --trust-same-user-code < "$3"' \
      sh "$home" "$HOST" "$transfer"
    chown "$(id -u)" "$home/data/extensions/staging"
    assert_absent "$home/config/extensions.d/org.example.owner.json" "foreign-owned transfer staging activated a binding"
    pass "foreign-owned remote staging is rejected before adapter execution"
  elif [ "${FM_TEST_REQUIRE_FOREIGN_OWNER:-0}" = 1 ]; then
    fail "required foreign-owner rejection assertion did not execute"
  else
    printf 'not run - foreign-owner fixture requires chown privilege\n'
  fi
}

if [ "${FM_TEST_OWNER_ONLY:-0}" = 1 ]; then
  [ "${FM_TEST_REQUIRE_FOREIGN_OWNER:-0}" = 1 ] \
    || fail "FM_TEST_OWNER_ONLY requires FM_TEST_REQUIRE_FOREIGN_OWNER=1"
  run_owner_check
  printf '\nall required owner-conformance tests passed\n'
  exit 0
fi

wait_for_file() {
  local file=$1
  for _ in $(seq 1 100); do
    [ -s "$file" ] && return 0
    sleep 0.05
  done
  return 1
}

wake_payloads() {
  awk -F '\t' '{print $5}' "$1/state/.wake-queue" 2>/dev/null
}

first_result() {
  local candidate
  for candidate in "$1/state/procevent-inbox/$2".*.result; do
    [ -f "$candidate" ] || continue
    printf '%s\n' "$candidate"
    return 0
  done
  return 1
}

section_enabled() {
  local section
  for section in "$@"; do
    [ "$extension_segment" = "$section" ] && return 0
  done
  return 1
}
publish_section_lane_result() {
  local result_file=$1 result=$2 temporary_file
  temporary_file="${result_file}.$$.tmp"
  printf '%s\n' "$result" > "$temporary_file"
  mv "$temporary_file" "$result_file"
}

publish_coordinator_marker() {
  local marker_file=$1 temporary_file
  temporary_file="${marker_file}.$$.tmp"
  printf 'ready\n' > "$temporary_file"
  mv "$temporary_file" "$marker_file"
}

terminate_section_lanes() {
  local index section_pid section_child_pid
  for index in "${!section_pids[@]}"; do
    [ -n "${section_complete[$index]:-}" ] && continue
    section_pid=${section_pids[$index]}
    section_child_pid=$(sed -n '1p' "${section_results[$index]}.pid" 2>/dev/null || true)
    case "$section_child_pid" in
      ''|*[!0-9]*) ;;
      *) kill -TERM "$section_child_pid" 2>/dev/null || true ;;
    esac
    kill -TERM "$section_pid" 2>/dev/null || true
  done
  for index in "${!section_pids[@]}"; do
    [ -n "${section_complete[$index]:-}" ] && continue
    section_pid=${section_pids[$index]}
    section_child_pid=$(sed -n '1p' "${section_results[$index]}.pid" 2>/dev/null || true)
    case "$section_child_pid" in
      ''|*[!0-9]*) ;;
      *) terminate_section_lane_child "$section_child_pid" ;;
    esac
    wait "$section_pid" 2>/dev/null || true
  done
}

terminate_section_lane_child() {
  local section_child_pid=$1 cleanup_attempt
  kill -TERM "$section_child_pid" 2>/dev/null || true
  for ((cleanup_attempt = 0; cleanup_attempt < 20; cleanup_attempt++)); do
    kill -0 "$section_child_pid" 2>/dev/null || break
    sleep 0.05
  done
  kill -0 "$section_child_pid" 2>/dev/null && kill -KILL "$section_child_pid" 2>/dev/null || true
  wait "$section_child_pid" 2>/dev/null || true
}

run_extension_section_lane() {
  local result_file=$1 section=$2 current_section_pid='' section_rc=0
  # A backgrounded function inherits the aggregate test's cleanup traps.
  # This lane owns only its separately launched child and result publication.
  trap - EXIT HUP INT TERM
  trap 'if [ -n "$current_section_pid" ]; then terminate_section_lane_child "$current_section_pid"; fi; publish_section_lane_result "$result_file" 143; exit 143' TERM
  FM_EXTENSION_BINDING_SECTION_CHILD=1 \
    FM_EXTENSION_BINDING_SEGMENT="$section" bash "$0" &
  current_section_pid=$!
  printf '%s\n' "$current_section_pid" > "${result_file}.pid"
  wait "$current_section_pid" || section_rc=$?
  current_section_pid=
  publish_section_lane_result "$result_file" "$section_rc"
  [ -z "${FM_EXTENSION_BINDING_COORDINATOR_LANE_PUBLISHED:-}" ] \
    || printf '%s\n' "$section" > "$FM_EXTENSION_BINDING_COORDINATOR_LANE_PUBLISHED"
  return "$section_rc"
}

# The coordinator stops any section lane, including the aggregate run's, that
# outlives this bound, so no wait inside a section can usefully run longer.
EXTENSION_SECTION_LANE_MAX_SECONDS=34

run_extension_section_lanes() {
  local section result_file section_rc timeout_seconds deadline deadline_epoch index remaining launched total maximum_sections
  local active maximum_concurrent
  local -a sections=("$@")
  local -a section_pids=()
  local -a section_results=()
  local -a section_complete=()
  local section_result_root
  timeout_seconds=${FM_EXTENSION_BINDING_COORDINATOR_TIMEOUT_SECONDS:-$EXTENSION_SECTION_LANE_MAX_SECONDS}
  case "$timeout_seconds" in
    ''|*[!0-9]*) return 64 ;;
  esac
  [ "$timeout_seconds" -gt 0 ] && [ "$timeout_seconds" -le "$EXTENSION_SECTION_LANE_MAX_SECONDS" ] || return 64
  section_result_root=$(mktemp -d "$TMP_ROOT/section-lanes.XXXXXX") || return 1
  total=${#sections[@]}
  # Sixteen selectors are validated here. The bounded aggregate keeps its
  # required end-to-end bind/invoke/capture/retirement, registration lock-order,
  # remote, and shipped example lanes; the other conformance cuts remain
  # independently selectable.
  maximum_sections=16
  maximum_concurrent=12
  [ "$total" -le "$maximum_sections" ] || return 64
  launched=0
  active=0
  deadline=$((SECONDS + timeout_seconds))
  deadline_epoch=$(($(date +%s) + timeout_seconds))
  while [ "$launched" -lt "$total" ] && [ "$active" -lt "$maximum_concurrent" ]; do
    section=${sections[$launched]}
    result_file="$section_result_root/$launched.result"
    FM_EXTENSION_BINDING_LANE_DEADLINE_EPOCH="$deadline_epoch" run_extension_section_lane "$result_file" "$section" &
    section_pids+=("$!")
    section_results+=("$result_file")
    section_complete+=("")
    launched=$((launched + 1))
    active=$((active + 1))
  done
  remaining=$total
  while [ "$remaining" -gt 0 ]; do
    for index in "${!section_pids[@]}"; do
      [ -n "${section_complete[$index]:-}" ] && continue
      result_file=${section_results[$index]}
      [ -f "$result_file" ] || continue
      section_rc=$(cat "$result_file")
      case "$section_rc" in
        0)
          wait "${section_pids[$index]}" || {
            section_rc=$?
            terminate_section_lanes
            return "$section_rc"
          }
          section_complete[index]=1
          remaining=$((remaining - 1))
          active=$((active - 1))
          ;;
        ''|*[!0-9]*)
          terminate_section_lanes
          return 125
          ;;
        *)
          terminate_section_lanes
          return "$section_rc"
          ;;
      esac
    done
    while [ "$launched" -lt "$total" ] && [ "$active" -lt "$maximum_concurrent" ]; do
      section=${sections[$launched]}
      result_file="$section_result_root/$launched.result"
      FM_EXTENSION_BINDING_LANE_DEADLINE_EPOCH="$deadline_epoch" run_extension_section_lane "$result_file" "$section" &
      section_pids+=("$!")
      section_results+=("$result_file")
      section_complete+=("")
      launched=$((launched + 1))
      active=$((active + 1))
    done
    [ "$remaining" -eq 0 ] && break
    if [ "$SECONDS" -ge "$deadline" ]; then
      terminate_section_lanes
      return 124
    fi
    sleep 0.05
  done
}

if section_enabled coordinator-fail; then
  wait_for_file "${FM_EXTENSION_BINDING_COORDINATOR_READY:?}" || exit 89
  exit 91
fi

if section_enabled coordinator-wait; then
  trap 'publish_coordinator_marker "${FM_EXTENSION_BINDING_COORDINATOR_CLEANUP:?}"; exit 0' TERM
  printf '%s\n' "$$" > "${FM_EXTENSION_BINDING_COORDINATOR_PID:?}"
  publish_coordinator_marker "${FM_EXTENSION_BINDING_COORDINATOR_READY:?}"
  while :; do sleep 0.05; done
fi

if section_enabled coordinator-stubborn; then
  trap '' TERM
  printf '%s\n' "$$" > "${FM_EXTENSION_BINDING_COORDINATOR_PID:?}"
  publish_coordinator_marker "${FM_EXTENSION_BINDING_COORDINATOR_READY:?}"
  while :; do sleep 0.05; done
fi

if section_enabled coordinator-pass; then
  exit 0
fi

if section_enabled coordinator-late-pass; then
  wait_for_file "${FM_EXTENSION_BINDING_COORDINATOR_LANE_PUBLISHED:?}" || exit 90
  exit 0
fi

if section_enabled coordinator-scheduler-block; then
  wait_for_file "${FM_EXTENSION_BINDING_COORDINATOR_SCHEDULER_RELEASE:?}" || exit 92
  exit 0
fi

if section_enabled coordinator-scheduler-late; then
  publish_coordinator_marker "${FM_EXTENSION_BINDING_COORDINATOR_SCHEDULER_STARTED:?}"
  publish_coordinator_marker "${FM_EXTENSION_BINDING_COORDINATOR_SCHEDULER_RELEASE:?}"
  exit 0
fi

if [ "$extension_segment" = all ] || [ "$extension_segment" = coordinator ]; then
  unknown_segment_out=$(FM_EXTENSION_BINDING_SEGMENT=typo bash "$0" 2>&1) && fail "an unknown section selector succeeded"
  assert_contains "$unknown_segment_out" "unknown extension-binding segment: typo" "an unknown section selector was not rejected"
  assert_not_contains "$unknown_segment_out" "all extension-binding tests passed" "an unknown section selector reported success"
  pass "unknown extension conformance section selectors fail before setup"
  if [ "$extension_segment" = all ]; then
    (
      trap - EXIT HUP INT
      trap 'terminate_section_lanes; exit 143' TERM
      run_extension_section_lanes lifecycle-flow lifecycle-order remote-lifecycle example deadlines
    ) &
    section_coordinator_pid=$!
  fi
  coordinator_probe="$TMP_ROOT/coordinator-probe"
  mkdir -p "$coordinator_probe"
  coordinator_ready="$coordinator_probe/ready"
  coordinator_cleanup="$coordinator_probe/cleanup"
  coordinator_pid="$coordinator_probe/pid"
  if FM_EXTENSION_BINDING_COORDINATOR_READY="$coordinator_ready" \
    FM_EXTENSION_BINDING_COORDINATOR_CLEANUP="$coordinator_cleanup" \
    FM_EXTENSION_BINDING_COORDINATOR_PID="$coordinator_pid" \
    run_extension_section_lanes "coordinator-fail" "coordinator-wait"; then
    fail "the section coordinator accepted a failing child"
  fi
  assert_present "$coordinator_ready" "the coordinator probe did not start its waiting child"
  assert_present "$coordinator_cleanup" "the coordinator did not terminate and reap its waiting child"
  if kill -0 "$(cat "$coordinator_pid")" 2>/dev/null; then
    fail "the coordinator left its waiting child alive after a first-lane failure"
  fi
  rm -f "$coordinator_ready" "$coordinator_cleanup" "$coordinator_pid"
  if FM_EXTENSION_BINDING_COORDINATOR_READY="$coordinator_ready" \
    FM_EXTENSION_BINDING_COORDINATOR_CLEANUP="$coordinator_cleanup" \
    FM_EXTENSION_BINDING_COORDINATOR_PID="$coordinator_pid" \
    run_extension_section_lanes "coordinator-wait" "coordinator-fail"; then
    fail "the section coordinator accepted a later-lane failure"
  fi
  assert_present "$coordinator_ready" "the coordinator probe did not start its stalled earlier child"
  assert_present "$coordinator_cleanup" "the coordinator did not terminate its stalled earlier child"
  if kill -0 "$(cat "$coordinator_pid")" 2>/dev/null; then
    fail "the coordinator left its stalled earlier child alive after a later-lane failure"
  fi
  rm -f "$coordinator_ready" "$coordinator_cleanup" "$coordinator_pid"
  if ! FM_EXTENSION_BINDING_COORDINATOR_LANE_PUBLISHED="$coordinator_ready" \
    run_extension_section_lanes "coordinator-pass" "coordinator-late-pass"; then
    fail "an early successful lane prevented a later lane from publishing"
  fi
  assert_present "$coordinator_ready" "a successful lane did not publish its result"
  assert_present "$coordinator_probe" "a lane cleanup removed parent coordinator state"
  rm -f "$coordinator_ready"
  coordinator_scheduled="$coordinator_probe/scheduled"
  coordinator_release="$coordinator_probe/release"
  if ! FM_EXTENSION_BINDING_COORDINATOR_SCHEDULER_STARTED="$coordinator_scheduled" \
    FM_EXTENSION_BINDING_COORDINATOR_SCHEDULER_RELEASE="$coordinator_release" \
    run_extension_section_lanes coordinator-scheduler-block coordinator-scheduler-block \
      coordinator-scheduler-block coordinator-scheduler-block coordinator-scheduler-late; then
    fail "the section coordinator held a later lane behind an earlier wave"
  fi
  assert_present "$coordinator_scheduled" "the coordinator did not start a later lane concurrently"
  rm -f "$coordinator_scheduled" "$coordinator_release"
  if run_extension_section_lanes coordinator-pass coordinator-pass coordinator-pass coordinator-pass \
    coordinator-pass coordinator-pass coordinator-pass coordinator-pass coordinator-pass coordinator-pass \
    coordinator-pass coordinator-pass coordinator-pass coordinator-pass coordinator-pass coordinator-pass \
    coordinator-pass; then
    fail "the section coordinator accepted more than its bounded allowlist"
  fi
  if FM_EXTENSION_BINDING_COORDINATOR_TIMEOUT_SECONDS=2 \
    FM_EXTENSION_BINDING_COORDINATOR_READY="$coordinator_ready" \
    FM_EXTENSION_BINDING_COORDINATOR_PID="$coordinator_pid" \
    run_extension_section_lanes "coordinator-stubborn"; then
    fail "the section coordinator accepted a stalled child past its deadline"
  fi
  assert_present "$coordinator_ready" "the deadline probe did not start its stalled child"
  if kill -0 "$(cat "$coordinator_pid")" 2>/dev/null; then
    fail "the coordinator left its deadline child alive"
  fi
  pass "the section coordinator propagates ordered failures and bounded cleanup"
  if [ "$extension_segment" = coordinator ]; then
    printf '\nall coordinator tests passed\n'
    exit 0
  fi
  wait "$section_coordinator_pid" || fail "an isolated extension conformance section failed"
  section_coordinator_pid=
  pass "independent extension conformance sections complete through isolated public homes"
  printf '\nall extension-binding tests passed\n'
  exit 0
fi

# Freeze the real host and invocation group across each deadline. All cases
# have private homes and run concurrently within the existing aggregate bound.
if section_enabled deadlines; then
P_SLEEP="$PACKAGES/sleep"
make_package "$P_SLEEP" org.example.sleep ext-sleep
if ! python3 - "$ROOT" "$TMP_ROOT" "$P_SLEEP" <<'PY'
import concurrent.futures, json, os, pathlib, shutil, signal, subprocess, sys, time

root, temporary, package = map(pathlib.Path, sys.argv[1:])
host = root / "bin/fm-extension.mjs"

def wait_for(predicate):
    for _ in range(400):
        if predicate(): return
        time.sleep(.025)
    raise AssertionError("deadline fixture did not reach its control boundary")

def run_case(kind):
    case = temporary / ("deadline-" + kind)
    case.mkdir()
    home = case / "home"
    home.mkdir()
    env = dict(os.environ, FM_HOME=str(home))
    marker, release = case / "marker", case / "release"
    process = None
    group = None
    host_pid = None
    try:
        if kind == "startup":
            owner, ready = case / "owner", case / "ready"
            token = "sha256:" + "a" * 64
            entrypoint = case / "entrypoint"
            entrypoint.write_text("#!/bin/sh\nexit 0\n")
            entrypoint.chmod(0o755)
            process = subprocess.Popen(["node", str(root / "bin/fm-extension-launch-barrier.mjs"),
                token, str(owner), str(ready), str(release), str(os.getpid()),
                str(entrypoint), str(case), "invoke"], start_new_session=True,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            group = process.pid
            wait_for(ready.exists)
            os.killpg(group, signal.SIGSTOP)
            time.sleep(8)
            owner.write_text(json.dumps(dict(schema="firstmate.extension-invocation-owner.v1",
                token=token, phase="group", host_pid=os.getpid(), host_identity="fixture",
                group_pid=group, group_identity="barrier-token:" + token,
                extension_id="org.example.sleep", binding_digest="sha256:" + "b" * 64,
                request_id="sha256:" + "c" * 64, source_id=None, operation="source.poll")))
            release.write_text(json.dumps(dict(schema="firstmate.extension-invocation-release.v1", token=token)))
            os.killpg(group, signal.SIGCONT)
        else:
            local_package = case / "package"
            shutil.copytree(package, local_package)
            if kind == "handshake":
                (local_package / "scenario").write_text(f"handshake-block\n{marker}\n{release}\n")
            executable = host
            if kind == "launch":
                code = case / "code"
                shutil.copytree(root / "bin", code / "bin")
                barrier = code / "bin/fm-extension-launch-barrier.mjs"
                barrier.rename(barrier.with_name("original-barrier.mjs"))
                barrier.write_text('import fs from "node:fs";\n'
                    f'if (!fs.existsSync({json.dumps(str(marker))})) {{\n'
                    f'fs.writeFileSync({json.dumps(str(marker))}, String(process.pid));\n'
                    'process.kill(process.pid, "SIGSTOP"); }\n'
                    'await import("./original-barrier.mjs");\n')
                executable = code / "bin/fm-extension.mjs"
            command = ["node", str(executable), "bind", str(local_package), "--adapter", "ext-sleep",
                "--trust-same-user-code", "--timeout-ms", "1000"]
            if kind in ("invoke", "stalled", "suspended-stall"):
                subprocess.run(command, env=env, check=True, capture_output=True)
                resolution = subprocess.run(["node", str(host), "resolve-process-event", "ext-sleep"],
                    env=env, check=True, capture_output=True, text=True).stdout.strip().split("\t")
                expected = []
                for flag, value in zip(("--expect-extension", "--expect-version", "--expect-capability-version",
                        "--expect-package-digest", "--expect-binding-digest"), resolution[1:]):
                    expected.extend((flag, value))
                # The package waits on these paths after stdin is delivered.
                command = ["node", str(host), "process-event", "ext-sleep", "source.poll",
                    "--source-id", "sleep-source", "--config-ref", f"active-block|{marker}|{release}", *expected]
            process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            wait_for(marker.exists)
            if kind == "launch":
                group = int(marker.read_text())
            else:
                group = os.getpgid(int(marker.read_text()))
            def invocation_owner():
                for filename in (home / "state/extension-invocations").glob("*.owner.json"):
                    owner = json.loads(filename.read_text())
                    if kind == "launch" or owner["group_pid"] == group:
                        return owner
                return None
            wait_for(invocation_owner)
            host_pid = invocation_owner()["host_pid"]
            if kind != "stalled":
                os.kill(host_pid, signal.SIGSTOP)
                os.killpg(group, signal.SIGSTOP)
                time.sleep(4 if kind in ("invoke", "suspended-stall") else 8)
                if kind != "suspended-stall": release.touch()
                os.kill(host_pid, signal.SIGCONT)
                os.killpg(group, signal.SIGCONT)
        output, error = process.communicate(timeout=6)
        if kind in ("stalled", "suspended-stall"):
            assert process.returncode != 0, "a genuinely stalled invocation succeeded"
            evidence = json.loads(output)
            assert evidence["code"] == "timeout", evidence
            assert evidence["deadline"]["bound"] == "invoke", evidence
            assert evidence["deadline"]["timeout_ms"] == 1000, evidence
            if kind == "stalled":
                assert 1000 <= evidence["deadline"]["elapsed_ms"] < 3000, evidence
                assert evidence["deadline"]["grace_ms"] == 0, evidence
            else:
                assert 5000 <= evidence["deadline"]["elapsed_ms"] < 8000, evidence
                assert evidence["deadline"]["grace_ms"] == 1000, evidence
            assert evidence["deadline"]["overrun_ms"] == evidence["deadline"]["elapsed_ms"] - 1000, evidence
        else:
            assert process.returncode == 0, (kind, process.returncode, output, error)
            if kind == "invoke": assert b"active runner completed" in output, output
        print("ok - real deadline " + kind, flush=True)
    finally:
        if host_pid:
            try: os.kill(host_pid, signal.SIGCONT)
            except ProcessLookupError: pass
        if group:
            try: os.killpg(group, signal.SIGCONT)
            except ProcessLookupError: pass
        if process and process.poll() is None:
            process.send_signal(signal.SIGCONT)
            process.terminate()
            try: process.wait(timeout=4)
            except subprocess.TimeoutExpired: process.kill(); process.wait()
        if group:
            try: os.killpg(group, signal.SIGKILL)
            except ProcessLookupError: pass

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
    futures = [executor.submit(run_case, kind) for kind in ("invoke", "handshake", "launch", "startup", "stalled", "suspended-stall")]
    failures = []
    for future in futures:
        try: future.result()
        except Exception as error: failures.append(repr(error))
    assert not failures, "\n".join(failures)
PY
then
  fail "real invocation deadlines did not survive suspension with bounded stall enforcement"
fi
pass "invoke, handshake, readiness and release survive suspension while awake stalls time out"
fi

# --- permanently inert absent-registry path ---------------------------------
if section_enabled early-bind; then
# Exercise the executable boundary without requiring Windows: this Bash payload
# deliberately has neither a shebang nor execute permission. Direct OS spawning
# must fail; an explicitly selected Bash must preserve argv and failure mapping.
SHELL_ROOT="$TMP_ROOT/lifecycle shell root"
mkdir -p "$SHELL_ROOT/bin"
cp "$HOST" "$SHELL_ROOT/bin/fm-extension.mjs"
cp "$ROOT/bin/fm-extension-deadline.mjs" "$SHELL_ROOT/bin/"
cat > "$SHELL_ROOT/bin/fm-procevent.sh" <<'SH'
[[ -n "$BASH_VERSION" ]] || exit 98
if [[ "${*: -1}" = reject ]]; then
  printf 'fixture refused\n' >&2
  exit 23
fi
printf '%s\n' "$@"
SH
chmod 600 "$SHELL_ROOT/bin/fm-procevent.sh"
H_SHELL="$HOMES/shell"; new_home "$H_SHELL"
# The command substitution is intentionally literal to detect shell evaluation.
# shellcheck disable=SC2016
literal_arg='space ; $(exit 97) *'
for shell_command in bind retire-binding retire-transfer process-event; do
  case "$shell_command" in
    bind) expected=$(printf '%s\n' extension-bind bind "$literal_arg"); error_code=binding-failed ;;
    retire-binding) expected=$(printf '%s\n' extension-retirement binding "$literal_arg"); error_code=retirement-failed ;;
    retire-transfer) expected=$(printf '%s\n' extension-retirement transfer "$literal_arg"); error_code=retirement-failed ;;
    process-event) expected=$(printf '%s\n' extension-process-event "$literal_arg"); error_code=process-event-failed ;;
  esac
  out=$(FM_HOME="$H_SHELL" node "$SHELL_ROOT/bin/fm-extension.mjs" "$shell_command" "$literal_arg") \
    || fail "$shell_command did not launch the non-executable Bash payload"
  [ "$out" = "$expected" ] || fail "$shell_command changed literal lifecycle argv: $out"
  shell_rc=0
  out=$(FM_HOME="$H_SHELL" node "$SHELL_ROOT/bin/fm-extension.mjs" "$shell_command" reject 2>&1) || shell_rc=$?
  if [ "$shell_command" = process-event ]; then
    [ "$shell_rc" -eq 23 ] && [ "$out" = 'fixture refused' ] \
      || fail "process-event changed the lifecycle exit status or stderr: $shell_rc $out"
  else
    [ "$shell_rc" -eq 1 ] && [ "$out" = "error[$error_code]: fixture refused" ] \
      || fail "$shell_command changed the lifecycle failure mapping: $shell_rc $out"
  fi
done
pass "lifecycle wrappers use Bash without shell interpolation and preserve failure mapping"
# POSIX resolution stays on the sanitized PATH: an exported BASH is never tried.
exported_bash="$TMP_ROOT/exported bash"
real_bash=$(command -v bash)
printf '#!%s\ntouch "%s.used"\nexec "%s" "$@"\n' "$real_bash" "$exported_bash" "$real_bash" > "$exported_bash"
chmod 700 "$exported_bash"
out=$(BASH="$exported_bash" FM_HOME="$H_SHELL" node "$SHELL_ROOT/bin/fm-extension.mjs" process-event "$literal_arg") \
  || fail "process-event did not launch with an exported BASH present"
[ "$out" = "$(printf '%s\n' extension-process-event "$literal_arg")" ] || fail "process-event changed literal argv with an exported BASH: $out"
[ ! -e "$exported_bash.used" ] || fail "POSIX lifecycle resolution tried the exported BASH"
pass "POSIX lifecycle Bash resolution ignores an exported BASH"

H_ABSENT="$HOMES/absent"
new_home "$H_ABSENT"
before=$(find "$H_ABSENT" -mindepth 1 -print | LC_ALL=C sort)
out=$(FM_HOME="$H_ABSENT" FIRSTMATE_EXTENSION_BINDING="$PACKAGES/ignored.json" "$HOST" list)
assert_contains "$out" "no extension bindings" "an absent registry does not discover an environment binding"
out=$(cd "$ROOT" && FM_HOME="$H_ABSENT" "$HOST" verify)
assert_contains "$out" "no extension bindings" "the current project and its Pi packages are not extension discovery roots"
after=$(find "$H_ABSENT" -mindepth 1 -print | LC_ALL=C sort)
[ "$before" = "$after" ] || fail "absent-registry inspection created home state: $after"
pass "an absent home-local registry is inert, state-free, and ignores project/environment discovery"

# --- manifest, path, mode, owner, link, and tree validation -----------------
P_GOOD="$PACKAGES/good"
make_package "$P_GOOD" org.example.good ext-good
H_GOOD="$HOMES/good"
new_home "$H_GOOD"
out=$(bind_package "$H_GOOD" "$P_GOOD" ext-good --timeout-ms 1000)
assert_contains "$out" "verified: process-event-adapter/1" "bind does not finish before the live handshake"
assert_contains "$(FM_HOME="$H_GOOD" "$HOST" list)" "org.example.good" "the explicit binding is discoverable"
assert_contains "$(FM_HOME="$H_GOOD" "$HOST" inspect org.example.good)" '"host_protocol": 1' "highest-common host protocol negotiation is inspectable"
assert_contains "$(FM_HOME="$H_GOOD" "$HOST" inspect org.example.good)" '"version": 1' "highest-common capability negotiation is inspectable"
assert_contains "$(FM_HOME="$H_GOOD" "$HOST" verify org.example.good)" "verified: org.example.good@1.2.3" "verify re-runs integrity and handshake checks"
package_root=$(binding_value "$H_GOOD" org.example.good package_root)
case "$package_root" in "$H_GOOD"/data/extensions/packages/*) ;; *) fail "binding did not use the home-local managed package store: $package_root" ;; esac
[ "$(stat -c '%a' "$package_root" 2>/dev/null || stat -f '%Lp' "$package_root")" = 555 ] \
  || fail "managed package root is not read-only"
pass "bind computes a content-addressed package, negotiates v1, and publishes an inspectable binding"

P_CONCURRENT_ONE="$PACKAGES/concurrent-one"
P_CONCURRENT_TWO="$PACKAGES/concurrent-two"
concurrent_marker="$TMP_ROOT/concurrent.entered"
concurrent_release="$TMP_ROOT/concurrent.release"
make_package "$P_CONCURRENT_ONE" org.example.concurrent-one ext-concurrent "$(printf 'handshake-block\n%s\n%s' "$concurrent_marker" "$concurrent_release")"
make_package "$P_CONCURRENT_TWO" org.example.concurrent-two ext-concurrent
H_CONCURRENT="$HOMES/concurrent"; new_home "$H_CONCURRENT"
bind_package "$H_CONCURRENT" "$P_CONCURRENT_ONE" ext-concurrent \
  > "$TMP_ROOT/concurrent-first.out" 2>&1 &
first_bind_pid=$!
for _ in $(seq 1 200); do
  [ -s "$concurrent_marker" ] && break
  sleep 0.01
done
[ -s "$concurrent_marker" ] || fail "first concurrent bind never reached its pre-publication handshake"
bind_package "$H_CONCURRENT" "$P_CONCURRENT_TWO" ext-concurrent > "$TMP_ROOT/concurrent-second.out" 2>&1 &
second_bind_pid=$!
sleep 0.2
kill -0 "$second_bind_pid" 2>/dev/null || fail "second concurrent bind bypassed the extension lifecycle boundary"
touch "$concurrent_release"
first_bind_rc=0
wait "$first_bind_pid" || first_bind_rc=$?
first_bind_pid=
second_bind_rc=0
wait "$second_bind_pid" || second_bind_rc=$?
second_bind_pid=
concurrent_release=
[ "$first_bind_rc" -eq 0 ] || fail "first concurrent bind did not publish its binding"
[ "$second_bind_rc" -ne 0 ] || fail "both concurrent adapter binds unexpectedly succeeded"
assert_contains "$(cat "$TMP_ROOT/concurrent-second.out")" "adapter is already enabled by another binding" \
  "losing concurrent bind did not report the adapter conflict"
assert_contains "$(FM_HOME="$H_CONCURRENT" "$HOST" verify org.example.concurrent-one)" "verified: org.example.concurrent-one@1.2.3" \
  "serialized bind did not preserve the winning package"
expect_failure "no binding exists for extension: org.example.concurrent-two" env FM_HOME="$H_CONCURRENT" "$HOST" verify org.example.concurrent-two
pass "concurrent binds serialize adapter ownership through publication"

P_CONSENT="$PACKAGES/consent"
make_package "$P_CONSENT" org.example.consent ext-consent good network
H_CONSENT="$HOMES/consent"
new_home "$H_CONSENT"
expect_failure "requires explicit --consent network" bind_package "$H_CONSENT" "$P_CONSENT" ext-consent
bind_package "$H_CONSENT" "$P_CONSENT" ext-consent --consent network >/dev/null
assert_contains "$(FM_HOME="$H_CONSENT" "$HOST" inspect org.example.consent)" '"network": true' "required consent is not recorded explicitly"
pass "package trust and manifest-required capability consent are separate explicit facts"
fi

if section_enabled early-validation; then
P_GOOD="$PACKAGES/good"
make_package "$P_GOOD" org.example.good ext-good
P_MODE="$PACKAGES/mode"
make_package "$P_MODE" org.example.mode ext-mode
chmod 0664 "$P_MODE/helper.txt"
H_MODE="$HOMES/mode"; new_home "$H_MODE"
expect_failure "group/world writable" bind_package "$H_MODE" "$P_MODE" ext-mode
pass "group/world-writable package code is rejected"

P_EXEC="$PACKAGES/nonexec"
make_package "$P_EXEC" org.example.nonexec ext-nonexec
chmod 0644 "$P_EXEC/entrypoint.py"
H_EXEC="$HOMES/nonexec"; new_home "$H_EXEC"
expect_failure "not executable" bind_package "$H_EXEC" "$P_EXEC" ext-nonexec
pass "a non-executable manifest entrypoint is rejected"

P_LINK="$PACKAGES/symlink-tree"
make_package "$P_LINK" org.example.symlink ext-symlink
ln -s helper.txt "$P_LINK/linked-helper"
H_LINK="$HOMES/symlink-tree"; new_home "$H_LINK"
expect_failure "symbolic link" bind_package "$H_LINK" "$P_LINK" ext-symlink
P_ALIAS="$PACKAGES/source-alias"
ln -s "$P_GOOD" "$P_ALIAS"
expect_failure "real directory" bind_package "$H_LINK" "$P_ALIAS" ext-good
pass "source-root traversal and package-tree symlinks are rejected"

P_HARD="$PACKAGES/hardlink"
make_package "$P_HARD" org.example.hardlink ext-hardlink
ln "$P_HARD/helper.txt" "$P_HARD/helper-alias.txt"
H_HARD="$HOMES/hardlink"; new_home "$H_HARD"
expect_failure "hard links" bind_package "$H_HARD" "$P_HARD" ext-hardlink
pass "hard-linked package code is rejected"

P_GIT="$PACKAGES/git-package"
make_package "$P_GIT" org.example.git ext-git
git -C "$P_GIT" init -q
H_GIT="$HOMES/git"; new_home "$H_GIT"
expect_failure "Git project or task copy" bind_package "$H_GIT" "$P_GIT" ext-git
example_package=$(cd "$ROOT/docs/examples/process-event-extension" && pwd -P)
expect_failure "Git project or task copy" bind_package "$H_GIT" "$example_package" file-signal --consent artifact-references
P_HOME_LOCAL="$H_GIT/projects/home-package"
make_package "$P_HOME_LOCAL" org.example.home-local ext-home-local
expect_failure "outside the active Firstmate home" bind_package "$H_GIT" "$P_HOME_LOCAL" ext-home-local
pass "a project, task-copy, or operational-home package cannot register even when named explicitly"

P_TRAVERSAL="$PACKAGES/entrypoint-traversal"
make_package "$P_TRAVERSAL" org.example.traversal ext-traversal
python3 - "$P_TRAVERSAL/firstmate-extension.json" <<'PY'
import json, sys
p = sys.argv[1]
data = json.load(open(p))
data['entrypoint'] = '../entrypoint.py'
open(p, 'w').write(json.dumps(data))
PY
H_TRAVERSAL="$HOMES/entrypoint-traversal"; new_home "$H_TRAVERSAL"
expect_failure "normalized relative POSIX path" bind_package "$H_TRAVERSAL" "$P_TRAVERSAL" ext-traversal
pass "manifest entrypoint traversal is rejected before execution"

P_MANIFEST_DUP="$PACKAGES/manifest-duplicate"
make_package "$P_MANIFEST_DUP" org.example.dup ext-dup
python3 - "$P_MANIFEST_DUP/firstmate-extension.json" <<'PY'
from pathlib import Path
p = Path(__import__('sys').argv[1])
s = p.read_text()
p.write_text(s.replace('"schema":', '"schema":"firstmate.extension-manifest.v1","schema":', 1))
PY
H_MANIFEST_DUP="$HOMES/manifest-duplicate"; new_home "$H_MANIFEST_DUP"
expect_failure "duplicate object key" bind_package "$H_MANIFEST_DUP" "$P_MANIFEST_DUP" ext-dup

P_MANIFEST_UNKNOWN="$PACKAGES/manifest-unknown"
make_package "$P_MANIFEST_UNKNOWN" org.example.unknown ext-manifest-unknown
python3 - "$P_MANIFEST_UNKNOWN/firstmate-extension.json" <<'PY'
import json, sys
p = sys.argv[1]
data = json.load(open(p))
data['plugin_hooks'] = ['before-merge']
open(p, 'w').write(json.dumps(data))
PY
H_MANIFEST_UNKNOWN="$HOMES/manifest-unknown"; new_home "$H_MANIFEST_UNKNOWN"
expect_failure "fields must be exactly" bind_package "$H_MANIFEST_UNKNOWN" "$P_MANIFEST_UNKNOWN" ext-manifest-unknown
pass "manifest JSON rejects duplicate and unknown fields instead of widening into plugin hooks"
fi

if section_enabled early-handshake; then
P_PROTOCOL="$PACKAGES/protocol"
make_package "$P_PROTOCOL" org.example.protocol ext-protocol
python3 - "$P_PROTOCOL/firstmate-extension.json" <<'PY'
import json, sys
p = sys.argv[1]
data = json.load(open(p))
data['host_protocols'] = [2]
data['capabilities'][0]['versions'] = [2]
open(p, 'w').write(json.dumps(data))
PY
H_PROTOCOL="$HOMES/protocol"; new_home "$H_PROTOCOL"
expect_failure "no common process-event protocol version" bind_package "$H_PROTOCOL" "$P_PROTOCOL" ext-protocol
pass "unknown-only protocol and capability versions refuse without downgrade"

for scenario in handshake-wrong-id handshake-unknown handshake-duplicate handshake-malformed handshake-nonzero; do
  package="$PACKAGES/$scenario"
  adapter="ext-${scenario//handshake-/hs-}"
  id="org.example.${scenario//-/.}"
  make_package "$package" "$id" "$adapter" "$scenario"
  home="$HOMES/$scenario"; new_home "$home"
  expect_failure "error[" bind_package "$home" "$package" "$adapter"
  [ ! -e "$home/config/extensions.d/$id.json" ] || fail "failed handshake published an enabled binding: $scenario"
done
pass "handshake request identity, exact fields, JSON, and process exit are validated before enablement"

run_owner_check
fi

# Binding file and complete installed tree are revalidated on every use.
if section_enabled early-integrity; then
P_GOOD="$PACKAGES/good"
make_package "$P_GOOD" org.example.good ext-good
H_GOOD="$HOMES/good"
new_home "$H_GOOD"
bind_package "$H_GOOD" "$P_GOOD" ext-good >/dev/null
package_root=$(binding_value "$H_GOOD" org.example.good package_root)
chmod 0644 "$H_GOOD/config/extensions.d/org.example.good.json"
expect_failure "mode 0600" env FM_HOME="$H_GOOD" "$HOST" verify org.example.good
chmod 0600 "$H_GOOD/config/extensions.d/org.example.good.json"
binding_good="$H_GOOD/config/extensions.d/org.example.good.json"
ln "$binding_good" "$TMP_ROOT/binding-hardlink"
expect_failure "single regular file" env FM_HOME="$H_GOOD" "$HOST" verify org.example.good
rm -f "$TMP_ROOT/binding-hardlink"
mv "$binding_good" "$TMP_ROOT/binding-target.json"
ln -s "$TMP_ROOT/binding-target.json" "$binding_good"
expect_failure "single regular file" env FM_HOME="$H_GOOD" "$HOST" verify org.example.good
rm -f "$binding_good"
mv "$TMP_ROOT/binding-target.json" "$binding_good"
chmod 0755 "$package_root"
chmod 0644 "$package_root/helper.txt"
printf 'mutated helper\n' > "$package_root/helper.txt"
chmod 0444 "$package_root/helper.txt"
chmod 0555 "$package_root"
expect_failure "tree digest" env FM_HOME="$H_GOOD" "$HOST" verify org.example.good
pass "binding mode and complete installed code-tree digest are revalidated"

P_IDENTITY="$PACKAGES/identity"
make_package "$P_IDENTITY" org.example.identity ext-identity
H_IDENTITY="$HOMES/identity"; new_home "$H_IDENTITY"
bind_package "$H_IDENTITY" "$P_IDENTITY" ext-identity >/dev/null
identity_root=$(binding_value "$H_IDENTITY" org.example.identity package_root)
chmod 0755 "$identity_root"
chmod 0755 "$identity_root/entrypoint.py"
printf '\n# changed identity\n' >> "$identity_root/entrypoint.py"
chmod 0555 "$identity_root/entrypoint.py" "$identity_root"
expect_failure "tree digest" env FM_HOME="$H_IDENTITY" "$HOST" verify org.example.identity
pass "the exact executable identity cannot change underneath a binding"
fi

# --- strict invocation matrix, replay, timeout, and process cleanup ----------
if section_enabled matrix matrix-runtime; then
P_MATRIX="$PACKAGES/matrix"
make_package "$P_MATRIX" org.example.matrix ext-matrix
H_MATRIX="$HOMES/matrix"; new_home "$H_MATRIX"
bind_package "$H_MATRIX" "$P_MATRIX" ext-matrix --timeout-ms 5000 >/dev/null
resolution=$(FM_HOME="$H_MATRIX" "$HOST" resolve-process-event ext-matrix)
IFS=$'\t' read -r resolution_schema resolution_id resolution_version resolution_cap resolution_package resolution_binding resolution_extra <<< "$resolution"
[ "$resolution_schema" = fm-extension-process-event-resolution.v1 ] && [ -z "$resolution_extra" ] \
  || fail "resolution record is malformed: $resolution"

invoke_matrix() {  # <config-ref> [request-id]
  local config_ref=$1 request_id=${2:-} args=()
  [ -z "$request_id" ] || args+=(--request-id "$request_id")
  FM_HOME="$H_MATRIX" "$HOST" process-event ext-matrix source.poll \
    --source-id matrix-source --config-ref "$config_ref" \
    --expect-extension "$resolution_id" --expect-version "$resolution_version" \
    --expect-capability-version "$resolution_cap" \
    --expect-package-digest "$resolution_package" \
    --expect-binding-digest "$resolution_binding" ${args[@]+"${args[@]}"}
}

state_root="$H_MATRIX/state/extensions/org.example.matrix"
if section_enabled matrix; then
shell_sentinel="$TMP_ROOT/extension-shell-sentinel"
literal_ref="\$(touch $shell_sentinel); one arg; *"
literal_out=$(invoke_matrix "$literal_ref")
assert_contains "$literal_out" "$literal_ref" "configuration reference was re-split or interpreted instead of JSON encoded"
assert_absent "$shell_sentinel" "configuration reference unexpectedly executed through a shell"
pass "source configuration references cross one JSON envelope with no shell interpretation"

matrix_cases="$TMP_ROOT/matrix-cases"
mkdir -p "$matrix_cases"
for scenario in malformed invalid-utf8 bom control multiple duplicate wrong-id unknown oversize stderr-oversize nonzero crash leak foreground-leak error-injection authority; do
  rc=0
  out=$(invoke_matrix "$scenario" 2>&1) || rc=$?
  printf '%s\n' "$rc" > "$matrix_cases/$scenario.rc"
  printf '%s' "$out" > "$matrix_cases/$scenario.out"
done
for scenario in malformed invalid-utf8 bom control multiple duplicate wrong-id unknown oversize stderr-oversize nonzero crash leak foreground-leak error-injection authority; do
  rc=$(cat "$matrix_cases/$scenario.rc")
  out=$(cat "$matrix_cases/$scenario.out")
  [ "$rc" -ne 0 ] || fail "invalid extension response was accepted: $scenario"
  assert_contains "$out" 'firstmate.process-event-extension-error.v1' "invalid source response did not become bounded host evidence: $scenario"
  assert_not_contains "$out" "merge_authorized" "authority-shaped extension bytes escaped strict response validation"
  assert_not_contains "$out" "MERGE NOW" "extension diagnostic text escaped into host evidence"
done
leaked_pid=$(cat "$H_MATRIX/state/extensions/org.example.matrix/leaked.pid")
for _ in $(seq 1 50); do
  kill -0 "$leaked_pid" 2>/dev/null || break
  sleep 0.05
done
kill -0 "$leaked_pid" 2>/dev/null && fail "a successful response left its background descendant alive"
rapid_pid=$(cat "$H_MATRIX/state/extensions/org.example.matrix/foreground-leak.pid")
for _ in $(seq 1 50); do
  kill -0 "$rapid_pid" 2>/dev/null || break
  sleep 0.05
done
kill -0 "$rapid_pid" 2>/dev/null && fail "a foreground descendant escaped invocation-group cleanup"
pass "malformed, invalid UTF-8, BOM, control, multiple, duplicate, unknown, oversized, crash, nonzero, stderr, and foreground leaked-process responses are rejected"

overlap_out="$TMP_ROOT/overlap.out"
invoke_matrix overlap >"$overlap_out" &
overlap_invoke_pid=$!
wait_for_file "$state_root/overlap-ready" || fail "overlap fixture never entered its invocation window"
unrelated_pid_file="$TMP_ROOT/unrelated-daemon.pid"
python3 - "$unrelated_pid_file" <<'PY' &
import os, subprocess, sys
child = subprocess.Popen(["/bin/sleep", "300"], cwd="/", start_new_session=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         env={"LANG":"C", "LC_ALL":"C", "PATH":"/usr/bin:/bin"})
with open(sys.argv[1], "w", encoding="utf-8") as output: output.write(f"{child.pid}\n")
PY
unrelated_launcher_pid=$!
wait_for_file "$unrelated_pid_file" || fail "unrelated daemon launcher never published its child"
unrelated_daemon_pid=$(cat "$unrelated_pid_file")
touch "$state_root/overlap-release"
wait "$overlap_invoke_pid" || {
  cat "$overlap_out" >&2
  fail "a proven-unrelated daemon made a valid extension invocation fail"
}
assert_contains "$(cat "$overlap_out")" "overlap complete" "overlap fixture did not return its valid result"
kill -0 "$unrelated_daemon_pid" 2>/dev/null || fail "extension cleanup terminated an unrelated same-user daemon"
wait "$unrelated_launcher_pid"
unrelated_launcher_pid=
kill -KILL "$unrelated_daemon_pid" 2>/dev/null || true
unrelated_daemon_pid=
pass "process cleanup never adopts a proven-unrelated same-user process"
fi

if section_enabled matrix-runtime; then
fixed_request="sha256:$(printf '1%.0s' $(seq 1 64))"
out_one=$(invoke_matrix replay "$fixed_request")
out_two=$(invoke_matrix replay "$fixed_request")
[ "$out_one" = "$out_two" ] || fail "replaying one exact request identity changed its result"
[ "$(cat "$state_root/side-effect-count")" = 1 ] || fail "the reference adapter applied one replay identity more than once"
pass "an exact request id is matched and supports idempotent replay"

H_CORE_REPLAY="$HOMES/core-replay"; new_home "$H_CORE_REPLAY"
bind_package "$H_CORE_REPLAY" "$P_MATRIX" ext-matrix >/dev/null
core_registration=$(FM_HOME="$H_CORE_REPLAY" "$PROCEVENT" register-extension ext-matrix replay-source --config-ref replay-no-result)
core_token=$(printf '%s\n' "$core_registration" | sed -n 's/^owner-token: //p')
FM_HOME="$H_CORE_REPLAY" "$PROCEVENT" start replay-source >/dev/null
FM_HOME="$H_CORE_REPLAY" "$PROCEVENT" start replay-source >/dev/null
core_request_ids="$H_CORE_REPLAY/state/extensions/org.example.matrix/request-ids"
[ "$(wc -l < "$core_request_ids" | tr -d ' ')" = 2 ] || fail "core replay fixture did not receive two requests"
[ "$(sort -u "$core_request_ids" | wc -l | tr -d ' ')" = 1 ] \
  || fail "retry before durable capture changed the request identity"
[ "$(cat "$H_CORE_REPLAY/state/extensions/org.example.matrix/side-effect-count")" = 1 ] \
  || fail "stable core retry identity applied the fixture effect twice"
FM_HOME="$H_CORE_REPLAY" "$PROCEVENT" retire replay-source --if-owner "$core_token" >/dev/null
pass "the generic runner reuses one request id until that source sequence is durably captured"

P_TIMEOUT="$PACKAGES/timeout"
make_package "$P_TIMEOUT" org.example.timeout ext-timeout
H_TIMEOUT="$HOMES/timeout"; new_home "$H_TIMEOUT"
bind_package "$H_TIMEOUT" "$P_TIMEOUT" ext-timeout --timeout-ms 500 >/dev/null
timeout_resolution=$(FM_HOME="$H_TIMEOUT" "$HOST" resolve-process-event ext-timeout)
IFS=$'\t' read -r timeout_schema timeout_id timeout_version timeout_cap timeout_package timeout_binding timeout_extra <<< "$timeout_resolution"
[ "$timeout_schema" = fm-extension-process-event-resolution.v1 ] && [ -z "$timeout_extra" ] \
  || fail "timeout resolution record is malformed: $timeout_resolution"
rc=0
out=$(FM_HOME="$H_TIMEOUT" "$HOST" process-event ext-timeout source.poll \
  --source-id timeout-source --config-ref timeout \
  --expect-extension "$timeout_id" --expect-version "$timeout_version" \
  --expect-capability-version "$timeout_cap" \
  --expect-package-digest "$timeout_package" --expect-binding-digest "$timeout_binding" 2>/dev/null) || rc=$?
[ "$rc" -ne 0 ] || fail "timed-out extension invocation succeeded"
assert_contains "$out" '"code":"timeout"' "timeout did not produce deterministic bounded evidence"
timeout_state_root="$H_TIMEOUT/state/extensions/org.example.timeout"
wait_for_file "$timeout_state_root/descendant.pid" || fail "timeout fixture never started its descendant"
descendant=$(cat "$timeout_state_root/descendant.pid")
for _ in $(seq 1 50); do
  kill -0 "$descendant" 2>/dev/null || break
  sleep 0.05
done
kill -0 "$descendant" 2>/dev/null && fail "timed-out extension left its descendant alive"
pass "timeout escalates through invocation-group cleanup and reaps descendants"

# A missing installed executable is actionable evidence, never fallback to a
# similarly named command or another adapter.
P_MISSING="$PACKAGES/missing"
make_package "$P_MISSING" org.example.missing ext-missing
H_MISSING="$HOMES/missing"; new_home "$H_MISSING"
bind_package "$H_MISSING" "$P_MISSING" ext-missing >/dev/null
missing_root=$(binding_value "$H_MISSING" org.example.missing package_root)
chmod 0755 "$missing_root"
rm -f "$missing_root/entrypoint.py"
chmod 0555 "$missing_root"
resolution_missing=$(FM_HOME="$H_MISSING" "$HOST" inspect org.example.missing 2>&1 || true)
assert_contains "$resolution_missing" "manifest entrypoint is missing" "missing executable was not diagnosed"
pass "a missing package executable refuses instead of falling back"
fi
fi

# --- repeated host failures remain bounded without blocking recovery --------
if section_enabled lifecycle-host-errors; then
host_error_case() {
  local shape=$1 case_root="$TMP_ROOT/host-error-$1" home package installed binding_file saved_binding
  local source="host-error-$1" expected_code poll_count result_count command round log runner_pid result
  local HOME XDG_STATE_HOME FM_PROCEVENT_CLAIM_ROOT PROCEVENT=$PROCEVENT
  mkdir -p "$case_root/user-home"
  export HOME="$case_root/user-home" XDG_STATE_HOME="$case_root/xdg"
  export FM_PROCEVENT_CLAIM_ROOT="$XDG_STATE_HOME/firstmate/procevent-claims"
  export FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=10
  home="$case_root/home"; new_home "$home"
  package="$case_root/package"
  make_package "$package" "org.example.$shape" ext-host-error
  bind_package "$home" "$package" ext-host-error >/dev/null || fail "cannot bind $shape fixture"
  installed=$(binding_value "$home" "org.example.$shape" package_root)
  binding_file="$home/config/extensions.d/org.example.$shape.json"
  fm_test_track_procevent_home "$home" "$FM_PROCEVENT_CLAIM_ROOT"
  FM_HOME="$home" "$PROCEVENT" register-extension ext-host-error "$source" --config-ref replay-no-result >/dev/null \
    || fail "cannot register $shape fixture"
  FM_HOME="$home" "$PROCEVENT" start "$source" > "$case_root/healthy.out" \
    || fail "healthy $shape fixture failed"
  poll_count="$home/state/extensions/org.example.$shape/request-ids"
  [ "$(wc -l < "$poll_count" | tr -d ' ')" -eq 1 ] || fail "healthy poll did not reach adapter"
  case "$shape" in
    package)
      mv "$installed" "$installed.saved"
      expected_code='package-missing'
      ;;
    conflict)
      make_package "$case_root/other-package" org.example.other ext-other
      node -e 'const fs=require("fs"); const p=process.argv[1]; const m=JSON.parse(fs.readFileSync(p)); m.capabilities[0].adapter_names.push("ext-host-error"); fs.writeFileSync(p,JSON.stringify(m)+"\n");' \
        "$case_root/other-package/firstmate-extension.json"
      bind_package "$home" "$case_root/other-package" ext-other >/dev/null
      cp "$home/config/extensions.d/org.example.other.json" "$case_root/other-binding.saved"
      node -e 'const fs=require("fs"); const p=process.argv[1]; const b=JSON.parse(fs.readFileSync(p)); b.capabilities[0].adapter_names=["ext-host-error"]; fs.writeFileSync(p,JSON.stringify(b)+"\n");' \
        "$home/config/extensions.d/org.example.other.json"
      expected_code='adapter-conflict'
      ;;
    barrier)
      mkdir -p "$case_root/code"
      cp -R "$ROOT/bin" "$case_root/code/bin"
      mv "$case_root/code/bin/fm-extension-launch-barrier.mjs" "$case_root/code/bin/fm-extension-launch-barrier.original.mjs"
      printf '%s\n' 'await new Promise(resolve => setTimeout(resolve, 15000));' \
        'await import("./fm-extension-launch-barrier.original.mjs");' > "$case_root/code/bin/fm-extension-launch-barrier.mjs"
      PROCEVENT="$case_root/code/bin/fm-procevent.sh"
      expected_code=timeout
      ;;
  esac
  for round in 1 2 3 4 5; do
    command=start
    [ "$round" -lt 3 ] || command=reconcile
    log="$case_root/$round.out"
    if [ "$command" = start ]; then
      FM_HOME="$home" "$PROCEVENT" start "$source" > "$log" 2>&1 || fail "$shape start failed: $(cat "$log")"
    else
      FM_HOME="$home" "$PROCEVENT" reconcile > "$log" 2>&1 || fail "$shape reconcile failed: $(cat "$log")"
      assert_contains "$(cat "$log")" 'started=1' "$shape reconcile did not launch a recovery poll"
    fi
    # Reconcile confirms a launch, not completion. Wait on this private source's
    # recorded runner and claim, so the next command exercises a settled retry.
    for _ in $(seq 1 600); do
      runner_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/$source.claim" 2>/dev/null || true)
      if [ ! -e "$home/state/procevent/$source.runner" ] && [ -z "$runner_pid" ]; then break; fi
      sleep 0.05
    done
    [ -z "$runner_pid" ] || fail "$shape runner did not settle"
    result_count=0
    for result in "$home/state/procevent-inbox/$source".*.result; do
      [ -f "$result" ] || continue
      result_count=$((result_count + 1))
      assert_grep "\"code\":\"$expected_code\"" "$result" "$shape captured the wrong failure"
      assert_absent "${result%.result}.handled" "$shape retry acknowledged its earlier failure"
    done
    [ "$result_count" -eq 1 ] || fail "$shape retry $round allocated $result_count distinct errors"
    [ "$(wc -l < "$poll_count" | tr -d ' ')" -eq 1 ] || fail "$shape failure entered adapter polling"
  done
  assert_contains "$(wake_payloads "$home")" "procevent ext-host-error $source 1" "$shape first failure was suppressed"
  case "$shape" in
    package) mv "$installed.saved" "$installed" ;;
    conflict) cp "$case_root/other-binding.saved" "$home/config/extensions.d/org.example.other.json" ;;
    barrier) mv "$case_root/code/bin/fm-extension-launch-barrier.original.mjs" "$case_root/code/bin/fm-extension-launch-barrier.mjs" ;;
  esac
  FM_HOME="$home" "$PROCEVENT" start "$source" > "$case_root/recovery.out" 2>&1 || fail "$shape recovery failed"
  assert_contains "$(cat "$case_root/recovery.out")" 'no-result:' "$shape recovery did not complete"
  [ "$(wc -l < "$poll_count" | tr -d ' ')" -eq 2 ] || fail "$shape recovery was blocked by old evidence"
  assert_absent "$home/state/procevent-inbox/$source.2.result" "$shape recovery allocated another error"
  assert_absent "$home/state/procevent-inbox/$source.1.handled" "$shape recovery acknowledged old evidence"

  # A changed host failure retains its own durable identity.
  saved_binding="$case_root/binding.saved"
  mv "$binding_file" "$saved_binding"
  FM_HOME="$home" "$PROCEVENT" start "$source" > "$case_root/changed.out" 2>&1 || fail "$shape changed poll failed"
  assert_present "$home/state/procevent-inbox/$source.2.result" "$shape changed host failure was suppressed"
  cmp -s "$home/state/procevent-inbox/$source.1.result" "$home/state/procevent-inbox/$source.2.result" \
    && fail "$shape changed failure was not distinguishable"
  mv "$saved_binding" "$binding_file"
  pass "$shape host failures coalesce across two starts and three reconciles, with recovery and changed evidence"
}
for host_error_shape in package conflict barrier; do
  host_error_case "$host_error_shape" || exit 1
done

# Adapter results may contain the host evidence schema verbatim. Their success
# status must keep identical genuine results distinct and unhandled.
P_IDENTICAL="$PACKAGES/identical"
make_package "$P_IDENTICAL" org.example.identical ext-identical keep-armed
H_IDENTICAL="$HOMES/identical"; new_home "$H_IDENTICAL"
bind_package "$H_IDENTICAL" "$P_IDENTICAL" ext-identical >/dev/null
FM_HOME="$H_IDENTICAL" "$PROCEVENT" register-extension ext-identical identical-source --config-ref host-error-output >/dev/null
for _ in 1 2; do
  FM_HOME="$H_IDENTICAL" "$PROCEVENT" start identical-source > "$TMP_ROOT/identical-start.out" \
    || fail "identical adapter result failed"
done
cmp "$H_IDENTICAL/state/procevent-inbox/identical-source.1.result" "$H_IDENTICAL/state/procevent-inbox/identical-source.2.result" \
  || fail "identical adapter fixture did not emit identical host-shaped bytes"
assert_absent "$H_IDENTICAL/state/procevent-inbox/identical-source.1.handled" "first adapter result was acknowledged"
assert_absent "$H_IDENTICAL/state/procevent-inbox/identical-source.2.handled" "second adapter result was acknowledged"
pass "successful identical adapter results retain distinct sequences even with host-shaped output"
identical_installed=$(binding_value "$H_IDENTICAL" org.example.identical package_root)
mv "$identical_installed" "$identical_installed.saved"
for _ in 1 2; do
  FM_HOME="$H_IDENTICAL" "$PROCEVENT" start identical-source > "$TMP_ROOT/identical-failure.out" \
    || fail "host failure after genuine evidence failed"
done
cmp "$H_IDENTICAL/state/procevent-inbox/identical-source.1.result" "$H_IDENTICAL/state/procevent-inbox/identical-source.3.result" \
  || fail "host and genuine result fixtures did not emit identical bytes"
assert_absent "$H_IDENTICAL/state/procevent-inbox/identical-source.4.result" "repeated host failure allocated another result"
FM_HOME="$H_IDENTICAL" "$PROCEVENT" handled identical-source 3 >/dev/null
FM_HOME="$H_IDENTICAL" "$PROCEVENT" start identical-source > "$TMP_ROOT/identical-after-handled.out" \
  || fail "host failure after acknowledgement failed"
assert_present "$H_IDENTICAL/state/procevent-inbox/identical-source.4.result" "handled host evidence suppressed a fresh failure"
assert_absent "$H_IDENTICAL/state/procevent-inbox/identical-source.4.handled" "fresh failure inherited acknowledgement"
pass "genuine evidence cannot suppress the first host error, and handled errors do not suppress fresh failures"
fi

# --- registration, invocation, unhandled capture, and binding retirement -----
if section_enabled lifecycle-flow; then
P_FLOW="$PACKAGES/flow"
make_package "$P_FLOW" org.example.flow ext-flow
H_FLOW="$HOMES/flow"; new_home "$H_FLOW"
flow_bind=$(bind_package "$H_FLOW" "$P_FLOW" ext-flow)
flow_binding_digest=$(printf '%s\n' "$flow_bind" | sed -n 's/^binding-digest: //p')
case "$flow_binding_digest" in sha256:*) ;; *) fail "local bind returned no binding retirement identity" ;; esac
registration=$(FM_HOME="$H_FLOW" "$PROCEVENT" register-extension ext-flow flow-source --config-ref good)
assert_contains "$registration" "org.example.flow@1.2.3" "extension registration omits its exact owner identity"
owner_one=$(printf '%s\n' "$registration" | sed -n 's/^owner-token: //p')
case "$owner_one" in
  sha256:*) [ "${#owner_one}" -eq 71 ] || fail "registration emitted a malformed owner token" ;;
  *) fail "registration emitted no bounded owner token" ;;
esac
expect_failure "still owns process-event registration" env FM_HOME="$H_FLOW" "$HOST" retire-binding org.example.flow --if-binding-digest "$flow_binding_digest"
assert_grep 'extension_id=org.example.flow' "$H_FLOW/state/procevent/flow-source.source" "registration did not retain extension identity"
assert_grep 'capability_version=1' "$H_FLOW/state/procevent/flow-source.source" "registration did not retain capability version"
assert_grep 'package_digest=sha256:' "$H_FLOW/state/procevent/flow-source.source" "registration did not retain package digest"

FM_HOME="$H_FLOW" "$PROCEVENT" start flow-source > "$TMP_ROOT/flow-start.out"
result=$(first_result "$H_FLOW" flow-source) || fail "external source produced no captured result"
assert_contains "$(wake_payloads "$H_FLOW")" "procevent ext-flow flow-source 1" "external source did not publish the existing bounded event"
assert_absent "${result%.result}.handled" "external evidence was silently treated as handled"
COLLISION_ROOT="$TMP_ROOT/collision-root"
mkdir -p "$COLLISION_ROOT/bin"
cat > "$COLLISION_ROOT/bin/fm-procevent-ext-flow.sh" <<'SH'
#!/usr/bin/env bash
printf 'wrong-built-in-owner\n'
exit 0
SH
chmod +x "$COLLISION_ROOT/bin/fm-procevent-ext-flow.sh"
classification=$(FM_ROOT_OVERRIDE="$COLLISION_ROOT" FM_HOME="$H_FLOW" "$PROCEVENT" classify "$result")
assert_contains "$classification" "external-ready" "captured evidence could not be classified through its immutable owner"
assert_not_contains "$classification" "wrong-built-in-owner" "a later same-name built-in reinterpreted extension evidence"
assert_absent "$H_FLOW/state/procevent/flow-source.source" "terminal external source stayed registered"
FM_HOME="$H_FLOW" "$PROCEVENT" retire flow-source --if-owner "$owner_one" >/dev/null
pass "one external adapter registers, invokes, captures unhandled evidence, classifies, and terminally retires end to end"
FM_HOME="$H_FLOW" "$PROCEVENT" register-extension ext-flow crash-silent-source --config-ref crash-silent >/dev/null
FM_HOME="$H_FLOW" "$PROCEVENT" start crash-silent-source > "$TMP_ROOT/crash-silent-start.out" 2>&1 &
crash_silent_start_pid=$!
for _ in $(seq 1 400); do
  if [ -f "$TMP_ROOT/claims/crash-silent-source.claim" ]; then
    # The successful crash-recovery path may release this durable claim between
    # the observation above and this best-effort cleanup PID read.
    crash_silent_runner_pid=$(sed -n '2p' "$TMP_ROOT/claims/crash-silent-source.claim" 2>/dev/null || true)
  fi
  kill -0 "$crash_silent_start_pid" 2>/dev/null || break
  sleep 0.01
done
if kill -0 "$crash_silent_start_pid" 2>/dev/null; then
  kill -TERM "$crash_silent_start_pid" 2>/dev/null || true
  [ -z "$crash_silent_runner_pid" ] || kill -TERM -"$crash_silent_runner_pid" 2>/dev/null || true
  wait "$crash_silent_start_pid" 2>/dev/null || true
  crash_silent_start_pid=
  crash_silent_runner_pid=
  fail "inner host crash during result.silent wedged its runner before result.terminal"
fi
wait "$crash_silent_start_pid" || fail "runner did not recover from inner result.silent crash"
crash_silent_start_pid=
crash_silent_runner_pid=
assert_present "$H_FLOW/state/procevent-inbox/crash-silent-source.1.result" "crashed silent invocation discarded captured evidence"
assert_absent "$H_FLOW/state/procevent/crash-silent-source.source" "terminal retry did not retire the crashed silent source"
assert_absent "$H_FLOW/state/procevent/.extension-binding-lifecycle.lock" "inner host crash left a lifecycle lock behind"
FM_HOME="$H_FLOW" "$PROCEVENT" handled crash-silent-source 1 >/dev/null
pass "inner result.silent host crash releases the parent lifecycle lock before terminal retry"
wrong_binding_digest="sha256:$(printf '0%.0s' {1..64})"
expect_failure "expected binding identity" env FM_HOME="$H_FLOW" "$HOST" retire-binding org.example.flow --if-binding-digest "$wrong_binding_digest"
assert_present "$H_FLOW/config/extensions.d/org.example.flow.json" "stale identity retired the local binding"
expect_failure "unhandled process-event result" env FM_HOME="$H_FLOW" "$HOST" retire-binding org.example.flow --if-binding-digest "$flow_binding_digest"
FM_HOME="$H_FLOW" "$PROCEVENT" handled flow-source 1 >/dev/null
FM_HOME="$H_FLOW" "$HOST" retire-binding org.example.flow --if-binding-digest "$flow_binding_digest" >/dev/null
assert_absent "$H_FLOW/config/extensions.d/org.example.flow.json" "exact local binding retirement left discovery enabled"
assert_present "$H_FLOW/data/extensions/retired-bindings/org.example.flow/${flow_binding_digest#sha256:}.json" "local binding retirement was not reversible"
expect_failure "no home-local extension binding" env FM_HOME="$H_FLOW" "$HOST" resolve-process-event ext-flow
pass "local binding retirement requires its exact identity and disables invocation"
fi

# --- registration against reconcile of an unhandled extension result ---------
# Re-registering a source while reconcile republishes its unhandled extension
# result must not deadlock. Registration holds binding resolution open here, so
# reconcile reaches the source before registration asks for it.
if section_enabled lifecycle-order; then
P_ORDER="$PACKAGES/lock-order"
order_marker="$TMP_ROOT/lock-order.marker"
order_release="$TMP_ROOT/lock-order.release"
make_package "$P_ORDER" org.example.lock-order ext-lock-order "$(printf 'handshake-block\n%s\n%s' "$order_marker" "$order_release")"
H_ORDER="$HOMES/lock-order"; new_home "$H_ORDER"
touch "$order_release"
bind_package "$H_ORDER" "$P_ORDER" ext-lock-order >/dev/null
FM_HOME="$H_ORDER" "$PROCEVENT" register-extension ext-lock-order order-source --config-ref good >/dev/null
FM_HOME="$H_ORDER" "$PROCEVENT" start order-source > "$TMP_ROOT/lock-order-start.out" 2>&1 \
  || fail "lock-order source did not capture its result"
assert_absent "$H_ORDER/state/procevent/order-source.source" "lock-order terminal source stayed registered"
assert_absent "$H_ORDER/state/procevent-inbox/order-source.1.handled" "lock-order result was not left unhandled"
rm -f "$order_marker" "$order_release"
FM_HOME="$H_ORDER" "$PROCEVENT" register-extension ext-lock-order order-source --config-ref no-result \
  > "$TMP_ROOT/lock-order-register.out" 2>&1 &
order_register_pid=$!
wait_for_file "$order_marker" || fail "lock-order registration never entered binding resolution"
FM_HOME="$H_ORDER" "$PROCEVENT" reconcile > "$TMP_ROOT/lock-order-reconcile.out" 2>&1 &
order_reconcile_pid=$!
for _ in $(seq 1 200); do
  [ -L "$FM_PROCEVENT_CLAIM_ROOT/order-source.lock" ] && break
  sleep 0.01
done
[ -L "$FM_PROCEVENT_CLAIM_ROOT/order-source.lock" ] || fail "neither lock-order contender took the source lock"
sleep 0.2
touch "$order_release"
order_deadline=$((SECONDS + 12))
while kill -0 "$order_register_pid" 2>/dev/null || kill -0 "$order_reconcile_pid" 2>/dev/null; do
  if [ "$SECONDS" -ge "$order_deadline" ]; then
    # Killing registration lets lock recovery free reconcile for cleanup.
    kill -KILL "$order_register_pid" 2>/dev/null || true
    wait "$order_register_pid" 2>/dev/null || true
    order_register_pid=
    wait "$order_reconcile_pid" 2>/dev/null || true
    order_reconcile_pid=
    fail "register-extension and reconcile deadlocked on an unhandled extension result"
  fi
  sleep 0.05
done
order_register_rc=0
wait "$order_register_pid" || order_register_rc=$?
order_register_pid=
wait "$order_reconcile_pid" 2>/dev/null || true
order_reconcile_pid=
order_release=
[ "$order_register_rc" -eq 0 ] || fail "lock-order registration failed: $(cat "$TMP_ROOT/lock-order-register.out")"
assert_contains "$(cat "$TMP_ROOT/lock-order-reconcile.out")" "reconciled:" "lock-order reconcile did not complete its cycle"
order_owner=$(sed -n 's/^owner-token: //p' "$TMP_ROOT/lock-order-register.out")
FM_HOME="$H_ORDER" "$PROCEVENT" retire order-source --if-owner "$order_owner" >/dev/null
FM_HOME="$H_ORDER" "$PROCEVENT" handled order-source 1 >/dev/null
pass "register-extension and reconcile of an unhandled extension result take their locks in one order"
fi

# --- registration and retirement serialization plus lock recovery -------------
if section_enabled lifecycle-lock; then
wrong_binding_digest="sha256:$(printf '0%.0s' {1..64})"
P_RETIRE_RACE="$PACKAGES/retire-race"
race_marker="$TMP_ROOT/retire-race.marker"
race_release="$TMP_ROOT/retire-race.release"
make_package "$P_RETIRE_RACE" org.example.retire-race ext-retire-race "$(printf 'handshake-block\n%s\n%s' "$race_marker" "$race_release")"
H_RETIRE_RACE="$HOMES/retire-race"; new_home "$H_RETIRE_RACE"
touch "$race_release"
race_bind=$(bind_package "$H_RETIRE_RACE" "$P_RETIRE_RACE" ext-retire-race)
race_binding_digest=$(printf '%s\n' "$race_bind" | sed -n 's/^binding-digest: //p')
rm -f "$race_marker" "$race_release"
FM_HOME="$H_RETIRE_RACE" "$PROCEVENT" register-extension ext-retire-race race-source --config-ref good > "$TMP_ROOT/retire-race-register.out" 2>&1 &
race_register_pid=$!
wait_for_file "$race_marker" || fail "registration race fixture never entered binding resolution"
FM_HOME="$H_RETIRE_RACE" "$HOST" retire-binding org.example.retire-race --if-binding-digest "$race_binding_digest" > "$TMP_ROOT/retire-race-retire.out" 2>&1 &
race_retire_pid=$!
sleep 0.2
kill -0 "$race_retire_pid" 2>/dev/null || fail "binding retirement bypassed an in-flight registration"
touch "$race_release"
race_register_rc=0
wait "$race_register_pid" || race_register_rc=$?
race_register_pid=
[ "$race_register_rc" -eq 0 ] || fail "serialized registration did not publish its owner record"
race_retire_rc=0
wait "$race_retire_pid" || race_retire_rc=$?
race_retire_pid=
[ "$race_retire_rc" -ne 0 ] || fail "serialized retirement removed a binding with a new registration"
assert_contains "$(cat "$TMP_ROOT/retire-race-retire.out")" "still owns process-event registration" "serialized retirement did not observe the published registration"
assert_present "$H_RETIRE_RACE/config/extensions.d/org.example.retire-race.json" "registration race left a dangling owner record"
race_owner=$(sed -n 's/^owner-token: //p' "$TMP_ROOT/retire-race-register.out")
FM_HOME="$H_RETIRE_RACE" "$PROCEVENT" retire race-source --if-owner "$race_owner" >/dev/null
FM_HOME="$H_RETIRE_RACE" "$HOST" retire-binding org.example.retire-race --if-binding-digest "$race_binding_digest" >/dev/null
race_release=
pass "registration publication and binding retirement share one lifecycle boundary"

P_PROCESS_RETIRE_RACE="$PACKAGES/process-retire-race"
process_race_marker="$TMP_ROOT/process-retire-race.marker"
process_race_release="$TMP_ROOT/process-retire-race.release"
make_package "$P_PROCESS_RETIRE_RACE" org.example.process-retire-race ext-process-retire-race "$(printf 'handshake-block\n%s\n%s' "$process_race_marker" "$process_race_release")"
H_PROCESS_RETIRE_RACE="$HOMES/process-retire-race"; new_home "$H_PROCESS_RETIRE_RACE"
touch "$process_race_release"
process_race_bind=$(bind_package "$H_PROCESS_RETIRE_RACE" "$P_PROCESS_RETIRE_RACE" ext-process-retire-race)
process_race_binding=$(printf '%s\n' "$process_race_bind" | sed -n 's/^binding-digest: //p')
FM_HOME="$H_PROCESS_RETIRE_RACE" "$PROCEVENT" register-extension ext-process-retire-race process-race-source --config-ref good >/dev/null
rm -f "$process_race_marker" "$process_race_release"
FM_HOME="$H_PROCESS_RETIRE_RACE" "$PROCEVENT" start process-race-source > "$TMP_ROOT/process-retire-race-start.out" 2>&1 &
process_race_start_pid=$!
wait_for_file "$process_race_marker" || fail "process-event race fixture never reached binding resolution"
FM_HOME="$H_PROCESS_RETIRE_RACE" "$HOST" retire-binding org.example.process-retire-race --if-binding-digest "$process_race_binding" > "$TMP_ROOT/process-retire-race-retire.out" 2>&1 &
process_race_retire_pid=$!
sleep 0.2
kill -0 "$process_race_retire_pid" 2>/dev/null || fail "binding retirement bypassed an in-flight process-event resolution"
touch "$process_race_release"
wait "$process_race_start_pid" || fail "lifecycle-locked process-event did not complete after release"
process_race_start_pid=
process_race_retire_rc=0
wait "$process_race_retire_pid" || process_race_retire_rc=$?
process_race_retire_pid=
[ "$process_race_retire_rc" -ne 0 ] || fail "retirement crossed a reserved process-event invocation"
assert_contains "$(cat "$TMP_ROOT/process-retire-race-retire.out")" "still owns process-event registration" "retirement did not observe the reserved process-event registration"
assert_present "$H_PROCESS_RETIRE_RACE/state/procevent-inbox/process-race-source.1.result" "reserved process-event did not capture its result"
pass "process-event resolution reserves the lifecycle before invocation"
process_race_release=

process_race_result="$H_PROCESS_RETIRE_RACE/state/procevent-inbox/process-race-source.1.result"
process_race_resolution=$(FM_HOME="$H_PROCESS_RETIRE_RACE" "$HOST" resolve-process-event ext-process-retire-race)
IFS=$'\t' read -r process_race_schema process_race_id process_race_version process_race_cap process_race_package process_race_resolution_binding process_race_extra <<< "$process_race_resolution"
[ "$process_race_schema" = fm-extension-process-event-resolution.v1 ] && [ -z "$process_race_extra" ] \
  || fail "process-event retirement race resolution was malformed"
for process_race_operation in result.classify result.terminal result.silent; do
  process_race_guard="process-race-${process_race_operation#result.}"
  process_race_registration=$(FM_HOME="$H_PROCESS_RETIRE_RACE" "$PROCEVENT" register-extension ext-process-retire-race "$process_race_guard" --config-ref good)
  process_race_owner=$(printf '%s\n' "$process_race_registration" | sed -n 's/^owner-token: //p')
  rm -f "$process_race_marker" "$process_race_release"
  FM_HOME="$H_PROCESS_RETIRE_RACE" "$HOST" process-event ext-process-retire-race "$process_race_operation" \
    --result-file "$process_race_result" \
    --expect-extension "$process_race_id" --expect-version "$process_race_version" \
    --expect-capability-version "$process_race_cap" \
    --expect-package-digest "$process_race_package" \
    --expect-binding-digest "$process_race_resolution_binding" \
    > "$TMP_ROOT/process-retire-race-${process_race_operation#result.}.out" 2>&1 &
  process_race_start_pid=$!
  wait_for_file "$process_race_marker" || fail "$process_race_operation race fixture never reached binding resolution"
  FM_HOME="$H_PROCESS_RETIRE_RACE" "$HOST" retire-binding org.example.process-retire-race --if-binding-digest "$process_race_binding" \
    > "$TMP_ROOT/process-retire-race-${process_race_operation#result.}-retire.out" 2>&1 &
  process_race_retire_pid=$!
  sleep 0.2
  kill -0 "$process_race_retire_pid" 2>/dev/null || fail "binding retirement bypassed $process_race_operation lifecycle reservation"
  touch "$process_race_release"
  wait "$process_race_start_pid" 2>/dev/null || true
  process_race_start_pid=
  process_race_retire_rc=0
  wait "$process_race_retire_pid" || process_race_retire_rc=$?
  process_race_retire_pid=
  [ "$process_race_retire_rc" -ne 0 ] || fail "retirement crossed a reserved $process_race_operation invocation"
  assert_contains "$(cat "$TMP_ROOT/process-retire-race-${process_race_operation#result.}-retire.out")" "still owns process-event registration" \
    "retirement did not observe the $process_race_operation registration"
  FM_HOME="$H_PROCESS_RETIRE_RACE" "$PROCEVENT" retire "$process_race_guard" --if-owner "$process_race_owner" >/dev/null
done
process_race_release=
pass "every external result operation reserves the lifecycle before invocation"

expect_failure "unknown command" env FM_HOME="$H_RETIRE_RACE" "$HOST" retire-binding-locked org.example.retire-race --if-binding-digest "$race_binding_digest"
expect_failure "unknown command" env FM_HOME="$H_RETIRE_RACE" "$HOST" retire-transfer-locked org.example.retire-race --if-transfer-digest "$wrong_binding_digest" --if-binding-digest "$race_binding_digest"
pass "public extension dispatch exposes no unlocked retirement entry"

P_LOCK_OWNER="$PACKAGES/lock-owner"
make_package "$P_LOCK_OWNER" org.example.lock-owner ext-lock-owner
H_LOCK_OWNER="$HOMES/lock-owner"; new_home "$H_LOCK_OWNER"
owner_bind=$(bind_package "$H_LOCK_OWNER" "$P_LOCK_OWNER" ext-lock-owner)
owner_binding_digest=$(printf '%s\n' "$owner_bind" | sed -n 's/^binding-digest: //p')
owner_lock="$H_LOCK_OWNER/state/procevent/.extension-binding-lifecycle.lock"
FM_HOME="$H_LOCK_OWNER" "$HOST" retire-binding org.example.lock-owner --if-binding-digest "$owner_binding_digest" > "$TMP_ROOT/lock-owner-retire.out" 2>&1 &
owner_retire_pid=$!
owner_worker_pid=
for _ in $(seq 1 400); do
  if [ -e "$owner_lock/pid" ]; then
    candidate=$(cat "$owner_lock/pid" 2>/dev/null || true)
    if [ -n "$candidate" ] && kill -STOP "$candidate" 2>/dev/null; then
      owner_worker_pid=$candidate
      break
    fi
  fi
  sleep 0.005
done
[ -n "$owner_worker_pid" ] || fail "retirement worker never acquired its lifecycle lock"
[ "$owner_worker_pid" != "$owner_retire_pid" ] || fail "retirement fixture did not cross the public wrapper boundary"
kill -TERM "$owner_retire_pid" 2>/dev/null || true
wait "$owner_retire_pid" 2>/dev/null || true
owner_retire_pid=
FM_HOME="$H_LOCK_OWNER" "$PROCEVENT" register-extension ext-lock-owner owner-source --config-ref good > "$TMP_ROOT/lock-owner-register.out" 2>&1 &
owner_register_pid=$!
sleep 0.2
kill -0 "$owner_register_pid" 2>/dev/null || fail "wrapper death released a live retirement worker's lifecycle lock"
kill -KILL "$owner_worker_pid" 2>/dev/null || true
wait "$owner_worker_pid" 2>/dev/null || true
owner_worker_pid=
owner_register_rc=0
wait "$owner_register_pid" || owner_register_rc=$?
owner_register_pid=
[ "$owner_register_rc" -eq 0 ] || fail "registration did not recover the dead retirement worker's lifecycle lock"
assert_present "$H_LOCK_OWNER/config/extensions.d/org.example.lock-owner.json" "dead retirement worker continued mutating after lock recovery"
owner_token=$(sed -n 's/^owner-token: //p' "$TMP_ROOT/lock-owner-register.out")
FM_HOME="$H_LOCK_OWNER" "$PROCEVENT" retire owner-source --if-owner "$owner_token" >/dev/null
FM_HOME="$H_LOCK_OWNER" "$HOST" retire-binding org.example.lock-owner --if-binding-digest "$owner_binding_digest" >/dev/null
pass "retirement worker ownership survives wrapper death and recovers exactly"

P_SIGNAL_LOCK="$PACKAGES/signal-lock"
make_package "$P_SIGNAL_LOCK" org.example.signal-lock ext-signal-lock
H_SIGNAL_LOCK="$HOMES/signal-lock"; new_home "$H_SIGNAL_LOCK"
signal_bind=$(bind_package "$H_SIGNAL_LOCK" "$P_SIGNAL_LOCK" ext-signal-lock)
signal_binding_digest=$(printf '%s\n' "$signal_bind" | sed -n 's/^binding-digest: //p')
signal_lock="$H_SIGNAL_LOCK/state/procevent/.extension-binding-lifecycle.lock"
FM_HOME="$H_SIGNAL_LOCK" "$HOST" retire-binding org.example.signal-lock --if-binding-digest "$signal_binding_digest" > "$TMP_ROOT/signal-lock-retire.out" 2>&1 &
signal_retire_pid=$!
signal_worker_pid=
for _ in $(seq 1 400); do
  if [ -e "$signal_lock/pid" ]; then
    candidate=$(cat "$signal_lock/pid" 2>/dev/null || true)
    if [ -n "$candidate" ] && kill -STOP "$candidate" 2>/dev/null; then
      signal_worker_pid=$candidate
      break
    fi
  fi
  sleep 0.005
done
[ -n "$signal_worker_pid" ] || fail "signal retirement worker never acquired its lifecycle lock"
kill -TERM "$signal_worker_pid" 2>/dev/null || fail "cannot signal retirement worker"
kill -CONT "$signal_worker_pid" 2>/dev/null || fail "cannot resume signalled retirement worker"
for _ in $(seq 1 400); do
  kill -0 "$signal_worker_pid" 2>/dev/null || break
  sleep 0.005
done
kill -0 "$signal_worker_pid" 2>/dev/null && fail "signalled retirement worker did not exit"
signal_worker_pid=
wait "$signal_retire_pid" 2>/dev/null || true
signal_retire_pid=
[ -L "$signal_lock" ] || fail "signalled retirement worker released its lifecycle lock before exit recovery"
signal_registration=$(FM_HOME="$H_SIGNAL_LOCK" "$PROCEVENT" register-extension ext-signal-lock signal-source --config-ref good)
signal_owner=$(printf '%s\n' "$signal_registration" | sed -n 's/^owner-token: //p')
assert_absent "$signal_lock" "registration left a recovered lifecycle lock behind"
FM_HOME="$H_SIGNAL_LOCK" "$PROCEVENT" retire signal-source --if-owner "$signal_owner" >/dev/null
FM_HOME="$H_SIGNAL_LOCK" "$HOST" retire-binding org.example.signal-lock --if-binding-digest "$signal_binding_digest" >/dev/null
pass "signal interruption leaves lifecycle lock recovery to the next owner"
fi

if section_enabled lifecycle-runner; then
P_FLOW="$PACKAGES/flow"
make_package "$P_FLOW" org.example.flow ext-flow
H_ACTIVE_RUNNER="$HOMES/active-runner"; new_home "$H_ACTIVE_RUNNER"
bind_package "$H_ACTIVE_RUNNER" "$P_FLOW" ext-flow >/dev/null
active_runner_marker="$TMP_ROOT/active-runner.marker"
active_runner_release="$TMP_ROOT/active-runner.release"
active_config="active-block|$active_runner_marker|$active_runner_release"
FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" register-extension ext-flow active-source --config-ref "$active_config" >/dev/null
FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" start active-source > "$TMP_ROOT/active-runner.out" 2>&1 &
active_runner_pid=$!
wait_for_file "$active_runner_marker" || fail "active extension runner never entered its poll"
expect_failure "prior runner remains active" env FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" register-extension ext-flow active-source --config-ref replacement
expect_failure "prior runner remains active" env FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" register lavish active-source -- /bin/echo built-in
touch "$active_runner_release"
active_runner_release=
wait "$active_runner_pid" || fail "active extension runner did not complete"
active_runner_pid=
assert_absent "$H_ACTIVE_RUNNER/state/procevent/active-source.source" "terminal extension runner retained its registration"
FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" register lavish active-source -- /bin/echo built-in >/dev/null
FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" retire active-source --if-matches lavish -- /bin/echo built-in >/dev/null
active_replacement=$(FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" register-extension ext-flow active-source --config-ref replacement)
active_replacement_owner=$(printf '%s\n' "$active_replacement" | sed -n 's/^owner-token: //p')
FM_HOME="$H_ACTIVE_RUNNER" "$PROCEVENT" retire active-source --if-owner "$active_replacement_owner" >/dev/null
pass "all registration owner transitions wait for the prior extension runner"
fi

# --- owner tokens, overridden state, sweep, and legacy compatibility --------
if section_enabled lifecycle-state; then
P_FLOW="$PACKAGES/flow"
make_package "$P_FLOW" org.example.flow ext-flow
H_OWNER_SAFE="$HOMES/owner-safe"; new_home "$H_OWNER_SAFE"
bind_package "$H_OWNER_SAFE" "$P_FLOW" ext-flow >/dev/null
first=$(FM_HOME="$H_OWNER_SAFE" "$PROCEVENT" register-extension ext-flow replace-source --config-ref first)
first_token=$(printf '%s\n' "$first" | sed -n 's/^owner-token: //p')
second=$(FM_HOME="$H_OWNER_SAFE" "$PROCEVENT" register-extension ext-flow replace-source --config-ref second)
second_token=$(printf '%s\n' "$second" | sed -n 's/^owner-token: //p')
[ "$first_token" != "$second_token" ] || fail "replacement registration reused its owner generation"
expect_failure "requires its exact --if-owner token" env FM_HOME="$H_OWNER_SAFE" "$PROCEVENT" retire replace-source
expect_failure "does not match the expected owner" env FM_HOME="$H_OWNER_SAFE" "$PROCEVENT" retire replace-source --if-owner "$first_token"
assert_present "$H_OWNER_SAFE/state/procevent/replace-source.source" "stale owner retired the replacement"
FM_HOME="$H_OWNER_SAFE" "$PROCEVENT" retire replace-source --if-owner "$second_token" >/dev/null
assert_absent "$H_OWNER_SAFE/state/procevent/replace-source.source" "current owner could not retire its own registration"
pass "owner-matched retirement refuses a stale generation and accepts the current one"

H_STATE_OVERRIDE="$HOMES/state-override"; new_home "$H_STATE_OVERRIDE"
STATE_OVERRIDE="$TMP_ROOT/overridden-state"
override_bind=$(bind_package "$H_STATE_OVERRIDE" "$P_FLOW" ext-flow)
override_bind_digest=$(printf '%s\n' "$override_bind" | sed -n 's/^binding-digest: //p')
override_registration=$(FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$PROCEVENT" register-extension ext-flow override-source --config-ref silent-result)
override_owner=$(printf '%s\n' "$override_registration" | sed -n 's/^owner-token: //p')
override_resolution=$(FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$HOST" resolve-process-event ext-flow)
IFS=$'\t' read -r override_schema override_id override_version override_cap override_package override_binding override_extra <<< "$override_resolution"
[ "$override_schema" = fm-extension-process-event-resolution.v1 ] && [ -z "$override_extra" ] \
  || fail "overridden-state resolution record is malformed"
expect_failure "still owns process-event registration" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$HOST" retire-binding org.example.flow --if-binding-digest "$override_bind_digest"
assert_present "$H_STATE_OVERRIDE/config/extensions.d/org.example.flow.json" "overridden-state dependency did not preserve its binding"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$PROCEVENT" start override-source >/dev/null
override_result="$STATE_OVERRIDE/procevent-inbox/override-source.1.result"
assert_present "$override_result" "overridden-state runner did not capture its result"
assert_present "$STATE_OVERRIDE/procevent-inbox/override-source.1.handled" "overridden-state silent verdict was not recorded"
assert_absent "$STATE_OVERRIDE/procevent/override-source.source" "overridden-state terminal verdict did not retire its registration"
assert_contains "$(FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$PROCEVENT" classify "$override_result")" "external-ready" \
  "overridden-state result could not be classified"
mkdir "$TMP_ROOT/override-outside"
cp "$override_result" "$TMP_ROOT/override-outside/override-source.1.result"
cp "$STATE_OVERRIDE/procevent-inbox/override-source.1.adapter" "$TMP_ROOT/override-outside/override-source.1.adapter"
cp "$STATE_OVERRIDE/procevent-inbox/override-source.1.extension" "$TMP_ROOT/override-outside/override-source.1.extension"
chmod 0600 "$TMP_ROOT/override-outside/override-source.1.result"
chmod 0600 "$TMP_ROOT/override-outside/override-source.1.adapter" "$TMP_ROOT/override-outside/override-source.1.extension"
expect_failure "directly inside" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" classify "$TMP_ROOT/override-outside/override-source.1.result"
mkdir "$TMP_ROOT/forged-pinned-result"
printf 'forged extension evidence\n' > "$TMP_ROOT/forged-pinned-result/forged-source.1.result"
chmod 0600 "$TMP_ROOT/forged-pinned-result/forged-source.1.result"
# shellcheck disable=SC2016 # Child shell intentionally expands its positional parameters.
expect_failure "directly inside" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  FM_PROCEVENT_CAPTURE_PINNED_RESULT=1 sh -c '
    cd "$1" || exit 1
    exec "$2" process-event "$3" result.classify --result-file ./forged-source.1.result \
      --expect-extension "$4" --expect-version "$5" --expect-capability-version "$6" \
      --expect-package-digest "$7" --expect-binding-digest "$8"
  ' sh "$TMP_ROOT/forged-pinned-result" "$HOST" ext-flow "$override_id" "$override_version" \
  "$override_cap" "$override_package" "$override_binding"
# shellcheck disable=SC2016 # Child shell intentionally expands its positional parameters.
expect_failure "directly inside" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  sh -c '
    cd "$1" || exit 1
    authority=$(mktemp .forged-authority.XXXXXXXX) || exit 1
    dd if=/dev/urandom of="$authority" bs=32 count=1 2>/dev/null || exit 1
    chmod 0600 "$authority" || exit 1
    exec 7<"$authority"
    rm -f -- "$authority"
    exec 8<.
    exec "$2" extension-process-event "$3" result.classify --result-file ./forged-source.1.result \
      --expect-extension "$4" --expect-version "$5" --expect-capability-version "$6" \
      --expect-package-digest "$7" --expect-binding-digest "$8"
  ' sh "$TMP_ROOT/forged-pinned-result" "$PROCEVENT" ext-flow "$override_id" "$override_version" \
  "$override_cap" "$override_package" "$override_binding"
# shellcheck disable=SC2016 # Child shell intentionally expands its positional parameters.
expect_failure "directly inside" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  FM_PROCEVENT_INTERNAL_CAPTURE_RESERVATION="$(printf 'd%.0s' {1..64})" \
  FM_PROCEVENT_INTERNAL_CAPTURE_CLAIM_PID="$$" \
  FM_PROCEVENT_INTERNAL_CAPTURE_CLAIM_IDENTITY=forged-identity \
  FM_PROCEVENT_INTERNAL_CAPTURE_CLAIM_TOKEN=forged-claim \
  FM_PROCEVENT_INTERNAL_CAPTURE_SOURCE_ID=forged-source \
  FM_PROCEVENT_INTERNAL_CAPTURE_SEQUENCE=1 \
  FM_PROCEVENT_INTERNAL_CAPTURE_PARENT_PID="$$" sh -c '
    cd "$1" || exit 1
    exec 6<.
    exec 7<.
    exec 8<.
    exec "$2" extension-process-event "$3" result.silent --result-file ./forged-source.1.result \
      --expect-extension "$4" --expect-version "$5" --expect-capability-version "$6" \
      --expect-package-digest "$7" --expect-binding-digest "$8"
  ' sh "$TMP_ROOT/forged-pinned-result" "$PROCEVENT" ext-flow "$override_id" "$override_version" \
  "$override_cap" "$override_package" "$override_binding"
forged_reservation_root="$TMP_ROOT/forged-capture-reservations"
mkdir "$forged_reservation_root"
forged_reservation_token=$(printf 'c%.0s' {1..64})
forged_claim_identity=$(FM_HOME="$TMP_ROOT/forged-identity-home" FM_STATE_OVERRIDE="$TMP_ROOT/forged-identity-state" \
  bash -c '. "$1"; fm_pid_identity "$2"' sh "$ROOT/bin/fm-wake-lib.sh" "$$")
printf '%s\n' '{"schema":"fm-procevent-capture-reservation.v1","token":"'"$forged_reservation_token"'","operation":"result.silent","source_id":"forged-source","sequence":1,"inbox_device":"1","inbox_inode":"1","result_device":"1","result_inode":"1","claim_pid":"'"$$"'","claim_identity":"'"$forged_claim_identity"'","claim_token":"forged-claim","binding_digest":"'"$override_binding"'"}' \
  > "$forged_reservation_root/.extension-capture-forged-claim.$forged_reservation_token.json"
chmod 0600 "$forged_reservation_root/.extension-capture-forged-claim.$forged_reservation_token.json"
# shellcheck disable=SC2016 # Child shell intentionally expands its positional parameters.
expect_failure "reservation" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  FM_PROCEVENT_CLAIM_ROOT="$forged_reservation_root" sh -c '
    cd "$1" || exit 1
    exec "$2" extension-process-event "$3" result.silent --result-file ./forged-source.1.result \
      --expect-extension "$4" --expect-version "$5" --expect-capability-version "$6" \
      --expect-package-digest "$7" --expect-binding-digest "$8" \
      --capture-reservation "$9"
  ' sh "$TMP_ROOT/forged-pinned-result" "$PROCEVENT" ext-flow "$override_id" "$override_version" \
  "$override_cap" "$override_package" "$override_binding" "$forged_reservation_token"
printf 'forged adapter\n' > "$TMP_ROOT/forged-pinned-result/forged-source.1.adapter"
chmod 0600 "$TMP_ROOT/forged-pinned-result/forged-source.1.adapter"
# shellcheck disable=SC2016 # Child shell intentionally expands its positional parameters.
expect_failure "cannot durably" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  FM_PROCEVENT_CAPTURE_PINNED_INBOX=1 sh -c '
    cd "$1" || exit 1
    exec "$2" handled forged-source 1
  ' sh "$TMP_ROOT/forged-pinned-result" "$PROCEVENT"
assert_absent "$TMP_ROOT/forged-pinned-result/forged-source.1.handled" \
  "caller environment forged a handled acknowledgement"
pass "caller environment, descriptors, and lifecycle entry cannot forge capture authority"
reservation_records=$(find "$STATE_OVERRIDE/procevent-capture-reservations" -type f -print 2>/dev/null | wc -l | tr -d '[:space:]')
[ "$reservation_records" -eq 0 ] || fail "completed extension capture left residual reservation state"
pass "extension capture reservations are bounded to their runner lifecycle"
state_path_decoy="$H_STATE_OVERRIDE/state/procevent-capture-reservations/.extension-capture-control-path-decoy.json"
mkdir -p "${state_path_decoy%/*}"
chmod 0700 "$H_STATE_OVERRIDE/state" "${state_path_decoy%/*}"
printf 'decoy\n' > "$state_path_decoy"
chmod 0600 "$state_path_decoy"
for control_kind in tab newline; do
  case "$control_kind" in
    tab) control_state="$TMP_ROOT/control-state"$'\t'"tab" ;;
    newline) control_state="$TMP_ROOT/control-state"$'\n'"newline" ;;
  esac
  control_source="control-${control_kind}-state-source"
  mkdir -p "$control_state"
  chmod 0700 "$control_state"
  FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$control_state" \
    "$PROCEVENT" register lavish "$control_source" -- /bin/echo control >/dev/null
  expect_failure "cannot acquire source ownership" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$control_state" \
    "$PROCEVENT" start "$control_source"
  assert_absent "$TMP_ROOT/claims/$control_source.claim" "control-byte state root created a malformed claim"
  assert_absent "$control_state/procevent-capture-reservations" "control-byte state root created reservation state"
  assert_present "$state_path_decoy" "control-byte state root touched unrelated reservation state"
done
pass "control-byte state roots cannot serialize claims or reservations"
override_crash_marker="$TMP_ROOT/override-crash.marker"
override_crash_release="$TMP_ROOT/override-crash.release"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow override-crash-source \
  --config-ref "silent-block|$override_crash_marker|$override_crash_release" >/dev/null
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start override-crash-source > "$TMP_ROOT/override-crash-start.out" 2>&1 &
override_crash_start_pid=$!
wait_for_file "$override_crash_marker" || fail "overridden-state crash fixture never reached its reservation handoff"
override_crash_claim="$TMP_ROOT/claims/override-crash-source.claim"
assert_present "$override_crash_claim" "overridden-state crash fixture did not retain its claim"
override_crash_runner_pid=$(sed -n '2p' "$override_crash_claim")
override_crash_token=$(sed -n '3p' "$override_crash_claim")
override_crash_records=$(find "$STATE_OVERRIDE/procevent-capture-reservations" -type f \
  -name ".extension-capture-$override_crash_token.*" -print | wc -l | tr -d '[:space:]')
[ "$override_crash_records" -eq 2 ] || fail "overridden-state crash fixture did not create both immediate reservations"
mkdir -p "$H_STATE_OVERRIDE/state/procevent-capture-reservations"
chmod 0700 "$H_STATE_OVERRIDE/state" "$H_STATE_OVERRIDE/state/procevent-capture-reservations"
override_crash_decoy="$H_STATE_OVERRIDE/state/procevent-capture-reservations/.extension-capture-$override_crash_token.decoy.json"
printf 'decoy\n' > "$override_crash_decoy"
chmod 0600 "$override_crash_decoy"
kill -KILL -"$override_crash_runner_pid" 2>/dev/null || fail "could not terminate overridden-state runner"
wait "$override_crash_start_pid" 2>/dev/null || true
override_crash_start_pid=
override_crash_runner_pid=
FM_HOME="$H_STATE_OVERRIDE" "$PROCEVENT" reconcile >/dev/null
assert_absent "$override_crash_claim" "reconcile retained a dead overridden-state claim"
override_crash_records=$(find "$STATE_OVERRIDE/procevent-capture-reservations" -type f \
  -name ".extension-capture-$override_crash_token.*" -print -quit)
[ -z "$override_crash_records" ] || fail "reconcile left reservations in the recorded overridden state root"
assert_present "$override_crash_decoy" "reconcile removed reservations from the current default state root"
pass "crash recovery revalidates and cleans only the recorded state root"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow inbox-swap-source --config-ref good >/dev/null
mkdir "$TMP_ROOT/inbox-link-target"
mv "$STATE_OVERRIDE/procevent-inbox" "$TMP_ROOT/override-real-inbox"
ln -s "$TMP_ROOT/inbox-link-target" "$STATE_OVERRIDE/procevent-inbox"
expect_failure "cannot durably capture the extension result" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start inbox-swap-source
[ -z "$(find "$TMP_ROOT/inbox-link-target" -mindepth 1 -print -quit)" ] \
  || fail "a post-registration inbox symlink received extension evidence"
rm "$STATE_OVERRIDE/procevent-inbox"
mv "$TMP_ROOT/override-real-inbox" "$STATE_OVERRIDE/procevent-inbox"
pass "post-registration inbox symlink substitution cannot redirect extension evidence"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow registry-swap-source --config-ref good >/dev/null
mkdir "$TMP_ROOT/registry-link-target"
mv "$STATE_OVERRIDE/procevent" "$TMP_ROOT/registry-link-target"
REGISTRY_LINK_TARGET="$TMP_ROOT/registry-link-target/procevent"
registry_entries_before=$(find "$REGISTRY_LINK_TARGET" -mindepth 1 -maxdepth 1 -print | LC_ALL=C sort)
ln -s "$REGISTRY_LINK_TARGET" "$STATE_OVERRIDE/procevent"
expect_failure "cannot safely prepare the external registry staging boundary" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start registry-swap-source
registry_entries_after=$(find "$REGISTRY_LINK_TARGET" -mindepth 1 -maxdepth 1 -print | LC_ALL=C sort)
[ "$registry_entries_before" = "$registry_entries_after" ] \
  || fail "a post-registration registry symlink received external evidence"
rm "$STATE_OVERRIDE/procevent"
mv "$REGISTRY_LINK_TARGET" "$STATE_OVERRIDE/procevent"
pass "post-registration registry symlink substitution cannot redirect external evidence"
registry_race_marker="$TMP_ROOT/registry-race.marker"
registry_race_release="$TMP_ROOT/registry-race.release"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow registry-race-source \
  --config-ref "active-block|$registry_race_marker|$registry_race_release" >/dev/null
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start registry-race-source > "$TMP_ROOT/registry-race.out" 2>&1 &
registry_race_pid=$!
wait_for_file "$registry_race_marker" || fail "registry race fixture never reached its pinned staging boundary"
mkdir "$TMP_ROOT/registry-race-outside"
mv "$STATE_OVERRIDE/procevent" "$TMP_ROOT/registry-race-real"
ln -s "$TMP_ROOT/registry-race-outside" "$STATE_OVERRIDE/procevent"
touch "$registry_race_release"
registry_race_rc=0
wait "$registry_race_pid" || registry_race_rc=$?
registry_race_pid=
[ "$registry_race_rc" -eq 0 ] || fail "registry swap race did not complete through its pinned staging directory"
[ -z "$(find "$TMP_ROOT/registry-race-outside" -mindepth 1 -print -quit)" ] \
  || fail "a registry directory swap received external evidence"
rm "$STATE_OVERRIDE/procevent"
mv "$TMP_ROOT/registry-race-real" "$STATE_OVERRIDE/procevent"
pass "external staging remains descriptor-bound across a registry directory swap"
registry_race_release=
leaf_race_marker="$TMP_ROOT/leaf-race.marker"
leaf_race_release="$TMP_ROOT/leaf-race.release"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow leaf-race-source \
  --config-ref "active-block|$leaf_race_marker|$leaf_race_release" >/dev/null
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start leaf-race-source > "$TMP_ROOT/leaf-race.out" 2>&1 &
leaf_race_pid=$!
wait_for_file "$leaf_race_marker" || fail "leaf race fixture never entered its staged invocation"
leaf_stage=$(find "$STATE_OVERRIDE/procevent" -maxdepth 1 -name '.leaf-race-source.*.output' -print -quit)
leaf_runner="$STATE_OVERRIDE/procevent/leaf-race-source.runner"
[ -n "$leaf_stage" ] && [ -f "$leaf_runner" ] || fail "leaf race fixture did not create both protected leaves"
mkdir "$TMP_ROOT/leaf-race-outside"
mv "$leaf_stage" "$TMP_ROOT/leaf-race-real-output"
mv "$leaf_runner" "$TMP_ROOT/leaf-race-real-runner"
ln -s "$TMP_ROOT/leaf-race-outside/output" "$leaf_stage"
ln -s "$TMP_ROOT/leaf-race-outside/runner" "$leaf_runner"
touch "$leaf_race_release"
leaf_race_rc=0
wait "$leaf_race_pid" || leaf_race_rc=$?
leaf_race_pid=
[ "$leaf_race_rc" -eq 0 ] || fail "leaf substitution race did not complete through held descriptors"
[ ! -e "$TMP_ROOT/leaf-race-outside/output" ] && [ ! -e "$TMP_ROOT/leaf-race-outside/runner" ] \
  || fail "a substituted staging leaf received external evidence"
rm -f "$leaf_stage" "$leaf_runner"
pass "external staging leaves remain no-follow descriptor-bound through capture"
leaf_race_release=
publication_race_marker="$TMP_ROOT/publication-race.marker"
publication_race_release="$TMP_ROOT/publication-race.release"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" register-extension ext-flow publication-race-source \
  --config-ref "silent-block|$publication_race_marker|$publication_race_release" >/dev/null
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" start publication-race-source > "$TMP_ROOT/publication-race.out" 2>&1 &
publication_race_pid=$!
wait_for_file "$publication_race_marker" || fail "publication race fixture never reached result handoff"
mkdir "$TMP_ROOT/publication-race-outside"
mv "$STATE_OVERRIDE/procevent-inbox" "$TMP_ROOT/publication-race-real-inbox"
ln -s "$TMP_ROOT/publication-race-outside" "$STATE_OVERRIDE/procevent-inbox"
touch "$publication_race_release"
publication_race_rc=0
wait "$publication_race_pid" || publication_race_rc=$?
publication_race_pid=
[ "$publication_race_rc" -eq 0 ] || fail "publication race did not complete through its pinned inbox"
assert_present "$TMP_ROOT/publication-race-real-inbox/publication-race-source.1.result" \
  "pinned inbox lost the captured result during publication"
assert_present "$TMP_ROOT/publication-race-real-inbox/publication-race-source.1.handled" \
  "pinned inbox lost its handled acknowledgement during publication"
[ -z "$(find "$TMP_ROOT/publication-race-outside" -mindepth 1 -print -quit)" ] \
  || fail "post-capture inbox substitution redirected extension evidence or metadata"
rm "$STATE_OVERRIDE/procevent-inbox"
mv "$TMP_ROOT/publication-race-real-inbox" "$STATE_OVERRIDE/procevent-inbox"
pass "external publication remains descriptor-bound after capture"
publication_race_release=
capture_signal_state="$TMP_ROOT/capture-signal-state"
capture_signal_registry="$capture_signal_state/procevent"
mkdir -p "$capture_signal_registry" "$capture_signal_state/procevent-inbox"
chmod 0700 "$capture_signal_state" "$capture_signal_registry" "$capture_signal_state/procevent-inbox"
exec 9<"$capture_signal_registry"
exec 6<"$capture_signal_registry"
exec 8<"$capture_signal_state/procevent-inbox"
capture_signal_authority=$(mktemp "$capture_signal_registry/.authority.XXXXXXXX")
dd if=/dev/urandom of="$capture_signal_authority" bs=32 count=1 2>/dev/null
chmod 0600 "$capture_signal_authority"
exec 7<"$capture_signal_authority"
rm "$capture_signal_authority"
capture_signal=$(perl "$ROOT/bin/fm-procevent-extension-capture.pl" \
  9 8 6 capture-signal-source ext-flow org.example.flow 1.2.3 1 \
  "sha256:$(printf 'a%.0s' {1..64})" "sha256:$(printf 'b%.0s' {1..64})" signal-token \
  capture-signal-source.runner .capture-signal.output "$$" "$forged_claim_identity" 1024 -- perl -e 'kill "KILL", $$')
exec 9<&-
exec 6<&-
exec 8<&-
exec 7<&-
[ "$capture_signal" = $'failure\t0' ] || fail "signal-terminated extension invocation was not reported as failure"
[ -z "$(find "$capture_signal_registry" "$capture_signal_state/procevent-inbox" -mindepth 1 -print -quit)" ] \
  || fail "signal-terminated extension invocation left staged or successful evidence"
pass "signal-terminated extension capture cannot publish an empty success"
capture_swap_state="$TMP_ROOT/capture-swap-state"
capture_swap_registry="$capture_swap_state/procevent"
capture_swap_inbox="$capture_swap_state/procevent-inbox"
mkdir -p "$capture_swap_registry" "$capture_swap_inbox" "$TMP_ROOT/capture-swap-outside"
chmod 0700 "$capture_swap_state" "$capture_swap_registry" "$capture_swap_inbox" "$TMP_ROOT/capture-swap-outside"
exec 9<"$capture_swap_registry"
exec 6<"$capture_swap_registry"
exec 8<"$capture_swap_inbox"
capture_swap_authority=$(mktemp "$capture_swap_registry/.authority.XXXXXXXX")
dd if=/dev/urandom of="$capture_swap_authority" bs=32 count=1 2>/dev/null
chmod 0600 "$capture_swap_authority"
exec 7<"$capture_swap_authority"
rm "$capture_swap_authority"
mv "$capture_swap_inbox" "$TMP_ROOT/capture-swap-real-inbox"
ln -s "$TMP_ROOT/capture-swap-outside" "$capture_swap_inbox"
capture_swap=$(perl "$ROOT/bin/fm-procevent-extension-capture.pl" \
  9 8 6 capture-swap-source ext-flow org.example.flow 1.2.3 1 \
  "sha256:$(printf 'a%.0s' {1..64})" "sha256:$(printf 'b%.0s' {1..64})" swap-token \
  capture-swap-source.runner .capture-swap.output "$$" "$forged_claim_identity" 1024 -- /bin/printf 'pinned helper result')
exec 9<&-
exec 6<&-
exec 8<&-
exec 7<&-
IFS=$'\t' read -r capture_swap_state capture_swap_result capture_swap_rc capture_swap_truncated _ <<< "$capture_swap"
[ "$capture_swap_state" = captured ] && [ "$capture_swap_result" = capture-swap-source.1.result ] \
  && [ "$capture_swap_rc" = 0 ] && [ "$capture_swap_truncated" = 0 ] \
  || fail "pinned capture helper did not report its captured result"
assert_present "$TMP_ROOT/capture-swap-real-inbox/capture-swap-source.1.result" \
  "pinned capture helper lost evidence after an inbox substitution"
[ -z "$(find "$TMP_ROOT/capture-swap-outside" -mindepth 1 -print -quit)" ] \
  || fail "capture helper reopened a substituted inbox pathname"
pass "capture helper retains the inherited inbox descriptor before publication"
H_LEGACY_LINK="$HOMES/legacy-link"; new_home "$H_LEGACY_LINK"
LEGACY_REAL_STATE="$TMP_ROOT/legacy-real-state"
LEGACY_LINK_STATE="$TMP_ROOT/legacy-state-link"
mkdir "$LEGACY_REAL_STATE"
ln -s "$LEGACY_REAL_STATE" "$LEGACY_LINK_STATE"
FM_HOME="$H_LEGACY_LINK" FM_STATE_OVERRIDE="$LEGACY_LINK_STATE" \
  "$PROCEVENT" register lavish legacy-link-source -- /bin/echo legacy-link >/dev/null
FM_HOME="$H_LEGACY_LINK" FM_STATE_OVERRIDE="$LEGACY_LINK_STATE" \
  "$PROCEVENT" start legacy-link-source >/dev/null
assert_present "$LEGACY_REAL_STATE/procevent-inbox/legacy-link-source.1.result" \
  "an absent-registry built-in capture no longer accepts its legacy state path"
pass "absent-registry built-in capture retains its legacy state-path behavior"
mv "$STATE_OVERRIDE/procevent-inbox" "$TMP_ROOT/override-real-inbox"
ln -s "$TMP_ROOT/override-real-inbox" "$STATE_OVERRIDE/procevent-inbox"
expect_failure "traverses a symbolic link" env FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" \
  "$PROCEVENT" classify "$STATE_OVERRIDE/procevent-inbox/override-source.1.result"
rm "$STATE_OVERRIDE/procevent-inbox"
mv "$TMP_ROOT/override-real-inbox" "$STATE_OVERRIDE/procevent-inbox"
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$PROCEVENT" retire override-source --if-owner "$override_owner" >/dev/null
FM_HOME="$H_STATE_OVERRIDE" FM_STATE_OVERRIDE="$STATE_OVERRIDE" "$HOST" retire-binding org.example.flow --if-binding-digest "$override_bind_digest" >/dev/null
pass "overridden state confines extension work and captured-result operations"

H_SWEEP="$HOMES/sweep"; new_home "$H_SWEEP"
bind_package "$H_SWEEP" "$P_FLOW" ext-flow >/dev/null
FM_HOME="$H_SWEEP" "$PROCEVENT" register-extension ext-flow sweep-source --config-ref good >/dev/null
assert_contains "$(FM_HOME="$H_SWEEP" "$PROCEVENT" sweep-home)" "swept: attempted=1" \
  "home sweep did not use the extension registration's owner identity"
assert_absent "$H_SWEEP/state/procevent/sweep-source.source" "home sweep retained an extension registration"
pass "bounded home sweep retires an extension source through its exact owner token"

H_LEGACY="$HOMES/legacy"; mkdir -p "$H_LEGACY/state"
FM_HOME="$H_LEGACY" "$PROCEVENT" register lavish legacy-source -- /bin/echo legacy >/dev/null
expect_failure "does not match the expected owner" env FM_HOME="$H_LEGACY" "$PROCEVENT" retire legacy-source --if-matches lavish -- /bin/echo replacement
assert_present "$H_LEGACY/state/procevent/legacy-source.source" "legacy conditional mismatch retired the registration"
FM_HOME="$H_LEGACY" "$PROCEVENT" retire legacy-source --if-matches lavish -- /bin/echo legacy >/dev/null
pass "legacy built-in registrations retain behavior and gain exact conditional retirement"
fi

# --- static launch barrier and signal/crash cleanup --------------------------
if section_enabled lifecycle-invocation-cleanup; then
P_INVOCATION_CLEANUP="$PACKAGES/invocation-cleanup"
make_package "$P_INVOCATION_CLEANUP" org.example.invocation-cleanup ext-invocation-cleanup
H_INVOCATION_CLEANUP="$HOMES/invocation-cleanup"; new_home "$H_INVOCATION_CLEANUP"
cleanup_bind=$(bind_package "$H_INVOCATION_CLEANUP" "$P_INVOCATION_CLEANUP" ext-invocation-cleanup)
cleanup_binding_digest=$(printf '%s\n' "$cleanup_bind" | sed -n 's/^binding-digest: //p')
cleanup_resolution=$(FM_HOME="$H_INVOCATION_CLEANUP" "$HOST" resolve-process-event ext-invocation-cleanup)
IFS=$'\t' read -r cleanup_schema cleanup_id cleanup_version cleanup_cap cleanup_package cleanup_binding cleanup_extra <<< "$cleanup_resolution"
[ "$cleanup_schema" = fm-extension-process-event-resolution.v1 ] && [ -z "$cleanup_extra" ] \
  || fail "cleanup resolution record is malformed: $cleanup_resolution"

invoke_cleanup() {  # <config-ref> [host command...]
  local config_ref=$1
  shift
  FM_HOME="$H_INVOCATION_CLEANUP" "$@" process-event ext-invocation-cleanup source.poll \
    --source-id invocation-cleanup-source --config-ref "$config_ref" \
    --expect-extension "$cleanup_id" --expect-version "$cleanup_version" \
    --expect-capability-version "$cleanup_cap" \
    --expect-package-digest "$cleanup_package" --expect-binding-digest "$cleanup_binding"
}

first_invocation_owner() {  # <home>
  local candidate
  for candidate in "$1/state/extension-invocations"/*.owner.json; do
    [ -f "$candidate" ] || continue
    printf '%s\n' "$candidate"
    return 0
  done
  return 1
}

wait_for_invocation_owner() {  # <home>
  local candidate
  for _ in $(seq 1 200); do
    candidate=$(first_invocation_owner "$1" 2>/dev/null || true)
    [ -n "$candidate" ] && { printf '%s\n' "$candidate"; return 0; }
    sleep 0.01
  done
  return 1
}

owner_group_pid() {  # <owner-file>
  node -e 'const fs=require("fs");const value=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));if(value.phase!=="group"||!Number.isSafeInteger(value.group_pid))process.exit(1);process.stdout.write(String(value.group_pid));' "$1"
}

guarded_out=$(invoke_cleanup guarded node --disallow-code-generation-from-strings "$HOST")
assert_contains "$guarded_out" "external evidence: guarded" \
  "the tracked static launch barrier failed under Node's no-dynamic-code guard"
pass "extension launch uses a tracked static core barrier without dynamic code evaluation"

signal_state="$H_INVOCATION_CLEANUP/state/extensions/org.example.invocation-cleanup"
rm -f "$signal_state/descendant.pid"
FM_HOME="$H_INVOCATION_CLEANUP" "$HOST" process-event ext-invocation-cleanup source.poll \
  --source-id invocation-cleanup-source --config-ref timeout \
  --expect-extension "$cleanup_id" --expect-version "$cleanup_version" \
  --expect-capability-version "$cleanup_cap" \
  --expect-package-digest "$cleanup_package" --expect-binding-digest "$cleanup_binding" \
  > "$TMP_ROOT/invocation-signal.out" 2>&1 &
signal_cleanup_host_pid=$!
wait_for_file "$signal_state/descendant.pid" || fail "signal cleanup fixture never started its descendant"
signal_owner=$(wait_for_invocation_owner "$H_INVOCATION_CLEANUP") \
  || fail "signal cleanup fixture published no invocation owner"
signal_cleanup_group_pid=$(owner_group_pid "$signal_owner") \
  || fail "signal cleanup fixture published no exact process group"
kill -TERM "$signal_cleanup_host_pid" 2>/dev/null || fail "cannot interrupt the active extension host"
signal_cleanup_rc=0
wait "$signal_cleanup_host_pid" || signal_cleanup_rc=$?
signal_cleanup_host_pid=
[ "$signal_cleanup_rc" -ne 0 ] || fail "interrupted extension host unexpectedly succeeded"
if kill -0 -"$signal_cleanup_group_pid" 2>/dev/null; then
  fail "interrupted extension host exited before its exact process group was gone"
fi
signal_descendant=$(cat "$signal_state/descendant.pid")
kill -0 "$signal_descendant" 2>/dev/null && fail "signal cleanup left the extension descendant alive"
signal_cleanup_group_pid=
if first_invocation_owner "$H_INVOCATION_CLEANUP" >/dev/null 2>&1; then
  fail "successful signal cleanup retained stale invocation ownership"
fi
pass "signal interruption proves exact invocation-group extinction before host exit"

crash_marker="$TMP_ROOT/invocation-crash.marker"
crash_cleanup_release="$TMP_ROOT/invocation-crash.release"
crash_config="active-block|$crash_marker|$crash_cleanup_release"
FM_HOME="$H_INVOCATION_CLEANUP" "$HOST" process-event ext-invocation-cleanup source.poll \
  --source-id invocation-cleanup-source --config-ref "$crash_config" \
  --expect-extension "$cleanup_id" --expect-version "$cleanup_version" \
  --expect-capability-version "$cleanup_cap" \
  --expect-package-digest "$cleanup_package" --expect-binding-digest "$cleanup_binding" \
  > "$TMP_ROOT/invocation-crash.out" 2>&1 &
crash_cleanup_host_pid=$!
wait_for_file "$crash_marker" || fail "crash cleanup fixture never entered extension code"
crash_owner=$(wait_for_invocation_owner "$H_INVOCATION_CLEANUP") \
  || fail "crash cleanup fixture published no invocation owner"
crash_cleanup_group_pid=$(owner_group_pid "$crash_owner") \
  || fail "crash cleanup fixture published no exact process group"
crash_entry_pid=$(cat "$crash_marker")
kill -KILL "$crash_cleanup_host_pid" 2>/dev/null || fail "cannot stop the extension host at the crash cut"
wait "$crash_cleanup_host_pid" 2>/dev/null || true
crash_cleanup_host_pid=
kill -0 -"$crash_cleanup_group_pid" 2>/dev/null \
  || fail "host crash did not leave the tracked invocation group for recovery"
FM_HOME="$H_INVOCATION_CLEANUP" "$HOST" retire-binding org.example.invocation-cleanup \
  --if-binding-digest "$cleanup_binding_digest" >/dev/null
if kill -0 -"$crash_cleanup_group_pid" 2>/dev/null; then
  fail "binding retirement completed while its tracked invocation group survived"
fi
kill -0 "$crash_entry_pid" 2>/dev/null && fail "binding retirement left the crashed host's extension process alive"
crash_cleanup_group_pid=
crash_cleanup_release=
assert_absent "$H_INVOCATION_CLEANUP/config/extensions.d/org.example.invocation-cleanup.json" \
  "identity-safe retirement retained the recovered binding"
pass "host-crash recovery retires only after exact invocation-group extinction"
fi

if section_enabled lifecycle-flow lifecycle-orphan-readiness; then
# Ownerless readiness records have no source selector or signalling authority.
# Use only private fixture groups, and keep an unrelated live PID as a reuse case.
P_INVOCATION_CLEANUP="$PACKAGES/orphan-cleanup"
make_package "$P_INVOCATION_CLEANUP" org.example.invocation-cleanup ext-invocation-cleanup
H_ORPHAN_READY="$HOMES/orphan-ready"; new_home "$H_ORPHAN_READY"
fm_test_track_procevent_home "$H_ORPHAN_READY" "$FM_PROCEVENT_CLAIM_ROOT"
bind_package "$H_ORPHAN_READY" "$P_INVOCATION_CLEANUP" ext-invocation-cleanup >/dev/null
for orphan_source in orphan-first orphan-second; do
  FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" register-extension ext-invocation-cleanup "$orphan_source" --config-ref silent-result >/dev/null
done
orphan_root="$H_ORPHAN_READY/state/extension-invocations"
mkdir -p "$orphan_root"
chmod 0700 "$orphan_root"
orphan_token="sha256:$(printf 'a%.0s' {1..64})"
orphan_ready="$orphan_root/${orphan_token#sha256:}.ready.json"
write_orphan_ready() {  # <token> <pid> <identity>
  node - "$orphan_ready" "$1" "$2" "$3" <<'JS'
const fs = require("fs");
const [file, token, pid, identity] = process.argv.slice(2);
fs.writeFileSync(file, JSON.stringify({schema: "firstmate.extension-invocation-ready.v1",
  token, group_pid: Number(pid), group_identity: identity}) + "\n", {mode: 0o600});
JS
}
crash_cleanup_group_pid=$(node - "$ROOT/bin/fm-extension-launch-barrier.mjs" "$orphan_token" <<'JS'
const {spawn} = require("child_process");
const child = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)", ...process.argv.slice(2)],
  {detached: true, stdio: "ignore"});
console.log(child.pid);
child.unref();
JS
)
write_orphan_ready "$orphan_token" "$crash_cleanup_group_pid" "barrier-token:$orphan_token"
expect_failure "process-cleanup-failed" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
kill -0 -"$crash_cleanup_group_pid" 2>/dev/null || fail "ownerless cleanup signalled a live fixture group"
assert_present "$orphan_ready" "ownerless cleanup discarded a live group's readiness"
write_orphan_ready "$orphan_token" "$$" "barrier-token:$orphan_token"
expect_failure "process-cleanup-failed" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
kill -0 "$$" 2>/dev/null || fail "ownerless cleanup signalled a reused PID"
kill -0 -"$crash_cleanup_group_pid" 2>/dev/null || fail "ownerless cleanup signalled an unrelated group"
orphan_dead_pid=$crash_cleanup_group_pid
kill -TERM -"$crash_cleanup_group_pid" 2>/dev/null || fail "cannot stop private orphan fixture group"
for _ in $(seq 1 200); do
  kill -0 -"$crash_cleanup_group_pid" 2>/dev/null || break
  sleep 0.1
done
kill -0 -"$crash_cleanup_group_pid" 2>/dev/null && fail "private orphan fixture group did not exit"
crash_cleanup_group_pid=
write_orphan_ready "sha256:$(printf 'b%.0s' {1..64})" "$orphan_dead_pid" "barrier-token:$orphan_token"
expect_failure "process-cleanup-failed" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
write_orphan_ready "$orphan_token" "$orphan_dead_pid" "unprovable-identity"
expect_failure "process-cleanup-failed" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
write_orphan_ready "$orphan_token" "$orphan_dead_pid" "barrier-token:$orphan_token"
chmod 0644 "$orphan_ready"
expect_failure "private host-owned file" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
chmod 0600 "$orphan_ready"
mv "$orphan_ready" "$TMP_ROOT/orphan-outside.json"
ln -s "$TMP_ROOT/orphan-outside.json" "$orphan_ready"
expect_failure "private host-owned file" env FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations
assert_present "$TMP_ROOT/orphan-outside.json" "cleanup followed an unsafe readiness symlink"
mv "$orphan_ready" "$TMP_ROOT/orphan-symlink"
mv "$TMP_ROOT/orphan-outside.json" "$orphan_ready"
orphan_cleaned=$(FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations --source-id orphan-first)
assert_contains "$orphan_cleaned" "cleaned-invocations: 1" "dead exact-token orphan readiness was not reclaimed"
assert_absent "$orphan_ready" "dead orphan readiness survived successful cleanup"
pass "ownerless readiness recovers only dead exact-token groups and refuses unsafe or unproved ownership"

# One malformed residue must neither silently disable both sources nor wake on
# every reconcile.
write_orphan_ready "$orphan_token" "$orphan_dead_pid" "unprovable-identity"
for _ in 1 2; do
  orphan_reconcile=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" reconcile)
  assert_contains "$orphan_reconcile" "uncertain=2" "unsafe residue did not preserve both sources"
done
for orphan_source in orphan-first orphan-second; do
  orphan_wakes=$(wake_payloads "$H_ORPHAN_READY" | grep -c "source $orphan_source .*cleanup" || true)
  [ "$orphan_wakes" -eq 1 ] || fail "cleanup uncertainty must wake once per source failure episode: $orphan_wakes"
done
write_orphan_ready "$orphan_token" "$orphan_dead_pid" "barrier-token:$orphan_token"
orphan_reconcile=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" reconcile)
assert_contains "$orphan_reconcile" "started=2" "dead orphan readiness blocked recovery of two extension sources"
assert_contains "$orphan_reconcile" "uncertain=0" "recovered extension sources remained uncertain"
# Reconcile confirms each launch, not its completion. Each recovered runner owns
# its poll, capture, silent verdict, and terminal retirement, and the two take
# their verdicts in turn under this home's extension lifecycle lock, so a loaded
# host stretches the pair past any fixed marker poll. Wait for the recorded
# runner groups to exit instead, and stop any survivor before failing.
orphan_runners=()
for orphan_source in orphan-first orphan-second; do
  orphan_runner=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/$orphan_source.claim" 2>/dev/null || true)
  [ -z "$orphan_runner" ] || orphan_runners+=("$orphan_source:$orphan_runner")
done
orphan_wait_seconds=$EXTENSION_SECTION_LANE_MAX_SECONDS
if [ -n "${FM_EXTENSION_BINDING_LANE_DEADLINE_EPOCH:-}" ]; then
  orphan_remaining=$((FM_EXTENSION_BINDING_LANE_DEADLINE_EPOCH - $(date +%s) - 3))
  [ "$orphan_remaining" -ge "$orphan_wait_seconds" ] || orphan_wait_seconds=$orphan_remaining
  [ "$orphan_wait_seconds" -ge 1 ] || orphan_wait_seconds=1
fi
orphan_deadline=$((SECONDS + orphan_wait_seconds))
while :; do
  orphan_live=()
  for orphan_runner in "${orphan_runners[@]+"${orphan_runners[@]}"}"; do
    kill -0 -"${orphan_runner#*:}" 2>/dev/null && orphan_live+=("$orphan_runner")
  done
  [ "${#orphan_live[@]}" -gt 0 ] && [ "$SECONDS" -lt "$orphan_deadline" ] || break
  sleep 0.1
done
if [ "${#orphan_live[@]}" -gt 0 ]; then
  # Killing the runner groups strands their detached invocation groups, which
  # the home sweep's invocation cleanup then reclaims as host-crash residue.
  for orphan_runner in "${orphan_live[@]}"; do
    kill -KILL -"${orphan_runner#*:}" 2>/dev/null || true
  done
  FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" sweep-home >/dev/null 2>&1 || true
  fail "recovered source ${orphan_live[*]%%:*} did not finish within ${orphan_wait_seconds}s"
fi
for orphan_source in orphan-first orphan-second; do
  assert_present "$H_ORPHAN_READY/state/procevent-inbox/$orphan_source.1.handled" \
    "recovered source $orphan_source never handled its private result"
  assert_absent "$H_ORPHAN_READY/state/procevent/$orphan_source.source" "recovered terminal source did not retire"
  assert_absent "$FM_PROCEVENT_CLAIM_ROOT/$orphan_source.claim" "recovered terminal source retained its claim"
done
assert_absent "$orphan_ready" "reconcile did not reclaim dead orphan readiness"
pass "reconcile durably announces cleanup uncertainty once and recovers both extension sources"

surface_orphan_wakes() {
  FM_HOME="$H_ORPHAN_READY" bash -c '
    . "$1/bin/fm-watch.sh"
    procevent_surface_queued
  ' _ "$ROOT"
}
for orphan_recovery in attached live; do
  orphan_source="orphan-$orphan_recovery"
  orphan_config=no-result
  if [ "$orphan_recovery" = live ]; then
    active_runner_marker="$TMP_ROOT/orphan-live.marker"
    active_runner_release="$TMP_ROOT/orphan-live.release"
    orphan_config="no-result-block|$active_runner_marker|$active_runner_release"
  fi
  orphan_registration=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" register-extension ext-invocation-cleanup "$orphan_source" --config-ref "$orphan_config") \
    || fail "could not register $orphan_source"
  orphan_owner=$(printf '%s\n' "$orphan_registration" | sed -n 's/^owner-token: //p')
  [ -n "$orphan_owner" ] || fail "registration returned no retirement identity for $orphan_source"
  write_orphan_ready "$orphan_token" "$orphan_dead_pid" "unprovable-identity"
  for _ in 1 2; do
    orphan_reconcile=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" reconcile)
    assert_contains "$orphan_reconcile" "uncertain=1" "cleanup episode did not preserve $orphan_source"
  done
  orphan_wakes=$(wake_payloads "$H_ORPHAN_READY" | grep -c "source $orphan_source .*cleanup" || true)
  [ "$orphan_wakes" -eq 1 ] || fail "first cleanup episode must wake once for $orphan_source: $orphan_wakes"
  orphan_headline=$(surface_orphan_wakes) || fail "watcher could not deliver cleanup failure wakes"
  assert_contains "$orphan_headline" "process-event source failed to start:" "cleanup failure delivered the wrong headline"
  assert_not_contains "$orphan_headline" "process-event result captured:" "cleanup uncertainty was presented as captured evidence"
  assert_contains "$orphan_headline" "procevent:$orphan_source:launch-failed:" "watcher omitted $orphan_source cleanup failure"
  cp "$H_ORPHAN_READY/state/procevent/.$orphan_source.cleanup-failed" "$TMP_ROOT/orphan.previous-episode" \
    || fail "could not retain the previous cleanup episode"
  write_orphan_ready "$orphan_token" "$orphan_dead_pid" "barrier-token:$orphan_token"
  FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations >/dev/null
  if [ "$orphan_recovery" = attached ]; then
    FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" start "$orphan_source" > "$TMP_ROOT/orphan-attached.out" \
      || fail "attached start did not recover after public cleanup"
  else
    FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" start "$orphan_source" > "$TMP_ROOT/orphan-live.out" 2>&1 &
    active_runner_pid=$!
    wait_for_file "$active_runner_marker" || fail "live recovery source never entered extension code"
    cp "$TMP_ROOT/orphan.previous-episode" "$H_ORPHAN_READY/state/procevent/.$orphan_source.cleanup-failed" \
      || fail "could not restore a prior cleanup episode for live-owner recovery"
    orphan_reconcile=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" reconcile)
    assert_contains "$orphan_reconcile" "uncertain=0" "live-owner recovery remained uncertain"
    assert_absent "$H_ORPHAN_READY/state/procevent/.$orphan_source.cleanup-failed" "live-owner recovery retained a prior cleanup episode"
    touch "$active_runner_release"
    wait "$active_runner_pid" || fail "live recovery source did not complete successfully"
    active_runner_pid=
    active_runner_release=
  fi
  assert_present "$H_ORPHAN_READY/state/procevent/$orphan_source.source" "no-result recovery replaced its registration"
  assert_absent "$H_ORPHAN_READY/state/procevent/.$orphan_source.cleanup-failed" "$orphan_recovery recovery retained its prior cleanup episode"
  write_orphan_ready "$orphan_token" "$orphan_dead_pid" "unprovable-identity"
  for _ in 1 2; do
    orphan_reconcile=$(FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" reconcile)
    assert_contains "$orphan_reconcile" "uncertain=1" "second cleanup episode did not preserve $orphan_source"
  done
  orphan_wakes=$(wake_payloads "$H_ORPHAN_READY" | grep -c "source $orphan_source .*cleanup" || true)
  [ "$orphan_wakes" -eq 2 ] || fail "second cleanup episode must wake again for $orphan_source: $orphan_wakes"
  orphan_headline=$(surface_orphan_wakes) || fail "watcher could not deliver the second cleanup episode"
  assert_contains "$orphan_headline" "process-event source failed to start:" "second cleanup episode delivered the wrong headline"
  assert_not_contains "$orphan_headline" "process-event result captured:" "second cleanup episode was presented as captured evidence"
  assert_contains "$orphan_headline" "procevent:$orphan_source:launch-failed:" "watcher suppressed $orphan_source second cleanup episode"
  assert_equals "$(surface_orphan_wakes)" "" "watcher delivered a cleanup failure more than once"
  write_orphan_ready "$orphan_token" "$orphan_dead_pid" "barrier-token:$orphan_token"
  FM_HOME="$H_ORPHAN_READY" "$HOST" cleanup-invocations >/dev/null
  FM_HOME="$H_ORPHAN_READY" "$PROCEVENT" retire "$orphan_source" --if-owner "$orphan_owner" >/dev/null \
    || fail "could not retire the recovered $orphan_source fixture"
done
pass "attached start and live-owner recovery renew cleanup failure wakes with delivered failure headlines"
fi

# --- independent remote envelope, lifecycle, and retirement paths -----------
if section_enabled remote-envelope remote-activation remote-lifecycle remote-retirement; then
wrong_binding_digest="sha256:$(printf '0%.0s' {1..64})"
P_REMOTE="$PACKAGES/remote-transport"
make_package "$P_REMOTE" org.example.remote ext-remote
mkdir "$P_REMOTE/nested"
printf 'nested transfer evidence\n' > "$P_REMOTE/nested/evidence.txt"
chmod 0755 "$P_REMOTE/nested"
chmod 0644 "$P_REMOTE/nested/evidence.txt"
H_REMOTE_CONTROL="$HOMES/remote-control"
H_REMOTE="$HOMES/remote-home"
REMOTE_ROOT="$TMP_ROOT/remote-root"
REMOTE_FAKEBIN=$(fm_fakebin "$TMP_ROOT/remote-fakebin")
REMOTE_SSH_COUNT="$TMP_ROOT/remote-ssh.count"
mkdir -p "$H_REMOTE_CONTROL/data" "$H_REMOTE" "$REMOTE_ROOT/bin"
printf 'fixture\n' > "$REMOTE_ROOT/AGENTS.md"
for remote_file in \
  fm-extension.mjs fm-extension-deadline.mjs fm-extension-launch-barrier.mjs fm-extension.sh fm-procevent.sh fm-procevent-lib.sh fm-procevent-extension-capture.pl fm-procevent-lavish.sh \
  fm-pr-lib.sh fm-wake-lib.sh fm-path-lib.sh fm-remote-entrypoint.sh fm-remote-job-lib.sh \
  fm-remote-job-worker.sh; do
  cp "$ROOT/bin/$remote_file" "$REMOTE_ROOT/bin/$remote_file"
done
chmod +x "$REMOTE_ROOT/bin"/fm-*.sh "$REMOTE_ROOT/bin/fm-extension.mjs" "$REMOTE_ROOT/bin/fm-extension-launch-barrier.mjs"
git -C "$REMOTE_ROOT" init -q -b main
git -C "$REMOTE_ROOT" config user.email test@example.com
git -C "$REMOTE_ROOT" config user.name Test
git -C "$REMOTE_ROOT" add AGENTS.md bin
git -C "$REMOTE_ROOT" commit -qm 'remote extension fixture'
cat > "$H_REMOTE_CONTROL/data/secondmates.md" <<EOF
- ios - remote extension home (host: remote-mac; root: $REMOTE_ROOT; home: $H_REMOTE; scope: extension test; projects: none; added 2026-08-27)
EOF
cat > "$REMOTE_FAKEBIN/fake-ssh" <<'SH'
#!/usr/bin/env bash
count=$(cat "$FM_FAKE_SSH_COUNT" 2>/dev/null || echo 0)
printf '%s\n' "$((count + 1))" > "$FM_FAKE_SSH_COUNT"
while [ "$#" -gt 0 ]; do
  case "$1" in -o) shift 2 ;; --) shift; break ;; *) exit 90 ;; esac
done
host=$1
entry=$2
shift 2
[ "$host" = remote-mac ] || exit 91
[ "$entry" = fm-remote-entrypoint.sh ] || exit 92
exec "$FM_FAKE_REMOTE_ENTRYPOINT" "$@"
SH
chmod +x "$REMOTE_FAKEBIN/fake-ssh"
remote_on() {
  FM_HOME="$H_REMOTE_CONTROL" \
  FM_ROOT_OVERRIDE="$REMOTE_ROOT" \
  FM_SSH_BIN="$REMOTE_FAKEBIN/fake-ssh" \
  FM_FAKE_SSH_COUNT="$REMOTE_SSH_COUNT" \
  FM_FAKE_REMOTE_ENTRYPOINT="$REMOTE_ROOT/bin/fm-remote-entrypoint.sh" \
  FM_REMOTE_JOB_PLATFORM_OVERRIDE=Linux \
  FM_REMOTE_JOB_STATE_ROOT="$TMP_ROOT/remote-jobs" \
  "$ROOT/bin/fm-on.sh" --stdin ios "$@"
}
remote_controller() {
  FM_HOME="$H_REMOTE_CONTROL" \
  FM_ROOT_OVERRIDE="$REMOTE_ROOT" \
  FM_SSH_BIN="$REMOTE_FAKEBIN/fake-ssh" \
  FM_FAKE_SSH_COUNT="$REMOTE_SSH_COUNT" \
  FM_FAKE_REMOTE_ENTRYPOINT="$REMOTE_ROOT/bin/fm-remote-entrypoint.sh" \
  FM_REMOTE_JOB_PLATFORM_OVERRIDE=Linux \
  FM_REMOTE_JOB_STATE_ROOT="$TMP_ROOT/remote-jobs" \
  "$@"
}
remote_receive_file() {
  local file=$1 adapter=$2
  remote_on fm-extension.sh receive-transfer-bind \
    --adapter "$adapter" --trust-same-user-code < "$file"
}
remote_direct() {
  local command=$1
  shift
  FM_HOME="$H_REMOTE" \
  FM_ROOT_OVERRIDE="$REMOTE_ROOT" \
  FM_REMOTE_JOB_PLATFORM_OVERRIDE=Linux \
  FM_REMOTE_JOB_STATE_ROOT="$TMP_ROOT/remote-jobs" \
  "$REMOTE_ROOT/bin/$command" "$@"
}
remote_receive_file_direct() {
  local file=$1 adapter=$2
  remote_direct fm-extension.sh receive-transfer-bind \
    --adapter "$adapter" --trust-same-user-code < "$file"
}

if section_enabled remote-envelope; then
REMOTE_TRANSFER="$TMP_ROOT/remote-transfer.json"
FM_HOME="$H_REMOTE_CONTROL" "$HOST" pack-transfer "$P_REMOTE" > "$REMOTE_TRANSFER"
mutate_transfer() {
  node - "$REMOTE_TRANSFER" "$1" "$2" <<'JS'
const fs = require("fs");
const crypto = require("crypto");
const value = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const scenario = process.argv[3];
if (scenario === "traversal") value.manifest.entries[0].path = "../escape";
if (scenario === "symlink") value.manifest.entries[0].type = "symlink";
if (scenario === "hash") value.payloads[value.payloads.findIndex((entry) => typeof entry === "string")] = "eA==";
if (scenario === "size") value.manifest.entries.find((entry) => entry.type === "file").size = 262145;
if (scenario === "duplicate") value.manifest.entries[1].path = value.manifest.entries[0].path;
if (scenario === "unexpected") {
  const index = value.manifest.entries.findIndex((entry) => entry.type === "directory");
  value.manifest.entries.splice(index, 1);
  value.payloads.splice(index, 1);
  value.manifest.entry_count -= 1;
}
if (scenario !== "hash") {
  const canonical = (entry) => Array.isArray(entry)
    ? `[${entry.map(canonical).join(",")}]`
    : entry && typeof entry === "object"
      ? `{${Object.keys(entry).sort().map((key) => `${JSON.stringify(key)}:${canonical(entry[key])}`).join(",")}}`
      : JSON.stringify(entry);
  value.manifest_sha256 = `sha256:${crypto.createHash("sha256").update(canonical(value.manifest)).digest("hex")}`;
}
fs.writeFileSync(process.argv[4], JSON.stringify(value));
JS
}
for transfer_case in traversal symlink hash size duplicate unexpected; do
  bad_transfer="$TMP_ROOT/remote-transfer-$transfer_case.json"
  mutate_transfer "$transfer_case" "$bad_transfer"
  case "$transfer_case" in
    traversal) transfer_error="path-unsafe" ;;
    symlink) transfer_error="package-invalid" ;;
    hash) transfer_error=integrity-mismatch ;;
    size|duplicate) transfer_error=schema-invalid ;;
    unexpected) transfer_error="package-invalid" ;;
  esac
  expect_failure "$transfer_error" remote_receive_file_direct "$bad_transfer" ext-remote
done
printf '{broken' > "$TMP_ROOT/remote-transfer-malformed.json"
head -c 80 "$REMOTE_TRANSFER" > "$TMP_ROOT/remote-transfer-truncated.json"
expect_failure "package transfer has a non-string object key" remote_receive_file "$TMP_ROOT/remote-transfer-malformed.json" ext-remote
expect_failure "json-invalid" remote_receive_file_direct "$TMP_ROOT/remote-transfer-truncated.json" ext-remote
assert_absent "$H_REMOTE/config/extensions.d/org.example.remote.json" "invalid transfer published a remote binding"
if find "$H_REMOTE/data/extensions/staging" -name '.receive-*' -print 2>/dev/null | grep -q .; then
  fail "invalid transfer left a partial receive directory"
fi
pass "remote receiver rejects malformed, truncated, traversal, link, hash, size, duplicate, and incomplete envelopes"

P_REMOTE_PARTIAL="$PACKAGES/remote-partial"
make_package "$P_REMOTE_PARTIAL" org.example.remote-partial ext-remote-partial handshake-malformed
FM_HOME="$H_REMOTE_CONTROL" "$HOST" pack-transfer "$P_REMOTE_PARTIAL" > "$TMP_ROOT/remote-partial.json"
expect_failure "error[" remote_receive_file_direct "$TMP_ROOT/remote-partial.json" ext-remote-partial
assert_absent "$H_REMOTE/config/extensions.d/org.example.remote-partial.json" "failed remote activation published a binding"
if find "$H_REMOTE/data/extensions/staging/org.example.remote-partial" -mindepth 2 -maxdepth 2 -type d -print 2>/dev/null | grep -q .; then
  fail "failed remote activation left a published staging package"
fi
find "$H_REMOTE/data/extensions/retired-staging/org.example.remote-partial" -mindepth 2 -maxdepth 2 -type d -print 2>/dev/null | grep -q . \
  || fail "failed remote activation was not retained reversibly"
pass "failed activation cannot partially publish and retains exact transfer evidence"

[ "$(cat "$REMOTE_SSH_COUNT")" -eq 1 ] || fail "remote malformed-envelope transport crossing was not retained"
fi

if section_enabled remote-activation; then
remote_bind=$(remote_controller "$ROOT/bin/fm-extension.sh" remote-bind ios "$P_REMOTE" --adapter ext-remote --trust-same-user-code)
assert_contains "$remote_bind" "bound: org.example.remote@1.2.3" "remote transport did not publish the binding"
remote_transfer_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^transfer-digest: //p')
case "$remote_transfer_digest" in sha256:*) ;; *) fail "remote bind returned no transfer identity" ;; esac
remote_binding_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^binding-digest: //p')
case "$remote_binding_digest" in sha256:*) ;; *) fail "remote bind returned no binding retirement identity" ;; esac
assert_contains "$(remote_direct fm-extension.sh list)" "org.example.remote" "addressed remote home did not discover the transferred binding"
remote_package_root=$(binding_value "$H_REMOTE" org.example.remote package_root)
case "$remote_package_root" in "$H_REMOTE"/data/extensions/packages/*) ;; *) fail "remote package escaped its addressed home: $remote_package_root" ;; esac
remote_source_root=$(binding_value "$H_REMOTE" org.example.remote source.path)
case "$remote_source_root" in "$H_REMOTE"/data/extensions/staging/*/package) ;; *) fail "remote binding reused a controller-local pathname: $remote_source_root" ;; esac
[ "$remote_source_root" != "$P_REMOTE" ] || fail "remote binding did not cross the serialized path boundary"
remote_active_marker="$TMP_ROOT/remote-active.marker"
remote_active_release="$TMP_ROOT/remote-active.release"
remote_active_config="active-block|$remote_active_marker|$remote_active_release"
remote_direct fm-procevent.sh register-extension ext-remote remote-active-source --config-ref "$remote_active_config" >/dev/null
remote_direct fm-procevent.sh reconcile >/dev/null
wait_for_file "$remote_active_marker" || fail "remote active runner never reached its addressed-home poll"
expect_failure "prior runner remains active" remote_direct fm-procevent.sh register-extension ext-remote remote-active-source --config-ref replacement
expect_failure "prior runner remains active" remote_direct fm-procevent.sh register lavish remote-active-source -- /bin/echo remote-built-in
touch "$remote_active_release"
remote_active_release=
for _ in $(seq 1 400); do
  [ ! -e "$H_REMOTE/state/procevent/remote-active-source.source" ] && break
  sleep 0.01
done
assert_absent "$H_REMOTE/state/procevent/remote-active-source.source" "remote terminal runner retained its registration"
remote_direct fm-procevent.sh handled remote-active-source 1 >/dev/null
remote_direct fm-procevent.sh register lavish remote-active-source -- /bin/echo remote-built-in >/dev/null
remote_direct fm-procevent.sh retire remote-active-source --if-matches lavish -- /bin/echo remote-built-in >/dev/null
remote_active_replacement=$(remote_direct fm-procevent.sh register-extension ext-remote remote-active-source --config-ref replacement)
remote_active_owner=$(printf '%s\n' "$remote_active_replacement" | sed -n 's/^owner-token: //p')
remote_direct fm-procevent.sh retire remote-active-source --if-owner "$remote_active_owner" >/dev/null
pass "remote registration owner transitions observe the active runner boundary"
fi

if section_enabled remote-lifecycle; then
remote_bind=$(remote_controller "$ROOT/bin/fm-extension.sh" remote-bind ios "$P_REMOTE" --adapter ext-remote --trust-same-user-code)
assert_contains "$remote_bind" "bound: org.example.remote@1.2.3" "remote transport did not publish the binding"
remote_transfer_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^transfer-digest: //p')
case "$remote_transfer_digest" in sha256:*) ;; *) fail "remote bind returned no transfer identity" ;; esac
remote_binding_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^binding-digest: //p')
case "$remote_binding_digest" in sha256:*) ;; *) fail "remote bind returned no binding retirement identity" ;; esac
assert_contains "$(remote_direct fm-extension.sh list)" "org.example.remote" "addressed remote home did not discover the transferred binding"
remote_package_root=$(binding_value "$H_REMOTE" org.example.remote package_root)
case "$remote_package_root" in "$H_REMOTE"/data/extensions/packages/*) ;; *) fail "remote package escaped its addressed home: $remote_package_root" ;; esac
remote_source_root=$(binding_value "$H_REMOTE" org.example.remote source.path)
case "$remote_source_root" in "$H_REMOTE"/data/extensions/staging/*/package) ;; *) fail "remote binding reused a controller-local pathname: $remote_source_root" ;; esac
[ "$remote_source_root" != "$P_REMOTE" ] || fail "remote binding did not cross the serialized path boundary"
remote_registration=$(remote_direct fm-procevent.sh register-extension ext-remote remote-source --config-ref remote-result)
remote_owner=$(printf '%s\n' "$remote_registration" | sed -n 's/^owner-token: //p')
expect_failure "still owns process-event registration" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
remote_resolution=$(remote_direct fm-extension.sh resolve-process-event ext-remote)
IFS=$'\t' read -r _remote_schema remote_id remote_version remote_capability remote_package remote_binding remote_extra <<< "$remote_resolution"
[ -z "$remote_extra" ] || fail "remote resolution returned extra fields"
remote_result=$(remote_direct fm-extension.sh process-event ext-remote source.poll \
  --expect-extension "$remote_id" \
  --expect-version "$remote_version" \
  --expect-capability-version "$remote_capability" \
  --expect-package-digest "$remote_package" \
  --expect-binding-digest "$remote_binding" \
  --source-id remote-source \
  --config-ref remote-result \
  --request-id "sha256:$(printf '6%.0s' {1..64})")
assert_contains "$remote_result" "external evidence: remote-result" "addressed remote invocation returned no extension evidence"
remote_direct fm-procevent.sh start remote-source >/dev/null
assert_present "$H_REMOTE/state/procevent-inbox/remote-source.1.result" "remote runner did not capture its extension result"
remote_direct fm-procevent.sh retire remote-source --if-owner "$remote_owner" >/dev/null
assert_absent "$H_REMOTE/state/procevent/remote-source.source" "remote owner-matched retirement left its registration"
expect_failure "unhandled process-event result" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
remote_direct fm-procevent.sh handled remote-source 1 >/dev/null
remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest" >/dev/null
assert_absent "$H_REMOTE/config/extensions.d/org.example.remote.json" "remote lifecycle retirement left its binding discoverable"
[ "$(cat "$REMOTE_SSH_COUNT")" -eq 1 ] || fail "remote lifecycle transport crossing count diverged"
pass "serialized remote binding crosses fm-on through addressed-home capture and retirement"
fi

if section_enabled remote-retirement; then
REMOTE_TRANSFER="$TMP_ROOT/remote-retirement-transfer.json"
FM_HOME="$H_REMOTE_CONTROL" "$HOST" pack-transfer "$P_REMOTE" > "$REMOTE_TRANSFER"
remote_bind=$(remote_receive_file_direct "$REMOTE_TRANSFER" ext-remote)
remote_transfer_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^transfer-digest: //p')
remote_binding_digest=$(printf '%s\n' "$remote_bind" | sed -n 's/^binding-digest: //p')
case "$remote_transfer_digest:$remote_binding_digest" in sha256:*:sha256:*) ;; *) fail "direct remote binding returned incomplete identities" ;; esac
remote_source_root=$(binding_value "$H_REMOTE" org.example.remote source.path)
remote_registration=$(remote_direct fm-procevent.sh register-extension ext-remote remote-source --config-ref remote-result)
remote_owner=$(printf '%s\n' "$remote_registration" | sed -n 's/^owner-token: //p')
remote_resolution=$(remote_direct fm-extension.sh resolve-process-event ext-remote)
IFS=$'\t' read -r _remote_schema remote_id remote_version remote_capability remote_package remote_binding remote_extra <<< "$remote_resolution"
[ -z "$remote_extra" ] || fail "remote retirement resolution returned extra fields"
remote_result=$(remote_direct fm-extension.sh process-event ext-remote source.poll \
  --expect-extension "$remote_id" --expect-version "$remote_version" \
  --expect-capability-version "$remote_capability" --expect-package-digest "$remote_package" \
  --expect-binding-digest "$remote_binding" --source-id remote-source --config-ref remote-result \
  --request-id "sha256:$(printf '6%.0s' {1..64})")
assert_contains "$remote_result" "external evidence: remote-result" "retirement fixture did not invoke its addressed extension"
remote_direct fm-procevent.sh start remote-source >/dev/null
assert_present "$H_REMOTE/state/procevent-inbox/remote-source.1.result" "retirement fixture did not capture its result"
remote_direct fm-procevent.sh retire remote-source --if-owner "$remote_owner" >/dev/null
assert_absent "$H_REMOTE/state/procevent/remote-source.source" "retirement fixture owner retirement left its registration"
remote_stage_root=${remote_source_root%/package}
remote_receipt="$remote_stage_root/receipt.json"
wrong_binding_digest="sha256:$(printf '0%.0s' {1..64})"
expect_failure "unhandled process-event result" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
remote_direct fm-procevent.sh handled remote-source 1 >/dev/null
expect_failure "expected binding identity" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$wrong_binding_digest"
assert_present "$H_REMOTE/config/extensions.d/org.example.remote.json" "stale binding identity retired the remote binding"
expect_failure "no unique staged package" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$wrong_binding_digest" --if-binding-digest "$remote_binding_digest"
cp "$remote_receipt" "$TMP_ROOT/remote-receipt.json"
node - "$remote_receipt" <<'JS'
const fs = require("fs");
const file = process.argv[2];
const value = JSON.parse(fs.readFileSync(file, "utf8"));
value.package_digest = `sha256:${"f".repeat(64)}`;
fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);
JS
chmod 0600 "$remote_receipt"
expect_failure "staged package identity" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
cp "$TMP_ROOT/remote-receipt.json" "$remote_receipt"
chmod 0600 "$remote_receipt"
cp "$remote_source_root/helper.txt" "$TMP_ROOT/remote-helper.txt"
printf 'drifted staged bytes\n' > "$remote_source_root/helper.txt"
expect_failure "staged package identity" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
cp "$TMP_ROOT/remote-helper.txt" "$remote_source_root/helper.txt"
chmod 0644 "$remote_source_root/helper.txt"
remote_version_root=${remote_stage_root%/*}
remote_wrong_version="${remote_version_root%/*}/9.9.9"
mv "$remote_version_root" "$remote_wrong_version"
expect_failure "version directory" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
mv "$remote_wrong_version" "$remote_version_root"
P_REMOTE_OTHER="$PACKAGES/remote-other"
make_package "$P_REMOTE_OTHER" org.example.remote-other ext-remote-other
REMOTE_OTHER_TRANSFER="$TMP_ROOT/remote-other-transfer.json"
FM_HOME="$H_REMOTE_CONTROL" "$HOST" pack-transfer "$P_REMOTE_OTHER" > "$REMOTE_OTHER_TRANSFER"
remote_other_bind=$(remote_receive_file_direct "$REMOTE_OTHER_TRANSFER" ext-remote-other)
remote_other_transfer=$(printf '%s\n' "$remote_other_bind" | sed -n 's/^transfer-digest: //p')
remote_other_binding=$(printf '%s\n' "$remote_other_bind" | sed -n 's/^binding-digest: //p')
remote_binding_path="$H_REMOTE/config/extensions.d/org.example.remote.json"
remote_partial_binding="$remote_stage_root/binding.json"
cp "$remote_binding_path" "$remote_partial_binding"
expect_failure "enabled and partial binding state" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
rm -f "$remote_partial_binding"
cp "$remote_binding_path" "$TMP_ROOT/remote-binding.json"
mv "$remote_binding_path" "$remote_partial_binding"
printf ' ' >> "$remote_partial_binding"
expect_failure "partial binding does not match" remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest"
cp "$TMP_ROOT/remote-binding.json" "$remote_partial_binding"
chmod 0600 "$remote_partial_binding"
remote_direct fm-extension.sh retire-transfer org.example.remote \
  --if-transfer-digest "$remote_transfer_digest" --if-binding-digest "$remote_binding_digest" >/dev/null
assert_absent "$H_REMOTE/data/extensions/staging/org.example.remote/1.2.3/${remote_transfer_digest#sha256:}" "remote staged package was not retired"
assert_present "$H_REMOTE/data/extensions/retired-staging/org.example.remote/1.2.3/${remote_transfer_digest#sha256:}/package" "remote staged package retirement was not reversible"
assert_present "$H_REMOTE/data/extensions/retired-staging/org.example.remote/1.2.3/${remote_transfer_digest#sha256:}/binding.json" "remote enabled binding was not retained with its exact transfer"
assert_absent "$H_REMOTE/config/extensions.d/org.example.remote.json" "remote enabled binding remained discoverable after retirement"
expect_failure "no home-local extension binding" remote_direct fm-extension.sh resolve-process-event ext-remote
assert_contains "$(remote_direct fm-extension.sh list)" "org.example.remote-other" "retirement changed an unrelated remote binding"
remote_direct fm-extension.sh verify org.example.remote-other >/dev/null
pass "remote retirement refuses ambiguous drift and resumes an exact crash cut"
remote_direct fm-extension.sh retire-transfer org.example.remote-other \
  --if-transfer-digest "$remote_other_transfer" --if-binding-digest "$remote_other_binding" >/dev/null
assert_absent "$H_REMOTE_CONTROL/config/extensions.d/org.example.remote.json" "remote binding was published into the local control home"
pass "remote retirement and refusal checks run against an isolated addressed home"
fi
fi

# --- shipped runnable example ------------------------------------------------
if section_enabled example; then
P_EXAMPLE="$PACKAGES/file-signal-example"
cp -R "$ROOT/docs/examples/process-event-extension" "$P_EXAMPLE"
chmod 0755 "$P_EXAMPLE" "$P_EXAMPLE/file-signal.mjs"
chmod 0644 "$P_EXAMPLE/firstmate-extension.json"
H_EXAMPLE="$HOMES/example"; new_home "$H_EXAMPLE"
bind_package "$H_EXAMPLE" "$P_EXAMPLE" file-signal --consent artifact-references >/dev/null
SIGNAL_FILE="$TMP_ROOT/example-result.txt"
example_registration=$(FM_HOME="$H_EXAMPLE" "$PROCEVENT" register-extension file-signal example-file --config-ref "file:$SIGNAL_FILE")
example_token=$(printf '%s\n' "$example_registration" | sed -n 's/^owner-token: //p')
FM_HOME="$H_EXAMPLE" "$PROCEVENT" start example-file > "$TMP_ROOT/example-start.out" &
example_start=$!
for _ in $(seq 1 100); do
  [ -f "$FM_PROCEVENT_CLAIM_ROOT/example-file.claim" ] && break
  sleep 0.05
done
assert_present "$FM_PROCEVENT_CLAIM_ROOT/example-file.claim" "example source never started waiting"
printf 'build 42 completed successfully\n' > "$SIGNAL_FILE"
wait "$example_start" || fail "example source failed after its file appeared"
example_result=$(first_result "$H_EXAMPLE" example-file) || fail "example captured no file result"
assert_grep 'build 42 completed successfully' "$example_result" "example did not preserve external evidence"
assert_contains "$(FM_HOME="$H_EXAMPLE" "$PROCEVENT" classify "$example_result")" "file-signal" "example result did not classify through the package"
assert_absent "$H_EXAMPLE/state/procevent/example-file.source" "example terminal result did not retire its source"
FM_HOME="$H_EXAMPLE" "$PROCEVENT" retire example-file --if-owner "$example_token" >/dev/null
pass "the shipped file-signal package is a runnable end-to-end external adapter"

# The same home spelled through a symlinked ancestor must capture external
# evidence identically, including the external capture path's pinned staging,
# inbox, and reservation boundaries.
ln -s "$HOMES" "$TMP_ROOT/homes-through-symlink"
H_EXAMPLE_SYMLINKED="$TMP_ROOT/homes-through-symlink/example"
SIGNAL_FILE_SYMLINKED="$TMP_ROOT/example-symlinked-result.txt"
symlinked_registration=$(FM_HOME="$H_EXAMPLE_SYMLINKED" "$PROCEVENT" register-extension file-signal example-symlinked \
  --config-ref "file:$SIGNAL_FILE_SYMLINKED")
symlinked_token=$(printf '%s\n' "$symlinked_registration" | sed -n 's/^owner-token: //p')
FM_HOME="$H_EXAMPLE_SYMLINKED" "$PROCEVENT" start example-symlinked > "$TMP_ROOT/example-symlinked-start.out" &
symlinked_start=$!
for _ in $(seq 1 100); do
  [ -f "$FM_PROCEVENT_CLAIM_ROOT/example-symlinked.claim" ] && break
  sleep 0.05
done
assert_present "$FM_PROCEVENT_CLAIM_ROOT/example-symlinked.claim" \
  "a home reached through a symlinked ancestor never started its external source"
printf 'build 43 completed successfully\n' > "$SIGNAL_FILE_SYMLINKED"
wait "$symlinked_start" \
  || fail "a home reached through a symlinked ancestor failed its external source"
symlinked_result=$(first_result "$H_EXAMPLE" example-symlinked) \
  || fail "a home reached through a symlinked ancestor captured no external result"
assert_grep 'build 43 completed successfully' "$symlinked_result" \
  "the symlinked-ancestor home did not preserve external evidence"
FM_HOME="$H_EXAMPLE_SYMLINKED" "$PROCEVENT" retire example-symlinked --if-owner "$symlinked_token" >/dev/null
pass "a home reached through a symlinked ancestor captures external evidence normally"

P_HANDSHAKE_ORPHAN="$PACKAGES/handshake-orphan"
P_HANDSHAKE_RECOVER="$PACKAGES/handshake-recover"
handshake_orphan_pid_file="$TMP_ROOT/handshake-orphan.pid"
make_package "$P_HANDSHAKE_ORPHAN" org.example.handshake-orphan ext-handshake-orphan "$(printf 'handshake-leak\n%s' "$handshake_orphan_pid_file")"
make_package "$P_HANDSHAKE_RECOVER" org.example.handshake-orphan ext-handshake-orphan
H_HANDSHAKE_ORPHAN="$HOMES/handshake-orphan"; new_home "$H_HANDSHAKE_ORPHAN"
handshake_orphan_rc=0
handshake_orphan_out=$(bind_package "$H_HANDSHAKE_ORPHAN" "$P_HANDSHAKE_ORPHAN" ext-handshake-orphan 2>&1) || handshake_orphan_rc=$?
wait_for_file "$handshake_orphan_pid_file" || fail "handshake leak fixture did not start its foreground child"
handshake_orphan_pid=$(cat "$handshake_orphan_pid_file")
[ "$handshake_orphan_rc" -ne 0 ] || fail "a handshake orphan was accepted as a successful binding"
assert_contains "$handshake_orphan_out" "process-leak" "handshake leak did not reject binding publication"
assert_absent "$H_HANDSHAKE_ORPHAN/config/extensions.d/org.example.handshake-orphan.json" "handshake orphan published an enabled binding"
kill -0 "$handshake_orphan_pid" 2>/dev/null && fail "handshake leak escaped invocation-group cleanup"
for _ in $(seq 1 50); do
  kill -0 "$handshake_orphan_pid" 2>/dev/null || break
  sleep 0.05
done
handshake_orphan_pid=
bind_package "$H_HANDSHAKE_ORPHAN" "$P_HANDSHAKE_RECOVER" ext-handshake-orphan >/dev/null
assert_contains "$(FM_HOME="$H_HANDSHAKE_ORPHAN" "$HOST" verify org.example.handshake-orphan)" "verified: org.example.handshake-orphan@1.2.3" \
  "cleaned handshake state did not permit safe binding"
pass "handshake execution rejects and reaps foreground descendants"
fi

printf '\nall extension-binding tests passed\n'
