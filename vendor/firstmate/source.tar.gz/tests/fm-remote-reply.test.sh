#!/usr/bin/env bash
# End-to-end remote reply relay through fm-on and the process-event runner.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)
TMP_ROOT=$(fm_test_tmproot fm-remote-reply)
mkdir -p "$TMP_ROOT"
TMP_ROOT=$(cd "$TMP_ROOT" && pwd -P)
PARENT="$TMP_ROOT/parent"
REMOTE="$TMP_ROOT/remote"
FAKEBIN=$(fm_fakebin "$TMP_ROOT/fake")
CLAIMS="$TMP_ROOT/claims"
mkdir -p "$PARENT/data" "$PARENT/state" "$REMOTE/state" "$REMOTE/data/reply" "$CLAIMS"
# shellcheck source=bin/fm-remote-job-lib.sh
. "$ROOT/bin/fm-remote-job-lib.sh"
# The recorded worker pid is the serving child, not its restart supervisor, so
# stopping that pid alone leaves the supervisor to respawn - the leak
# tests/fm-remote-job-orphan-reap.test.sh pins. Stop the whole worker tree.
cleanup() {
  local worker_pid=''
  FM_HOME="$PARENT" FM_PROCEVENT_CLAIM_ROOT="$CLAIMS" \
    "$ROOT/bin/fm-procevent.sh" sweep-home >/dev/null 2>&1 || true
  if [ -f "$TMP_ROOT/remote-jobs/worker.pid" ]; then
    worker_pid=$(cat "$TMP_ROOT/remote-jobs/worker.pid")
    fm_remote_job_stop_worker_tree "$worker_pid" || true
  fi
  rm -rf -- "$TMP_ROOT"
}
trap cleanup EXIT

cat > "$PARENT/data/secondmates.md" <<EOF
- ios - iOS delivery (host: remote-mac; root: $ROOT; home: $REMOTE; scope: iOS work; projects: alpha; added 2026-08-02)
EOF
printf '# Detailed remote answer\n\nThe build is green.\n' > "$REMOTE/data/reply/report.md"
printf '# Mentioned but never offered\n' > "$REMOTE/data/reply/prose-only.md"
: > "$REMOTE/state/parent-replies.status"
SOURCE_BEFORE="$TMP_ROOT/source-before"
cp "$REMOTE/state/parent-replies.status" "$SOURCE_BEFORE"

cat > "$FAKEBIN/fake-ssh" <<'SH'
#!/usr/bin/env bash
while [ "$#" -gt 0 ]; do
  case "$1" in
    -o) shift 2 ;;
    --) shift; break ;;
    *) exit 90 ;;
  esac
done
if [ -n "${FM_REMOTE_REPLY_POLL_LOG:-}" ]; then
  printf 'x\n' >> "$FM_REMOTE_REPLY_POLL_LOG"
fi
[ "${FM_REMOTE_REPLY_TRANSPORT_ERROR:-}" != 1 ] || {
  printf 'A\000 connection attempt failed because the connected party did not properly respond\000 Error code: Bash/Service/WSAETIMEDOUT\000\n'
  exit 255
}
[ "${FM_REMOTE_REPLY_FAIL_READ:-}" != 1 ] || exit 255
host=$1
entry=$2
shift 2
[ "$host" = remote-mac ] || exit 91
[ "$entry" = fm-remote-entrypoint.sh ] || exit 92
exec "$FM_FAKE_REMOTE_ENTRYPOINT" "$@"
SH
chmod +x "$FAKEBIN/fake-ssh"

remote_env() {
  FM_HOME="$PARENT" \
  FM_ROOT_OVERRIDE="$ROOT" \
  FM_PROCEVENT_CLAIM_ROOT="$CLAIMS" \
  FM_SSH_BIN="$FAKEBIN/fake-ssh" \
  FM_FAKE_REMOTE_ENTRYPOINT="$ROOT/bin/fm-remote-entrypoint.sh" \
  FM_REMOTE_JOB_PLATFORM_OVERRIDE=Linux \
  FM_REMOTE_JOB_STATE_ROOT="$TMP_ROOT/remote-jobs" \
  FM_REMOTE_REPLY_WAIT_SECONDS="${FM_REMOTE_REPLY_WAIT_SECONDS:-10}" \
  "$@"
}

wait_for() {
  local path=$1
  for _ in $(seq 1 100); do
    [ -e "$path" ] && return 0
    sleep 0.05
  done
  return 1
}

reply_owner() {
  remote_env "$ROOT/bin/fm-procevent.sh" list 2>/dev/null \
    | awk -v id="$SID" 'NR > 1 && $1 == id { print $3; exit }'
}

stop_reply_listener() {
  local pid _
  pid=$(sed -n '2p' "$CLAIMS/$SID.claim" 2>/dev/null || true)
  case "$pid" in ''|*[!0-9]*) return 0 ;; esac
  kill -TERM -- -"$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
  for _ in $(seq 1 80); do
    kill -0 "$pid" 2>/dev/null || return 0
    sleep 0.05
  done
  return 1
}

# Block until this generation's capture has been applied. A listener that stays
# live keeps its claim across polls, so start is launched only when nothing owns
# the source. Handling a generation re-arms it, which supersedes the live
# runner's launch floor: that runner exits without a result, and a check that
# sampled its claim just before release would otherwise wait out the full bound
# with no owner listening. Re-check the owner on a one-second cadence so a
# superseded runner is replaced while the same total bound still applies.
await_reply_result() { # <result-path>
  local result=$1 handled=${1%.result}.handled i owner starter=
  for i in $(seq 1 800); do
    [ -s "$result" ] && [ -f "$handled" ] && return 0
    if [ "$((i % 20))" -eq 1 ]; then
      if [ -z "$starter" ] || ! kill -0 "$starter" 2>/dev/null; then
        starter=
        owner=$(reply_owner)
        if [ "$owner" != live ]; then
          remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 &
          starter=$!
        fi
      fi
    fi
    sleep 0.05
  done
  return 1
}

sha256_file() {
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    sha256sum "$1" | awk '{print $1}'
  fi
}

# Drive the real delta-reader executable across its unchanged-file wait.
# The recording sleep appends a complete line after the initial empty snapshot,
# so the next snapshot must deliver it without consuming or modifying the log.
delta_cadence_case() {
  local label=$1 override=$2 expected=$3 dir log empty_hash
  dir="$TMP_ROOT/delta-$label"
  mkdir -p "$dir/bin" "$dir/home/state"
  log="$dir/home/state/replies.status"
  : > "$log"
  empty_hash=$(sha256_file "$log")
  cat > "$dir/bin/sleep" <<'SH'
#!/bin/bash
printf '%s\n' "$1" >> "$FM_DELTA_SLEEP_LOG"
printf 'cadence-delivered\n' >> "$FM_DELTA_APPEND_LOG"
exec /bin/sleep "$@"
SH
  chmod +x "$dir/bin/sleep"
  FM_HOME="$dir/home" PATH="$dir/bin:$PATH" FM_REMOTE_DELTA_POLL_SECONDS="$override" \
    FM_DELTA_SLEEP_LOG="$dir/sleeps" FM_DELTA_APPEND_LOG="$log" \
    "$BASH" "$ROOT/bin/fm-remote-delta-read.sh" state/replies.status 0 "$empty_hash" 30 \
    > "$dir/result" || fail "$label delta reader failed"
  [ "$(cat "$dir/sleeps")" = "$expected" ] || fail "$label delta reader did not wait $expected seconds"
  assert_grep 'status=delta' "$dir/result" "$label delta reader did not publish a delta"
  assert_grep 'cadence-delivered' "$dir/result" "$label delta reader lost the appended complete line"
  [ "$(cat "$log")" = cadence-delivered ] || fail "$label delta reader changed its source log"
  pass "$label delta reader waits $expected seconds then delivers a non-destructive complete-line delta"
}
delta_cadence_case default '' 0.5
delta_cadence_case override 0.07 0.07

ADAPTER="$ROOT/bin/fm-procevent-remote-reply.sh"

# Temporary-path hygiene, in its own home with a private TMPDIR: the continuity
# return, a die after staging, a lifecycle-locked handle, and a signal during a
# document fetch must each leave TMPDIR empty and release the lifecycle lock.
LEAK_HOME="$TMP_ROOT/leak-home"
LEAK_TMPDIR="$TMP_ROOT/leak-tmpdir"
mkdir -p "$LEAK_HOME/data" "$LEAK_HOME/state" "$LEAK_TMPDIR"
printf -- '- ios - iOS delivery (host: remote-mac; root: %s; home: %s; scope: iOS work; projects: alpha; added 2026-08-02)\n' \
  "$ROOT" "$REMOTE" > "$LEAK_HOME/data/secondmates.md"
# A document fetch that hangs until signalled, recording its own pid.
cat > "$FAKEBIN/fake-ssh-hang" <<'SH'
#!/usr/bin/env bash
printf '%s\n' "$$" > "$FM_LEAK_FETCH_STARTED"
exec sleep 30
SH
chmod +x "$FAKEBIN/fake-ssh-hang"
leak_env() {
  TMPDIR="$LEAK_TMPDIR" FM_HOME="$LEAK_HOME" FM_ROOT_OVERRIDE="$ROOT" \
    FM_SSH_BIN="$FAKEBIN/fake-ssh-hang" FM_LEAK_FETCH_STARTED="$TMP_ROOT/leak-fetch-started" "$@"
}
leak_result() { # <status> <payload-file> <destination>
  local empty to to_hash bytes
  empty=$(sha256_file /dev/null)
  bytes=$(LC_ALL=C wc -c < "$2" | tr -d ' ')
  to=$bytes
  to_hash=$(sha256_file "$2")
  [ "$1" = delta ] || { to=0; to_hash=$empty; }
  {
    printf 'schema=fm-remote-delta.v1\nstatus=%s\npath=state/parent-replies.status\n' "$1"
    printf 'from_offset=0\nto_offset=%s\nfrom_prefix_sha256=%s\nto_prefix_sha256=%s\n' "$to" "$empty" "$to_hash"
    printf 'payload_sha256=%s\npayload_bytes=%s\nreason=leak-check\n\n' "$(sha256_file "$2")" "$bytes"
    cat "$2"
  } > "$3"
}
assert_no_leak() { # <path-description>
  local left
  left=$(ls -A "$LEAK_TMPDIR")
  [ -z "$left" ] || fail "$1 left temporary paths behind: $left"
  [ -z "$(find "$LEAK_HOME/data" -name '.remote-doc.*' -print -quit)" ] \
    || fail "$1 left a staged document behind"
  [ -z "$(find "$LEAK_HOME/state" -maxdepth 1 -name '.remote-reply-lifecycle-*' -print -quit)" ] \
    || fail "$1 left the lifecycle lock held"
}
: > "$TMP_ROOT/leak-empty"
leak_result continuity-broken "$TMP_ROOT/leak-empty" "$TMP_ROOT/leak-continuity.result"
leak_rc=0
leak_env "$ADAPTER" ingest ios "$TMP_ROOT/leak-continuity.result" > "$TMP_ROOT/leak.out" 2>&1 || leak_rc=$?
[ "$leak_rc" -eq 3 ] || fail "continuity ingest returned an unexpected status: $leak_rc"
assert_no_grep 'unbound variable' "$TMP_ROOT/leak.out" "continuity ingest cleanup tripped on an unbound variable"
assert_no_leak "continuity ingest"
leak_env "$ADAPTER" handle ios 1 "$TMP_ROOT/leak-continuity.result" > "$TMP_ROOT/leak.out" 2>&1 || true
assert_no_leak "continuity handle"
printf 'working: leak check\n' > "$TMP_ROOT/leak-payload"
leak_result delta "$TMP_ROOT/leak-payload" "$TMP_ROOT/leak-delta.result"
sed 's/^payload_bytes=.*/payload_bytes=99/' "$TMP_ROOT/leak-delta.result" > "$TMP_ROOT/leak-bad.result"
leak_rc=0
leak_env "$ADAPTER" ingest ios "$TMP_ROOT/leak-bad.result" > "$TMP_ROOT/leak.out" 2>&1 || leak_rc=$?
[ "$leak_rc" -eq 1 ] || fail "a payload digest mismatch returned an unexpected status: $leak_rc"
assert_no_leak "die after staging"
leak_rc=0
leak_env "$ADAPTER" handle ios 2 "$TMP_ROOT/leak-bad.result" > "$TMP_ROOT/leak.out" 2>&1 || leak_rc=$?
[ "$leak_rc" -eq 1 ] || fail "a handled payload digest mismatch returned an unexpected status: $leak_rc"
assert_no_leak "die inside a lifecycle-locked handle"
leak_env "$ADAPTER" handle ios 3 "$TMP_ROOT/leak-delta.result" > "$TMP_ROOT/leak.out" 2>&1 || true
assert_grep 'ingested: ios appended=1' "$TMP_ROOT/leak.out" "the leak-check delta was not ingested"
assert_no_leak "ingested lifecycle-locked handle"
rm -rf "$LEAK_HOME/state/remote-replies"
printf 'done: leak check report=data/leak/report.md\n' > "$TMP_ROOT/leak-doc-payload"
leak_result delta "$TMP_ROOT/leak-doc-payload" "$TMP_ROOT/leak-doc.result"
rm -f "$TMP_ROOT/leak-fetch-started"
# A plain background command, not the leak_env function, so the signal reaches
# the adapter process itself rather than a wrapping subshell.
TMPDIR="$LEAK_TMPDIR" FM_HOME="$LEAK_HOME" FM_ROOT_OVERRIDE="$ROOT" \
  FM_SSH_BIN="$FAKEBIN/fake-ssh-hang" FM_LEAK_FETCH_STARTED="$TMP_ROOT/leak-fetch-started" \
  "$ADAPTER" ingest ios "$TMP_ROOT/leak-doc.result" > "$TMP_ROOT/leak.out" 2>&1 &
leak_pid=$!
wait_for_content() {
  local _
  for _ in $(seq 1 200); do
    [ -s "$1" ] && return 0
    sleep 0.05
  done
  return 1
}
wait_for_content "$TMP_ROOT/leak-fetch-started" || fail "the leak-check document fetch never started"
kill -TERM "$leak_pid"
# Bash can defer TERM until its foreground fetch exits. Interrupt that fetch
# before waiting so normal completion cannot satisfy the cleanup assertion.
kill -TERM "$(cat "$TMP_ROOT/leak-fetch-started")" 2>/dev/null \
  || fail "the leak-check fetch exited before it could be interrupted"
leak_rc=0
wait "$leak_pid" 2>/dev/null || leak_rc=$?
[ "$leak_rc" -eq 143 ] || fail "interrupted ingest returned an unexpected status: $leak_rc"
assert_no_leak "signal during a document fetch"
# The source leg stages the remote read's output before classifying it; a signal
# during that read must remove the staged file as well.
rm -f "$TMP_ROOT/leak-fetch-started"
TMPDIR="$LEAK_TMPDIR" FM_HOME="$LEAK_HOME" FM_ROOT_OVERRIDE="$ROOT" \
  FM_SSH_BIN="$FAKEBIN/fake-ssh-hang" FM_LEAK_FETCH_STARTED="$TMP_ROOT/leak-fetch-started" \
  "$ADAPTER" source ios > "$TMP_ROOT/leak.out" 2>&1 &
leak_pid=$!
wait_for_content "$TMP_ROOT/leak-fetch-started" || fail "the leak-check source read never started"
[ -n "$(find "$LEAK_TMPDIR" -name 'fm-remote-reply-source.*' -print -quit)" ] \
  || fail "the leak-check source read did not stage its output file"
kill -TERM "$leak_pid"
kill -TERM "$(cat "$TMP_ROOT/leak-fetch-started")" 2>/dev/null \
  || fail "the leak-check source read exited before it could be interrupted"
leak_rc=0
wait "$leak_pid" 2>/dev/null || leak_rc=$?
[ "$leak_rc" -eq 143 ] || fail "interrupted source returned an unexpected status: $leak_rc"
assert_no_leak "signal during a source read"
pass "remote reply adapter leaves no temporary path or lifecycle lock behind on any exit"

SID=$(remote_env "$ADAPTER" source-id ios)
out=$(remote_env "$ADAPTER" arm ios)
assert_contains "$out" "armed: $SID offset=0" "remote reply source was not armed at the empty cursor"

# A failed or non-schema remote leg must never become a malformed capture.
set +e
FM_REMOTE_REPLY_TRANSPORT_ERROR=1 remote_env "$ADAPTER" source ios > "$TMP_ROOT/transport-error.result"
transport_error_rc=$?
FM_REMOTE_REPLY_FAIL_READ=1 remote_env "$ADAPTER" source ios > "$TMP_ROOT/ssh-255.result"
ssh_255_rc=$?
set -e
[ "$transport_error_rc" -ne 0 ] || fail "a non-schema transport diagnostic returned success"
[ ! -s "$TMP_ROOT/transport-error.result" ] || fail "a non-schema transport diagnostic was emitted as a result"
[ "$ssh_255_rc" -ne 0 ] || fail "ssh exit 255 returned success"
[ ! -s "$TMP_ROOT/ssh-255.result" ] || fail "ssh exit 255 emitted a result"
pass "transport failures and non-schema diagnostics stay out of captured results"

remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" > "$TMP_ROOT/start-one.out" 2>&1 &
wait_for "$CLAIMS/$SID.claim" || fail "process-event runner never claimed the remote reply source"
printf 'done [corr=0123456789abcdef] [at=1700000000]: build verified report=data/reply/report.md\n' \
  >> "$REMOTE/state/parent-replies.status"
RESULT=
for _ in $(seq 1 800); do
  RESULT=$(find "$PARENT/state/procevent-inbox" -name "$SID.1.result" -print -quit 2>/dev/null || true)
  [ -n "$RESULT" ] && [ -f "${RESULT%.result}.handled" ] && break
  sleep 0.05
done
RESULT=$(find "$PARENT/state/procevent-inbox" -name "$SID.1.result" -print -quit 2>/dev/null || true)
if [ -z "$RESULT" ]; then
  printf 'runner output:\n%s\n' "$(cat "$TMP_ROOT/start-one.out")" >&2
  fail "the remote reply delta was not durably captured"
fi
assert_grep 'done [corr=0123456789abcdef]' "$RESULT" "captured delta lost the correlated status line"
# One remote note, one announcement: the adapter declares self-announcing, so a
# fully autohandled capture publishes NO check wake - the mirrored status bytes
# are the single announcement, observed here through the same signature-vs-seen
# gate the watcher's signal scan and the drain's annotation check consume.
if [ -e "$PARENT/state/.wake-queue" ] && grep -q "procevent remote-reply $SID 1" "$PARENT/state/.wake-queue"; then
  fail "an autohandled remote-reply capture still published a duplicate check wake"
fi
FM_STATE_OVERRIDE="$PARENT/state" bash -c '
  . "$1/bin/fm-wake-lib.sh"
  fm_wake_signal_seen_current "$2/state" "$2/state/ios.status"
' _ "$ROOT" "$PARENT" && fail "the mirrored reply bytes are not visible to the watcher signal scan"
cmp -s "$SOURCE_BEFORE" "$REMOTE/state/parent-replies.status" \
  && fail "fixture did not append the expected source line"
SOURCE_AFTER="$TMP_ROOT/source-after"
cp "$REMOTE/state/parent-replies.status" "$SOURCE_AFTER"
pass "a blocking non-destructive remote delta reaches durable process-event capture"

# The runner applies a captured result through this adapter itself, so the reply
# is already mirrored, acknowledged, and the next source re-armed before any
# handler runs. That is the primary guarantee; assert it before exercising the
# handler's own path below.
assert_grep 'done [corr=0123456789abcdef]' "$PARENT/state/ios.status" \
  "the captured reply was not applied to the parent status stream at capture"
assert_present "$PARENT/state/procevent-inbox/$SID.1.handled" \
  "the applied capture was left unacknowledged"
assert_present "$PARENT/state/procevent/$SID.source" \
  "applying the capture left the relay unarmed for the next delta"
pass "a captured delta is applied, acknowledged, and re-armed without a handler"

# Now the handler's own retry path, from the state a crash between applying and
# acknowledging leaves behind: the acknowledgement is gone and re-arming fails.
# A handled marker precedes the runner's re-listen transition. Quiesce it before
# mutating its state here and in the unsafe-acknowledgement fixture below.
stop_reply_listener || fail "the reply listener did not stop before the failed re-arm fixture"
rm -f "$PARENT/state/procevent-inbox/$SID.1.handled"
rm -rf "$PARENT/state/procevent"
: > "$PARENT/state/procevent"
set +e
remote_env "$ADAPTER" handle ios 1 "$RESULT" > "$TMP_ROOT/handle-arm-fail.out" 2>&1
handle_arm_rc=$?
set -e
[ "$handle_arm_rc" -ne 0 ] || fail "reply handling acknowledged a result whose re-arm failed"
assert_grep 'done [corr=0123456789abcdef]' "$PARENT/state/ios.status" "failed re-arm lost the ingested reply"
assert_grep 'ingested: ios appended=0' "$TMP_ROOT/handle-arm-fail.out" "failed re-arm did not replay the committed reply"
rm -f "$PARENT/state/procevent"
mkdir "$PARENT/state/procevent"
reconcile_out=$(remote_env "$ROOT/bin/fm-procevent.sh" reconcile)
assert_contains "$reconcile_out" 'published=1' "failed re-arm did not leave the result eligible for retry"
out=$(remote_env "$ADAPTER" handle ios 1 "$RESULT")
assert_contains "$out" 'ingested: ios appended=0' "retried reply ingest was not idempotent"
assert_contains "$out" 'handled: remote-reply-ios 1' "captured generation was not acknowledged"
assert_grep 'done [corr=0123456789abcdef]' "$PARENT/state/ios.status" "parent status did not receive the correlated reply"
assert_grep 'data/remote-secondmates/ios/data/reply/report.md' "$PARENT/state/ios.status" "remote document pointer was not rewritten locally"
cmp -s "$REMOTE/data/reply/report.md" "$PARENT/data/remote-secondmates/ios/data/reply/report.md" \
  || fail "the path-confined remote document copy is not byte-identical"
cmp -s "$SOURCE_AFTER" "$REMOTE/state/parent-replies.status" \
  || fail "handling consumed or rewrote the remote append-only log"
expected_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$expected_offset" "$PARENT/state/remote-replies/ios.cursor" "reply cursor did not advance to the committed delta"
assert_grep 'done [corr=0123456789abcdef] [at=1700000000]: build verified' "$PARENT/state/ios.status" \
  "relay replaced the source event time with observation time"
pass "ingest appends one validated line, fetches its document, and advances the cursor"

out=$(remote_env "$ADAPTER" handle ios 1 "$RESULT")
assert_contains "$out" 'ingested: ios appended=0' "replayed result was not deduplicated"
assert_contains "$out" 'already-handled: remote-reply-ios 1' "replayed generation was not acknowledged idempotently"
[ "$(grep -cF 'done [corr=0123456789abcdef]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "replayed ingest duplicated the parent status line"
pass "replayed capture has one deduplicated append and one durable handling identity"

printf 'working [corr=1111111111111111]: second generation\n' \
  >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.2.result" \
  || fail "second reply generation was not captured"
RESULT_TWO="$PARENT/state/procevent-inbox/$SID.2.result"
# The runner already applied and acknowledged this capture. Drop that genuine
# acknowledgement and put an unsafe one in its place, so the handler's refusal
# to trust a non-regular marker stays under test.
stop_reply_listener || fail "the reply listener did not stop before the unsafe acknowledgement fixture"
rm -f "$PARENT/state/procevent-inbox/$SID.2.handled"
ln -s "$TMP_ROOT/missing-handled-marker" "$PARENT/state/procevent-inbox/$SID.2.handled"
set +e
remote_env "$ADAPTER" handle ios 2 "$RESULT_TWO" > "$TMP_ROOT/handle-two-unacked.out" 2>&1
handle_two_rc=$?
set -e
[ "$handle_two_rc" -ne 0 ] || fail "second generation acknowledged through an unsafe handled marker"
assert_grep 'working [corr=1111111111111111]' "$PARENT/state/ios.status" "unacknowledged generation was not ingested"
printf 'done [corr=2222222222222222]: third generation\n' \
  >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.3.result" \
  || fail "third reply generation was not captured"
RESULT_THREE="$PARENT/state/procevent-inbox/$SID.3.result"
remote_env "$ADAPTER" handle ios 3 "$RESULT_THREE" >/dev/null \
  || fail "third reply generation was not handled"
rm -f "$PARENT/state/procevent-inbox/$SID.2.handled"
out=$(remote_env "$ADAPTER" handle ios 2 "$RESULT_TWO")
assert_contains "$out" 'ingested: ios appended=0' "earlier generation did not replay from its durable ingestion receipt"
assert_contains "$out" 'handled: remote-reply-ios 2' "earlier generation remained unacknowledged after later cursor advancement"
[ "$(grep -cF 'working [corr=1111111111111111]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "earlier generation replay duplicated its parent status"
grep -Fxq 'working [corr=1111111111111111]: second generation' "$PARENT/state/ios.status" \
  || fail "relay invented an emission time for a legacy source event"
pass "later generations cannot invalidate an unacknowledged ingested result"

# The channel mirrors the remote mate's content-bearing status lines at most once
# while omitting blank separators. A remote mate's own progress line and a NEWLY
# raised needs-decision carry no corr= by charter contract, and a delta carrying
# them alongside a correlated answer must ingest whole: every content-bearing
# line reaches the parent stream, the new decision reaches the parent's
# open-decision fold, the correlated line still settles its pending-reply record,
# and the cursor advances so the channel cannot wedge on a line it once refused.
# shellcheck source=bin/fm-pending-reply-lib.sh
. "$ROOT/bin/fm-pending-reply-lib.sh"
PENDING_CORR=$(fm_pending_reply_create "$PARENT" "$PARENT/state" ios 'audit the release chain')
[ -n "$PENDING_CORR" ] || fail "could not create the parent pending-reply record"
fm_pending_reply_mark_delivered "$PARENT/state" "$PENDING_CORR" \
  || fail "could not mark the pending-reply request delivered"
{
  printf 'working [key=version-audit]: family --version audit complete (data/reply/prose-only.md)\n'
  printf 'needs-decision [key=rough-cut-version]: implement --version or retire the tool\n'
  printf 'needs-decision [at=1700000000]: which base branch?\n'
  printf 'needs-decision [at=1700086400]: which base branch?\n'
  printf 'done [corr=%s]: release chain audited\n' "$PENDING_CORR"
} >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.4.result" \
  || fail "the mirrored status stream was not captured"
RESULT_FOUR="$PARENT/state/procevent-inbox/$SID.4.result"
remote_env "$ADAPTER" handle ios 4 "$RESULT_FOUR" > "$TMP_ROOT/handle-mirror.out" 2>&1 \
  || fail "an uncorrelated status line stopped the delta: $(cat "$TMP_ROOT/handle-mirror.out")"
assert_grep 'working [key=version-audit]' "$PARENT/state/ios.status" "an uncorrelated progress line never reached the parent stream"
assert_grep 'needs-decision [key=rough-cut-version]' "$PARENT/state/ios.status" "a newly raised remote decision never reached the parent stream"
assert_grep "done [corr=$PENDING_CORR]" "$PARENT/state/ios.status" "the correlated answer sharing the delta was lost"
for epoch in 1700000000 1700086400; do
  grep -Fxq "needs-decision [at=$epoch]: which base branch?" "$PARENT/state/ios.status" \
    || fail "relay discarded a distinct event with identical text and a different time"
done
mirror_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$mirror_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the cursor did not advance past an uncorrelated line"
# The prose line NAMES a path that really does exist on the remote, so only the
# structured-pointer trigger can explain the parent never fetching it.
assert_absent "$PARENT/data/remote-secondmates/ios/data/reply/prose-only.md" \
  "a bare path mentioned in prose was fetched as though the line offered it"
assert_grep 'audit complete (data/reply/prose-only.md)' "$PARENT/state/ios.status" \
  "the prose mention was rewritten as though its document had been fetched"
assert_no_grep 'blocked [key=remote-reply-document-ios]' "$PARENT/state/ios.status" \
  "a bare path mentioned in prose raised a document transfer obligation"
pass "the remote status and decision model mirrors and the cursor advances"

# The newly raised decision must be indistinguishable from a local mate's, so the
# shared fold - not this adapter - decides it is open.
# shellcheck source=bin/fm-classify-lib.sh
. "$ROOT/bin/fm-classify-lib.sh"
OPEN=$(status_open_decisions "$PARENT/state/ios.status")
printf '%s' "$OPEN" | grep -q '^rough-cut-version	needs-decision	' \
  || fail "the remote mate's new decision did not surface as open to the parent: $OPEN"
[ "$(fm_pending_reply_get "$PARENT/state/pending-replies/$PENDING_CORR" phase)" = resolved ] \
  || fail "the correlated answer in the same delta did not settle its pending-reply record"
pass "a remote mate's new decision folds open exactly as a local mate's does"

# Ingesting the same generation again is idempotent: no duplicated lines and no
# cursor movement, so a replay can never wedge or double-count the stream.
remote_env "$ADAPTER" handle ios 4 "$RESULT_FOUR" >/dev/null 2>&1 || true
[ "$(grep -cF 'needs-decision [key=rough-cut-version]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "replaying the mirrored delta duplicated the new decision"
assert_grep "offset=$mirror_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "replaying the mirrored delta moved the cursor"
pass "a replayed mirrored delta is idempotent in both the stream and the cursor"
[ "$(grep -Fc ': which base branch?' "$PARENT/state/ios.status")" -eq 2 ] \
  || fail "replaying a delta duplicated distinct timed requests"
if [ "${FM_TEST_EVIDENCE:-0}" = 1 ]; then
  printf 'Remote source status records:\n'
  cat "$REMOTE/state/parent-replies.status"
  printf '\nParent status after handling and replaying generation 4:\n'
  cat "$PARENT/state/ios.status"
  printf '\nCommitted remote cursor:\n'
  cat "$PARENT/state/remote-replies/ios.cursor"
fi

# Bytes crossing a machine boundary are normalized, never dropped: a control
# character cannot make the parent's status file unsafe and cannot stop the
# stream either.
printf 'blocked [key=ctl]: escape \033[31mhere\033[0m bell \007 caf\xc3\xa9 end\n' \
  >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.5.result" \
  || fail "the control-character line was not captured"
RESULT_FIVE="$PARENT/state/procevent-inbox/$SID.5.result"
remote_env "$ADAPTER" handle ios 5 "$RESULT_FIVE" >/dev/null 2>&1 \
  || fail "a control character stopped the stream"
assert_grep 'blocked [key=ctl]: escape ?[31mhere' "$PARENT/state/ios.status" \
  "the control-character line was not mirrored in normalized form"
[ -z "$(LC_ALL=C tr -d '\11\12\40-\176\200-\377' < "$PARENT/state/ios.status")" ] \
  || fail "a control byte reached the parent status file"
assert_grep "$(printf 'caf\xc3\xa9 end')" "$PARENT/state/ios.status" \
  "normalization mangled a UTF-8 note a local secondmate could have written"
ctl_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$ctl_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the cursor did not advance past a control-character line"
pass "transported control bytes are normalized in place and never stop the stream"

printf 'status=delta\n' >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.6.result" \
  || fail "the header-collision line was not captured"
RESULT_SIX="$PARENT/state/procevent-inbox/$SID.6.result"
remote_env "$ADAPTER" handle ios 6 "$RESULT_SIX" >/dev/null 2>&1 \
  || fail "a payload protocol-field name stopped the stream"
assert_grep 'status=delta' "$PARENT/state/ios.status" \
  "the payload protocol-field line did not reach the parent stream"
collision_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$collision_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the cursor did not advance past a payload protocol-field line"
pass "payload protocol-field names cannot collide with transport metadata"

printf 'working [key=nul-byte]: before\000after\n' >> "$REMOTE/state/parent-replies.status"
await_reply_result "$PARENT/state/procevent-inbox/$SID.7.result" \
  || fail "the NUL-bearing line was not captured"
RESULT_SEVEN="$PARENT/state/procevent-inbox/$SID.7.result"
remote_env "$ADAPTER" handle ios 7 "$RESULT_SEVEN" >/dev/null 2>&1 \
  || fail "a NUL byte stopped the stream"
assert_grep 'working [key=nul-byte]: before?after' "$PARENT/state/ios.status" \
  "the NUL byte was not normalized in place"
nul_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$nul_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the cursor did not advance past a NUL-bearing line"
pass "NUL bytes are normalized in place before shell line processing"

stop_reply_listener || fail "the reply listener did not stop before the obstructed document capture"
printf '# Retryable remote answer\n' > "$REMOTE/data/reply/retry.md"
printf 'done [key=retry-document]: retry local storage report=data/reply/retry.md\n' \
  >> "$REMOTE/state/parent-replies.status"
# Obstruct local document storage BEFORE the capture, so the runner's own
# automatic application fails for real. That is the documented fallback: a
# capture whose application does not complete stays unacknowledged and
# uncommitted, and the handler finishes it once storage recovers.
retry_destination="$PARENT/data/remote-secondmates/ios/data/reply/retry.md"
retry_decoy="$TMP_ROOT/retry-decoy.md"
printf 'local decoy\n' > "$retry_decoy"
ln -s "$retry_decoy" "$retry_destination"
remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 \
  || fail "the retryable document line was not captured"
RESULT_EIGHT="$PARENT/state/procevent-inbox/$SID.8.result"
assert_absent "$PARENT/state/procevent-inbox/$SID.8.handled" \
  "a capture whose automatic application failed was acknowledged anyway"
# The self-announcing declaration never silences a capture the adapter could
# NOT fully apply: this one must still publish its check wake for the handler.
assert_grep "procevent remote-reply $SID 8" "$PARENT/state/.wake-queue" \
  "a not-fully-applied capture lost its check-wake announcement"
assert_no_grep 'retry local storage' "$PARENT/state/.wake-queue" \
  "reply payload leaked into the event queue"
retry_cursor_before=$(cat "$PARENT/state/remote-replies/ios.cursor")
set +e
remote_env "$ADAPTER" handle ios 8 "$RESULT_EIGHT" > "$TMP_ROOT/handle-local-document-failure.out" 2>&1
local_document_rc=$?
set -e
[ "$local_document_rc" -ne 0 ] || fail "local document storage failure committed the delta"
assert_grep 'could not store referenced remote document' "$TMP_ROOT/handle-local-document-failure.out" \
  "local document storage failure was misclassified as remote refusal"
[ "$(cat "$PARENT/state/remote-replies/ios.cursor")" = "$retry_cursor_before" ] \
  || fail "local document storage failure advanced the cursor"
assert_no_grep 'done [key=retry-document]' "$PARENT/state/ios.status" \
  "local document storage failure mirrored an undelivered line"
assert_no_grep 'blocked [key=remote-reply-document-ios]' "$PARENT/state/ios.status" \
  "local document storage failure raised a permanent remote refusal"
rm -f "$retry_destination"
remote_env "$ADAPTER" handle ios 8 "$RESULT_EIGHT" >/dev/null \
  || fail "the document delta did not succeed after local storage recovered"
assert_grep 'data/remote-secondmates/ios/data/reply/retry.md' "$PARENT/state/ios.status" \
  "the retried document pointer was not rewritten locally"
cmp -s "$REMOTE/data/reply/retry.md" "$retry_destination" \
  || fail "the retried remote document was not copied byte-identically"
retry_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$retry_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the recovered document delta did not advance the cursor"
pass "local document storage failures remain retryable until delivery succeeds"

# ---------------------------------------------------------------------------
# A document a line OFFERS is fetched; one the reader cannot deliver fails open.
# The reader cannot tell a report still being written from one that will never
# exist, so a refusal never becomes a decision on the parent's board: the line
# keeps its own pointer, the cursor advances, and an unkeyed note says why.
GEN=8
mirror_lines() { # <line>...
  GEN=$((GEN + 1))
  printf '%s\n' "$@" >> "$REMOTE/state/parent-replies.status"
  await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
    || fail "generation $GEN was not captured"
  assert_present "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
    "generation $GEN was captured but never applied"
}
mirrored_cursor_is_current() { # <label>
  local offset
  offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
  assert_grep "offset=$offset" "$PARENT/state/remote-replies/ios.cursor" "$1"
}
assert_no_document_decision() { # <label>
  if status_open_decisions "$PARENT/state/ios.status" | grep -q '^remote-reply-document-'; then
    fail "$1"
  fi
  assert_no_grep '[key=remote-reply-document-' "$PARENT/state/ios.status" "$1"
}

printf '# valid report behind a malformed pointer\n' > "$REMOTE/data/reply/result.md"
mirror_lines 'working [key=malformed-report]: malformed offer report=data/reply/result.md.bak'
assert_absent "$PARENT/data/remote-secondmates/ios/data/reply/result.md" \
  "a valid prefix of a malformed report pointer was fetched"
assert_grep 'report=data/reply/result.md.bak' "$PARENT/state/ios.status" \
  "a valid prefix of a malformed report pointer was rewritten"
assert_no_document_decision "a malformed report pointer raised a document decision"
mirrored_cursor_is_current "a malformed report pointer prevented the cursor from advancing"
pass "a structured pointer must end at its token boundary"

printf '# first adjacent report\n' > "$REMOTE/data/reply/adjacent-a.md"
printf '# second adjacent report\n' > "$REMOTE/data/reply/adjacent-b.md"
mirror_lines 'done [key=adjacent-reports]: report=data/reply/adjacent-a.md,report=data/reply/adjacent-b.md report=data/reply/result.md alongside report=data/reply/result.md.bak'
cmp -s "$REMOTE/data/reply/adjacent-a.md" "$PARENT/data/remote-secondmates/ios/data/reply/adjacent-a.md" \
  || fail "the first comma-separated structured pointer was not fetched"
cmp -s "$REMOTE/data/reply/adjacent-b.md" "$PARENT/data/remote-secondmates/ios/data/reply/adjacent-b.md" \
  || fail "the second comma-separated structured pointer was not fetched"
cmp -s "$REMOTE/data/reply/result.md" "$PARENT/data/remote-secondmates/ios/data/reply/result.md" \
  || fail "the whitespace-separated structured pointer was not fetched"
assert_grep 'report=data/remote-secondmates/ios/data/reply/adjacent-a.md,report=data/remote-secondmates/ios/data/reply/adjacent-b.md report=data/remote-secondmates/ios/data/reply/result.md alongside report=data/reply/result.md.bak' "$PARENT/state/ios.status" \
  "structured pointer rewriting skipped an adjacent pointer or changed a malformed token"
mirrored_cursor_is_current "adjacent structured pointers prevented the cursor from advancing"
pass "adjacent pointers are fetched while malformed tokens remain unchanged"

# A rejected candidate must not make the text right after it look like the start
# of a line: the second `report=` here has no boundary of its own.
printf '# glued report\n' > "$REMOTE/data/reply/glued.md"
mirror_lines 'working [key=glued-pointers]: glued report=data/reply/glued-prefix.mdreport=data/reply/glued.md'
assert_absent "$PARENT/data/remote-secondmates/ios/data/reply/glued.md" \
  "a pointer with no preceding boundary was fetched after a rejected candidate"
assert_grep 'glued report=data/reply/glued-prefix.mdreport=data/reply/glued.md' "$PARENT/state/ios.status" \
  "a pointer with no preceding boundary was rewritten after a rejected candidate"
pass "a rejected candidate never gives the following text a false leading boundary"

# A `report=` under a remote-secondmates mirror tree is fetched like any other
# structured offer. When this mate genuinely holds it, it is a nested remote
# report worth relaying; when it does not, the fetch fails open and harmlessly.
mkdir -p "$REMOTE/data/remote-secondmates/nested/data/reply"
printf '# nested grandchild report\n' > "$REMOTE/data/remote-secondmates/nested/data/reply/report.md"
mirror_lines 'done [key=nested-remote]: nested report=data/remote-secondmates/nested/data/reply/report.md foreign report=data/remote-secondmates/other/data/reply/report.md'
cmp -s "$REMOTE/data/remote-secondmates/nested/data/reply/report.md" \
  "$PARENT/data/remote-secondmates/ios/data/remote-secondmates/nested/data/reply/report.md" \
  || fail "a nested remote report this mate holds was not relayed"
assert_grep 'nested report=data/remote-secondmates/ios/data/remote-secondmates/nested/data/reply/report.md foreign report=data/remote-secondmates/other/data/reply/report.md' "$PARENT/state/ios.status" \
  "the nested pointer was not rewritten or the undeliverable foreign pointer was changed"
assert_grep 'note: remote document did not transfer for ios: data/remote-secondmates/other/data/reply/report.md - ' <(sed -E 's/ \[at=[0-9]+\]//' "$PARENT/state/ios.status") \
  "an undeliverable foreign pointer left no note"
assert_no_document_decision "an undeliverable foreign pointer raised a document decision"
mirrored_cursor_is_current "an undeliverable foreign pointer prevented the cursor from advancing"
pass "nested remote reports relay while an undeliverable foreign pointer fails open"

# The reported incident, end to end. The mate announces a scout and names in
# prose the path its report WILL be written to, then explains the resulting
# false alarm in two more lines of the same delta. None of that is an offer, so
# nothing is fetched, nothing is noted, and no decision ever opens. The report
# arrives through the ledger publisher's structured offer once it exists.
INCIDENT_DOC=data/reply/voice-scout-report.md
rm -f "$REMOTE/$INCIDENT_DOC"
mirror_lines "reply [corr=3333333333333333]: dispatched the voice scout, report path $INCIDENT_DOC, will relay on completion"
mirror_lines \
  "reply [corr=3333333333333333]: No report to transfer YET - $INCIDENT_DOC is NOT yet written; nothing is lost" \
  "reply [corr=3333333333333333]: same - the report does not exist yet (scout still working, $INCIDENT_DOC not written)"
assert_no_document_decision "a report path mentioned in prose raised a document decision"
assert_no_grep "note: remote document did not transfer for ios: $INCIDENT_DOC" "$PARENT/state/ios.status" \
  "a report path mentioned in prose was treated as an undeliverable offer"
assert_grep "report path $INCIDENT_DOC, will relay" "$PARENT/state/ios.status" \
  "the prose announcement was not mirrored verbatim"
mirrored_cursor_is_current "the prose announcement delta did not advance the cursor"
printf '# voice scout report\n\nfindings\n' > "$REMOTE/$INCIDENT_DOC"
# The exact shape bin/fm-inactive-reconcile.sh publishes for a finished child.
mirror_lines "done [key=child-outcome-voice-scout-done-ab12cd34]: child voice-scout done: report ready mode=scout report=$INCIDENT_DOC"
cmp -s "$REMOTE/$INCIDENT_DOC" "$PARENT/data/remote-secondmates/ios/$INCIDENT_DOC" \
  || fail "the structured ledger offer did not deliver the finished report"
assert_grep "report ready mode=scout report=data/remote-secondmates/ios/$INCIDENT_DOC" "$PARENT/state/ios.status" \
  "the structured ledger offer was not rewritten to its local copy"
assert_no_document_decision "the reported incident left a document decision standing"
pass "the reported incident raises no standing decision and still delivers the report"

# A structured offer the reader cannot deliver fails open with its own reason.
# Offered again twice in one delta, the unchanged note is not repeated.
mirror_lines 'reply [corr=4444444444444444]: dispatched a scout report=data/reply/never-written.md'
assert_grep 'note: remote document did not transfer for ios: data/reply/never-written.md - file is not a non-symlink regular file' <(sed -E 's/ \[at=[0-9]+\]//' "$PARENT/state/ios.status") \
  "an undeliverable structured offer left no note carrying the reader's reason"
status_line_at_epoch "$(grep -E '^note( \[at=[0-9]+\])?: remote document did not transfer for ios: data/reply/never-written\.md' "$PARENT/state/ios.status")" >/dev/null \
  || fail "new remote document note has unknown emission time"
assert_grep 'dispatched a scout report=data/reply/never-written.md' "$PARENT/state/ios.status" \
  "an undeliverable offer's line was not mirrored with its own pointer intact"
assert_no_document_decision "an undeliverable structured offer raised a document decision"
mirrored_cursor_is_current "an undeliverable structured offer held the cursor back"
mirror_lines \
  'reply [corr=4444444444444444]: still writing report=data/reply/never-written.md' \
  'reply [corr=4444444444444444]: same, report=data/reply/never-written.md'
[ "$(sed -E 's/ \[at=[0-9]+\]//' "$PARENT/state/ios.status" | grep -cF 'note: remote document did not transfer for ios: data/reply/never-written.md')" -eq 1 ] \
  || fail "re-offering the same undeliverable document repeated its note"
assert_no_document_decision "re-offering an undeliverable document raised a document decision"
pass "an undeliverable structured offer fails open with one note and never a decision"

# The positive remote-refusal case with a genuinely non-transient cause: the
# reader bounds document size, and that refusal is visible by its own reason.
head -c 300000 /dev/zero | tr '\0' 'x' > "$REMOTE/data/reply/big.md"
mirror_lines 'done [key=big-report]: oversize deliverable report=data/reply/big.md'
assert_grep 'note: remote document did not transfer for ios: data/reply/big.md - file exceeds max-bytes' <(sed -E 's/ \[at=[0-9]+\]//' "$PARENT/state/ios.status") \
  "an oversize document's refusal did not surface with its reason"
assert_absent "$PARENT/data/remote-secondmates/ios/data/reply/big.md" \
  "a refused oversize document was stored locally anyway"
assert_no_document_decision "an oversize document raised a document decision"
mirrored_cursor_is_current "an oversize document held the cursor back"
pass "a remote refusal surfaces its own reason without opening a decision"

# A failed extraction pass must leave the delta wholly uncommitted. Once the
# parser works again, the same captured delta applies in full.
printf '# extraction-failure probe\n' > "$REMOTE/data/reply/extractfail.md"
GEN=$((GEN + 1))
stop_reply_listener || fail "the reply listener did not stop before the extraction-failure capture"
printf 'done [key=extraction-failure]: probe report=data/reply/extractfail.md\n' \
  >> "$REMOTE/state/parent-replies.status"
extractfail_cursor_before=$(cat "$PARENT/state/remote-replies/ios.cursor")
cp "$PARENT/state/ios.status" "$TMP_ROOT/ios-status-before-extractfail"
EXTRACT_FAIL_BIN="$TMP_ROOT/extract-fail-bin"
mkdir -p "$EXTRACT_FAIL_BIN"
REAL_AWK=$(command -v awk)
# The stand-in awk refuses only the extraction pass, so every other awk the
# relay depends on keeps working.
{
  cat <<'SH'
#!/usr/bin/env bash
for argument in "$@"; do
  [ "$argument" != mode=extract ] || exit 97
done
SH
  printf 'exec %q "$@"\n' "$REAL_AWK"
} > "$EXTRACT_FAIL_BIN/awk"
chmod +x "$EXTRACT_FAIL_BIN/awk"
PATH="$EXTRACT_FAIL_BIN:$PATH" remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" \
  >/dev/null 2>&1 || true
RESULT_EXTRACTFAIL="$PARENT/state/procevent-inbox/$SID.$GEN.result"
assert_present "$RESULT_EXTRACTFAIL" "the extraction-failure delta was not captured"
assert_absent "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
  "a capture whose pointer extraction failed was acknowledged anyway"
extractfail_rc=0
PATH="$EXTRACT_FAIL_BIN:$PATH" remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_EXTRACTFAIL" \
  > "$TMP_ROOT/extract-fail.out" 2>&1 || extractfail_rc=$?
[ "$extractfail_rc" -ne 0 ] || fail "the failed extraction pass reported success"
assert_grep 'cannot extract remote document pointers' "$TMP_ROOT/extract-fail.out" \
  "the failed extraction pass did not report its failure"
[ "$(cat "$PARENT/state/remote-replies/ios.cursor")" = "$extractfail_cursor_before" ] \
  || fail "a failed extraction pass advanced the cursor past dropped status content"
cmp -s "$TMP_ROOT/ios-status-before-extractfail" "$PARENT/state/ios.status" \
  || fail "a failed extraction pass appended partial or blank status content"
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_EXTRACTFAIL" >/dev/null \
  || fail "the delta did not apply once pointer extraction worked again"
assert_grep 'report=data/remote-secondmates/ios/data/reply/extractfail.md' "$PARENT/state/ios.status" \
  "the recovered delta did not mirror its rewritten pointer"
cmp -s "$REMOTE/data/reply/extractfail.md" "$PARENT/data/remote-secondmates/ios/data/reply/extractfail.md" \
  || fail "the recovered delta did not fetch its offered document"
mirrored_cursor_is_current "the recovered extraction-failure delta did not advance the cursor"
pass "a failed pointer extraction never commits a partial delta"

# A mirror write that cannot complete must fail loudly rather than leave blank
# or partial content behind and advance the cursor past status bytes nobody
# ever received. The delta stays uncommitted and applies in full once the
# stream is writable again.
printf '# write-failure probe\n' > "$REMOTE/data/reply/writefail.md"
GEN=$((GEN + 1))
stop_reply_listener || fail "the reply listener did not stop before the unwritable-stream capture"
printf 'done [key=write-failure]: probe report=data/reply/writefail.md\n' \
  >> "$REMOTE/state/parent-replies.status"
writefail_cursor_before=$(cat "$PARENT/state/remote-replies/ios.cursor")
cp "$PARENT/state/ios.status" "$TMP_ROOT/ios-status-before-writefail"
chmod 444 "$PARENT/state/ios.status"
remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 || true
RESULT_WRITEFAIL="$PARENT/state/procevent-inbox/$SID.$GEN.result"
assert_present "$RESULT_WRITEFAIL" "the unwritable-stream delta was not captured"
assert_absent "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
  "a capture whose mirror write failed was acknowledged anyway"
[ "$(cat "$PARENT/state/remote-replies/ios.cursor")" = "$writefail_cursor_before" ] \
  || fail "a failed mirror write advanced the cursor past dropped status content"
chmod 644 "$PARENT/state/ios.status"
cmp -s "$TMP_ROOT/ios-status-before-writefail" "$PARENT/state/ios.status" \
  || fail "a failed mirror write left partial or blank content on the parent stream"
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_WRITEFAIL" >/dev/null \
  || fail "the delta did not apply once the parent stream was writable again"
assert_grep 'report=data/remote-secondmates/ios/data/reply/writefail.md' "$PARENT/state/ios.status" \
  "the recovered delta did not mirror its rewritten pointer"
mirrored_cursor_is_current "the recovered delta did not advance the cursor"
pass "a failed mirror write never drops status content or advances the cursor"

# The whole-log recapture re-fetches every document the log offers, one remote
# job at a time, so it needs far more than one await_reply_result budget on a
# loaded runner. Each attempt is a full wait that re-checks ownership of the
# source, so the recapture is bounded by RECAPTURE_WAIT_ATTEMPTS of them.
RECAPTURE_WAIT_ATTEMPTS=3
await_recapture_result() { # <result-path>
  local attempt
  for attempt in $(seq 1 "$RECAPTURE_WAIT_ATTEMPTS"); do
    await_reply_result "$1" && return 0
  done
  return 1
}

# A source line remains the replay identity even when document availability
# changes between a successful mirror append and a failed ingestion commit.
REPLAY_LINE='needs-decision [key=replay-decision]: pick report=data/reply/replay.md'
rm -f "$REMOTE/data/reply/replay.md"
GEN=$((GEN + 1))
stop_reply_listener || fail "the reply listener did not stop before the receipt-failure capture"
printf '%s\n' "$REPLAY_LINE" >> "$REMOTE/state/parent-replies.status"
replay_commit_cursor_before=$(cat "$PARENT/state/remote-replies/ios.cursor")
RECEIPT_FAIL_BIN="$TMP_ROOT/receipt-fail-bin"
mkdir -p "$RECEIPT_FAIL_BIN"
REAL_MKTEMP=$(command -v mktemp)
{
  cat <<'SH'
#!/usr/bin/env bash
case "${1:-}" in
  */state/remote-replies/.ingested.XXXXXX) exit 73 ;;
esac
SH
  printf 'exec %q "$@"\n' "$REAL_MKTEMP"
} > "$RECEIPT_FAIL_BIN/mktemp"
chmod +x "$RECEIPT_FAIL_BIN/mktemp"
PATH="$RECEIPT_FAIL_BIN:$PATH" remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" \
  >/dev/null 2>&1 || true
RESULT_REPLAY_COMMIT="$PARENT/state/procevent-inbox/$SID.$GEN.result"
assert_present "$RESULT_REPLAY_COMMIT" "the replay-identity delta was not captured"
assert_absent "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
  "the generation whose ingestion receipt failed was acknowledged"
[ "$(cat "$PARENT/state/remote-replies/ios.cursor")" = "$replay_commit_cursor_before" ] \
  || fail "an ingestion receipt failure advanced the remote reply cursor"
[ "$(grep -cF "$REPLAY_LINE" "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "the pre-rewrite decision line was not mirrored exactly once before commit failure"
printf '# replay decision report\n' > "$REMOTE/data/reply/replay.md"
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_REPLAY_COMMIT" >/dev/null \
  || fail "the uncommitted generation did not retry after its document arrived"
[ "$(grep -cF "$REPLAY_LINE" "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "retrying after document arrival duplicated the source decision line"
assert_no_grep 'needs-decision [key=replay-decision]: pick report=data/remote-secondmates/ios/data/reply/replay.md' \
  "$PARENT/state/ios.status" "retrying after document arrival appended a rewritten duplicate"
assert_present "$PARENT/data/remote-secondmates/ios/data/reply/replay.md" \
  "the retry did not fetch the document that had since arrived"
printf 'resolved [key=replay-decision]: selection complete\n' >> "$PARENT/state/ios.status"
assert_not_contains "$(status_open_decisions "$PARENT/state/ios.status")" $'replay-decision\t' \
  "the replay decision fixture did not close before cursor-loss recapture"
stop_reply_listener || fail "the reply listener did not stop before the cursor-loss recapture"
rm -f "$PARENT/state/remote-replies/ios.cursor"
GEN=$((GEN + 1))
await_recapture_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the replay-identity whole-log recapture was not captured"
assert_present "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
  "the replay-identity whole-log recapture was not applied"
[ "$(grep -cF "$REPLAY_LINE" "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "cursor-loss recapture duplicated the resolved decision"
assert_no_grep 'needs-decision [key=replay-decision]: pick report=data/remote-secondmates/ios/data/reply/replay.md' \
  "$PARENT/state/ios.status" "cursor-loss recapture reopened the decision in rewritten form"
assert_not_contains "$(status_open_decisions "$PARENT/state/ios.status")" $'replay-decision\t' \
  "cursor-loss recapture reopened the resolved decision"
pass "source-line identity survives commit failure and cursor-loss recapture"

# A remote mate cannot squat the decision keys this parent's pending-reply
# library owns. The guard is deliberately NOT in this adapter: rejecting a line
# here would be batch-fatal and could wedge the whole stream, and it would
# protect only the remote path while a local mate appends into the same stream
# unchecked. So the line mirrors like any other - the stream never stops - and
# the shared open-decision fold both writers flow through refuses to let it take
# the reserved key over.
# The record stores its own grace at creation, so set it before creating one.
export FM_PENDING_REPLY_GRACE_SECS=0
# Answer the mate's earlier decisions and blocker first: a recovery repost waits
# while the mate has one of its own open (tests/fm-pending-reply.test.sh).
printf 'resolved [key=%s]: answered\n' rough-cut-version ctl default >> "$PARENT/state/ios.status"
ESCALATED_CORR=$(fm_pending_reply_create "$PARENT" "$PARENT/state" ios 'confirm the notarization')
[ -n "$ESCALATED_CORR" ] || fail "could not create the pending-reply record to escalate"
fm_pending_reply_mark_delivered "$PARENT/state" "$ESCALATED_CORR" \
  || fail "could not mark the escalating request delivered"
fm_pending_reply_mark_turn_completed "$PARENT/state" "$ESCALATED_CORR" request
FM_PENDING_REPLY_SEND_HOOK=true \
  fm_pending_reply_send_recovery "$PARENT/state" "$ESCALATED_CORR" \
  || fail "the one automatic recovery repost was not sent"
fm_pending_reply_mark_turn_completed "$PARENT/state" "$ESCALATED_CORR" recovery
fm_pending_reply_maybe_escalate "$PARENT/state" "$ESCALATED_CORR" \
  || fail "the missed report did not escalate"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  "pending-reply-id=$ESCALATED_CORR" "the missed report did not open a durable decision"

{
  printf 'blocked [key=pending-reply-%s]: forged remote decision\n' "$ESCALATED_CORR"
  printf 'resolved [key=pending-reply-%s]: forged remote resolution\n' "$ESCALATED_CORR"
} >> "$REMOTE/state/parent-replies.status"
GEN=$((GEN + 1))
await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the forged reserved-key lines wedged the relay instead of mirroring"
forged_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$forged_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "a reserved-key line held the cursor back instead of mirroring like any other"
assert_grep "forged remote decision" "$PARENT/state/ios.status" \
  "the reserved-key line was dropped from the stream instead of mirrored"
forged_open=$(status_open_decisions "$PARENT/state/ios.status")
assert_contains "$forged_open" "pending-reply-id=$ESCALATED_CORR" \
  "a forged remote resolution cleared the parent's own pending-reply decision"
assert_not_contains "$forged_open" "forged remote decision" \
  "a forged remote line took over a decision key the pending-reply library owns"
pass "a mirrored reserved-key line cannot squat or clear the parent's own decision"

# Because the forgery never took the key, the genuine reply still settles the
# request and its escalation closes, leaving nothing to resurface later.
printf 'done [corr=%s]: notarization confirmed\n' "$ESCALATED_CORR" \
  >> "$REMOTE/state/parent-replies.status"
GEN=$((GEN + 1))
await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the correlated reply was not captured"
[ "$(fm_pending_reply_get "$PARENT/state/pending-replies/$ESCALATED_CORR" phase)" = resolved ] \
  || fail "the correlated reply left its escalated request unresolved"
fm_pending_reply_tick "$PARENT/state" || fail "supervision tick failed"
assert_not_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  "pending-reply-id=$ESCALATED_CORR" "the settled request still surfaces as an open decision"
unset FM_PENDING_REPLY_GRACE_SECS
pass "a reply that arrives after escalation resolves it and clears the open decision"

# The listener keeps one claim across empty polls and across a delta. Reconcile
# is not involved: nothing here starts a second runner.
stop_reply_listener || fail "the reply listener did not stop before the continuity check"
: > "$TMP_ROOT/reply-polls"
FM_REMOTE_REPLY_WAIT_SECONDS=1 \
FM_REMOTE_REPLY_POLL_LOG="$TMP_ROOT/reply-polls" \
  remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 &
wait_for "$CLAIMS/$SID.claim" || fail "continuous reply listener never claimed the source"
HELD_PID=$(sed -n '2p' "$CLAIMS/$SID.claim")
polls=0
for _ in $(seq 1 120); do
  polls=$(wc -l < "$TMP_ROOT/reply-polls" | tr -d ' ')
  [ "$polls" -ge 2 ] && break
  sleep 0.25
done
[ "$polls" -ge 2 ] || fail "the reply listener did not poll twice while still owned"
[ "$(reply_owner)" = live ] || fail "the reply listener dropped its claim between empty waits"
[ "$(sed -n '2p' "$CLAIMS/$SID.claim")" = "$HELD_PID" ] \
  || fail "an empty wait replaced the reply listener"
printf 'working [corr=abcdefabcdefabcd]: held across an empty wait\n' \
  >> "$REMOTE/state/parent-replies.status"
for _ in $(seq 1 80); do
  grep -q 'held across an empty wait' "$PARENT/state/ios.status" && break
  sleep 0.1
done
grep -q 'held across an empty wait' "$PARENT/state/ios.status" \
  || fail "a delta appended while the listener was owned was not mirrored"
GEN=$((GEN + 1))
[ "$(sed -n '2p' "$CLAIMS/$SID.claim")" = "$HELD_PID" ] \
  || fail "a delta replaced the reply listener"
polls_after_delta=$(wc -l < "$TMP_ROOT/reply-polls" | tr -d ' ')
for _ in $(seq 1 120); do
  polls=$(wc -l < "$TMP_ROOT/reply-polls" | tr -d ' ')
  [ "$polls" -gt "$polls_after_delta" ] && break
  sleep 0.25
done
[ "$polls" -gt "$polls_after_delta" ] || fail "the reply listener did not poll again after a delta"
[ "$(reply_owner)" = live ] || fail "the reply listener dropped its claim after a delta"
[ "$(sed -n '2p' "$CLAIMS/$SID.claim")" = "$HELD_PID" ] \
  || fail "the post-delta poll was a new listener"
if [ "${FM_TEST_EVIDENCE:-0}" = 1 ]; then
  printf 'Continuous listener: owner=%s pid=%s polls=%s; mirrored status: ' \
    "$(reply_owner)" "$HELD_PID" "$polls"
  grep -F 'held across an empty wait' "$PARENT/state/ios.status" | tail -1
fi
stop_reply_listener || fail "the continuity listener did not stop"
pass "a remote reply listener stays owned across empty waits and a delta"

# A failed transport is not an empty wait: do not launch a second read under
# the same owner, even when the launch floor is short.
: > "$TMP_ROOT/failed-polls"
FM_REMOTE_REPLY_FAIL_READ=1 FM_REMOTE_REPLY_POLL_LOG="$TMP_ROOT/failed-polls" \
  FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 \
  remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 &
failed_reader=$!
wait "$failed_reader" || fail "failed reader did not leave the runner"
sleep 2
[ "$(wc -l < "$TMP_ROOT/failed-polls" | tr -d ' ')" -eq 1 ] \
  || fail "failed reader relaunched within the launch floor"
pass "a failed remote read exits instead of relistening"

# Make local ingestion persistently fail after the delta has been captured.
# Its durable generation must remain the only copy until reconciliation.
mv "$PARENT/state/ios.status" "$TMP_ROOT/ios-status-before-failure"
mkdir "$PARENT/state/ios.status"
printf 'working: cannot ingest yet\n' >> "$REMOTE/state/parent-replies.status"
failed_gen=$((GEN + 1))
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 FM_REMOTE_REPLY_WAIT_SECONDS=1 \
  remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 &
failed_ingest=$!
wait "$failed_ingest" || fail "failed ingestion did not leave the runner"
sleep 2
[ -f "$PARENT/state/procevent-inbox/$SID.$failed_gen.result" ] \
  || fail "failed ingestion lost its durable capture"
[ ! -e "$PARENT/state/procevent-inbox/$SID.$((failed_gen + 1)).result" ] \
  || fail "failed ingestion recaptured the same delta"
rmdir "$PARENT/state/ios.status"
mv "$TMP_ROOT/ios-status-before-failure" "$PARENT/state/ios.status"
# The next sections assume the cursor has advanced; apply the one saved result.
remote_env "$ADAPTER" handle ios "$failed_gen" \
  "$PARENT/state/procevent-inbox/$SID.$failed_gen.result" >/dev/null \
  || fail "saved capture could not be retried"
GEN=$failed_gen
pass "persistent ingestion failure leaves exactly one durable capture"

rm -f -- "$PARENT/state/remote-replies/ios.caught-up"
remote_env "$ADAPTER" source ios > "$TMP_ROOT/preempted-source.out" 2>&1 &
PREEMPTED_SOURCE=$!
running_poll=''
for _ in $(seq 1 100); do
  for job in "$TMP_ROOT"/remote-jobs/jobs/job-*; do
    [ -d "$job" ] || continue
    if [ "$(fm_remote_job_read_state "$job" 2>/dev/null || true)" = running ]; then
      running_poll=$job
      break 2
    fi
  done
  sleep 0.05
done
[ -n "$running_poll" ] || fail "the reply poll did not begin running before preemption"
remote_env "$ROOT/bin/fm-on.sh" ios fm-remote-file.sh get data/reply/report.md 262144 >/dev/null
set +e
wait "$PREEMPTED_SOURCE"
preempted_rc=$?
set -e
[ "$preempted_rc" -eq 75 ] \
  || fail "a preempted reply poll did not report a closed window: $preempted_rc"
assert_absent "$PARENT/state/remote-replies/ios.caught-up" \
  "a preempted reply poll published a caught-up watermark"
pass "a preempted reply poll reports a closed window without publishing channel freshness"

# The per-cycle liveness probe is a non-preemptible job for the same remote home,
# so the job worker preempts the listener's long-poll on every watcher cycle.
# That must not cost the listener: it keeps its claim and polls again, and the
# watcher's reconcile has nothing to relaunch.
: > "$TMP_ROOT/preempted-polls"
FM_REMOTE_REPLY_POLL_LOG="$TMP_ROOT/preempted-polls" FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 \
  remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" >/dev/null 2>&1 &
PREEMPTED_RUNNER=$!
wait_for "$CLAIMS/$SID.claim" || fail "the preempted-listener case never claimed the source"
HELD_PID=$(sed -n '2p' "$CLAIMS/$SID.claim")
running_poll=''
for _ in $(seq 1 100); do
  for job in "$TMP_ROOT"/remote-jobs/jobs/job-*; do
    [ -d "$job" ] || continue
    if [ "$(fm_remote_job_read_state "$job" 2>/dev/null || true)" = running ]; then
      running_poll=$job
      break 2
    fi
  done
  sleep 0.05
done
[ -n "$running_poll" ] || fail "the listener's poll did not begin running before preemption"
remote_env "$ROOT/bin/fm-on.sh" ios fm-remote-file.sh get data/reply/report.md 262144 >/dev/null
polls=0
for _ in $(seq 1 120); do
  polls=$(wc -l < "$TMP_ROOT/preempted-polls" | tr -d ' ')
  [ "$polls" -ge 2 ] && break
  sleep 0.25
done
[ "$polls" -ge 2 ] || fail "the preempted listener did not poll again"
case "$(ps -p "$PREEMPTED_RUNNER" -o stat= 2>/dev/null)" in
  ''|Z*) fail "a preempted poll ended the reply listener" ;;
esac
[ "$(reply_owner)" = live ] || fail "a preempted poll released the listener's claim"
[ "$(sed -n '2p' "$CLAIMS/$SID.claim")" = "$HELD_PID" ] \
  || fail "a preempted poll replaced the reply listener"
reconcile_out=$(remote_env "$ROOT/bin/fm-procevent.sh" reconcile)
assert_contains "$reconcile_out" 'started=0' \
  "reconcile relaunched a listener after a preempted poll"
[ "$(sed -n '2p' "$CLAIMS/$SID.claim")" = "$HELD_PID" ] \
  || fail "reconcile replaced the preempted listener"
stop_reply_listener || fail "the preempted listener did not stop"
wait "$PREEMPTED_RUNNER" 2>/dev/null || true
pass "a preempted reply poll keeps its listener and reconcile launches nothing"

# A quiet window is the one moment this channel can prove it is NOT behind, and
# the parent's pending-reply guard needs that proof: a remote report that exists
# but has not been mirrored yet must never be mistaken for a report the mate
# never wrote. The window opened with the log matching the committed cursor, so
# the published watermark is the window's start.
watermark_before=$(date +%s)
set +e
FM_REMOTE_REPLY_WAIT_SECONDS=1 remote_env "$ADAPTER" source ios >/dev/null 2>&1
quiet_rc=$?
set -e
[ "$quiet_rc" -eq 75 ] || fail "a quiet reply window exited with an unexpected status: $quiet_rc"
watermark_after=$(date +%s)
caught_up=$(FM_STATE_OVERRIDE="$PARENT/state" bash -c '
  . "$1/bin/fm-pending-reply-lib.sh"
  fm_pending_reply_remote_channel_epoch "$2/state" ios
' _ "$ROOT" "$PARENT")
[ -n "$caught_up" ] || fail "a quiet reply window published no caught-up watermark"
[ "$caught_up" -ge "$watermark_before" ] && [ "$caught_up" -le "$watermark_after" ] \
  || fail "the caught-up watermark ($caught_up) is outside the quiet window"
pass "a quiet reply window publishes the caught-up watermark the reply guard reads"

# The observed already-handled replay class: a lost cursor (an update or
# convergence retire) makes the next armed source recapture the WHOLE remote
# log from offset 0. Every line is already mirrored, so the at-most-once
# append adds no bytes, the adapter acknowledges the generation, and the
# self-announcing runner publishes nothing - the replay stays completely
# quiet, observed through the same seen-signature gate the watcher consumes.
FM_STATE_OVERRIDE="$PARENT/state" bash -c '
  . "$1/bin/fm-wake-lib.sh"
  fm_wake_status_mark_current "$2/state" "$2/state/ios.status"
' _ "$ROOT" "$PARENT" || fail "could not prime the seen marker for the replay leg"
cp "$PARENT/state/ios.status" "$TMP_ROOT/ios-status-before-replay"
mv "$PARENT/state/.wake-queue" "$TMP_ROOT/wake-queue-before-replay" 2>/dev/null || true
stop_reply_listener || fail "the reply listener did not stop before the whole-log recapture"
rm -f "$PARENT/state/remote-replies/ios.cursor"
GEN=$((GEN + 1))
await_recapture_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the cursor-loss recapture was not captured"
assert_present "$PARENT/state/procevent-inbox/$SID.$GEN.handled" \
  "the whole-log recapture was not acknowledged by the adapter"
# Documents that were undelivered when their lines first mirrored have since
# arrived, so this replay also pins that a line mirrors once whichever pointer
# form it was first written under.
cmp -s "$TMP_ROOT/ios-status-before-replay" "$PARENT/state/ios.status" \
  || fail "the whole-log recapture duplicated already-mirrored lines"
if [ -e "$PARENT/state/.wake-queue" ] && grep -q "procevent remote-reply $SID $GEN" "$PARENT/state/.wake-queue"; then
  fail "an already-mirrored recapture still published a check wake"
fi
FM_STATE_OVERRIDE="$PARENT/state" bash -c '
  . "$1/bin/fm-wake-lib.sh"
  fm_wake_signal_seen_current "$2/state" "$2/state/ios.status"
' _ "$ROOT" "$PARENT" || fail "a byte-identical recapture left unannounced status bytes behind"
replay_offset=$(LC_ALL=C wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
assert_grep "offset=$replay_offset" "$PARENT/state/remote-replies/ios.cursor" \
  "the recapture did not rebuild the lost cursor"
pass "a cursor-loss whole-log recapture is acknowledged quietly with no duplicate wake"

# The adapter re-armed at the committed cursor. Truncation is detected from the
# next blocking source and escalated once; it is never silently treated as a new
# log or re-armed past the break.
stop_reply_listener || fail "the reply listener did not stop before the continuity break"
printf 'failed [corr=fedcba9876543210]: source was replaced\n' > "$REMOTE/state/parent-replies.status"
GEN=$((GEN + 1))
remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" > "$TMP_ROOT/start-two.out" 2>&1 &
RUNNER=$!
wait "$RUNNER" || fail "continuity break was not captured as a structured result"
RESULT_TWELVE=$(find "$PARENT/state/procevent-inbox" -name "$SID.$GEN.result" -print -quit)
[ -n "$RESULT_TWELVE" ] || fail "continuity break produced no durable result"
[ "$(remote_env "$ADAPTER" classify "$RESULT_TWELVE")" = continuity-broken ] \
  || fail "truncated source was not classified as a continuity break"
set +e
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_TWELVE" > "$TMP_ROOT/handle-nine.out" 2>&1
handle_rc=$?
set -e
[ "$handle_rc" -eq 3 ] || fail "continuity handling returned an unexpected status: $handle_rc"
assert_grep 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status" "continuity break did not escalate"
assert_absent "$PARENT/state/procevent/$SID.source" "continuity break was re-armed without an operator rebase"
remote_env "$ADAPTER" ingest ios "$RESULT_TWELVE" >/dev/null 2>&1 || true
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "continuity replay duplicated the escalation"
first_offset=$(sed -n 's/^offset=//p' "$PARENT/state/remote-replies/ios.cursor")
first_hash=$(sed -n 's/^prefix_sha256=//p' "$PARENT/state/remote-replies/ios.cursor" | tr 'A-F' 'a-f')
first_prefix=$(printf '%.12s' "$first_hash")
assert_grep "at offset ${first_offset} prefix ${first_prefix} retirements 0" "$PARENT/state/ios.status" \
  "continuity break did not record the reader position"
assert_no_grep "prefix ${first_hash}" "$PARENT/state/ios.status" \
  "continuity break recorded the full prefix hash"
assert_absent "$PARENT/state/remote-replies/ios.retirements" \
  "a route that has never been retired gained a retirement count"
status_line_at_epoch "$(grep -F 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" >/dev/null \
  || fail "new continuity escalation has unknown emission time"
if [ "${FM_TEST_EVIDENCE:-0}" = 1 ]; then
  printf '\nNew continuity escalation after ingest retry:\n'
  grep -F 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status"
fi
pass "truncation is detected, escalated once, and not silently rebased"

# The break does not advance the cursor, so a later read of the unchanged
# remote log reports the same break. An operator resolve in between must not
# make that repeat look like a new break.
printf '%s\n' 'resolved [key=remote-reply-continuity-ios]: operator accepted the break' \
  >> "$PARENT/state/ios.status"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "operator resolve left the continuity decision open"
rm -f "$PARENT/state/procevent-inbox/$SID.$GEN.handled"
set +e
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_TWELVE" > "$TMP_ROOT/handle-resolved.out" 2>&1
handle_rc=$?
set -e
[ "$handle_rc" -eq 3 ] || fail "repeated continuity handling returned an unexpected status: $handle_rc"
remote_env "$ADAPTER" ingest ios "$RESULT_TWELVE" >/dev/null 2>&1 || true
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "a repeated continuity break appended again after the operator resolve"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "a repeated continuity break reopened the decision the operator resolved"
pass "a repeated continuity break after an operator resolve appends nothing"

rm -f "$PARENT/state/procevent-inbox/$SID.$GEN.handled"
if remote_env "$ADAPTER" retire ios > "$TMP_ROOT/retire-pending.out" 2>&1; then
  fail "remote reply retirement accepted an unhandled captured result"
fi
assert_grep 'unhandled captured result' "$TMP_ROOT/retire-pending.out" \
  "remote reply retirement did not explain its pending-result refusal"
assert_absent "$PARENT/state/procevent/$SID.source" \
  "refused retirement left the reply source running past its pending-result check"
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_TWELVE" >/dev/null 2>&1 || [ "$?" -eq 3 ] \
  || fail "pending continuity result could not be acknowledged after retirement refusal"
remote_env "$ADAPTER" retire ios >/dev/null
assert_absent "$PARENT/state/remote-replies/ios.cursor" "adapter retirement left its cursor"
recorded_retirements=$(cat "$PARENT/state/remote-replies/ios.retirements" 2>/dev/null || true)
[ "$recorded_retirements" = count=1 ] \
  || fail "adapter retirement did not record its count (got: ${recorded_retirements:-absent})"
assert_absent "$PARENT/state/remote-replies/ios.caught-up" \
  "adapter retirement left a caught-up watermark a later route could inherit"
pass "remote reply retirement quiesces and refuses unhandled captured results"

# Empty the remote log under the committed cursor and handle the break the
# next blocking source reports. Sets RESULT_BREAK.
break_repaired_route() { # <label> [expected-handle-status]
  local label=$1 expected=${2:-3} runner handle_rc
  stop_reply_listener || fail "the reply listener did not stop before the $label continuity break"
  : > "$REMOTE/state/parent-replies.status"
  GEN=$((GEN + 1))
  remote_env "$ROOT/bin/fm-procevent.sh" start "$SID" > "$TMP_ROOT/start-$label-break.out" 2>&1 &
  runner=$!
  wait "$runner" || fail "the $label continuity break was not captured"
  RESULT_BREAK=$(find "$PARENT/state/procevent-inbox" -name "$SID.$GEN.result" -print -quit)
  [ -n "$RESULT_BREAK" ] || fail "the $label continuity break produced no durable result"
  [ "$(remote_env "$ADAPTER" classify "$RESULT_BREAK")" = continuity-broken ] \
    || fail "the $label truncation was not classified as a continuity break"
  set +e
  remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_BREAK" > "$TMP_ROOT/handle-$label-break.out" 2>&1
  handle_rc=$?
  set -e
  [ "$handle_rc" -eq "$expected" ] || fail "the $label continuity break returned an unexpected status: $handle_rc"
}

# Close the open continuity decision, put back the log the cursor was committed
# against with one more line, and let the reader advance over that line. The
# route is not retired, so the cursor moves only because new bytes were read.
resolve_and_extend_route() { # <label> <log-content>
  local label=$1 content=$2 bytes blocked_before
  blocked_before=$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")
  printf '%s\n' 'resolved [key=remote-reply-continuity-ios]: operator accepted the break' \
    >> "$PARENT/state/ios.status"
  printf '%s' "$content" > "$REMOTE/state/parent-replies.status"
  bytes=$(wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
  remote_env "$ADAPTER" arm ios >/dev/null
  GEN=$((GEN + 1))
  await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
    || fail "the route extended after the $label break was not read"
  assert_grep "offset=$bytes" "$PARENT/state/remote-replies/ios.cursor" \
    "the route extended after the $label break did not advance the cursor"
  [ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq "$blocked_before" ] \
    || fail "extending the route after the $label break appended a continuity break"
  [ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
    || fail "extending the route after the $label break reopened the continuity decision"
}

# The resolved break above stays closed through an unchanged re-read. Repair
# the log, let the reader advance, and truncate again. The later break is at
# another reader position, so its line is new and the decision opens again.
printf 'working: route restored and readable again\n' > "$REMOTE/state/parent-replies.status"
restored_bytes=$(wc -c < "$REMOTE/state/parent-replies.status" | tr -d ' ')
remote_env "$ADAPTER" arm ios >/dev/null
GEN=$((GEN + 1))
await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the repaired route was not read"
assert_grep "offset=$restored_bytes" "$PARENT/state/remote-replies/ios.cursor" \
  "the repaired route did not advance the cursor"
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 1 ] \
  || fail "repairing the route appended a continuity break"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "repairing the route reopened the continuity decision"
break_repaired_route "second" 3
RESULT_SECOND=$RESULT_BREAK
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 2 ] \
  || fail "a later continuity break after repair appended nothing"
second_offset=$(sed -n 's/^offset=//p' "$PARENT/state/remote-replies/ios.cursor")
second_hash=$(sed -n 's/^prefix_sha256=//p' "$PARENT/state/remote-replies/ios.cursor" | tr 'A-F' 'a-f')
second_prefix=$(printf '%.12s' "$second_hash")
assert_grep "at offset ${second_offset} prefix ${second_prefix} retirements 1" "$PARENT/state/ios.status" \
  "a later continuity break after repair did not record its reader position"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a later continuity break after repair did not reopen the decision"
remote_env "$ADAPTER" ingest ios "$RESULT_SECOND" >/dev/null 2>&1 || true
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 2 ] \
  || fail "a repeated read of the later continuity break appended again"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a repeated read of the later continuity break closed the decision"
pass "a later continuity break after repair and re-advance opens the decision again"

# A line from before the reader position was recorded names the route and the
# reason only. It does not match the new line, so this same break appends once.
awk '
  /blocked \[key=remote-reply-continuity-ios\]/ {
    sub(/ at offset [0-9]+ prefix [0-9a-f]+( retirements [0-9]+)?$/, "")
  }
  { print }
' "$PARENT/state/ios.status" > "$TMP_ROOT/ios-status-old-format"
mv "$TMP_ROOT/ios-status-old-format" "$PARENT/state/ios.status"
printf '%s\n' 'resolved [key=remote-reply-continuity-ios]: operator accepted the break' \
  >> "$PARENT/state/ios.status"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "operator resolve left the old-format continuity decision open"
set +e
remote_env "$ADAPTER" handle ios "$GEN" "$RESULT_SECOND" > "$TMP_ROOT/handle-old-format.out" 2>&1
handle_rc=$?
set -e
[ "$handle_rc" -eq 3 ] || fail "a continuity break after an old-format line returned an unexpected status: $handle_rc"
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 3 ] \
  || fail "a continuity break after an old-format line appended nothing"
assert_grep "at offset ${second_offset} prefix ${second_prefix} retirements 1" "$PARENT/state/ios.status" \
  "a continuity break after an old-format line did not record the reader position"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a continuity break after an old-format line did not reopen the decision"
remote_env "$ADAPTER" ingest ios "$RESULT_SECOND" >/dev/null 2>&1 || true
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 3 ] \
  || fail "a repeated read after the old-format upgrade appended again"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a repeated read after the old-format upgrade closed the decision"
pass "an old-format continuity line does not swallow the next break"

# No retirement this time. The cursor leaves the escalated offset only because
# the reader consumed new bytes, and that alone makes the next break new.
LOG_RESTORED=$'working: route restored and readable again\n'
LOG_EXTENDED=$LOG_RESTORED$'working: route extended without retirement\n'
resolve_and_extend_route "second" "$LOG_EXTENDED"
break_repaired_route "third" 3
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 4 ] \
  || fail "a later continuity break after the cursor moved without retirement appended nothing"
moved_offset=$(sed -n 's/^offset=//p' "$PARENT/state/remote-replies/ios.cursor")
moved_hash=$(sed -n 's/^prefix_sha256=//p' "$PARENT/state/remote-replies/ios.cursor" | tr 'A-F' 'a-f')
moved_prefix=$(printf '%.12s' "$moved_hash")
assert_grep "at offset ${moved_offset} prefix ${moved_prefix} retirements 1" "$PARENT/state/ios.status" \
  "a later continuity break after the cursor moved did not record its reader position"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a later continuity break after the cursor moved without retirement did not reopen the decision"
pass "a later continuity break after the cursor moves without retirement opens the decision again"

# Retire, put the same bytes back, and break at the same offset. The retirement
# count makes that line new, so the decision opens once. The repeat stays silent.
printf '%s\n' 'resolved [key=remote-reply-continuity-ios]: operator accepted the break' \
  >> "$PARENT/state/ios.status"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "operator resolve left the extended continuity decision open"
remote_env "$ADAPTER" retire ios >/dev/null
recorded_retirements=$(cat "$PARENT/state/remote-replies/ios.retirements" 2>/dev/null || true)
[ "$recorded_retirements" = count=2 ] \
  || fail "the second retirement did not advance the count (got: ${recorded_retirements:-absent})"
printf '%s' "$LOG_EXTENDED" > "$REMOTE/state/parent-replies.status"
remote_env "$ADAPTER" arm ios >/dev/null
GEN=$((GEN + 1))
await_reply_result "$PARENT/state/procevent-inbox/$SID.$GEN.result" \
  || fail "the restored route was not read"
assert_grep "offset=${moved_offset}" "$PARENT/state/remote-replies/ios.cursor" \
  "restoring the same bytes did not reach the same offset"
restored_hash=$(sed -n 's/^prefix_sha256=//p' "$PARENT/state/remote-replies/ios.cursor" | tr 'A-F' 'a-f')
[ "$restored_hash" = "$moved_hash" ] || fail "restoring the same bytes changed the prefix hash"
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 4 ] \
  || fail "restoring the same bytes appended a continuity break"
[ -z "$(status_open_decisions "$PARENT/state/ios.status")" ] \
  || fail "restoring the same bytes reopened the continuity decision"
break_repaired_route "retired-same" 3
RESULT_RETIRED=$RESULT_BREAK
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 5 ] \
  || fail "a continuity break after an identical restore appended nothing"
assert_grep "at offset ${moved_offset} prefix ${moved_prefix} retirements 2" "$PARENT/state/ios.status" \
  "a continuity break after an identical restore did not record the new retirement count"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a continuity break after an identical restore did not reopen the decision"
remote_env "$ADAPTER" ingest ios "$RESULT_RETIRED" >/dev/null 2>&1 || true
[ "$(grep -cF 'blocked [key=remote-reply-continuity-ios]' "$PARENT/state/ios.status")" -eq 5 ] \
  || fail "a repeated read of the break after an identical restore appended again"
assert_contains "$(status_open_decisions "$PARENT/state/ios.status")" \
  $'remote-reply-continuity-ios\t' \
  "a repeated read of the break after an identical restore closed the decision"
pass "a continuity break after retirement and an identical restore opens the decision once"

# A directory cannot be removed by rm without -r, for any user. Retirement must
# fail and leave the count where it was.
count_before=$(cat "$PARENT/state/remote-replies/ios.retirements")
rm -f "$PARENT/state/remote-replies/ios.cursor"
mkdir "$PARENT/state/remote-replies/ios.cursor"
set +e
remote_env "$ADAPTER" retire ios > "$TMP_ROOT/retire-cursor-stuck.out" 2>&1
retire_rc=$?
set -e
[ "$retire_rc" -ne 0 ] || fail "retirement reported success when the cursor could not be removed"
assert_grep 'cannot remove remote reply cursor' "$TMP_ROOT/retire-cursor-stuck.out" \
  "retirement did not report the failed cursor removal"
[ "$(cat "$PARENT/state/remote-replies/ios.retirements")" = "$count_before" ] \
  || fail "a failed cursor removal increased the retirement count"
[ -d "$PARENT/state/remote-replies/ios.cursor" ] \
  || fail "a failed cursor removal removed the cursor"
pass "a failed cursor removal does not increase the retirement count"

# The count write is the step after removal. Stopping there leaves the old count.
rm -rf "$PARENT/state/remote-replies/ios.cursor"
printf 'schema=fm-remote-reply-cursor.v1\noffset=1\nprefix_sha256=%064d\n' 0 \
  > "$PARENT/state/remote-replies/ios.cursor"
RETIRE_COUNT_FAIL_BIN="$TMP_ROOT/retire-count-fail-bin"
mkdir -p "$RETIRE_COUNT_FAIL_BIN"
REAL_MKTEMP=$(command -v mktemp)
{
  cat <<'SH'
#!/usr/bin/env bash
case "${1:-}" in
  */.retirements.XXXXXX) exit 73 ;;
esac
SH
  printf 'exec %q "$@"\n' "$REAL_MKTEMP"
} > "$RETIRE_COUNT_FAIL_BIN/mktemp"
chmod +x "$RETIRE_COUNT_FAIL_BIN/mktemp"
set +e
PATH="$RETIRE_COUNT_FAIL_BIN:$PATH" remote_env "$ADAPTER" retire ios \
  > "$TMP_ROOT/retire-count-stopped.out" 2>&1
retire_rc=$?
set -e
[ "$retire_rc" -ne 0 ] || fail "retirement reported success when the count could not be recorded"
assert_grep 'cannot record remote reply retirement' "$TMP_ROOT/retire-count-stopped.out" \
  "retirement did not report the failed count write"
assert_absent "$PARENT/state/remote-replies/ios.cursor" \
  "a retirement that stopped after removal left the cursor"
[ "$(cat "$PARENT/state/remote-replies/ios.retirements")" = "$count_before" ] \
  || fail "a retirement that stopped after removal changed the count"
pass "a retirement that stops after removing the cursor leaves the old count"

echo "ALL TESTS PASSED"
