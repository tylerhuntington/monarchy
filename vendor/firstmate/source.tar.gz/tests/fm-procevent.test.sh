#!/usr/bin/env bash
# Behavior tests for the generic process-to-event runner and its Lavish adapter.
#
# The source under test is a fake blocking process that returns only when its
# trigger file appears, so completion is a real process event and no test here
# depends on a discovery timer. The Lavish adapter is exercised through its own
# public commands against the currently published poll shape; no live Lavish
# server is started.
#
# Delivery is deliberately NOT asserted as at-least-once or lossless: the
# published Lavish poll clears feedback destructively before returning it, so
# the only durability under test is the runner's own - output that reached the
# runner is stored before it is announced.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
TMP_ROOT=$(fm_test_tmproot fm-procevent-tests)
export FM_PROCEVENT_CLAIM_ROOT="$TMP_ROOT/claims"
export LAVISH_AXI_STATE_DIR="$TMP_ROOT/lavish-state"
mkdir -p "$LAVISH_AXI_STATE_DIR"

# Lavish owns this persisted session contract. The fake CLI fixtures exercise
# its published poll and synchronous reply command boundaries without starting a server.
lavish_session() {  # <artifact> [session-url]
  perl -MJSON::PP -MCwd=realpath -MDigest::SHA=sha256_hex -MEncode=decode -e '
    my ($path, $artifact, $url) = @ARGV;
    my $real = realpath($artifact) // die "missing fixture artifact";
    my $key = substr(sha256_hex($real), 0, 16);
    my $state = { sessions => {} };
    if (-f $path) { open my $in, "<", $path or die $!; local $/; $state = decode_json(<$in>); }
    $state->{sessions}{$key} = {
      key => $key, file => decode("UTF-8", $real), status => "open", url => $url,
    };
    open my $out, ">", $path or die $!;
    print $out encode_json($state);
  ' "$LAVISH_AXI_STATE_DIR/state.json" "$1" "${2:-http://127.0.0.1:14387/session/0123456789abcdef}"
}

BLOCKER="$TMP_ROOT/blocker.sh"
cat > "$BLOCKER" <<'SH'
#!/usr/bin/env bash
# Blocks until the trigger exists, then emits its payload. Completion is the
# event; nothing here polls on a schedule. The wait is bounded so a stub that
# escapes its test cannot keep spawning processes indefinitely.
trigger=$1; shift
while [ ! -e "$trigger" ]; do
  [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ] || exit 75
  sleep 0.05
done
[ -n "${BLOCKER_STDERR:-}" ] && printf 'noise on stderr\n' >&2
[ -n "${BLOCKER_EXIT:-}" ] && exit "$BLOCKER_EXIT"
printf '%s\n' "$@"
SH
chmod +x "$BLOCKER"

# Records that the wrapped command actually started, then becomes it. A claim
# only proves its runner got as far as claiming; a test that needs the runner
# already inside its source command waits for this marker instead of a settle
# window, because a runner still short of that command retires itself when its
# registration goes away.
STARTED_BLOCKER="$TMP_ROOT/started-blocker.sh"
cat > "$STARTED_BLOCKER" <<'SH'
#!/usr/bin/env bash
printf 'started\n' > "$1"
shift
exec "$@"
SH
chmod +x "$STARTED_BLOCKER"

pe() { FM_HOME="$1" "$ROOT/bin/fm-procevent.sh" "${@:2}"; }

# Every home this suite registers a source in is tracked so teardown can stop
# its runners. A runner started by reconcile is detached and reparented, so a
# source that never completes outlives the suite unless its home is swept -
# removing the fixture directory does not stop an already-running child.
# tests/lib.sh owns that sweep and runs it from every cleanup path.
pe_register() {  # <home> <adapter> <source-id> -- <argv>...
  local home=$1 adapter=$2 id=$3
  shift 3
  fm_test_track_procevent_home "$home"
  pe "$home" register "$adapter" "$id" "$@"
}
new_home() { mkdir -p "$1/state"; }
# A worker-owned board can only be armed for a task whose endpoint metadata the
# runner can ring, so every fixture worker needs the same durable record a real
# spawn leaves behind.
new_task_endpoint() {  # <home> <task-id>
  mkdir -p "$1/state"
  printf 'window=fmtest:fm-%s\nworktree=%s/worktree-%s\nproject=fmtest\n' "$2" "$1" "$2" \
    > "$1/state/$2.meta"
}
wake_payloads() { awk -F '\t' '{print $5}' "$1/state/.wake-queue" 2>/dev/null; }

# The wake queue is a durable tab-separated record firstmate consumes:
# <epoch> <sequence> <kind> <key> <payload>. These read the rows reconcile
# publishes for a source it stranded, keyed by that source and its claim
# generation.
stranded_wake_keys() {  # <home> <source-id>
  [ -e "$1/state/.wake-queue" ] || return 0
  awk -F '\t' -v id="$2" \
    '$3 == "check" && index($4, "procevent:" id ":stranded:") == 1 { print $4 }' \
    "$1/state/.wake-queue"
}
stranded_wake_count() {  # <home> <source-id>
  stranded_wake_keys "$1" "$2" | grep -c . || true
}
stranded_wake_payloads() {  # <home> <source-id>
  [ -e "$1/state/.wake-queue" ] || return 0
  awk -F '\t' -v id="$2" \
    '$3 == "check" && index($4, "procevent:" id ":stranded:") == 1 { print $5 }' \
    "$1/state/.wake-queue"
}
# The same rows for a launch reconcile could not confirm, keyed by that source
# and the registration identity the launch ran under.
launch_failed_wake_keys() {  # <home> <source-id>
  [ -e "$1/state/.wake-queue" ] || return 0
  awk -F '\t' -v id="$2" \
    '$3 == "check" && index($4, "procevent:" id ":launch-failed:") == 1 { print $4 }' \
    "$1/state/.wake-queue"
}
launch_failed_wake_count() {  # <home> <source-id>
  launch_failed_wake_keys "$1" "$2" | grep -c . || true
}
launch_failed_wake_payloads() {  # <home> <source-id>
  [ -e "$1/state/.wake-queue" ] || return 0
  awk -F '\t' -v id="$2" \
    '$3 == "check" && index($4, "procevent:" id ":launch-failed:") == 1 { print $5 }' \
    "$1/state/.wake-queue"
}

first_result() {  # <home> <source-id>: print the first captured result, if any
  local g
  for g in "$1/state/procevent-inbox/$2".*.result; do
    [ -e "$g" ] || continue
    printf '%s\n' "$g"
    return 0
  done
  return 1
}

count_results() {  # <home> <source-id>
  local g n=0
  for g in "$1/state/procevent-inbox/$2".*.result; do
    [ -e "$g" ] && n=$((n + 1))
  done
  printf '%s\n' "$n"
}

wait_for() {  # <file> [tries]
  local f=$1 n=${2:-100}
  for _ in $(seq 1 "$n"); do [ -s "$f" ] && return 0; sleep 0.1; done
  return 1
}

# --- detached startup refreshes owner presence after slow caller work -------
LEASE_ADAPTERS="$TMP_ROOT/lease-adapters"
mkdir -p "$LEASE_ADAPTERS/bin"
cat > "$LEASE_ADAPTERS/bin/fm-procevent-leaseplain.sh" <<'SH'
#!/usr/bin/env bash
exit 2
SH
cat > "$LEASE_ADAPTERS/bin/fm-procevent-leasepublish.sh" <<'SH'
#!/usr/bin/env bash
case "${1-}" in
  silent)
    printf 'publishing\n' > "$LEASE_PUBLISH_READY"
    while [ ! -e "$LEASE_PUBLISH_RELEASE" ]; do
      [ "$SECONDS" -lt 30 ] || exit 2
      sleep 0.05
    done
    exit 1
    ;;
esac
exit 2
SH
chmod +x "$LEASE_ADAPTERS/bin/"*.sh

lease_pe() {
  FM_ROOT_OVERRIDE="$LEASE_ADAPTERS" FM_PROCEVENT_OWNER_LEASE_SECONDS=2 \
    FM_PROCEVENT_OWNER_CHECK_SECONDS=1 pe "$@"
}
wait_stale_lease() {  # <home>
  local lease="$1/state/procevent/.owner-lease" n
  for n in $(seq 1 100); do
    if perl -MTime::HiRes=clock_gettime,CLOCK_MONOTONIC -e '
      open my $in, "<", $ARGV[0] or exit 1;
      my $stamp = <$in>;
      exit(clock_gettime(CLOCK_MONOTONIC) - $stamp >= 3 ? 0 : 1);
    ' "$lease"; then
      return 0
    fi
    sleep 0.1
  done
  return 1
}

for lease_entry in reconcile ensure-listening; do
  LEASE_HOME="$TMP_ROOT/lease-$lease_entry"; new_home "$LEASE_HOME"
  fm_test_track_procevent_home "$LEASE_HOME"
  lease_id="lease-$lease_entry-src"
  lease_started="$TMP_ROOT/$lease_id.started"
  lease_pe "$LEASE_HOME" register leaseplain "$lease_id" -- \
    "$STARTED_BLOCKER" "$lease_started" "$BLOCKER" "$TMP_ROOT/$lease_id.trigger" payload >/dev/null
  if [ "$lease_entry" = reconcile ]; then
    mkdir -p "$LEASE_HOME/state/procevent-inbox"
    printf 'old payload\n' > "$LEASE_HOME/state/procevent-inbox/lease-old.1.result"
    printf 'leasepublish\n' > "$LEASE_HOME/state/procevent-inbox/lease-old.1.adapter"
    chmod 600 "$LEASE_HOME/state/procevent-inbox/lease-old.1."*
    export LEASE_PUBLISH_READY="$TMP_ROOT/lease-publish.ready"
    export LEASE_PUBLISH_RELEASE="$TMP_ROOT/lease-publish.release"
    lease_pe "$LEASE_HOME" reconcile > "$TMP_ROOT/lease-reconcile.out" 2>&1 &
    lease_caller=$!
    wait_for "$LEASE_PUBLISH_READY" || fail "reconcile never reached pre-launch publication"
    wait_stale_lease "$LEASE_HOME" || fail "publication did not outlast the fixture lease"
    touch "$LEASE_PUBLISH_RELEASE"
    wait "$lease_caller" || fail "reconcile failed after slow publication"
  else
    wait_stale_lease "$LEASE_HOME" || fail "the readiness fixture lease never expired"
    lease_pe "$LEASE_HOME" ensure-listening "$lease_id" \
      > "$TMP_ROOT/lease-ensure-listening.out" 2>&1 \
      || fail "ensure-listening failed with an old caller lease"
  fi
  wait_for "$lease_started" \
    || fail "$lease_entry confirmed a detached start without running the source command"
  assert_contains "$(lease_pe "$LEASE_HOME" list)" "live" \
    "$lease_entry leaves a live source owner after refreshing at launch"
  # No further owner-presence operation runs. The launch refresh must not keep
  # renewing itself after the caller has returned.
  lease_runner=$(cat "$LEASE_HOME/state/procevent/$lease_id.runner")
  lease_deadline=$((SECONDS + 10))
  while kill -0 "$lease_runner" 2>/dev/null; do
    [ "$SECONDS" -lt "$lease_deadline" ] \
      || fail "$lease_entry kept its runner alive after the owning home's lease expired"
    sleep 0.1
  done
  lease_pe "$LEASE_HOME" retire "$lease_id" >/dev/null
  pass "$lease_entry refreshes at detached launch and still stops after owner lease expiry"
done

# An ordinary runner descendant may request a detached launch, but may never
# turn that launch into new owner-presence activity for its missing home.
LEASE_INHERITED="$TMP_ROOT/lease-inherited"; new_home "$LEASE_INHERITED"
fm_test_track_procevent_home "$LEASE_INHERITED"
lease_pe "$LEASE_INHERITED" register leaseplain lease-inherited-src -- \
  "$STARTED_BLOCKER" "$TMP_ROOT/lease-inherited.started" /bin/sleep 30 >/dev/null
wait_stale_lease "$LEASE_INHERITED" || fail "the inherited caller fixture lease never expired"
lease_before=$(cat "$LEASE_INHERITED/state/procevent/.owner-lease")
FM_PROCEVENT_IN_RUNNER=1 lease_pe "$LEASE_INHERITED" ensure-listening lease-inherited-src \
  > "$TMP_ROOT/lease-inherited.out" 2>&1 || true
[ "$(cat "$LEASE_INHERITED/state/procevent/.owner-lease")" = "$lease_before" ] \
  || fail "a runner descendant refreshed the owning lease at detached launch"
assert_absent "$TMP_ROOT/lease-inherited.started" \
  "a runner descendant cannot start a source under its expired owning lease"
lease_pe "$LEASE_INHERITED" retire lease-inherited-src >/dev/null
pass "inherited runner callers cannot renew owner presence at detached startup"

# Arm now starts the listener, so a later start would poll again. Wait for the
# capture that listener is already producing, and for its runner to release the
# claim: the result lands before the runner publishes and exits, and a retire or
# re-arm in that gap meets a live claim the synchronous start never left behind.
wait_capture() {  # <home> <source-id> [tries]
  local home=$1 id=$2 n=${3:-100}
  local _
  for _ in $(seq 1 "$n"); do
    if first_result "$home" "$id" >/dev/null 2>&1 \
      && [ ! -e "$FM_PROCEVENT_CLAIM_ROOT/$id.claim" ]; then
      return 0
    fi
    sleep 0.1
  done
  return 1
}

# <file> <count> [tries]: wait until <file> holds at least <count> lines. A
# detached runner appends its execution marker after the command that started it
# has already returned, so a caller that needs that append must wait for it
# rather than assume a fixed settle window covered it on a loaded machine.
wait_for_lines() {
  local f=$1 want=$2 n=${3:-100} have
  for _ in $(seq 1 "$n"); do
    if [ -f "$f" ]; then
      have=$(wc -l < "$f" | tr -d ' ')
    else
      have=0
    fi
    case "$have" in ''|*[!0-9]*) have=0 ;; esac
    [ "$have" -ge "$want" ] && return 0
    sleep 0.1
  done
  return 1
}

hold_source_lock() {  # <source-id> <ready-file> <release-file>
  local id=$1 ready=$2 release=$3 parent=$$
  FM_HOME="$TMP_ROOT/lock-helper-home" bash -c '
    . "$1/bin/fm-pr-lib.sh"
    . "$1/bin/fm-wake-lib.sh"
    . "$1/bin/fm-procevent-lib.sh"
    fm_procevent_source_lock_acquire "$2" || exit 1
    trap "fm_procevent_source_lock_release \"$2\"" EXIT
    printf "ready\n" > "$3"
    while [ ! -e "$4" ]; do
      kill -0 "$5" 2>/dev/null || exit 0
      sleep 0.02
    done
  ' _ "$ROOT" "$id" "$ready" "$release" "$parent" &
  HOLDER_PID=$!
}

hold_source_lock_then_handle() {  # <home> <source-id> <sequence> <ready-file> <release-file>
  local home=$1 id=$2 seq=$3 ready=$4 release=$5 parent=$$
  FM_HOME="$home" bash -c '
    . "$1/bin/fm-pr-lib.sh"
    . "$1/bin/fm-wake-lib.sh"
    . "$1/bin/fm-procevent-lib.sh"
    fm_procevent_source_lock_acquire "$2" || exit 1
    trap "fm_procevent_source_lock_release \"$2\"" EXIT
    printf "ready\n" > "$4"
    while [ ! -e "$5" ]; do
      kill -0 "$6" 2>/dev/null || exit 1
      sleep 0.02
    done
    fm_procevent_mark_handled "$3/state" "$2" "$7"
  ' _ "$ROOT" "$id" "$home" "$ready" "$release" "$parent" "$seq" &
  HOLDER_PID=$!
}

# --- inert with nothing configured ------------------------------------------
IDLE="$TMP_ROOT/idle"; mkdir -p "$IDLE"
out=$(pe "$IDLE" list)
assert_contains "$out" "no sources registered" "an unconfigured home reports no sources"
out=$(pe "$IDLE" reconcile)
assert_contains "$out" "published=0 started=0" "reconcile is a no-op with nothing registered"
[ -z "$(ls -A "$IDLE/state" 2>/dev/null)" ] || fail "an unconfigured home generated state: $(ls -A "$IDLE/state")"
pass "no configured source means no generated state and no process"

sup=$(PATH="${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}" bash -c \
  '. "$1/bin/fm-supervision-lib.sh"; fm_supervision_needed "$2" && echo yes || echo no' _ "$ROOT" "$IDLE/state")
assert_contains "$sup" no "an unconfigured home does not need supervision"

# --- a blocking source completes into exactly one normalized event ----------
H1="$TMP_ROOT/h1"; mkdir -p "$H1"
TRIG="$TMP_ROOT/trigger-one"
out=$(pe_register "$H1" lavish src-one -- "$BLOCKER" "$TRIG" "payload one")
assert_contains "$out" "registered: src-one" "register records a source"

sup=$(PATH="${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}" bash -c \
  '. "$1/bin/fm-supervision-lib.sh"; fm_supervision_needed "$2" && echo yes || echo no' _ "$ROOT" "$H1/state")
assert_contains "$sup" yes "a registered source needs supervision with no task metadata"

pe "$H1" reconcile >/dev/null
# Reconcile's replacement runner is detached, so ownership is recorded after
# reconcile has already returned. Wait for the claim itself: a duplicate start
# only has an owner to lose to once that claim exists.
wait_for "$FM_PROCEVENT_CLAIM_ROOT/src-one.claim" || fail "reconcile never claimed the registered source"
out=$(pe "$H1" start src-one)
assert_contains "$out" "already owned" "a duplicate start loses instead of running a second child"

: > "$TRIG"
wait_for "$H1/state/.wake-queue" || fail "no event was published after the source completed"
payload=$(wake_payloads "$H1")
assert_contains "$payload" "procevent lavish src-one 1" "completion publishes the committed result sequence"
assert_not_contains "$payload" "payload one" "source output never reaches the event line"
[ "$(printf '%s\n' "$payload" | grep -c .)" = 1 ] || fail "expected exactly one event, got: $payload"
pass "one blocking completion yields exactly one bounded normalized event"

RESULT=$(first_result "$H1" src-one || true)
[ -n "$RESULT" ] || fail "no durable result was captured"
mode=$(PATH="${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}" bash -c \
  '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_mode "$2"' _ "$ROOT" "$RESULT")
assert_contains "$mode" 600 "the captured result is private"
assert_grep 'payload one' "$RESULT" "the captured result holds the source output verbatim"
assert_grep 'lavish' "${RESULT%.result}.adapter" "the captured result retains its immutable adapter"
assert_absent "${RESULT%.result}.handled" "publication alone never marks a result handled"

# --- a home spelled through a symlinked ancestor still runs its sources ------
# Such a home must run process-event sources exactly like a physically spelled
# one: reconcile's detached runner discards its own stderr, so a refusal here is
# invisible to the caller and the source simply never fires.
HPHYS="$TMP_ROOT/symlinked-parent-target"
mkdir -p "$HPHYS"
ln -s "$HPHYS" "$TMP_ROOT/symlinked-parent"
HSYM="$TMP_ROOT/symlinked-parent/home"; new_home "$HSYM"
SYM_TRIGGER="$TMP_ROOT/symlink-trigger"
pe_register "$HSYM" lavish symlinked-src -- "$BLOCKER" "$SYM_TRIGGER" "symlinked payload" >/dev/null
pe "$HSYM" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/symlinked-src.claim" \
  || fail "a home reached through a symlinked ancestor never claimed its source"
: > "$SYM_TRIGGER"
wait_for "$HSYM/state/.wake-queue" \
  || fail "a home reached through a symlinked ancestor published no event"
assert_contains "$(wake_payloads "$HSYM")" "procevent lavish symlinked-src 1" \
  "the symlinked-ancestor home publishes the committed result sequence"
SYM_RESULT=$(first_result "$HSYM" symlinked-src || true)
[ -n "$SYM_RESULT" ] || fail "the symlinked-ancestor home captured no durable result"
assert_grep 'symlinked payload' "$SYM_RESULT" \
  "the symlinked-ancestor home captures the source output verbatim"
pass "a home reached through a symlinked ancestor runs its sources normally"

# --- the public start boundary establishes generation group ownership -------
HPG="$TMP_ROOT/hpg"; new_home "$HPG"
DIRECT_TRIGGER="$TMP_ROOT/direct-trigger"
pe_register "$HPG" lavish direct-src -- "$BLOCKER" "$DIRECT_TRIGGER" "direct result" >/dev/null
pe "$HPG" start direct-src > "$TMP_ROOT/direct-start.out" &
direct_runner=$!
wait_for "$FM_PROCEVENT_CLAIM_ROOT/direct-src.claim" || fail "direct start never claimed its source"
direct_leader=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/direct-src.claim")
direct_group=$(ps -o pgid= -p "$direct_leader" 2>/dev/null | tr -d '[:space:]')
[ "$direct_group" = "$direct_leader" ] \
  || fail "direct start claimed before leading its process group: pid=$direct_leader pgid=$direct_group"
: > "$DIRECT_TRIGGER"
wait "$direct_runner" || fail "direct start failed after its source completed"
assert_contains "$(cat "$TMP_ROOT/direct-start.out")" "captured:" "direct start captures its result"
pass "public start owns the process group recorded by its claim"

SHARED_TRIGGER="$TMP_ROOT/shared-trigger"
SHARED_SIBLING="$TMP_ROOT/shared-sibling"
SHARED_LAUNCHER="$TMP_ROOT/shared-launcher.pl"
cat > "$SHARED_LAUNCHER" <<'PL'
use strict;
use warnings;
my ($sibling_file, @command) = @ARGV;
pipe(my $reader, my $writer) or exit 125;
defined(my $runner = fork) or exit 125;
if ($runner == 0) {
  close $reader;
  setpgrp(0, 0) or exit 125;
  print {$writer} "ready\n";
  close $writer;
  exec @command;
  exit 125;
}
close $writer;
<$reader>;
close $reader;
defined(my $sibling = fork) or exit 125;
if ($sibling == 0) {
  setpgrp(0, $runner) or exit 125;
  open(my $out, '>', $sibling_file) or exit 125;
  print {$out} "$$\n";
  close $out;
  sleep 30;
  exit 0;
}
waitpid($runner, 0);
waitpid($sibling, 0);
exit 0;
PL
pe_register "$HPG" lavish shared-src -- "$BLOCKER" "$SHARED_TRIGGER" "shared result" >/dev/null
FM_HOME="$HPG" perl "$SHARED_LAUNCHER" "$SHARED_SIBLING" \
  "$ROOT/bin/fm-procevent.sh" start shared-src > "$TMP_ROOT/shared-start.out" &
shared_launcher=$!
wait_for "$SHARED_SIBLING" || fail "shared caller group never started its unrelated sibling"
wait_for "$FM_PROCEVENT_CLAIM_ROOT/shared-src.claim" || fail "shared-group start never claimed its source"
shared_sibling=$(cat "$SHARED_SIBLING")
pe "$HPG" retire shared-src >/dev/null
kill -0 "$shared_sibling" 2>/dev/null || fail "retirement signaled an unrelated caller-group process"
kill "$shared_sibling" 2>/dev/null || true
wait "$shared_launcher" || fail "shared caller-group fixture did not exit cleanly"
pass "public start never claims an inherited caller process group"

# --- an unhandled result remains eligible for re-announcement on restart ----
# A result is durable but nothing has ever acknowledged handling it. Every
# reconcile call - not just the first restart after a crash - must keep
# re-announcing it, because the only thing that stops re-announcement is an
# explicit handled acknowledgement, never a prior publication.
H2="$TMP_ROOT/h2"; new_home "$H2"
future_status=0
future_out=$(pe "$H2" handled src-cut 7 2>&1) || future_status=$?
[ "$future_status" -ne 0 ] || fail "handled accepted a generation that has not been captured"
assert_contains "$future_out" "cannot durably record handling" "premature acknowledgement is rejected through the public interface"
assert_absent "$H2/state/procevent-inbox/src-cut.7.handled" "premature acknowledgement creates no marker for the future generation"
mkdir -p "$H2/state/procevent-inbox"
printf 'stranded result\n' > "$H2/state/procevent-inbox/src-cut.7.result"
printf 'lavish\n' > "$H2/state/procevent-inbox/src-cut.7.adapter"
chmod 0600 "$H2/state/procevent-inbox/src-cut.7.result" "$H2/state/procevent-inbox/src-cut.7.adapter"
out=$(pe "$H2" reconcile)
assert_contains "$out" "published=1" "a durably captured but unhandled result is announced after restart"
assert_contains "$(wake_payloads "$H2")" "procevent lavish src-cut 7" "durable adapter identity survives without a registration"
assert_absent "$H2/state/procevent-inbox/src-cut.7.handled" "recovery alone never marks the recovered result handled"
mv "$H2/state/.wake-queue" "$H2/state/.wake-queue.drained-1"
out=$(pe "$H2" reconcile)
assert_contains "$out" "published=1" "an unhandled result is re-announced on every reconcile, not only the first"
assert_contains "$(wake_payloads "$H2")" "procevent lavish src-cut 7" "the repeat wake preserves its deduplication identity"
[ "$(count_results "$H2" src-cut)" = 1 ] || fail "repeat re-announcement created a second durable copy"
mv "$H2/state/.wake-queue" "$H2/state/.wake-queue.drained-2"

ack_out=$(pe "$H2" handled src-cut 7)
assert_contains "$ack_out" "handled: src-cut 7" "the owned handling interface newly authorizes the first acknowledgement"
assert_present "$H2/state/procevent-inbox/src-cut.7.handled" "acknowledgement durably records handling"
before=$(wake_payloads "$H2" | wc -l | tr -d ' ')
out=$(pe "$H2" reconcile)
assert_contains "$out" "published=0" "reconcile stops re-announcing once a result is durably handled"
[ "$(wake_payloads "$H2" | wc -l | tr -d ' ')" = "$before" ] || fail "a handled result was announced again"

repeat_out=$(pe "$H2" handled src-cut 7)
assert_contains "$repeat_out" "already-handled: src-cut 7" "repeated acknowledgement is safe and reports the repeat distinctly"
case "$repeat_out" in
  handled:*) fail "a repeat acknowledgement re-authorized a second handled effect: $repeat_out" ;;
esac
pass "an unhandled result survives restart and repeat drains, and only explicit acknowledgement stops its re-announcement"

HRACE="$TMP_ROOT/hrace"; new_home "$HRACE"
mkdir -p "$HRACE/state/procevent-inbox"
printf 'racing result\n' > "$HRACE/state/procevent-inbox/racing-src.1.result"
printf 'lavish\n' > "$HRACE/state/procevent-inbox/racing-src.1.adapter"
chmod 0600 "$HRACE/state/procevent-inbox/racing-src.1.result" "$HRACE/state/procevent-inbox/racing-src.1.adapter"
RACE_PUBLISH_READY="$TMP_ROOT/race-publish-ready"
RACE_PUBLISH_RELEASE="$TMP_ROOT/race-publish-release"
RACE_RECONCILE_OUT="$TMP_ROOT/race-reconcile.out"
hold_source_lock_then_handle "$HRACE" racing-src 1 "$RACE_PUBLISH_READY" "$RACE_PUBLISH_RELEASE"
RACE_HANDLE_PID=$HOLDER_PID
wait_for "$RACE_PUBLISH_READY" || fail "publication race barrier did not acquire the source lock"
pe "$HRACE" reconcile > "$RACE_RECONCILE_OUT" &
RACE_RECONCILE_PID=$!
sleep 0.3
assert_absent "$HRACE/state/.wake-queue" "publication bypassed the source serialization boundary"
: > "$RACE_PUBLISH_RELEASE"
wait "$RACE_HANDLE_PID" || fail "publication race barrier could not record handling"
wait "$RACE_RECONCILE_PID" || fail "reconcile failed after the concurrent acknowledgement"
assert_contains "$(cat "$RACE_RECONCILE_OUT")" "published=0" "reconcile rechecks handling at the serialized publication boundary"
assert_present "$HRACE/state/procevent-inbox/racing-src.1.handled" "the concurrent acknowledgement remains durable"
assert_absent "$HRACE/state/.wake-queue" "an acknowledged result was appended after handling completed"
pass "publication cannot race a handled acknowledgement"

HPRIVATE="$TMP_ROOT/hprivate"; new_home "$HPRIVATE"
mkdir -p "$HPRIVATE/state/procevent-inbox"
printf 'private result\n' > "$HPRIVATE/state/procevent-inbox/private-src.1.result"
printf 'lavish\n' > "$HPRIVATE/state/procevent-inbox/private-src.1.adapter"
chmod 0600 "$HPRIVATE/state/procevent-inbox/private-src.1.result" "$HPRIVATE/state/procevent-inbox/private-src.1.adapter"
FAIL_CHMOD_BIN="$TMP_ROOT/fail-chmod-bin"
mkdir -p "$FAIL_CHMOD_BIN"
cat > "$FAIL_CHMOD_BIN/chmod" <<'SH'
#!/usr/bin/env bash
exit 1
SH
chmod +x "$FAIL_CHMOD_BIN/chmod"
private_status=0
private_out=$(PATH="$FAIL_CHMOD_BIN:$PATH" pe "$HPRIVATE" handled private-src 1 2>&1) || private_status=$?
[ "$private_status" -ne 0 ] || fail "handled succeeded when private mode enforcement failed"
assert_contains "$private_out" "cannot durably record handling" "mode enforcement failure is reported through the owned interface"
assert_absent "$HPRIVATE/state/procevent-inbox/private-src.1.handled" "failed mode enforcement left an authoritative marker"
private_out=$(umask 000; pe "$HPRIVATE" handled private-src 1)
assert_contains "$private_out" "handled: private-src 1" "handling succeeds after private mode enforcement recovers"
private_mode=$(PATH="${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}" bash -c \
  '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_mode "$2"' _ "$ROOT" "$HPRIVATE/state/procevent-inbox/private-src.1.handled")
assert_contains "$private_mode" 600 "the handled marker is private under a permissive caller umask"
pass "handled acknowledgement creation is private and fails safely"

# --- a terminal result retires its source, on the adapter's verdict alone ----
# The runner must carry no notion of its own about what "done" means for a
# source. It asks that source's adapter whether the captured result ends the
# source, and retires the registration only on that adapter's verdict. Two
# fixture adapters isolate exactly that decision - one that ends on any result,
# one with no terminal knowledge at all - so the observed behavior is proven to
# follow the adapter rather than any condition built into the runner.
ADAPTER_ROOT="$TMP_ROOT/adapter-root"
mkdir -p "$ADAPTER_ROOT/bin"
cat > "$ADAPTER_ROOT/bin/fm-procevent-endnow.sh" <<'SH'
#!/usr/bin/env bash
# Fixture adapter: every captured result ends this source.
case "${1-}" in
  terminal) [ -f "${2-}" ] && exit 0 || exit 1 ;;
esac
exit 2
SH
cat > "$ADAPTER_ROOT/bin/fm-procevent-openended.sh" <<'SH'
#!/usr/bin/env bash
# Fixture adapter with no terminal knowledge at all: nothing ever ends it.
exit 2
SH
cat > "$ADAPTER_ROOT/bin/fm-procevent-applying.sh" <<'SH'
#!/usr/bin/env bash
case "${1-}" in
  autohandle)
    printf '%s %s\n' "$2" "$3" >> "$FM_HOME/state/applied"
    "$FM_PROCEVENT_UNDER_TEST" handled "$2" "$3" >/dev/null
    ;;
  *) exit 2 ;;
esac
SH
cat > "$ADAPTER_ROOT/bin/fm-procevent-selfann.sh" <<'SH'
#!/usr/bin/env bash
# Fixture adapter that declares a durable downstream announcement of its own.
# FM_HOME/state/selfann-fail makes its application fail so the fallback
# publication path stays provable.
case "${1-}" in
  self-announcing) exit 0 ;;
  autohandle)
    [ ! -e "$FM_HOME/state/selfann-fail" ] || exit 1
    printf '%s %s\n' "$2" "$3" >> "$FM_HOME/state/applied"
    "$FM_PROCEVENT_UNDER_TEST" handled "$2" "$3" >/dev/null
    ;;
  *) exit 2 ;;
esac
SH
chmod +x "$ADAPTER_ROOT/bin/fm-procevent-endnow.sh" "$ADAPTER_ROOT/bin/fm-procevent-openended.sh" \
  "$ADAPTER_ROOT/bin/fm-procevent-applying.sh" "$ADAPTER_ROOT/bin/fm-procevent-selfann.sh"

pe_adapter() {  # <home> <command>...: run the runner against the fixture adapters
  local home=$1
  shift
  FM_ROOT_OVERRIDE="$ADAPTER_ROOT" FM_PROCEVENT_UNDER_TEST="$ROOT/bin/fm-procevent.sh" \
    FM_HOME="$home" "$ROOT/bin/fm-procevent.sh" "$@"
}

HPUBLISH="$TMP_ROOT/hpublish"; new_home "$HPUBLISH"
fm_test_track_procevent_home "$HPUBLISH"
pe_adapter "$HPUBLISH" register applying publish-src -- /bin/echo "apply after publish" >/dev/null
mkdir "$HPUBLISH/state/.wake-queue"
out=$(pe_adapter "$HPUBLISH" start publish-src 2>&1)
assert_contains "$out" "not-autohandled: publish-src" "failed publication did not suppress automatic application"
assert_absent "$HPUBLISH/state/applied" "a result was applied before its wake was durably published"
assert_absent "$HPUBLISH/state/procevent-inbox/publish-src.1.handled" "a result was acknowledged before its wake was durably published"
rmdir "$HPUBLISH/state/.wake-queue"
# This source's child returns instantly, so leaving it registered would have the
# recovery reconcile below start a detached poll that races every assertion after
# it for the source claim, the next sequence, and this home's applied record.
# Re-announcement is proven from the durable inbox alone and needs no
# registration, so retire it first - the same retire-before-reconcile discipline
# the blocker-backed sources rely on - and prove no competing poll was started.
pe_adapter "$HPUBLISH" retire publish-src >/dev/null
out=$(pe_adapter "$HPUBLISH" reconcile)
assert_contains "$out" "published=1" "the unpublished capture was not announced on later reconciliation"
assert_contains "$out" "started=0" "reconcile started an always-ready poll that races the recovery assertions"
assert_contains "$(wake_payloads "$HPUBLISH")" "procevent applying publish-src 1" "later reconciliation did not deliver the capture to a handler"
FM_HOME="$HPUBLISH" FM_PROCEVENT_UNDER_TEST="$ROOT/bin/fm-procevent.sh" \
  "$ADAPTER_ROOT/bin/fm-procevent-applying.sh" autohandle publish-src 1 \
    "$HPUBLISH/state/procevent-inbox/publish-src.1.result"
assert_grep 'publish-src 1' "$HPUBLISH/state/applied" "the handler could not apply the later announcement"
assert_present "$HPUBLISH/state/procevent-inbox/publish-src.1.handled" "the later handler application was not acknowledged"
pass "automatic application waits for durable publication and failed publication remains recoverable"

# A self-announcing adapter inverts that order on its own declaration: the
# runner applies first and publishes nothing for a capture the adapter fully
# applied and acknowledged, because the adapter's own durable downstream
# channel is the announcement. The declaration never silences a capture the
# adapter could NOT apply - that one still publishes for the handler.
HSELF="$TMP_ROOT/hself"; new_home "$HSELF"
fm_test_track_procevent_home "$HSELF"
pe_adapter "$HSELF" register selfann self-src -- /bin/echo "self announced" >/dev/null
out=$(pe_adapter "$HSELF" start self-src 2>&1)
assert_contains "$out" "autohandled: self-src" "the self-announcing adapter did not apply its own capture"
assert_not_contains "$out" "not-autohandled" "the applied capture was still reported as left for the handler"
assert_grep 'self-src 1' "$HSELF/state/applied" "the self-announcing capture was not applied"
assert_present "$HSELF/state/procevent-inbox/self-src.1.handled" "the self-announcing application was not acknowledged"
if [ -e "$HSELF/state/.wake-queue" ] && grep -q 'procevent selfann self-src 1' "$HSELF/state/.wake-queue"; then
  fail "a fully autohandled self-announcing capture still published a duplicate check wake"
fi
# This self-announcing source's child returns instantly, so reconcile would
# restart it and that detached poll would race the failing-path start below for
# the source claim - non-deterministically stealing its sequence or the claim
# itself. Retire it before the re-announcement check so reconcile starts no
# competing poll, then re-register for the failing-path capture, the same
# retire-before-reconcile discipline the blocker-backed sources rely on.
pe_adapter "$HSELF" retire self-src >/dev/null
out=$(pe_adapter "$HSELF" reconcile)
assert_contains "$out" "published=0" "reconcile re-announced a capture its adapter already acknowledged"
assert_contains "$out" "started=0" "reconcile restarted an always-ready acknowledged source and raced the next start"
pe_adapter "$HSELF" register selfann self-src -- /bin/echo "self announced" >/dev/null
: > "$HSELF/state/selfann-fail"
out=$(pe_adapter "$HSELF" start self-src 2>&1)
assert_contains "$out" "not-autohandled: self-src" "a failed self-announcing application was reported as applied"
assert_absent "$HSELF/state/procevent-inbox/self-src.2.handled" "a failed self-announcing application was acknowledged anyway"
assert_contains "$(wake_payloads "$HSELF")" "procevent selfann self-src 2" \
  "a capture the self-announcing adapter could not apply lost its check-wake announcement"
rm -f "$HSELF/state/selfann-fail"
pass "a self-announcing adapter applies quietly and still publishes what it could not apply"

HTERM="$TMP_ROOT/hterm"; new_home "$HTERM"
fm_test_track_procevent_home "$HTERM"
pe_adapter "$HTERM" register endnow ends-src -- /bin/echo "terminal payload" >/dev/null
out=$(pe_adapter "$HTERM" start ends-src)
assert_contains "$out" "captured:" "a terminal result is still captured durably"
assert_contains "$out" "retired: ends-src" "the runner reports the adapter-driven retirement"
assert_absent "$HTERM/state/procevent/ends-src.source" "an adapter-classified terminal result retires its registration"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/ends-src.claim" "terminal retirement releases this runner's own claim"
assert_contains "$(wake_payloads "$HTERM")" "procevent endnow ends-src 1" "the terminal result is still announced"
[ "$(count_results "$HTERM" ends-src)" = 1 ] || fail "terminal retirement lost or duplicated the captured result"
TERMINAL_RESULT=$(first_result "$HTERM" ends-src || true)
assert_grep 'terminal payload' "$TERMINAL_RESULT" "automatic retirement retains the captured output verbatim"
out=$(pe_adapter "$HTERM" reconcile)
assert_contains "$out" "started=0" "a retired terminal source is never restarted"
assert_contains "$out" "published=1" "an unhandled terminal result is still re-announced until acknowledged"
[ "$(count_results "$HTERM" ends-src)" = 1 ] || fail "a retired terminal source ran its poll again"
out=$(pe_adapter "$HTERM" retire ends-src)
assert_contains "$out" "retired: ends-src" "explicit retirement stays supported and idempotent after automatic retirement"
ack_out=$(pe_adapter "$HTERM" handled ends-src 1)
assert_contains "$ack_out" "handled: ends-src 1" "a terminal result is acknowledged through the owned interface"
out=$(pe_adapter "$HTERM" reconcile)
assert_contains "$out" "published=0" "an acknowledged terminal result stops being re-announced"
pass "an adapter-classified terminal result is captured once, announced, and retires its source automatically"

HOPEN="$TMP_ROOT/hopen"; new_home "$HOPEN"
fm_test_track_procevent_home "$HOPEN"
pe_adapter "$HOPEN" register openended open-src -- /bin/echo "open payload" >/dev/null
out=$(pe_adapter "$HOPEN" start open-src)
assert_contains "$out" "captured:" "a result from an adapter with no terminal verdict is captured"
assert_not_contains "$out" "retired:" "an adapter with no terminal verdict never retires its source"
assert_present "$HOPEN/state/procevent/open-src.source" "a source with no terminal verdict stays armed"
pe_adapter "$HOPEN" retire open-src >/dev/null
pass "a source stays armed unless its own adapter classifies the result terminal"

HREPLACE="$TMP_ROOT/hreplace"; new_home "$HREPLACE"
fm_test_track_procevent_home "$HREPLACE"
OLD_TRIGGER="$TMP_ROOT/replace-old-trigger"
OLD_STARTED="$TMP_ROOT/replace-old-started"
pe_adapter "$HREPLACE" register endnow replace-src -- \
  "$STARTED_BLOCKER" "$OLD_STARTED" "$BLOCKER" "$OLD_TRIGGER" "old terminal payload" >/dev/null
pe_adapter "$HREPLACE" start replace-src > "$TMP_ROOT/replace-old.out" 2>&1 &
replace_old_pid=$!
wait_for "$OLD_STARTED" || fail "the old registration never started"
pe_adapter "$HREPLACE" register openended replace-src -- /bin/echo "replacement payload" >/dev/null
touch "$OLD_TRIGGER"
wait "$replace_old_pid" || fail "the old terminal runner failed"
assert_contains "$(cat "$TMP_ROOT/replace-old.out")" "cannot retire terminal source" \
  "an old runner refuses to retire a replacement registration"
assert_present "$HREPLACE/state/procevent/replace-src.source" \
  "a replacement registration survives the old runner's terminal result"
assert_contains "$(cat "$HREPLACE/state/procevent/replace-src.source")" "adapter=openended" \
  "the surviving registration is the replacement generation"
out=$(pe_adapter "$HREPLACE" start replace-src)
assert_contains "$out" "captured:" "the replacement registration remains independently runnable"
[ "$(count_results "$HREPLACE" replace-src)" = 2 ] \
  || fail "the replacement generation did not capture its own result"
pe_adapter "$HREPLACE" retire replace-src >/dev/null
pass "terminal retirement preserves and releases a concurrently replaced registration"

HRETFAIL="$TMP_ROOT/hretfail"; new_home "$HRETFAIL"
fm_test_track_procevent_home "$HRETFAIL"
FAIL_RM_BIN=$(fm_fakebin "$TMP_ROOT/retire-fail-bin")
REAL_RM=$(command -v rm)
export REAL_RM
cat > "$FAIL_RM_BIN/rm" <<'SH'
#!/usr/bin/env bash
for arg in "$@"; do
  case "$arg" in */retire-fail-src.source) exit 1 ;; esac
done
exec "$REAL_RM" "$@"
SH
chmod +x "$FAIL_RM_BIN/rm"
pe_adapter "$HRETFAIL" register endnow retire-fail-src -- /bin/echo "one terminal payload" >/dev/null
out=$(PATH="$FAIL_RM_BIN:$PATH" pe_adapter "$HRETFAIL" start retire-fail-src 2>&1)
assert_contains "$out" "cannot retire terminal source" "a failed registration removal is reported"
assert_present "$HRETFAIL/state/procevent/retire-fail-src.source" \
  "failed retirement preserves the exact registration"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/retire-fail-src.claim" \
  "failed retirement preserves its terminal ownership claim"
out=$(PATH="$FAIL_RM_BIN:$PATH" pe_adapter "$HRETFAIL" reconcile)
assert_contains "$out" "started=0" "failed terminal retirement never restarts the poll"
[ "$(count_results "$HRETFAIL" retire-fail-src)" = 1 ] \
  || fail "failed retirement allowed recurring terminal capture"
pe_adapter "$HRETFAIL" reconcile >/dev/null
assert_absent "$HRETFAIL/state/procevent/retire-fail-src.source" \
  "repeated retirement removes the same registration once removal recovers"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/retire-fail-src.claim" \
  "the claim releases only after that registration is removed"
[ "$(count_results "$HRETFAIL" retire-fail-src)" = 1 ] \
  || fail "retirement recovery reran the terminal source"
pass "failed terminal retirement is fail-closed and idempotently recoverable"

# --- end-user-aligned regression: one Send & End, one captured result -------
# The dogfood defect: a real armed Lavish source received one human `Send & End`
# action, and the runner captured four results - the human's real feedback, then
# recurring empty ended sessions - because it kept restarting a source whose own
# adapter already knew the session had ended. Driven through the adapter's own
# arm command against a stand-in for the published poll shape, so registration,
# the runner, capture, publication, and retirement all run for real.
HLT="$TMP_ROOT/hlt"; new_home "$HLT"
LAVISH_BIN=$(fm_fakebin "$TMP_ROOT/lavish-stub")
LAVISH_POLL_COUNT="$TMP_ROOT/lavish-poll-count"
export LAVISH_POLL_COUNT
cat > "$LAVISH_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
# Stand-in for `lavish-axi poll <file>` around a human `Send & End`: the final
# feedback is delivered exactly once carrying session_ended, and every later
# poll returns an empty ended session immediately.
n=$(cat "$LAVISH_POLL_COUNT" 2>/dev/null || echo 0)
n=$((n + 1))
printf '%s\n' "$n" > "$LAVISH_POLL_COUNT"
if [ "$n" = 1 ]; then
  printf 'session:\n  file: /review.html\n  status: feedback\n  session_ended: true\n  ended_by: user\nfeedback[1]{text}:\n  ship it\n'
else
  printf 'session:\n  file: /review.html\n  status: ended\n  ended_by: user\n'
fi
SH
chmod +x "$LAVISH_BIN/lavish-axi"
REVIEW_ART="$TMP_ROOT/review.html"
printf '<h1>review</h1>\n' > "$REVIEW_ART"
lavish_session "$REVIEW_ART"
lavish_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$REVIEW_ART")
fm_test_track_procevent_home "$HLT"
PATH="$LAVISH_BIN:$PATH" FM_HOME="$HLT" "$ROOT/bin/fm-procevent-lavish.sh" arm "$REVIEW_ART" >/dev/null
for _ in $(seq 1 6); do
  PATH="$LAVISH_BIN:$PATH" pe "$HLT" reconcile >/dev/null
  sleep 0.3
done
[ "$(cat "$LAVISH_POLL_COUNT")" = 1 ] \
  || fail "an ended review kept being polled: $(cat "$LAVISH_POLL_COUNT") polls for one Send & End"
[ "$(count_results "$HLT" "$lavish_id")" = 1 ] \
  || fail "one Send & End produced $(count_results "$HLT" "$lavish_id") captured results"
[ "$(wake_payloads "$HLT" | sort -u | grep -c .)" = 1 ] \
  || fail "one Send & End produced more than one distinct event: $(wake_payloads "$HLT" | sort -u)"
assert_contains "$(wake_payloads "$HLT")" "procevent lavish $lavish_id 1" "the human's final feedback is announced"
assert_absent "$HLT/state/procevent/$lavish_id.source" "the ended review source retires automatically"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/$lavish_id.claim" "the ended review releases its owned claim"
LAVISH_RESULT=$(first_result "$HLT" "$lavish_id" || true)
assert_grep 'ship it' "$LAVISH_RESULT" "automatic retirement retains the human's final feedback"
out=$(PATH="$LAVISH_BIN:$PATH" FM_HOME="$HLT" "$ROOT/bin/fm-procevent-lavish.sh" retire "$REVIEW_ART")
assert_contains "$out" "retired: $lavish_id" "explicit adapter retirement stays supported after automatic retirement"
pass "one Send & End yields exactly one captured result, automatic retirement, and no recurring poll"

# --- end-user-aligned regression: an empty board close is not news ------------
# The captain's report: closing a review surface he had said nothing on still
# put a wake in his chat whose entire content was that nothing happened. The
# adapter now answers the runner's silence seam for exactly that shape, so the
# result is captured and recorded handled without ever being announced. Driven
# through the adapter's own arm command and the real runner, so registration,
# capture, the silence verdict, and retirement all run for real.
HEMPTY="$TMP_ROOT/hempty"; new_home "$HEMPTY"
EMPTY_BIN=$(fm_fakebin "$TMP_ROOT/lavish-empty-stub")
cat > "$EMPTY_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
# Stand-in for `lavish-axi poll <file>` when the captain closes a board he said
# nothing on: an ended session carrying no queued content at all.
printf 'session:\n  file: /quiet.html\n  status: ended\n  ended_by: user\n'
SH
chmod +x "$EMPTY_BIN/lavish-axi"
QUIET_ART="$TMP_ROOT/quiet-board.html"
printf '<h1>quiet</h1>\n' > "$QUIET_ART"
lavish_session "$QUIET_ART"
quiet_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$QUIET_ART")
fm_test_track_procevent_home "$HEMPTY"
PATH="$EMPTY_BIN:$PATH" FM_HOME="$HEMPTY" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$QUIET_ART" >/dev/null
quiet_out=$(PATH="$EMPTY_BIN:$PATH" pe "$HEMPTY" start "$quiet_id" 2>&1)
assert_not_contains "$quiet_out" "not-autohandled" \
  "a durably silenced result was reported as still unacknowledged"
# The handled marker is written at exactly the point the wake would otherwise
# have been appended, so waiting on it - rather than on a fixed sleep - is what
# makes "no wake" a real observation instead of a race the test won by being
# early.
QUIET_HANDLED="$HEMPTY/state/procevent-inbox/$quiet_id.1.handled"
for _ in $(seq 1 100); do
  [ -f "$QUIET_HANDLED" ] && break
  sleep 0.1
done
[ -f "$QUIET_HANDLED" ] \
  || fail "a silenced result was not durably recorded handled, so a later reconcile would announce it"
[ "$(count_results "$HEMPTY" "$quiet_id")" = 1 ] \
  || fail "an empty board close captured $(count_results "$HEMPTY" "$quiet_id") results instead of one"
[ -z "$(wake_payloads "$HEMPTY")" ] \
  || fail "an empty board close woke the captain: $(wake_payloads "$HEMPTY")"
# Re-announcement is exactly what the handled marker exists to stop, so the
# silence has to survive the reconcile that would otherwise republish it.
PATH="$EMPTY_BIN:$PATH" pe "$HEMPTY" reconcile >/dev/null
sleep 0.3
[ -z "$(wake_payloads "$HEMPTY")" ] \
  || fail "a later reconcile re-announced a silenced empty board close: $(wake_payloads "$HEMPTY")"
assert_absent "$HEMPTY/state/procevent/$quiet_id.source" \
  "an empty board close still retires its ended source"
pass "an empty board close is captured and recorded handled without ever waking the captain"

# --- end-user-aligned regression: worker-owned rounds stay open until re-arm -
# One worker-owned board runs three rounds: feedback reaches only the worker's
# inbox, each re-arm acknowledges the prior capture and posts its reply once,
# and a terminal session ends without another automatic poll.
HMULTI="$TMP_ROOT/hmulti"; new_home "$HMULTI"
MULTI_BIN=$(fm_fakebin "$TMP_ROOT/lavish-multi-stub")
MULTI_ROOT="$TMP_ROOT/lavish-multi-root"
mkdir -p "$MULTI_ROOT"
export MULTI_ROOT
cat > "$MULTI_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
[ "${1-}" != --version ] || { printf '0.1.79\n'; exit 0; }
n=$(cat "$MULTI_ROOT/count" 2>/dev/null || echo 0)
n=$((n + 1))
printf '%s\n' "$n" > "$MULTI_ROOT/count"
printf '%s:%s\n' "${LAVISH_AXI_HOST-unset}" "${LAVISH_AXI_PORT-unset}" >> "$MULTI_ROOT/routes"
for arg in "$@"; do
  case "$arg" in
    --agent-reply) ;;
    --*)
      printf 'error: unknown option %s\ncode: VALIDATION_ERROR\n' "$arg" >&2
      exit 2
      ;;
  esac
done
if [ "${1-}" = poll ] && [ "${3-}" = --agent-reply ]; then
  printf 'poll%s reply: %s\n' "$n" "$4" >> "$MULTI_ROOT/replies"
fi
while [ ! -e "$MULTI_ROOT/trigger$n" ]; do sleep 0.02; done
case "$n" in
  1|2)
    printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","round %s","","message",""\n' "$n"
    ;;
  3)
    printf 'session:\n  status: ended\n  session_ended: true\n'
    ;;
esac
SH
chmod +x "$MULTI_BIN/lavish-axi"
printf 'reply one\n' > "$MULTI_ROOT/reply1"
printf 'reply two\n' > "$MULTI_ROOT/reply2"
printf 'reply three\n' > "$MULTI_ROOT/reply3"
MULTI_ART="$MULTI_ROOT/board.html"
printf '<h1>multi-round</h1>\n' > "$MULTI_ART"
lavish_session "$MULTI_ART"
multi_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$MULTI_ART")
fm_test_track_procevent_home "$HMULTI"
new_task_endpoint "$HMULTI" worker-1
new_task_endpoint "$HMULTI" worker-2
mkdir -p "$HMULTI/config"
printf 'wrong-server.example\n' > "$HMULTI/config/lavish-axi-host"
PATH="$MULTI_BIN:$PATH" LAVISH_AXI_HOST=arming.example LAVISH_AXI_PORT=24387 FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" --for worker-1 \
  --agent-reply-file "$MULTI_ROOT/reply1" >/dev/null
if PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" >/dev/null 2>"$MULTI_ROOT/firstmate-arm.err"; then
  fail "firstmate arm replaced a worker-owned board"
fi
assert_contains "$(cat "$MULTI_ROOT/firstmate-arm.err")" "owned by task worker-1" \
  "second armer refusal did not name the worker owner"
list_out=$(FM_HOME="$HMULTI" "$ROOT/bin/fm-procevent.sh" list)
assert_contains "$list_out" "task:worker-1/listening" \
  "arm did not leave the worker-owned board with a live listener"
PATH="$MULTI_BIN:$PATH" LAVISH_AXI_HOST=recovery.example LAVISH_AXI_PORT=34387 FM_HOME="$HMULTI" \
  pe "$HMULTI" start "$multi_id" > "$MULTI_ROOT/run1" 2>&1 &
MULTI_RUN=$!
for _ in $(seq 1 100); do [ "$(cat "$MULTI_ROOT/count" 2>/dev/null || true)" = 1 ] && break; sleep 0.02; done
touch "$MULTI_ROOT/trigger1"
for _ in $(seq 1 100); do [ -f "$HMULTI/state/worker-1.inbox/001.msg" ] && break; sleep 0.02; done
[ -f "$HMULTI/state/worker-1.inbox/001.msg" ] \
  || fail "worker-owned feedback did not reach the worker inbox"
[ -z "$(wake_payloads "$HMULTI")" ] \
  || fail "worker-owned feedback woke firstmate: $(wake_payloads "$HMULTI")"

# An open nonterminal round keeps the board with worker-1 through every
# retirement and registration path: the one source record cannot be retired out
# from under that round, and while it stands neither firstmate nor a sibling
# task can register over it or acknowledge worker-1's capture.
open_retire_status=0
PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$MULTI_ART" \
  >/dev/null 2>"$MULTI_ROOT/open-retire.err" || open_retire_status=$?
[ "$open_retire_status" -ne 0 ] \
  || fail "explicit retire removed a worker-owned board with an unacknowledged round"
assert_contains "$(cat "$MULTI_ROOT/open-retire.err")" "unacknowledged" \
  "the refused retire did not say the owner's round is still unacknowledged"
[ -e "$HMULTI/state/procevent/$multi_id.source" ] \
  || fail "a refused retire still removed the worker-owned source record"
if PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" --for worker-2 \
  >/dev/null 2>"$MULTI_ROOT/open-sibling.err"; then
  fail "a sibling task registered over an open worker-owned round"
fi
assert_contains "$(cat "$MULTI_ROOT/open-sibling.err")" "owned by task worker-1" \
  "the sibling refusal over an open round did not name the worker owner"
if PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" \
  >/dev/null 2>"$MULTI_ROOT/open-firstmate.err"; then
  fail "firstmate armed a board with an open worker-owned round"
fi
assert_contains "$(cat "$MULTI_ROOT/open-firstmate.err")" "owned by task worker-1" \
  "the firstmate refusal over an open round did not name the worker owner"
[ ! -f "$HMULTI/state/procevent-inbox/$multi_id.1.handled" ] \
  || fail "a refused retire or registration acknowledged the owner's open round"
[ ! -e "$HMULTI/state/worker-2.inbox" ] \
  || fail "a refused sibling registration took delivery of the owner's feedback"

PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" --for worker-1 \
  --agent-reply-file "$MULTI_ROOT/reply2" >/dev/null
wait "$MULTI_RUN" || true
for _ in $(seq 1 100); do
  PATH="$MULTI_BIN:$PATH" pe "$HMULTI" reconcile >/dev/null 2>&1 || true
  [ "$(cat "$MULTI_ROOT/count" 2>/dev/null || true)" = 2 ] && break
  sleep 0.03
done
touch "$MULTI_ROOT/trigger2"
for _ in $(seq 1 100); do [ -f "$HMULTI/state/worker-1.inbox/002.msg" ] && break; sleep 0.02; done
[ -f "$HMULTI/state/worker-1.inbox/002.msg" ] \
  || fail "the next worker-owned feedback did not reach the worker inbox"
PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" --for worker-1 \
  --agent-reply-file "$MULTI_ROOT/reply3" >/dev/null
for _ in $(seq 1 100); do
  PATH="$MULTI_BIN:$PATH" pe "$HMULTI" reconcile >/dev/null 2>&1 || true
  [ "$(cat "$MULTI_ROOT/count" 2>/dev/null || true)" = 3 ] && break
  sleep 0.03
done
touch "$MULTI_ROOT/trigger3"
for _ in $(seq 1 100); do [ -f "$HMULTI/state/worker-1.inbox/003.msg" ] && break; sleep 0.02; done
[ -f "$HMULTI/state/procevent-inbox/$multi_id.1.handled" ] \
  || fail "first worker-owned round was not acknowledged by re-arm"
[ -f "$HMULTI/state/procevent-inbox/$multi_id.2.handled" ] \
  || fail "second worker-owned round was not acknowledged by re-arm"
assert_contains "$(cat "$HMULTI/state/worker-1.inbox/003.msg" 2>/dev/null || true)" \
  "do not re-arm" "terminal worker-owned result instructed the worker to stop"
[ "$(grep -c '^poll[123] reply:' "$MULTI_ROOT/replies" 2>/dev/null || true)" = 3 ] \
  || fail "worker replies were not posted once per round"
assert_contains "$(cat "$MULTI_ROOT/replies")" "poll1 reply: reply one" \
  "the reply staged with the arm was not the one the board received"
printf '%s\n' '127.0.0.1:14387' '127.0.0.1:14387' '127.0.0.1:14387' > "$MULTI_ROOT/expected-routes"
cmp -s "$MULTI_ROOT/expected-routes" "$MULTI_ROOT/routes" \
  || fail "worker replies/polls did not use the opened session server across start and reconcile"
pass "worker board replies and recovered listeners derive their server from the board session"

# The terminal round keeps the board with worker-1 until worker-1 acknowledges
# it, so the one source record stays the only ownership evidence there is: while
# it is open neither firstmate nor a sibling task can arm the board or consume
# the round, and acknowledging it is what concludes and retires the board.
[ -e "$HMULTI/state/procevent/$multi_id.source" ] \
  || fail "the terminal round released the worker's board before it was acknowledged"
if PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" >/dev/null 2>"$MULTI_ROOT/terminal-arm.err"; then
  fail "firstmate armed a worker-owned board whose terminal round was unacknowledged"
fi
assert_contains "$(cat "$MULTI_ROOT/terminal-arm.err")" "owned by task worker-1" \
  "the refusal over an open terminal round did not name the worker owner"
if PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$MULTI_ART" --for worker-2 \
  >/dev/null 2>"$MULTI_ROOT/sibling-arm.err"; then
  fail "a sibling task took over a worker-owned board whose terminal round was unacknowledged"
fi
assert_contains "$(cat "$MULTI_ROOT/sibling-arm.err")" "owned by task worker-1" \
  "the sibling registration refusal did not name the worker owner"
terminal_retire_status=0
PATH="$MULTI_BIN:$PATH" FM_HOME="$HMULTI" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$MULTI_ART" \
  >/dev/null 2>"$MULTI_ROOT/terminal-retire.err" || terminal_retire_status=$?
[ "$terminal_retire_status" -ne 0 ] \
  || fail "explicit retire removed a worker-owned board with an unacknowledged terminal round"
[ -e "$HMULTI/state/procevent/$multi_id.source" ] \
  || fail "a refused retire removed the worker-owned record of an open terminal round"
[ ! -f "$HMULTI/state/procevent-inbox/$multi_id.3.handled" ] \
  || fail "a refused sibling registration consumed the owner's terminal round"
[ ! -f "$HMULTI/state/worker-2.inbox/001.msg" ] \
  || fail "a refused sibling registration took delivery of the owner's feedback"
chmod 0500 "$HMULTI/state/procevent"
blocked_handled_status=0
PATH="$MULTI_BIN:$PATH" pe "$HMULTI" handled "$multi_id" 3 \
  >/dev/null 2>"$MULTI_ROOT/blocked-handled.err" || blocked_handled_status=$?
chmod 0700 "$HMULTI/state/procevent"
[ "$blocked_handled_status" -ne 0 ] \
  || fail "an acknowledgement that could not retire the board still reported success"
[ ! -f "$HMULTI/state/procevent-inbox/$multi_id.3.handled" ] \
  || fail "an acknowledgement that could not retire the board still closed the round"
[ -e "$HMULTI/state/procevent/$multi_id.source" ] \
  || fail "a failed conclude left the board unowned"
PATH="$MULTI_BIN:$PATH" pe "$HMULTI" handled "$multi_id" 3 >/dev/null
[ -f "$HMULTI/state/procevent-inbox/$multi_id.3.handled" ] \
  || fail "the owner's acknowledgement of the terminal round was not recorded"
[ ! -e "$HMULTI/state/procevent/$multi_id.source" ] \
  || fail "acknowledging the terminal round did not retire the worker-owned board"
PATH="$MULTI_BIN:$PATH" pe "$HMULTI" reconcile >/dev/null 2>&1 || true
[ "$(cat "$MULTI_ROOT/count")" = 3 ] \
  || fail "the concluded board was polled again: $(cat "$MULTI_ROOT/count") polls"
[ -z "$(wake_payloads "$HMULTI")" ] \
  || fail "worker-owned rounds produced a firstmate wake: $(wake_payloads "$HMULTI")"
pass "worker-owned Lavish rounds deliver to the worker, acknowledge on re-arm, and stop at session end"

# --- end-user-aligned regression: a half-written capture does not wedge -----
# The result file is a capture's commit marker, so an owner sidecar left behind
# at a sequence with no result - a crash between publishing that sidecar and
# committing the result - is replaceable staging state. The next capture takes
# the same sequence and still routes to the owning worker.
HORPHAN="$TMP_ROOT/horphan"; new_home "$HORPHAN"
ORPHAN_BIN=$(fm_fakebin "$TMP_ROOT/lavish-orphan-stub")
ORPHAN_TRIGGER="$TMP_ROOT/lavish-orphan-hold"
export ORPHAN_TRIGGER
cat > "$ORPHAN_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
while [ ! -e "$ORPHAN_TRIGGER" ]; do sleep 0.02; done
printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","after the crash","","message",""\n'
SH
chmod +x "$ORPHAN_BIN/lavish-axi"
ORPHAN_ART="$TMP_ROOT/orphan-board.html"
printf '<h1>orphan</h1>\n' > "$ORPHAN_ART"
lavish_session "$ORPHAN_ART"
orphan_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ORPHAN_ART")
fm_test_track_procevent_home "$HORPHAN"
new_task_endpoint "$HORPHAN" worker-4
PATH="$ORPHAN_BIN:$PATH" FM_HOME="$HORPHAN" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ORPHAN_ART" --for worker-4 >/dev/null
(umask 077; mkdir -p "$HORPHAN/state/procevent-inbox")
chmod 0700 "$HORPHAN/state/procevent-inbox"
printf 'worker-4\n' > "$HORPHAN/state/procevent-inbox/$orphan_id.1.owner-task"
chmod 0600 "$HORPHAN/state/procevent-inbox/$orphan_id.1.owner-task"
touch "$ORPHAN_TRIGGER"
PATH="$ORPHAN_BIN:$PATH" pe "$HORPHAN" start "$orphan_id" >/dev/null 2>&1 || true
wait_for "$HORPHAN/state/procevent-inbox/$orphan_id.1.result" \
  || fail "an owner sidecar with no committed result wedged the next capture of its source"
wait_for "$HORPHAN/state/worker-4.inbox/001.msg" \
  || fail "the recovered capture did not reach its owning worker's steering inbox"
[ -f "$HORPHAN/state/procevent-inbox/$orphan_id.1.result" ] \
  || fail "an owner sidecar with no committed result wedged the next capture of its source"
[ -f "$HORPHAN/state/worker-4.inbox/001.msg" ] \
  || fail "the recovered capture did not reach its owning worker's steering inbox"
pass "a capture interrupted before its result commit does not wedge its source"

# --- end-user-aligned regression: confirming a launch leaves the lock free ----
# A runner needs the source lock to claim. A confirmation loop polling that lock
# before any claim exists starves the launch it is waiting for, which on a loaded
# host pushed healthy listeners past the confirm window: arm then retired its own
# registration and reconcile announced a launch failure. The stand-in holds the
# runner at its first process-group check, just before it first takes the lock,
# so anything seen holding the lock during that hold is the confirmation itself.
STALL_BIN=$(fm_fakebin "$TMP_ROOT/ps-stall-stub")
STALL_STARTED="$TMP_ROOT/ps-stall-started"
STALL_RELEASE="$TMP_ROOT/ps-stall-release"
STALL_REAL_PS=$(command -v ps)
export STALL_STARTED STALL_RELEASE STALL_REAL_PS
cat > "$STALL_BIN/ps" <<'SH'
#!/usr/bin/env bash
case "$*" in
  *'-o pgid='*)
    printf 'held\n' > "$STALL_STARTED"
    while [ ! -e "$STALL_RELEASE" ]; do
      [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ] || exit 75
      sleep 0.02
    done
    ;;
esac
exec "$STALL_REAL_PS" "$@"
SH
chmod +x "$STALL_BIN/ps"
assert_confirmation_leaves_lock_free() {  # <home> <source-id> <description> <fm-procevent command...>
  local home=$1 id=$2 description=$3 lock pid sample_until touched=0
  shift 3
  rm -f "$STALL_STARTED" "$STALL_RELEASE"
  lock=$(printf '%s/%s.lock' "$FM_PROCEVENT_CLAIM_ROOT" "$id")
  FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=60 PATH="$STALL_BIN:$PATH" pe "$home" "$@" >/dev/null 2>&1 &
  pid=$!
  wait_for "$STALL_STARTED" || fail "the stalled runner never reached its process-group check: $description"
  sample_until=$((SECONDS + 2))
  while [ "$SECONDS" -lt "$sample_until" ]; do
    if [ -e "$lock" ] || [ -L "$lock" ]; then touched=1; fi
  done
  touch "$STALL_RELEASE"
  wait "$pid" || fail "a launch held only by a slow runner was not confirmed: $description"
  [ "$touched" -eq 0 ] || fail "confirmation took the source lock before any claim existed: $description"
  pe "$home" retire "$id" >/dev/null
}
HLOCKFREE="$TMP_ROOT/hlockfree"; new_home "$HLOCKFREE"
LOCKFREE_TRIGGER="$TMP_ROOT/lockfree-hold"
pe_register "$HLOCKFREE" lavish lockfree-src -- "$BLOCKER" "$LOCKFREE_TRIGGER" "lockfree payload" >/dev/null
assert_confirmation_leaves_lock_free "$HLOCKFREE" lockfree-src "ensure-listening" ensure-listening lockfree-src
pe_register "$HLOCKFREE" lavish lockfree-src -- "$BLOCKER" "$LOCKFREE_TRIGGER" "lockfree payload" >/dev/null
assert_confirmation_leaves_lock_free "$HLOCKFREE" lockfree-src "reconcile" reconcile
pass "confirming a launch leaves the source lock free until a claim exists"

# --- end-user-aligned regression: an orphaned capture keeps its owner ---------
# An unacknowledged capture belongs to whoever it was routed to. Retiring the
# board it came from orphans that capture without handing it to anyone, so a
# worker arming the same artifact is refused rather than silently acknowledging
# a round that never reached it.
HADOPT="$TMP_ROOT/hadopt"; new_home "$HADOPT"
ADOPT_BIN=$(fm_fakebin "$TMP_ROOT/lavish-adopt-stub")
cat > "$ADOPT_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","for firstmate","","message",""\n'
SH
chmod +x "$ADOPT_BIN/lavish-axi"
ADOPT_ART="$TMP_ROOT/adopt-board.html"
printf '<h1>adopt</h1>\n' > "$ADOPT_ART"
lavish_session "$ADOPT_ART"
adopt_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ADOPT_ART")
fm_test_track_procevent_home "$HADOPT"
new_task_endpoint "$HADOPT" worker-5
PATH="$ADOPT_BIN:$PATH" FM_HOME="$HADOPT" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ADOPT_ART" >/dev/null
wait_capture "$HADOPT" "$adopt_id" \
  || fail "the firstmate fixture capture never landed"
[ -f "$HADOPT/state/procevent-inbox/$adopt_id.1.result" ] \
  || fail "the firstmate fixture capture never landed"
[ ! -f "$HADOPT/state/procevent-inbox/$adopt_id.1.handled" ] \
  || fail "the firstmate fixture capture was already acknowledged"
PATH="$ADOPT_BIN:$PATH" FM_HOME="$HADOPT" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$ADOPT_ART" >/dev/null
if PATH="$ADOPT_BIN:$PATH" FM_HOME="$HADOPT" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ADOPT_ART" --for worker-5 \
  >/dev/null 2>"$TMP_ROOT/adopt-arm.err"; then
  fail "a worker armed a board carrying another owner's unacknowledged capture"
fi
assert_contains "$(cat "$TMP_ROOT/adopt-arm.err")" "firstmate" \
  "the refusal did not name the owner the orphaned capture belongs to"
[ ! -f "$HADOPT/state/procevent-inbox/$adopt_id.1.handled" ] \
  || fail "a refused arm still acknowledged another owner's capture"
[ ! -e "$HADOPT/state/procevent/$adopt_id.source" ] \
  || fail "a refused arm still published its task-owned registration"
pass "an orphaned capture is not acknowledged by a worker it never reached"

# --- end-user-aligned regression: a board is armed for a reachable owner ------
# Captured feedback goes straight to the owning task's steering inbox, so a task
# id that names no endpoint would strand every round it ever collects. The arm
# path refuses it instead of publishing a registration nobody can be told about.
HNOMETA="$TMP_ROOT/hnometa"; new_home "$HNOMETA"
NOMETA_ART="$TMP_ROOT/nometa-board.html"
printf '<h1>no endpoint</h1>\n' > "$NOMETA_ART"
lavish_session "$NOMETA_ART"
nometa_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$NOMETA_ART")
fm_test_track_procevent_home "$HNOMETA"
if PATH="$ADOPT_BIN:$PATH" FM_HOME="$HNOMETA" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$NOMETA_ART" --for worker-10 \
  >/dev/null 2>"$TMP_ROOT/nometa-arm.err"; then
  fail "a board was armed for a task id that names no endpoint"
fi
assert_contains "$(cat "$TMP_ROOT/nometa-arm.err")" "worker-10" \
  "the refusal did not name the task whose endpoint is missing"
[ ! -e "$HNOMETA/state/procevent/$nometa_id.source" ] \
  || fail "a board armed for an unreachable owner still published its registration"
new_task_endpoint "$HNOMETA" worker-10
PATH="$ADOPT_BIN:$PATH" FM_HOME="$HNOMETA" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$NOMETA_ART" --for worker-10 >/dev/null
[ -e "$HNOMETA/state/procevent/$nometa_id.source" ] \
  || fail "a board was refused for a task that does have an endpoint"
pass "a worker-owned board is only armed for an owner its feedback can reach"

# --- end-user-aligned regression: acknowledging a delivered note stops the ring
# The move into handled/ is the worker's own acknowledgement (the inbox
# contract), so a later reconcile that finds the same captured round must
# never move that note back into the active inbox or ring the worker again:
# only a write that actually creates a fresh record rings, and re-delivery of
# a still-open round is left to the inbox's own re-ring ladder.
HREDELIVER="$TMP_ROOT/hredeliver"; new_home "$HREDELIVER"
RING_BIN=$(fm_fakebin "$TMP_ROOT/ring-tmux-stub")
cat > "$RING_BIN/tmux" <<'SH'
#!/usr/bin/env bash
set -u
case "${1:-}" in
  send-keys)
    shift
    literal=0
    while [ $# -gt 0 ]; do
      case "$1" in
        -t) shift 2 ;;
        -l) literal=1; shift ;;
        *) break ;;
      esac
    done
    [ "$literal" = 1 ] && printf '%s\n' "${1:-}" >> "${FM_SEND_LOG:-/dev/null}"
    exit 0 ;;
  display-message)
    for a in "$@"; do
      case "$a" in
        *cursor_y*) printf '1\n'; exit 0 ;;
      esac
    done
    printf 'fakepane\n'; exit 0 ;;
  capture-pane)
    printf '╭────╮\n│    │\n╰────╯\n'
    exit 0 ;;
  list-windows) printf 'fm-worker-6\n'; exit 0 ;;
esac
exit 0
SH
chmod +x "$RING_BIN/tmux"
REDELIVER_ART="$TMP_ROOT/redeliver-board.html"
printf '<h1>redeliver</h1>\n' > "$REDELIVER_ART"
lavish_session "$REDELIVER_ART"
redeliver_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$REDELIVER_ART")
fm_test_track_procevent_home "$HREDELIVER"
new_task_endpoint "$HREDELIVER" worker-6
RING_LOG="$TMP_ROOT/redeliver-ring.log"; : > "$RING_LOG"
PATH="$RING_BIN:$ADOPT_BIN:$PATH" FM_SEND_LOG="$RING_LOG" FM_HOME="$HREDELIVER" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REDELIVER_ART" --for worker-6 >/dev/null
wait_capture "$HREDELIVER" "$redeliver_id" \
  || fail "the first worker-owned round was never captured"
[ -f "$HREDELIVER/state/worker-6.inbox/001.msg" ] \
  || fail "the first worker-owned round never reached the worker inbox"
wait_for_lines "$RING_LOG" 1 \
  || fail "the newly captured round never rang its owner's doorbell"
[ "$(wc -l < "$RING_LOG" | tr -d ' ')" = 1 ] \
  || fail "a single newly captured round rang more than once: $(cat "$RING_LOG")"
i=0
while [ "$i" -lt 5 ]; do
  PATH="$RING_BIN:$ADOPT_BIN:$PATH" FM_SEND_LOG="$RING_LOG" pe "$HREDELIVER" reconcile >/dev/null 2>&1 || true
  i=$((i + 1))
done
[ "$(wc -l < "$RING_LOG" | tr -d ' ')" = 1 ] \
  || fail "an unchanged active note re-rang the doorbell on every reconcile: $(cat "$RING_LOG")"
[ -f "$HREDELIVER/state/worker-6.inbox/001.msg" ] \
  || fail "repeated reconciles dropped the still-active note from the inbox"
mv "$HREDELIVER/state/worker-6.inbox/001.msg" \
  "$HREDELIVER/state/worker-6.inbox/handled/001.msg"
i=0
while [ "$i" -lt 5 ]; do
  PATH="$RING_BIN:$ADOPT_BIN:$PATH" FM_SEND_LOG="$RING_LOG" pe "$HREDELIVER" reconcile >/dev/null 2>&1 || true
  i=$((i + 1))
done
[ "$(wc -l < "$RING_LOG" | tr -d ' ')" = 1 ] \
  || fail "acknowledging the note did not stop repeated doorbell rings across reconciles: $(cat "$RING_LOG")"
[ ! -f "$HREDELIVER/state/worker-6.inbox/001.msg" ] \
  || fail "an already-acknowledged note was resurrected into the active inbox"
[ -f "$HREDELIVER/state/worker-6.inbox/handled/001.msg" ] \
  || fail "an already-acknowledged note vanished instead of staying acknowledged"
[ ! -f "$HREDELIVER/state/procevent-inbox/$redeliver_id.1.handled" ] \
  || fail "reconcile closed the round on its own, without the owner's explicit handled call"
pass "an acknowledged note is never resurrected and stops ringing across repeated reconciles"

# --- end-user-aligned regression: a conclude only closes its own round --------
# Acknowledging a terminal round retires the board it belongs to. The same
# acknowledgement repeated later is a no-op on a closed round, so it must not
# reach past it and retire whatever board the artifact carries by then.
HCONC="$TMP_ROOT/hconclude"; new_home "$HCONC"
CONC_BIN=$(fm_fakebin "$TMP_ROOT/lavish-conclude-stub")
cat > "$CONC_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
printf 'session:\n  status: ended\n  session_ended: true\n'
SH
chmod +x "$CONC_BIN/lavish-axi"
CONC_ART="$TMP_ROOT/conclude-board.html"
printf '<h1>conclude</h1>\n' > "$CONC_ART"
lavish_session "$CONC_ART"
conc_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$CONC_ART")
fm_test_track_procevent_home "$HCONC"
new_task_endpoint "$HCONC" worker-7
PATH="$CONC_BIN:$PATH" FM_HOME="$HCONC" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$CONC_ART" --for worker-7 >/dev/null
wait_capture "$HCONC" "$conc_id" \
  || fail "the terminal worker-owned round never landed"
[ -f "$HCONC/state/procevent-inbox/$conc_id.1.result" ] \
  || fail "the terminal worker-owned round never landed"
[ -e "$HCONC/state/procevent/$conc_id.source" ] \
  || fail "the terminal round released the board before its owner acknowledged it"
chmod 0500 "$HCONC/state/procevent-inbox"
unrecordable_status=0
PATH="$CONC_BIN:$PATH" pe "$HCONC" handled "$conc_id" 1 >/dev/null 2>&1 || unrecordable_status=$?
chmod 0700 "$HCONC/state/procevent-inbox"
[ "$unrecordable_status" -ne 0 ] \
  || fail "an acknowledgement that could not be recorded still reported success"
[ ! -f "$HCONC/state/procevent-inbox/$conc_id.1.handled" ] \
  || fail "an acknowledgement that could not be recorded still closed the round"
[ -e "$HCONC/state/procevent/$conc_id.source" ] \
  || fail "an acknowledgement that could not be recorded still released the board it was owed"
conclude_out=$(PATH="$CONC_BIN:$PATH" pe "$HCONC" handled "$conc_id" 1)
assert_contains "$conclude_out" "retired: $conc_id" \
  "acknowledging the terminal round did not report the board retired"
[ ! -e "$HCONC/state/procevent/$conc_id.source" ] \
  || fail "acknowledging the terminal round did not retire the worker-owned board"
PATH="$CONC_BIN:$PATH" FM_HOME="$HCONC" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$CONC_ART" --for worker-7 >/dev/null
repeat_out=$(PATH="$CONC_BIN:$PATH" pe "$HCONC" handled "$conc_id" 1)
assert_contains "$repeat_out" "already-handled: $conc_id 1" \
  "repeating a closed acknowledgement did not report it as already handled"
case "$repeat_out" in
  *retired:*) fail "repeating a closed acknowledgement retired a board it never belonged to" ;;
esac
[ -e "$HCONC/state/procevent/$conc_id.source" ] \
  || fail "repeating a closed acknowledgement retired the board armed after it"
pass "acknowledging a terminal round concludes that round only"

# --- end-user-aligned regression: an interrupted conclude ends the board -----
# The conclude drops the registration and then records the acknowledgement. An
# interruption between those steps must leave nothing that relaunches the ended
# board, and the same acknowledgement has to finish the job on the next try.
HINTR="$TMP_ROOT/hinterrupted"; new_home "$HINTR"
INTR_ROOT="$TMP_ROOT/lavish-interrupted-root"; mkdir -p "$INTR_ROOT"; export INTR_ROOT
INTR_BIN=$(fm_fakebin "$TMP_ROOT/lavish-interrupted-stub")
cat > "$INTR_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
n=$(cat "$INTR_ROOT/count" 2>/dev/null || echo 0)
printf '%s\n' "$((n + 1))" > "$INTR_ROOT/count"
printf 'session:\n  status: ended\n  session_ended: true\n'
SH
chmod +x "$INTR_BIN/lavish-axi"
INTR_ART="$TMP_ROOT/interrupted-board.html"
printf '<h1>interrupted</h1>\n' > "$INTR_ART"
lavish_session "$INTR_ART"
intr_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$INTR_ART")
fm_test_track_procevent_home "$HINTR"
new_task_endpoint "$HINTR" worker-12
PATH="$INTR_BIN:$PATH" FM_HOME="$HINTR" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$INTR_ART" --for worker-12 >/dev/null
wait_capture "$HINTR" "$intr_id" \
  || fail "the terminal worker-owned round was never captured"
[ "$(cat "$INTR_ROOT/count" 2>/dev/null || echo 0)" = 1 ] \
  || fail "the terminal worker-owned round was not polled exactly once"
rm -f "$HINTR/state/procevent/$intr_id.source"
PATH="$INTR_BIN:$PATH" pe "$HINTR" reconcile >/dev/null 2>&1 || true
[ "$(cat "$INTR_ROOT/count" 2>/dev/null || echo 0)" = 1 ] \
  || fail "an interrupted conclude let the ended board be polled again"
if PATH="$INTR_BIN:$PATH" FM_HOME="$HINTR" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$INTR_ART" --for worker-12 \
  >/dev/null 2>"$INTR_ROOT/intr-arm.err"; then
  fail "an interrupted conclude let its owner re-arm the ended board"
fi
assert_contains "$(cat "$INTR_ROOT/intr-arm.err")" "terminal" \
  "the refusal did not say the round still owed a conclude is terminal"
intr_out=$(PATH="$INTR_BIN:$PATH" pe "$HINTR" handled "$intr_id" 1)
assert_contains "$intr_out" "handled: $intr_id 1" \
  "repeating the interrupted acknowledgement did not record it"
[ -f "$HINTR/state/procevent-inbox/$intr_id.1.handled" ] \
  || fail "the interrupted conclude was never finished by the repeated acknowledgement"
pass "an interrupted conclude leaves the ended board unpollable and finishes on retry"

# --- end-user-aligned regression: a failed re-arm keeps the last generation ---
# Re-arm publishes the next generation and acknowledges the round it replaces.
# When that acknowledgement cannot be recorded the whole re-arm has to be off,
# leaving the generation the board is actually running untouched.
HROLL="$TMP_ROOT/hrollback"; new_home "$HROLL"
ROLL_ROOT="$TMP_ROOT/lavish-rollback-root"; mkdir -p "$ROLL_ROOT"; export ROLL_ROOT
ROLL_BIN=$(fm_fakebin "$TMP_ROOT/lavish-rollback-stub")
cat > "$ROLL_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
[ "${1-}" != --version ] || { printf '0.1.79\n'; exit 0; }
[ "${3-}" != --agent-reply ] || printf '%s\n' "$4" >> "$ROLL_ROOT/replies"
printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","another round","","message",""\n'
SH
chmod +x "$ROLL_BIN/lavish-axi"
ROLL_ART="$TMP_ROOT/rollback-board.html"
printf '<h1>rollback</h1>\n' > "$ROLL_ART"
lavish_session "$ROLL_ART"
roll_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ROLL_ART")
fm_test_track_procevent_home "$HROLL"
new_task_endpoint "$HROLL" worker-8
printf 'reply from generation one\n' > "$ROLL_ROOT/reply1"
printf 'reply from generation two\n' > "$ROLL_ROOT/reply2"
PATH="$ROLL_BIN:$PATH" FM_HOME="$HROLL" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ROLL_ART" --for worker-8 \
  --agent-reply-file "$ROLL_ROOT/reply1" >/dev/null
wait_for "$ROLL_ROOT/replies" \
  || fail "the first generation's reply never reached the board"
[ "$(grep -c 'generation one' "$ROLL_ROOT/replies" 2>/dev/null || true)" = 1 ] \
  || fail "the first generation's reply never reached the board"
# The reply is posted before the round is captured. Making the inbox read-only
# before the runner commits and exits would fail that capture instead of the
# re-arm's acknowledgement, leaving no round for the retried re-arm.
wait_capture "$HROLL" "$roll_id" \
  || fail "the first generation's round was never captured"
cp "$HROLL/state/procevent/$roll_id.source" "$ROLL_ROOT/generation-one.source"
chmod 0500 "$HROLL/state/procevent-inbox"
rollback_status=0
PATH="$ROLL_BIN:$PATH" FM_HOME="$HROLL" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ROLL_ART" --for worker-8 \
  --agent-reply-file "$ROLL_ROOT/reply2" >/dev/null 2>&1 || rollback_status=$?
chmod 0700 "$HROLL/state/procevent-inbox"
[ "$rollback_status" -ne 0 ] \
  || fail "a re-arm that could not acknowledge its round still reported success"
cmp -s "$ROLL_ROOT/generation-one.source" "$HROLL/state/procevent/$roll_id.source" \
  || fail "a failed re-arm replaced the generation the board is still running"
[ ! -f "$HROLL/state/procevent-inbox/$roll_id.1.handled" ] \
  || fail "a failed re-arm still acknowledged the round it could not close"
PATH="$ROLL_BIN:$PATH" FM_HOME="$HROLL" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ROLL_ART" --for worker-8 \
  --agent-reply-file "$ROLL_ROOT/reply2" >/dev/null
wait_for_lines "$ROLL_ROOT/replies" 2 \
  || fail "the retried re-arm did not hand the board its generation's reply exactly once"
[ "$(grep -c 'generation two' "$ROLL_ROOT/replies" 2>/dev/null || true)" = 1 ] \
  || fail "the retried re-arm did not hand the board its generation's reply exactly once"
pass "a re-arm that cannot acknowledge its round leaves the running generation alone"

# --- end-user-aligned regression: re-arm is acknowledgement, nothing else -----
# The board is armed once and re-armed only to acknowledge a captured round. A
# worker that re-arms while its listener is still waiting would replace the
# generation carrying the reply it already handed over, and that reply would be
# swept away without ever reaching the board.
HREARM="$TMP_ROOT/hrearm"; new_home "$HREARM"
REARM_ROOT="$TMP_ROOT/lavish-rearm-root"; mkdir -p "$REARM_ROOT"; export REARM_ROOT
REARM_BIN=$(fm_fakebin "$TMP_ROOT/lavish-rearm-stub")
cat > "$REARM_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
[ "${1-}" != --version ] || { printf '0.1.79\n'; exit 0; }
[ "${3-}" != --agent-reply ] || printf '%s\n' "$4" >> "$REARM_ROOT/replies"
while [ ! -e "$REARM_ROOT/release" ]; do sleep 0.02; done
printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","one more round","","message",""\n'
SH
chmod +x "$REARM_BIN/lavish-axi"
REARM_ART="$TMP_ROOT/rearm-board.html"
printf '<h1>rearm</h1>\n' > "$REARM_ART"
lavish_session "$REARM_ART"
rearm_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$REARM_ART")
fm_test_track_procevent_home "$HREARM"
new_task_endpoint "$HREARM" worker-11
printf 'first generation reply\n' > "$REARM_ROOT/reply1"
printf 'second generation reply\n' > "$REARM_ROOT/reply2"
PATH="$REARM_BIN:$PATH" FM_HOME="$HREARM" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REARM_ART" --for worker-11 \
  --agent-reply-file "$REARM_ROOT/reply1" >/dev/null
[ -e "$HREARM/state/procevent/$rearm_id.source" ] \
  || fail "the initial arm of a worker-owned board did not register it"
if PATH="$REARM_BIN:$PATH" FM_HOME="$HREARM" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REARM_ART" --for worker-11 \
  --agent-reply-file "$REARM_ROOT/reply2" >/dev/null 2>"$REARM_ROOT/idle-rearm.err"; then
  fail "a worker re-armed its own board with no captured round to acknowledge"
fi
assert_contains "$(cat "$REARM_ROOT/idle-rearm.err")" "worker-11" \
  "the refused idle re-arm did not name the task that already holds the board"
touch "$REARM_ROOT/release"
PATH="$REARM_BIN:$PATH" pe "$HREARM" start "$rearm_id" >/dev/null 2>&1 || true
wait_for "$REARM_ROOT/replies" || fail "the listener never posted the reply it was armed with"
wait_for "$HREARM/state/procevent-inbox/$rearm_id.1.result" \
  || fail "the first worker-owned round never landed"
[ "$(grep -c 'first generation reply' "$REARM_ROOT/replies" 2>/dev/null || true)" = 1 ] \
  || fail "the refused idle re-arm cost the board the reply its listener was already carrying"
[ -f "$HREARM/state/procevent-inbox/$rearm_id.1.result" ] \
  || fail "the first worker-owned round never landed"
if PATH="$REARM_BIN:$PATH" FM_HOME="$HREARM" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REARM_ART" --for worker-11 \
  --agent-reply-file "$REARM_ROOT/never-written" >/dev/null 2>&1; then
  fail "a re-arm carrying a nonexistent reply path was accepted"
fi
[ ! -f "$HREARM/state/procevent-inbox/$rearm_id.1.handled" ] \
  || fail "a re-arm refused over its reply path still acknowledged the open round"
PATH="$REARM_BIN:$PATH" FM_HOME="$HREARM" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REARM_ART" --for worker-11 \
  --agent-reply-file "$REARM_ROOT/reply2" >/dev/null
[ -f "$HREARM/state/procevent-inbox/$rearm_id.1.handled" ] \
  || fail "re-arming over an open round did not acknowledge that round"
wait_for_lines "$REARM_ROOT/replies" 2 \
  || fail "the acknowledging re-arm did not hand the board its own generation's reply"
[ "$(grep -c 'second generation reply' "$REARM_ROOT/replies" 2>/dev/null || true)" = 1 ] \
  || fail "the acknowledging re-arm did not hand the board its own generation's reply"
pass "a worker-owned board is armed once and re-armed only to acknowledge an open round"

# The other half of the same contract, on the same real path: a close that
# carries what the captain actually said must still reach him. Same runner, same
# adapter, one different response shape.
HANSWER="$TMP_ROOT/hanswer"; new_home "$HANSWER"
ANSWER_BIN=$(fm_fakebin "$TMP_ROOT/lavish-answer-stub")
cat > "$ANSWER_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
# Stand-in for `lavish-axi poll <file>` on a real `Send & End`: the captain's
# own choice, delivered with session_ended.
printf 'session:\n  file: /answered.html\n  status: feedback\n  session_ended: true\n  ended_by: user\nprompts[1]{tag,text,prompt}:\n  "choice","Option B","Context data: {\\"question\\":\\"noop-check-routing\\",\\"answer\\":\\"b\\"}"\n'
SH
chmod +x "$ANSWER_BIN/lavish-axi"
ANSWER_ART="$TMP_ROOT/answered-board.html"
printf '<h1>answered</h1>\n' > "$ANSWER_ART"
lavish_session "$ANSWER_ART"
answer_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ANSWER_ART")
fm_test_track_procevent_home "$HANSWER"
PATH="$ANSWER_BIN:$PATH" FM_HOME="$HANSWER" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ANSWER_ART" >/dev/null
PATH="$ANSWER_BIN:$PATH" pe "$HANSWER" reconcile >/dev/null
wait_for "$HANSWER/state/.wake-queue" \
  || fail "a board close carrying the captain's real answer produced no wake"
assert_contains "$(wake_payloads "$HANSWER")" "procevent lavish $answer_id 1" \
  "a real board answer still reaches the captain"
[ ! -f "$HANSWER/state/procevent-inbox/$answer_id.1.handled" ] \
  || fail "a real board answer was recorded handled without ever being handled"
pass "a board close carrying the captain's real answer is still announced"

# --- end-user-aligned regression: a transient poll interruption is not news ---
# The dogfood defect: a live board listener can answer with exactly
#     error: Lavish Editor poll response was interrupted
#     code: SERVER_ERROR
# while the board's marks remain available. Firstmate registered raw poll output,
# so the generic runner captured that transient response and woke the whole fleet
# over what is really an internal retry. Every scenario below runs through the
# adapter's own arm command and the real runner, so registration, capture, and
# publication are exercised for real.
LAVISH_SCRIPTED_BIN=$(fm_fakebin "$TMP_ROOT/lavish-scripted-stub")
cat > "$LAVISH_SCRIPTED_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
# Stand-in for `lavish-axi poll <file>`, scripted per scenario: LAVISH_SCRIPT
# names the response for each successive poll, one word per poll, and its last
# word repeats forever. `interrupt` is the exact transient response the server
# returns while the board's marks stay available.
[ "${1-}" != --version ] || { printf '0.1.79\n'; exit 0; }
n=$(cat "$LAVISH_COUNT" 2>/dev/null || echo 0)
n=$((n + 1))
printf '%s\n' "$n" > "$LAVISH_COUNT"
for arg in "$@"; do
  case "$arg" in
    --agent-reply) ;;
    --*)
      printf 'error: unknown option %s\ncode: VALIDATION_ERROR\n' "$arg" >&2
      exit 2
      ;;
  esac
done
if [ -n "${LAVISH_REPLY_LOG-}" ] && [ "${1-}" = poll ] && [ "${3-}" = --agent-reply ]; then
  printf '%s\n' "$4" >> "$LAVISH_REPLY_LOG"
fi
read -r -a plan <<< "$LAVISH_SCRIPT"
i=$((n - 1))
[ "$i" -ge "${#plan[@]}" ] && i=$((${#plan[@]} - 1))
case "${plan[$i]}" in
  interrupt)
    printf 'error: Lavish Editor poll response was interrupted\ncode: SERVER_ERROR\n'; exit 1 ;;
  near-interrupt)
    printf 'error: Lavish Editor poll response was interrupted \ncode: SERVER_ERROR\n'; exit 1 ;;
  other-server-error)
    printf 'error: Lavish Editor session store is unavailable\ncode: SERVER_ERROR\n'; exit 1 ;;
  feedback)
    printf 'session:\n  file: /board.html\n  status: feedback\n  session_ended: true\n  ended_by: user\nfeedback[1]{text}:\n  ship it\n' ;;
  stream)
    printf 'x%.0s' {1..4096}
    printf 'ready\n' > "$LAVISH_STREAM_READY"
    while [ ! -e "$LAVISH_STREAM_RELEASE" ]; do sleep 0.05; done
    printf '\n' ;;
esac
SH
chmod +x "$LAVISH_SCRIPTED_BIN/lavish-axi"
export LAVISH_COUNT LAVISH_SCRIPT

DEFAULT_RATE_ART="$TMP_ROOT/default-rate-board.html"
printf '<h1>default rate</h1>\n' > "$DEFAULT_RATE_ART"
lavish_session "$DEFAULT_RATE_ART"
DEFAULT_RATE_COUNT="$TMP_ROOT/default-rate-count"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" LAVISH_COUNT="$DEFAULT_RATE_COUNT" LAVISH_SCRIPT=interrupt \
  FM_LAVISH_POLL_RETRY_DELAY='' \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$DEFAULT_RATE_ART" >/dev/null 2>&1 &
DEFAULT_RATE_PID=$!
perl -MTime::HiRes=sleep -e 'sleep 6.2'
kill -TERM "$DEFAULT_RATE_PID" 2>/dev/null || true
wait "$DEFAULT_RATE_PID" 2>/dev/null || true
default_rate_count=$(cat "$DEFAULT_RATE_COUNT" 2>/dev/null || echo 0)
[ "$default_rate_count" -ge 2 ] \
  || fail "the default poll governor stopped an instantly returning source from making progress"
[ "$default_rate_count" -le 2 ] \
  || fail "the shipped poll governor allowed $default_rate_count iterations in 6.2 seconds"
pass "the shipped poll governor bounds an instantly returning source"

# A bounded test override keeps the retry policy's real bound under test without
# making the suite wait out the production delay.
export FM_LAVISH_POLL_RETRY_DELAY=1

# Two interruptions, then the captain's real feedback: the retries are silent and
# only the feedback becomes a captured result and a check wake.
HRETRY="$TMP_ROOT/hretry"; new_home "$HRETRY"
RETRY_ART="$TMP_ROOT/retry-board.html"
printf '<h1>retry</h1>\n' > "$RETRY_ART"
lavish_session "$RETRY_ART"
retry_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$RETRY_ART")
fm_test_track_procevent_home "$HRETRY"
LAVISH_COUNT="$TMP_ROOT/retry-count"; LAVISH_SCRIPT="interrupt interrupt feedback"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HRETRY" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$RETRY_ART" >/dev/null
PATH="$LAVISH_SCRIPTED_BIN:$PATH" pe "$HRETRY" reconcile >/dev/null
wait_for "$HRETRY/state/.wake-queue" || fail "feedback after interrupted polls produced no wake"
[ "$(cat "$LAVISH_COUNT")" = 3 ] \
  || fail "the interrupted listener was polled $(cat "$LAVISH_COUNT") times, not the two quiet retries plus the delivering poll"
[ "$(count_results "$HRETRY" "$retry_id")" = 1 ] \
  || fail "a retried interruption produced $(count_results "$HRETRY" "$retry_id") captured results instead of one"
[ "$(wake_payloads "$HRETRY" | sort -u | grep -c .)" = 1 ] \
  || fail "a retried interruption woke the fleet: $(wake_payloads "$HRETRY" | sort -u)"
assert_contains "$(wake_payloads "$HRETRY")" "procevent lavish $retry_id 1" \
  "feedback arriving after quiet retries is captured and announced"
assert_grep 'ship it' "$(first_result "$HRETRY" "$retry_id")" \
  "the announced result is the captain's feedback, not the interruption"
pass "a transient Lavish poll interruption is retried quietly and never announced"

# --- end-user-aligned regression: a retried poll does not resubmit the reply ---
# The worker hands its round reply to the adapter once. When the first poll of
# that round comes back as the transient interruption, the adapter's own quiet
# retries must keep polling WITHOUT the reply, or the board receives the same
# worker message once per retry.
HREPLY="$TMP_ROOT/hreply"; new_home "$HREPLY"
REPLY_ART="$TMP_ROOT/reply-retry-board.html"
printf '<h1>reply retry</h1>\n' > "$REPLY_ART"
lavish_session "$REPLY_ART"
fm_test_track_procevent_home "$HREPLY"
new_task_endpoint "$HREPLY" worker-9
printf 'applied round one\n' > "$TMP_ROOT/reply-retry.txt"
LAVISH_REPLY_LOG="$TMP_ROOT/reply-retry-log"; export LAVISH_REPLY_LOG
LAVISH_COUNT="$TMP_ROOT/reply-retry-count"; LAVISH_SCRIPT="interrupt interrupt feedback"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HREPLY" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$REPLY_ART" --for worker-9 \
  --agent-reply-file "$TMP_ROOT/reply-retry.txt" >/dev/null
wait_for "$HREPLY/state/worker-9.inbox/001.msg" 200 \
  || fail "the round that delivered after quiet retries did not reach the worker inbox"
[ "$(cat "$LAVISH_COUNT")" = 3 ] \
  || fail "the reply-carrying listener was polled $(cat "$LAVISH_COUNT") times, not the two quiet retries plus the delivering poll"
[ "$(grep -c 'applied round one' "$LAVISH_REPLY_LOG" 2>/dev/null || true)" = 1 ] \
  || fail "the staged worker reply reached the board $(grep -c 'applied round one' "$LAVISH_REPLY_LOG" 2>/dev/null || true) times across the adapter's internal retries"
[ -f "$HREPLY/state/worker-9.inbox/001.msg" ] \
  || fail "the round that delivered after quiet retries did not reach the worker inbox"
unset LAVISH_REPLY_LOG
pass "a staged worker reply is handed to the board once across quiet poll retries"

# The other side of the same best-effort contract: posting a reply is allowed to
# lose it, so a listener that starts with no staged reply - because a crash
# consumed it, or because the round simply carries none - must still poll the
# board, with no reply and no refusal.
MISSING_REPLY_COUNT="$TMP_ROOT/missing-reply-count"
MISSING_REPLY_LOG="$TMP_ROOT/missing-reply-log"
missing_reply_status=0
PATH="$LAVISH_SCRIPTED_BIN:$PATH" LAVISH_COUNT="$MISSING_REPLY_COUNT" LAVISH_SCRIPT=feedback \
  LAVISH_REPLY_LOG="$MISSING_REPLY_LOG" \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$REPLY_ART" \
  --agent-reply-file "$TMP_ROOT/never-staged-reply" >/dev/null 2>&1 || missing_reply_status=$?
[ "$missing_reply_status" -eq 0 ] \
  || fail "a listener whose staged reply was gone refused to poll (status $missing_reply_status)"
[ "$(cat "$MISSING_REPLY_COUNT" 2>/dev/null || echo 0)" = 1 ] \
  || fail "a listener whose staged reply was gone never polled the board"
[ ! -s "$MISSING_REPLY_LOG" ] \
  || fail "a listener whose staged reply was gone still posted something: $(cat "$MISSING_REPLY_LOG")"
pass "a listener whose staged reply is gone polls the board without one"

# The accepted loss window is consuming-to-calling and nothing wider: a listener
# that never reaches the board at all must leave the staged reply for the next
# one. A malformed retry-delay override is one of the ordinary setup refusals
# that used to happen after the reply had already been consumed.
SETUP_GUARD_REPLY="$TMP_ROOT/setup-guard-reply"
SETUP_GUARD_COUNT="$TMP_ROOT/setup-guard-count"
printf 'kept for the next listener\n' > "$SETUP_GUARD_REPLY"
setup_guard_status=0
PATH="$LAVISH_SCRIPTED_BIN:$PATH" LAVISH_COUNT="$SETUP_GUARD_COUNT" LAVISH_SCRIPT=feedback \
  FM_LAVISH_POLL_RETRY_DELAY=not-a-number \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$REPLY_ART" \
  --agent-reply-file "$SETUP_GUARD_REPLY" >/dev/null 2>&1 || setup_guard_status=$?
[ "$setup_guard_status" -ne 0 ] \
  || fail "a malformed retry delay did not stop the listener before it polled"
[ "$(cat "$SETUP_GUARD_COUNT" 2>/dev/null || echo 0)" = 0 ] \
  || fail "a listener that refused its setup still reached the board"
[ -f "$SETUP_GUARD_REPLY" ] \
  || fail "a listener that never reached the board consumed its staged reply anyway"
pass "a listener that refuses its own setup leaves the staged reply for the next one"

# The board itself is part of that setup: an artifact that vanished between the
# re-arm and the listener's launch cannot be polled at all, so the reply it was
# carrying has to survive for the listener that polls the next one.
GONE_ART="$TMP_ROOT/artifact-gone-board.html"
GONE_REPLY="$TMP_ROOT/artifact-gone-reply"
GONE_COUNT="$TMP_ROOT/artifact-gone-count"
printf '<h1>gone</h1>\n' > "$GONE_ART"
lavish_session "$GONE_ART"
printf 'owed to the next listener\n' > "$GONE_REPLY"
rm -f "$GONE_ART"
gone_status=0
PATH="$LAVISH_SCRIPTED_BIN:$PATH" LAVISH_COUNT="$GONE_COUNT" LAVISH_SCRIPT=feedback \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$GONE_ART" \
  --agent-reply-file "$GONE_REPLY" >/dev/null 2>&1 || gone_status=$?
[ "$gone_status" -ne 0 ] \
  || fail "a listener whose artifact vanished reported a successful poll"
[ "$(cat "$GONE_COUNT" 2>/dev/null || echo 0)" = 0 ] \
  || fail "a listener whose artifact vanished still reached the board"
[ -f "$GONE_REPLY" ] \
  || fail "a listener whose artifact vanished consumed its staged reply anyway"
pass "a listener whose artifact vanished leaves the staged reply for the next one"

# Exhaustion is news: after the bounded retries the same exact response is
# captured and announced normally rather than being swallowed forever.
HEXH="$TMP_ROOT/hexh"; new_home "$HEXH"
EXH_ART="$TMP_ROOT/exhaust-board.html"
printf '<h1>exhaust</h1>\n' > "$EXH_ART"
lavish_session "$EXH_ART"
exh_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$EXH_ART")
fm_test_track_procevent_home "$HEXH"
LAVISH_COUNT="$TMP_ROOT/exhaust-count"; LAVISH_SCRIPT="interrupt"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HEXH" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$EXH_ART" >/dev/null
wait_capture "$HEXH" "$exh_id" 200 \
  || fail "exhaustion produced no captured result"
[ "$(cat "$LAVISH_COUNT")" = 13 ] \
  || fail "the retry bound polled $(cat "$LAVISH_COUNT") times, not the first poll plus 12 bounded retries"
[ "$(count_results "$HEXH" "$exh_id")" = 1 ] \
  || fail "exhaustion produced $(count_results "$HEXH" "$exh_id") captured results instead of one"
wait_for "$HEXH/state/.wake-queue" \
  || fail "the interruption that survives the bound produced no wake"
assert_contains "$(wake_payloads "$HEXH")" "procevent lavish $exh_id 1" \
  "the interruption that survives the bound is announced normally"
assert_grep 'poll response was interrupted' "$(first_result "$HEXH" "$exh_id")" \
  "the announced result is the exact interruption the server returned"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HEXH" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$EXH_ART" >/dev/null
pass "an interruption that outlives the bounded retries is captured and announced"

# A different SERVER_ERROR is a genuine error, never a retry: no fail-open drift
# from the one exact transient response this adapter owns.
HOTHER="$TMP_ROOT/hother"; new_home "$HOTHER"
OTHER_ART="$TMP_ROOT/other-board.html"
printf '<h1>other</h1>\n' > "$OTHER_ART"
lavish_session "$OTHER_ART"
other_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$OTHER_ART")
fm_test_track_procevent_home "$HOTHER"
LAVISH_COUNT="$TMP_ROOT/other-count"; LAVISH_SCRIPT="other-server-error"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HOTHER" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$OTHER_ART" >/dev/null
wait_for "$HOTHER/state/.wake-queue" \
  || fail "an unrelated SERVER_ERROR is captured and announced immediately"
[ "$(cat "$LAVISH_COUNT")" = 1 ] \
  || fail "an unrelated SERVER_ERROR was retried $(cat "$LAVISH_COUNT") times instead of surfacing at once"
assert_contains "$(wake_payloads "$HOTHER")" "procevent lavish $other_id 1" \
  "an unrelated SERVER_ERROR is captured and announced immediately"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HOTHER" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$OTHER_ART" >/dev/null
pass "only the exact interruption is retried; an unrelated SERVER_ERROR still surfaces"
unset FM_LAVISH_POLL_RETRY_DELAY

# A whitespace variant is not the exact transient response and must surface on
# the first poll instead of drifting into the quiet retry policy.
HNEAR="$TMP_ROOT/hnear"; new_home "$HNEAR"
NEAR_ART="$TMP_ROOT/near-board.html"
printf '<h1>near</h1>\n' > "$NEAR_ART"
lavish_session "$NEAR_ART"
near_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$NEAR_ART")
fm_test_track_procevent_home "$HNEAR"
LAVISH_COUNT="$TMP_ROOT/near-count"; LAVISH_SCRIPT="near-interrupt feedback"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HNEAR" FM_LAVISH_POLL_RETRY_DELAY=1 \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$NEAR_ART" >/dev/null
wait_for "$HNEAR/state/.wake-queue" \
  || fail "a whitespace variant of the interruption is captured and announced immediately"
[ "$(cat "$LAVISH_COUNT")" = 1 ] \
  || fail "a near-match interruption was retried instead of surfacing on its first poll"
assert_contains "$(wake_payloads "$HNEAR")" "procevent lavish $near_id 1" \
  "a whitespace variant of the interruption is captured and announced immediately"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HNEAR" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$NEAR_ART" >/dev/null
pass "only the literal two-line interruption enters the quiet retry policy"

# The public arm boundary refuses invalid retry intervals before it publishes a
# source registration, rather than arming a listener that can only fail later.
HINVALID="$TMP_ROOT/hinvalid"; new_home "$HINVALID"
INVALID_ART="$TMP_ROOT/invalid-delay-board.html"
printf '<h1>invalid delay</h1>\n' > "$INVALID_ART"
lavish_session "$INVALID_ART"
invalid_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$INVALID_ART")
for invalid_delay in 0 61 invalid; do
  invalid_status=0
  invalid_out=$(PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HINVALID" \
    FM_LAVISH_POLL_RETRY_DELAY="$invalid_delay" \
    "$ROOT/bin/fm-procevent-lavish.sh" arm "$INVALID_ART" 2>&1) || invalid_status=$?
  [ "$invalid_status" -ne 0 ] \
    || fail "arm accepted invalid retry delay: $invalid_delay"
  assert_contains "$invalid_out" "must be whole seconds from 1 to 60" \
    "arm explains the rejected retry delay"
  assert_absent "$HINVALID/state/procevent/$invalid_id.source" \
    "arm publishes no source registration for an invalid retry delay"
done
pass "arm rejects malformed and out-of-range retry delays before registration"

# Shell-safe cleanup must preserve a valid TMPDIR containing an apostrophe.
QUOTED_TMPDIR="$TMP_ROOT/poll's-stage"
mkdir -p "$QUOTED_TMPDIR"
LAVISH_COUNT="$TMP_ROOT/quoted-count"; LAVISH_SCRIPT="feedback"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" TMPDIR="$QUOTED_TMPDIR" \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$NEAR_ART" >/dev/null
quoted_staged=("$QUOTED_TMPDIR"/fm-lavish-poll.*)
[ ! -e "${quoted_staged[0]}" ] \
  || fail "poll left its staged response behind in an apostrophe-containing TMPDIR"
pass "poll cleanup safely handles an apostrophe-containing TMPDIR"

HSTREAM="$TMP_ROOT/hstream"; new_home "$HSTREAM"
STREAM_ART="$TMP_ROOT/stream-board.html"
STREAM_TMPDIR="$TMP_ROOT/stream-stage"
LAVISH_STREAM_READY="$TMP_ROOT/stream-ready"
LAVISH_STREAM_RELEASE="$TMP_ROOT/stream-release"
mkdir -p "$STREAM_TMPDIR"
printf '<h1>stream</h1>\n' > "$STREAM_ART"
lavish_session "$STREAM_ART"
stream_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$STREAM_ART")
fm_test_track_procevent_home "$HSTREAM"
LAVISH_COUNT="$TMP_ROOT/stream-count"; LAVISH_SCRIPT="stream"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HSTREAM" TMPDIR="$STREAM_TMPDIR" \
  LAVISH_STREAM_READY="$LAVISH_STREAM_READY" LAVISH_STREAM_RELEASE="$LAVISH_STREAM_RELEASE" \
  FM_PROCEVENT_MAX_OUTPUT_BYTES=100 \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$STREAM_ART" >/dev/null
wait_for "$LAVISH_STREAM_READY" || fail "streaming poll did not start"
stream_staged=("$STREAM_TMPDIR"/fm-lavish-poll.*)
[ -e "${stream_staged[0]}" ] || fail "streaming poll created no classifier staging file"
[ "$(wc -c < "${stream_staged[0]}" | tr -d ' ')" -le 100 ] \
  || fail "streaming poll exceeded its bounded classifier staging"
: > "$LAVISH_STREAM_RELEASE"
wait_for "$HSTREAM/state/.wake-queue" || fail "streaming poll produced no wake"
stream_result=$(first_result "$HSTREAM" "$stream_id" || true)
[ "$(wc -c < "$stream_result" | tr -d ' ')" -le 100 ] \
  || fail "streaming poll bypassed the runner output bound"
PATH="$LAVISH_SCRIPTED_BIN:$PATH" FM_HOME="$HSTREAM" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$STREAM_ART" >/dev/null
pass "Lavish classification staging stays bounded while nonmatches stream"

# --- end-user-aligned regression: the exact drain-before-handling restart cut
# Reproduces the confirmed defect through the public interface end to end: a
# real blocking source completes, its result is captured and published, the
# wake is drained without any handling, a replacement session's reconcile must
# resurface the exact same source and sequence, and only the owned handling
# interface may retire it - safely and without ever authorizing a paired
# effect a second time.
HW="$TMP_ROOT/hw"; new_home "$HW"
TRIGW="$TMP_ROOT/trigger-restart-cut"
pe_register "$HW" lavish restart-cut-src -- "$BLOCKER" "$TRIGW" "restart cut payload" >/dev/null
pe "$HW" start restart-cut-src > "$TMP_ROOT/restart-cut-start.log" 2>&1 &
restart_cut_start_pid=$!
sleep 0.5
: > "$TRIGW"
wait_for "$HW/state/.wake-queue" || fail "the restart-cut source published no event"
assert_contains "$(wake_payloads "$HW")" "procevent lavish restart-cut-src 1" \
  "capture and publish reaches the wake queue before any handling"

# Retire the registration now that the source has completed and captured its
# one result. The fixture's trigger file persists on disk, so a still-armed
# registration would let every further reconcile call restart the blocker and
# capture a fresh generation; retiring leaves only the durable inbox and wake
# state under test, matching the exact restart cut - the source side is done,
# only the handling side is still open.
# Publication precedes runner exit; wait for completion before retiring.
wait "$restart_cut_start_pid" || fail "the restart-cut source did not complete"
pe "$HW" retire restart-cut-src >/dev/null \
  || fail "the restart-cut registration was not retired"

# Drain the wake without handling it: the end-user experience of a session
# reading the wake queue at turn end without yet acting on this specific line.
mv "$HW/state/.wake-queue" "$HW/state/.wake-queue.drained-unhandled"
[ -z "$(wake_payloads "$HW")" ] || fail "the wake queue was not actually drained"

# Simulate a replacement Firstmate session: reconcile runs cold, as it would on
# a fresh process with no memory of the prior turn.
out=$(pe "$HW" reconcile)
assert_contains "$out" "published=1" \
  "a replacement session's reconcile resurfaces a drained-but-unhandled result"
assert_contains "$(wake_payloads "$HW")" "procevent lavish restart-cut-src 1" \
  "the exact same captured source and sequence resurfaces, never a substitute"

# Acknowledge handling through the owned interface.
ack_out=$(pe "$HW" handled restart-cut-src 1)
assert_contains "$ack_out" "handled: restart-cut-src 1" \
  "the first acknowledgement newly authorizes the paired effect"

mv "$HW/state/.wake-queue" "$HW/state/.wake-queue.post-handle"
out=$(pe "$HW" reconcile)
assert_contains "$out" "published=0" \
  "a later reconcile does not resurface a result once it is durably handled"
[ -z "$(wake_payloads "$HW")" ] || fail "a handled result was announced again: $(wake_payloads "$HW")"

auth_count=0
for _ in 1 2 3; do
  repeat_ack=$(pe "$HW" handled restart-cut-src 1)
  assert_contains "$repeat_ack" "already-handled: restart-cut-src 1" "repeated acknowledgement stays safe and idempotent"
  case "$repeat_ack" in handled:*) auth_count=$((auth_count + 1)) ;; esac
done
[ "$auth_count" -eq 0 ] || fail "a result already durably handled was authorized again: count=$auth_count"
pass "a drained-but-unhandled result survives a replacement session and is retired only by explicit handling, never twice"

HP="$TMP_ROOT/hp"; new_home "$HP"
mkdir -p "$HP/state/procevent-inbox"
for seq in 10 2 1; do
  printf '%s\n' "$seq" > "$HP/state/procevent-inbox/ordered-src.$seq.result"
  printf 'lavish\n' > "$HP/state/procevent-inbox/ordered-src.$seq.adapter"
  chmod 0600 "$HP/state/procevent-inbox/ordered-src.$seq.result" "$HP/state/procevent-inbox/ordered-src.$seq.adapter"
done
pending=$(bash -c '. "$1/bin/fm-procevent-lib.sh"; fm_procevent_pending "$2"' _ "$ROOT" "$HP/state")
expected=$(printf '%s\n' \
  "$HP/state/procevent-inbox/ordered-src.1.result" \
  "$HP/state/procevent-inbox/ordered-src.2.result" \
  "$HP/state/procevent-inbox/ordered-src.10.result")
[ "$pending" = "$expected" ] || fail "pending results were not emitted in numeric sequence order: $pending"
pe "$HP" reconcile >/dev/null
deduped=$(FM_HOME="$HP" bash -c '
  . "$1/bin/fm-wake-lib.sh"
  fm_wake_print_deduped "$2/state/.wake-queue" | awk -F "\t" "{print \$5}"
' _ "$ROOT" "$HP")
expected=$(printf '%s\n' \
  'check: procevent lavish ordered-src 1' \
  'check: procevent lavish ordered-src 2' \
  'check: procevent lavish ordered-src 10')
[ "$deduped" = "$expected" ] || fail "distinct result generations were coalesced or reordered: $deduped"
pass "pending results preserve numeric order and distinct wake identity"

# --- two homes cannot both own one canonical source -------------------------
HA="$TMP_ROOT/ha"; HB="$TMP_ROOT/hb"; new_home "$HA"; new_home "$HB"
TRIG2="$TMP_ROOT/trigger-two"
pe_register "$HA" lavish shared-src -- "$BLOCKER" "$TRIG2" "shared" >/dev/null
pe_register "$HB" lavish shared-src -- "$BLOCKER" "$TRIG2" "shared" >/dev/null
pe "$HA" reconcile >/dev/null
sleep 0.5
out=$(pe "$HB" start shared-src)
assert_contains "$out" "already owned" "a second home cannot own a source another home already owns"
[ -z "$(wake_payloads "$HB")" ] || fail "the losing home published an event"
pass "one owner per canonical source across homes"

# A source whose child never completes must not survive retirement. This is the
# leak that reparented four orphaned runners: the fixture directory was removed
# while the detached child kept blocking, with nothing left to reap it.
runner_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/shared-src.claim" 2>/dev/null)
[ -n "$runner_pid" ] || fail "no runner pid recorded for the blocked source"
kill -0 "$runner_pid" 2>/dev/null || fail "the blocked runner is not live before retirement"
pe "$HA" retire shared-src >/dev/null
for _ in $(seq 1 40); do kill -0 "$runner_pid" 2>/dev/null || break; sleep 0.1; done
kill -0 "$runner_pid" 2>/dev/null && fail "retire left the blocked runner alive"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/shared-src.claim" "retire releases the claim"
pass "retiring a never-completing source stops its runner and its blocked child"

# reconcile must also stop a runner whose registration was removed out from under
# it. The input is a runner already blocked inside its source command, so wait for
# the start marker rather than a settle window: a runner still short of that
# command retires itself when the registration disappears, which on a loaded host
# turns this into a test of the other outcome and reports uncertain=1.
TRIG4="$TMP_ROOT/trigger-four"
ORPHAN_STARTED="$TMP_ROOT/orphan-src.started"
HZ="$TMP_ROOT/hz"; new_home "$HZ"
pe_register "$HZ" lavish orphan-src \
  -- "$STARTED_BLOCKER" "$ORPHAN_STARTED" "$BLOCKER" "$TRIG4" "orphan" >/dev/null
pe "$HZ" reconcile >/dev/null
wait_for "$ORPHAN_STARTED" || fail "the orphan fixture runner never entered its source command"
orphan_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/orphan-src.claim" 2>/dev/null)
if [ -z "$orphan_pid" ] || ! kill -0 "$orphan_pid" 2>/dev/null; then
  fail "orphan fixture runner did not start"
fi
rm -f "$HZ/state/procevent/orphan-src.source"
out=$(pe "$HZ" reconcile)
assert_contains "$out" "stopped=1" "reconcile stops a runner whose registration was removed"
for _ in $(seq 1 40); do kill -0 "$orphan_pid" 2>/dev/null || break; sleep 0.1; done
kill -0 "$orphan_pid" 2>/dev/null && fail "reconcile left an orphaned runner alive"
pass "reconcile reaps a runner whose source registration is gone"

# --- a stale claim is reclaimable, a live one is not ------------------------
CLAIM="$FM_PROCEVENT_CLAIM_ROOT/stale-src.claim"
mkdir -p "$FM_PROCEVENT_CLAIM_ROOT"
HC="$TMP_ROOT/hc"; new_home "$HC"
printf '%s\n%s\nstale-token\nstale-identity\n' "$HC" "999999" > "$CLAIM"
chmod 0600 "$CLAIM"
pe_register "$HC" lavish stale-src -- /bin/echo recovered >/dev/null
printf 'partial sensitive output\n' > "$HC/state/procevent/.stale-src.stale-token.output"
chmod 0600 "$HC/state/procevent/.stale-src.stale-token.output"
out=$(pe "$HC" start stale-src)
assert_contains "$out" "captured:" "a claim whose runner is gone is reclaimable"
assert_absent "$CLAIM" "the replacement claim generation is released after completion"
assert_absent "$HC/state/procevent/.stale-src.stale-token.output" "stale claim recovery removes its abandoned staging generation"
pass "stale-owner recovery removes abandoned output without displacing a live owner"

HC_OLD="$TMP_ROOT/hc-old"; new_home "$HC_OLD"
HC_NEW="$TMP_ROOT/hc-new"; new_home "$HC_NEW"
HC_OLD_STATE="$TMP_ROOT/hc-old-state"
mkdir -p "$HC_OLD_STATE/procevent"
printf '%s\n%s\ncross-home-token\ncross-home-identity\n%s\n' \
  "$HC_OLD" "999999" "$HC_OLD_STATE/procevent" > "$FM_PROCEVENT_CLAIM_ROOT/cross-home-src.claim"
chmod 0600 "$FM_PROCEVENT_CLAIM_ROOT/cross-home-src.claim"
printf 'partial cross-home output\n' > "$HC_OLD_STATE/procevent/.cross-home-src.cross-home-token.output"
chmod 0600 "$HC_OLD_STATE/procevent/.cross-home-src.cross-home-token.output"
pe_register "$HC_NEW" lavish cross-home-src -- /bin/echo recovered >/dev/null
out=$(pe "$HC_NEW" start cross-home-src)
assert_contains "$out" "captured:" "a second home can replace a stale source owner"
assert_absent "$HC_OLD_STATE/procevent/.cross-home-src.cross-home-token.output" "cross-home reclaim removes the old generation's recorded staging file"
pass "cross-home stale recovery removes abandoned output from the old state directory"

HR="$TMP_ROOT/hr"; new_home "$HR"
RACE_TRIGGER="$TMP_ROOT/race-trigger"
RACE_LOG="$TMP_ROOT/race-executions"
RACE_BLOCKER="$TMP_ROOT/race-blocker.sh"
cat > "$RACE_BLOCKER" <<'SH'
#!/usr/bin/env bash
printf 'started\n' >> "$1"
while [ ! -e "$2" ]; do sleep 0.05; done
printf 'race result\n'
SH
chmod +x "$RACE_BLOCKER"
pe_register "$HR" lavish race-src -- "$RACE_BLOCKER" "$RACE_LOG" "$RACE_TRIGGER" >/dev/null
printf '%s\n%s\nold-token\nold-identity\n' "$TMP_ROOT/gone-home" 999999 > "$FM_PROCEVENT_CLAIM_ROOT/race-src.claim"
chmod 0600 "$FM_PROCEVENT_CLAIM_ROOT/race-src.claim"
race_pids=()
for _ in $(seq 1 24); do
  pe "$HR" start race-src >/dev/null &
  race_pids+=("$!")
done
wait_for "$RACE_LOG" 300 || fail "no contender acquired the stale claim"
sleep 0.5
[ "$(wc -l < "$RACE_LOG" | tr -d ' ')" = 1 ] || fail "stale-claim race started more than one runner"
: > "$RACE_TRIGGER"
for race_pid in "${race_pids[@]}"; do wait "$race_pid" 2>/dev/null || true; done
pass "concurrent stale-claim replacement starts exactly one runner"

# --- a crashed runner leader must not make its live child group look stale ---
# The runner is its own process group leader, so SIGKILL on the leader alone
# leaves the blocking source child running in that group. Classifying the
# missing leader as stale would release ownership and start a second poller
# against one canonical source, which for a destructive source means two
# concurrent long polls racing on the same session. The surviving group must be
# stopped before ownership can move.
HG="$TMP_ROOT/hg"; new_home "$HG"
ORPHAN_TRIGGER="$TMP_ROOT/orphan-trigger"
ORPHAN_LOG="$TMP_ROOT/orphan-executions"
ORPHAN_GROUP="$TMP_ROOT/orphan-group"
ORPHAN_OVERLAP="$TMP_ROOT/orphan-overlap"
ORPHAN_BLOCKER="$TMP_ROOT/orphan-blocker.sh"
cat > "$ORPHAN_BLOCKER" <<'SH'
#!/usr/bin/env bash
printf 'started\n' >> "$1"
if [ -s "$3" ]; then
  IFS= read -r old_group < "$3"
  if kill -0 "-$old_group" 2>/dev/null; then
    printf 'overlap\n' > "$4"
  fi
fi
while [ ! -e "$2" ]; do sleep 0.05; done
printf 'orphan result\n'
SH
chmod +x "$ORPHAN_BLOCKER"
pe_register "$HG" lavish orphan-src -- \
  "$ORPHAN_BLOCKER" "$ORPHAN_LOG" "$ORPHAN_TRIGGER" "$ORPHAN_GROUP" "$ORPHAN_OVERLAP" >/dev/null
pe "$HG" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/orphan-src.claim" || fail "leader-crash fixture never claimed its source"
wait_for "$ORPHAN_LOG" || fail "leader-crash fixture source never started"
orphan_leader=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/orphan-src.claim")
case "$orphan_leader" in ''|*[!0-9]*) fail "could not read the runner leader pid: $orphan_leader" ;; esac
printf '%s\n' "$orphan_leader" > "$ORPHAN_GROUP"

kill -KILL "$orphan_leader" 2>/dev/null || fail "could not kill the runner leader"
for _ in $(seq 1 50); do kill -0 "$orphan_leader" 2>/dev/null || break; sleep 0.1; done
kill -0 "$orphan_leader" 2>/dev/null && fail "the runner leader survived SIGKILL"
kill -0 -"$orphan_leader" 2>/dev/null || fail "fixture invalid: the owned child group did not survive the leader"

orphan_out=$(pe "$HG" reconcile)
kill -0 -"$orphan_leader" 2>/dev/null \
  || fail "reconcile signalled an ambiguous leaderless process group: $orphan_out"
assert_contains "$orphan_out" "started=0" \
  "reconcile does not replace an ambiguous leaderless generation"
[ -e "$FM_PROCEVENT_CLAIM_ROOT/orphan-src.claim" ] \
  || fail "refusing ambiguous cleanup must preserve the claim"
[ "$(wc -l < "$ORPHAN_LOG" | tr -d ' ')" = 1 ] \
  || fail "reconcile started a source beside an ambiguous leaderless group"
assert_absent "$ORPHAN_OVERLAP" "no replacement source starts while the leaderless group remains"
# This is the ordinary crash shape, and it is refused permanently: `orphaned`
# in a listing and `uncertain=1` in output the supervision cycle discards
# reach nobody, so the strand has to announce itself durably, exactly once,
# under a key the watcher can tell apart from a captured result.
orphan_token=$(sed -n '3p' "$FM_PROCEVENT_CLAIM_ROOT/orphan-src.claim")
[ -n "$orphan_token" ] || fail "could not read the leaderless claim's token"
[ "$(stranded_wake_count "$HG" orphan-src)" = 1 ] \
  || fail "reconcile stranded a leaderless source without announcing it: $orphan_out"
[ "$(stranded_wake_keys "$HG" orphan-src)" = "procevent:orphan-src:stranded:$orphan_token" ] \
  || fail "the stranded wake is not keyed by source and claim generation: $(stranded_wake_keys "$HG" orphan-src)"
orphan_wake=$(stranded_wake_payloads "$HG" orphan-src)
assert_contains "$orphan_wake" "orphan-src" \
  "the leaderless stranded wake does not name the source it is about: $orphan_wake"
assert_contains "$orphan_wake" "polling" \
  "the leaderless stranded wake does not say what a human should check: $orphan_wake"
# `start` reports this claim as owned and reclaims nothing, so a wake that
# named it as the clearing command would send someone to a no-op.
case "$orphan_wake" in
  *"start orphan-src"*) fail "the leaderless stranded wake names start as clearing it: $orphan_wake" ;;
esac
orphan_start=$(pe "$HG" start orphan-src 2>&1)
assert_contains "$orphan_start" "already owned" \
  "start displaced a leaderless group's claim: $orphan_start"
[ "$(wc -l < "$ORPHAN_LOG" | tr -d ' ')" = 1 ] \
  || fail "start ran the source beside an ambiguous leaderless group"
orphan_again=$(pe "$HG" reconcile)
assert_contains "$orphan_again" "started=0" \
  "the second cycle replaced an ambiguous leaderless generation: $orphan_again"
assert_contains "$orphan_again" "uncertain=1" \
  "the second cycle stopped reporting the claim it could not settle: $orphan_again"
[ "$(stranded_wake_count "$HG" orphan-src)" = 1 ] \
  || fail "reconcile re-announced the same leaderless strand: $orphan_again"
[ "$(wc -l < "$ORPHAN_LOG" | tr -d ' ')" = 1 ] \
  || fail "the second cycle started a source beside an ambiguous leaderless group"
kill -0 -"$orphan_leader" 2>/dev/null \
  || fail "announcing the strand signalled the leaderless process group"
kill -KILL -"$orphan_leader" 2>/dev/null || true
for _ in $(seq 1 50); do kill -0 -"$orphan_leader" 2>/dev/null || break; sleep 0.1; done
kill -0 -"$orphan_leader" 2>/dev/null && fail "could not clean up the leaderless fixture group"
pe "$HG" retire orphan-src >/dev/null
pass "an ambiguous leaderless group is preserved without replacement"

# Counterexample: a genuinely dead generation - no leader and no surviving
# group - must still be reclaimable, or crash recovery would deadlock.
HG2="$TMP_ROOT/hg2"; new_home "$HG2"
DEAD_TRIGGER="$TMP_ROOT/dead-gen-trigger"
DEAD_LOG="$TMP_ROOT/dead-gen-executions"
pe_register "$HG2" lavish dead-gen-src -- "$RACE_BLOCKER" "$DEAD_LOG" "$DEAD_TRIGGER" >/dev/null
printf '%s\n%s\ndead-token\ndead-identity\n%s\n' "$HG2" 999999 "$HG2/state/procevent" \
  > "$FM_PROCEVENT_CLAIM_ROOT/dead-gen-src.claim"
chmod 0600 "$FM_PROCEVENT_CLAIM_ROOT/dead-gen-src.claim"
dead_out=$(pe "$HG2" reconcile)
assert_contains "$dead_out" "started=1" "a generation with no leader and no group is still reclaimable"
wait_for "$DEAD_LOG" || fail "the replacement source never started for a truly dead generation"
: > "$DEAD_TRIGGER"
pe "$HG2" retire dead-gen-src >/dev/null
pass "a truly dead generation with no surviving group is still safely reclaimed"

# --- a dead generation stays reclaimable when the state root cannot be
# revalidated -----------------------------------------------------------------
# The reported wedge. Reclaiming a dead generation ran the claim's
# capture-reservation cleanup first, and that cleanup re-verifies the recorded
# state-root identity. Once that identity stopped matching, a claim naming a pid
# and a process group that were both provably gone could not be cleared:
# reconcile kept reporting a start while nothing ever attached, and retire
# refused with "cannot release source ownership". Reservation records are keyed
# by claim token and a replacement always claims a fresh one, so they can never
# collide with the generation that replaces them - they are hygiene, not an
# ownership invariant, and they must not veto an ownership move that the
# documented promise already grants.
#
# The claim below is the modern shape (it carries the state-root identity block
# a legacy claim does not have), which is why the existing dead-generation case
# above never reached this path.
HSR="$TMP_ROOT/hsr"; new_home "$HSR"
SR_TRIGGER="$TMP_ROOT/state-root-trigger"
SR_LOG="$TMP_ROOT/state-root-executions"
pe_register "$HSR" lavish state-root-src -- "$RACE_BLOCKER" "$SR_LOG" "$SR_TRIGGER" >/dev/null
pe "$HSR" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/state-root-src.claim" \
  || fail "state-root fixture never claimed its source"
wait_for "$SR_LOG" || fail "state-root fixture source never started"
sr_leader=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/state-root-src.claim")
case "$sr_leader" in ''|*[!0-9]*) fail "could not read the state-root fixture leader pid" ;; esac
[ -n "$(sed -n '8p' "$FM_PROCEVENT_CLAIM_ROOT/state-root-src.claim")" ] \
  || fail "fixture invalid: the claim carries no state-root identity to invalidate"

kill -KILL -"$sr_leader" 2>/dev/null || true
kill -KILL "$sr_leader" 2>/dev/null || true
for _ in $(seq 1 50); do kill -0 -"$sr_leader" 2>/dev/null || break; sleep 0.1; done
kill -0 "$sr_leader" 2>/dev/null && fail "the state-root fixture leader survived SIGKILL"
kill -0 -"$sr_leader" 2>/dev/null && fail "fixture invalid: the owned group outlived the whole generation"
# Drift the live state root away from what the claim recorded.
chmod 750 "$HSR/state" || fail "could not drift the state-root identity"

sr_out=$(pe "$HSR" reconcile)
assert_contains "$sr_out" "started=1" "a dead generation was not reclaimed after the state root drifted: $sr_out"
# Reporting a start is not the same fact as listening: the previous behavior
# reported exactly this while the replacement silently failed to claim.
wait_for_lines "$SR_LOG" 2 \
  || fail "reconcile reported a start but no replacement source ever ran: $(cat "$SR_LOG")"
sr_new=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/state-root-src.claim")
[ "$sr_new" != "$sr_leader" ] || fail "the dead generation's claim was never replaced"
kill -0 "$sr_new" 2>/dev/null || fail "the replacement runner did not take ownership"
: > "$SR_TRIGGER"
pe "$HSR" retire state-root-src >/dev/null
pass "reconcile reclaims a dead generation whose state-root identity no longer matches"

# Retire must release the same wedged claim rather than refusing forever.
HSR2="$TMP_ROOT/hsr2"; new_home "$HSR2"
pe_register "$HSR2" lavish wedged-src -- /bin/echo recovered >/dev/null
sr2_identity=$(bash -c '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_identity "$2"' _ \
  "$ROOT" "$HSR2/state/procevent/wedged-src.source") \
  || fail "could not read the wedged fixture registration identity"
{
  printf '%s\n%s\nwedged-token\nwedged-identity\n' "$HSR2" 999999
  printf '%s\n%s\nactive\n' "$HSR2/state/procevent" "$sr2_identity"
  # A state-root identity that names the right directory with the wrong inode:
  # exactly what a claim recorded before its home was re-created looks like.
  printf '%s\n%s\n%s\n%s\n%s\n' "$HSR2/state" 1 1 "$(id -u)" 755
} > "$FM_PROCEVENT_CLAIM_ROOT/wedged-src.claim"
chmod 0600 "$FM_PROCEVENT_CLAIM_ROOT/wedged-src.claim"
wedged_out=$(pe "$HSR2" retire wedged-src 2>&1) \
  || fail "retire refused to release a claim whose whole generation is gone: $wedged_out"
assert_contains "$wedged_out" "retired: wedged-src" "retire did not report releasing the wedged source: $wedged_out"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/wedged-src.claim" "retire left the dead generation owning the source"
assert_absent "$HSR2/state/procevent/wedged-src.source" "retire left the wedged source registered"
pass "retire releases a dead generation's claim instead of refusing forever"

# The guard is not weakened in the other direction: the same unrevalidatable
# state root must NOT let anything take a source away from a live generation.
HSR3="$TMP_ROOT/hsr3"; new_home "$HSR3"
SR3_TRIGGER="$TMP_ROOT/state-root-live-trigger"
SR3_LOG="$TMP_ROOT/state-root-live-executions"
pe_register "$HSR3" lavish live-drift-src -- "$RACE_BLOCKER" "$SR3_LOG" "$SR3_TRIGGER" >/dev/null
pe "$HSR3" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/live-drift-src.claim" \
  || fail "live-drift fixture never claimed its source"
wait_for "$SR3_LOG" || fail "live-drift fixture source never started"
sr3_leader=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/live-drift-src.claim")
chmod 750 "$HSR3/state" || fail "could not drift the live owner's state-root identity"
sr3_out=$(pe "$HSR3" start live-drift-src)
assert_contains "$sr3_out" "already owned" "a live generation was displaced after its state root drifted: $sr3_out"
[ "$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/live-drift-src.claim")" = "$sr3_leader" ] \
  || fail "the live generation's claim was replaced"
kill -0 "$sr3_leader" 2>/dev/null || fail "the live owner was killed by a reclaim attempt"
sr3_reconcile=$(pe "$HSR3" reconcile)
assert_contains "$sr3_reconcile" "started=0" "reconcile started a second poller beside a live owner: $sr3_reconcile"
[ "$(wc -l < "$SR3_LOG" | tr -d ' ')" = 1 ] \
  || fail "a second source ran beside the live owner: $(cat "$SR3_LOG")"
: > "$SR3_TRIGGER"
pe "$HSR3" retire live-drift-src >/dev/null
pass "a live generation is never reclaimed, drifted state root or not"

HSR4="$TMP_ROOT/hsr4"; new_home "$HSR4"
SR4_TRIGGER="$TMP_ROOT/state-root-reused-trigger"
SR4_LOG="$TMP_ROOT/state-root-reused-executions"
pe_register "$HSR4" lavish reused-group-src -- "$RACE_BLOCKER" "$SR4_LOG" "$SR4_TRIGGER" >/dev/null
pe "$HSR4" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/reused-group-src.claim" \
  || fail "reused-group fixture never claimed its source"
wait_for "$SR4_LOG" || fail "reused-group fixture source never started"
sr4_claim="$FM_PROCEVENT_CLAIM_ROOT/reused-group-src.claim"
sr4_leader=$(sed -n '2p' "$sr4_claim")
sr4_identity=$(sed -n '4p' "$sr4_claim")
kill -0 -"$sr4_leader" 2>/dev/null \
  || fail "fixture invalid: the reused-pid process group is not alive"
awk 'NR == 4 { print "different-live-process-identity"; next } { print }' \
  "$sr4_claim" > "$sr4_claim.tmp" && mv "$sr4_claim.tmp" "$sr4_claim"
chmod 0600 "$sr4_claim"
chmod 750 "$HSR4/state" || fail "could not drift the reused-group state root"
sr4_out=$(pe "$HSR4" reconcile)
sleep 0.5
[ "$(wc -l < "$SR4_LOG" | tr -d ' ')" = 1 ] \
  || fail "reconcile started a replacement beside a reused pid's live group: $sr4_out"
# Ownership cannot move here by design, so a replacement could only die on the
# claim it cannot take - once per reconcile cycle, forever.
assert_contains "$sr4_out" "started=0" \
  "reconcile reported a start into a claim nothing can take: $sr4_out"
assert_contains "$sr4_out" "uncertain=1" \
  "reconcile did not report the claim it could not settle: $sr4_out"
[ "$(sed -n '2p' "$sr4_claim")" = "$sr4_leader" ] \
  || fail "reconcile replaced the reused-pid generation's claim"
# Nothing can take this source, so reporting it as unowned reads like an idle
# source waiting to be started - the reassuring answer this surface gave while a
# review board collected nothing.
sr4_owner=$(pe "$HSR4" list | awk '$1 == "reused-group-src" { print $3 }')
[ "$sr4_owner" = orphaned ] \
  || fail "a source no caller can claim is listed as '$sr4_owner'"
# `orphaned` in a listing and `uncertain=1` in output the supervision cycle
# discards reach nobody. The strand has to announce itself durably, exactly
# once, and say which command clears it.
[ "$(stranded_wake_count "$HSR4" reused-group-src)" = 1 ] \
  || fail "reconcile stranded a source without announcing it: $sr4_out"
# The key carries the source and its claim generation in a shape the watcher
# can tell apart from a captured result, so the strand is never headlined as one.
[ "$(stranded_wake_keys "$HSR4" reused-group-src)" = "procevent:reused-group-src:stranded:$(sed -n '3p' "$sr4_claim")" ] \
  || fail "the stranded wake is not keyed by source and claim generation: $(stranded_wake_keys "$HSR4" reused-group-src)"
sr4_wake=$(stranded_wake_payloads "$HSR4" reused-group-src)
assert_contains "$sr4_wake" "reused-group-src" \
  "the stranded wake does not name the source it is about: $sr4_wake"
assert_contains "$sr4_wake" "bin/fm-procevent.sh start reused-group-src" \
  "the stranded wake does not name the command that clears it: $sr4_wake"
# A wake nobody can silence is as unusable as one nobody gets: the same stranded
# generation must not re-announce on every supervision cycle.
sr4_again=$(pe "$HSR4" reconcile)
assert_contains "$sr4_again" "uncertain=1" \
  "the second cycle stopped reporting the claim it could not settle: $sr4_again"
[ "$(stranded_wake_count "$HSR4" reused-group-src)" = 1 ] \
  || fail "reconcile re-announced the same stranded generation: $sr4_again"
[ "$(wc -l < "$SR4_LOG" | tr -d ' ')" = 1 ] \
  || fail "the second cycle started a replacement beside a reused pid's live group: $sr4_again"
# The wake names `start` as the recovery, so run it against the state it will
# actually meet. The earlier end-to-end demonstration of that command used an
# UNDRIFTED fixture and therefore proved only the easy case; on this one the
# state root has drifted, so the dead generation's reservation records cannot
# be tidied, and the claim path waives that tidy-up only for a generation
# proven gone - which a surviving group is not. `start` must refuse here, keep
# the claim, and start no second source beside the live group, and the wake
# must have said so rather than promising a reclaim.
assert_contains "$sr4_wake" "cannot claim source" \
  "the stranded wake promises an unconditional reclaim: $sr4_wake"
set +e
sr4_start=$(pe "$HSR4" start reused-group-src 2>&1)
sr4_start_rc=$?
set -e
[ "$sr4_start_rc" -ne 0 ] \
  || fail "start reported success against a claim it could not tidy: $sr4_start"
assert_contains "$sr4_start" "cannot claim source" \
  "start did not refuse by name on the drifted reused-pid fixture: $sr4_start"
[ "$(sed -n '2p' "$sr4_claim")" = "$sr4_leader" ] \
  || fail "a refused start replaced the reused-pid generation's claim"
sleep 0.3
[ "$(wc -l < "$SR4_LOG" | tr -d ' ')" = 1 ] \
  || fail "a refused start ran a second source beside a reused pid's live group: $(cat "$SR4_LOG")"
set +e
sr4_retire=$(pe "$HSR4" retire reused-group-src 2>&1)
sr4_rc=$?
set -e
[ "$sr4_rc" -ne 0 ] || fail "retire released a claim whose process group survives: $sr4_retire"
[ -e "$sr4_claim" ] || fail "retire removed the reused-pid generation's claim"
[ -e "$HSR4/state/procevent/reused-group-src.source" ] \
  || fail "retire removed the reused-pid generation's registration"
awk -v identity="$sr4_identity" 'NR == 4 { print identity; next } { print }' \
  "$sr4_claim" > "$sr4_claim.tmp" && mv "$sr4_claim.tmp" "$sr4_claim"
chmod 0600 "$sr4_claim"
chmod 755 "$HSR4/state"
# Keep the child blocked so retirement alone ends the restored generation;
# releasing it races natural exit against the first signal's ownership check.
pe "$HSR4" retire reused-group-src >/dev/null \
  || fail "retirement failed after restoring the reused-group fixture's identity"
kill -0 -"$sr4_leader" 2>/dev/null \
  && fail "retirement left the restored reused-group fixture running"
pass "a reused pid never makes its surviving process group reclaimable"

# --- the easy case the wake promises: an undrifted reused-pid claim ----------
# Same strand, no state-root drift: the dead generation's reservation records
# can be tidied, so the attached `start` the wake names takes the claim and
# runs the source. The claim path does not consult the process group; that is
# the documented asymmetry between reconcile and a deliberate start.
HSR5="$TMP_ROOT/hsr5"; new_home "$HSR5"
SR5_TRIGGER="$TMP_ROOT/reused-plain-trigger"
SR5_LOG="$TMP_ROOT/reused-plain-executions"
pe_register "$HSR5" lavish reused-plain-src -- "$RACE_BLOCKER" "$SR5_LOG" "$SR5_TRIGGER" >/dev/null
pe "$HSR5" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/reused-plain-src.claim" \
  || fail "undrifted reused-pid fixture never claimed its source"
wait_for "$SR5_LOG" || fail "undrifted reused-pid fixture source never started"
sr5_claim="$FM_PROCEVENT_CLAIM_ROOT/reused-plain-src.claim"
sr5_leader=$(sed -n '2p' "$sr5_claim")
awk 'NR == 4 { print "different-live-process-identity"; next } { print }' \
  "$sr5_claim" > "$sr5_claim.tmp" && mv "$sr5_claim.tmp" "$sr5_claim"
chmod 0600 "$sr5_claim"
sr5_out=$(pe "$HSR5" reconcile)
assert_contains "$sr5_out" "uncertain=1" \
  "reconcile did not strand the undrifted reused-pid claim: $sr5_out"
[ "$(stranded_wake_count "$HSR5" reused-plain-src)" = 1 ] \
  || fail "the undrifted strand was not announced: $sr5_out"
pe "$HSR5" start reused-plain-src > "$TMP_ROOT/reused-plain-start.out" 2>&1 &
sr5_start_pid=$!
wait_for_lines "$SR5_LOG" 2 \
  || fail "start did not reclaim the undrifted reused-pid claim: $(cat "$TMP_ROOT/reused-plain-start.out")"
[ "$(sed -n '2p' "$sr5_claim")" != "$sr5_leader" ] \
  || fail "start ran the source without taking the claim from the dead generation"
: > "$SR5_TRIGGER"
wait "$sr5_start_pid" \
  || fail "start failed after reclaiming the undrifted claim: $(cat "$TMP_ROOT/reused-plain-start.out")"
assert_contains "$(cat "$TMP_ROOT/reused-plain-start.out")" "captured:" \
  "the reclaiming start did not capture the source's result"
for _ in $(seq 1 50); do kill -0 -"$sr5_leader" 2>/dev/null || break; sleep 0.1; done
pe "$HSR5" retire reused-plain-src >/dev/null 2>&1 || true
pass "start reclaims a reused-pid claim whose leftovers can still be tidied"

# --- a launch that cannot confirm is announced once per failure episode ------
# `bin/fm-watch.sh` discards reconcile's `failed=` count and exit status, so a
# runner that dies before claiming - for any cause, not only the claim wedge -
# would be relaunched and reported failed every cycle with nobody told: armed
# in appearance, a dead drop in fact. The episode is keyed by the registration
# identity the launch ran under and ends when a launch of that source confirms,
# so the registration below is damaged and repaired IN PLACE to keep that
# identity fixed across the whole sequence. The wake changes nothing about the
# launch: every failing cycle below still relaunches and still reports failed.
HEP="$TMP_ROOT/hep"; new_home "$HEP"
EP_SOURCE_CMD="$TMP_ROOT/episode-source.sh"
cat > "$EP_SOURCE_CMD" <<'SH'
#!/usr/bin/env bash
printf 'episode result\n'
SH
chmod +x "$EP_SOURCE_CMD"
pe_register "$HEP" lavish episode-src -- "$EP_SOURCE_CMD" >/dev/null
EP_SOURCE="$HEP/state/procevent/episode-src.source"
cp "$EP_SOURCE" "$TMP_ROOT/episode-good.source"
awk '/^argv:$/ { print; exit } { print }' "$EP_SOURCE" > "$TMP_ROOT/episode-bad.source" \
  || fail "could not prepare the damaged episode registration"
ep_damage() { cat "$TMP_ROOT/episode-bad.source" > "$EP_SOURCE"; }
ep_repair() { cat "$TMP_ROOT/episode-good.source" > "$EP_SOURCE"; }
ep_reconcile() {  # <expected-fragment> <expected-exit-nonzero:0|1> <msg>; sets ep_out
  local rc=0
  ep_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=2 pe "$HEP" reconcile) || rc=$?
  assert_contains "$ep_out" "$1" "$3: $ep_out"
  if [ "$2" -eq 1 ]; then
    [ "$rc" -ne 0 ] || fail "$3 (reconcile exited 0): $ep_out"
  else
    [ "$rc" -eq 0 ] || fail "$3 (reconcile exited $rc): $ep_out"
  fi
}
ep_damage
ep_reconcile "failed=1" 1 "a launch that never proved its claim was not reported failed"
[ "$(launch_failed_wake_count "$HEP" episode-src)" = 1 ] \
  || fail "a launch that could not confirm was not announced: $ep_out"
ep_key=$(launch_failed_wake_keys "$HEP" episode-src)
# <registration identity>-<per-episode nonce>: the watcher remembers every key
# it has surfaced for good, so the identity alone would announce only the first
# episode of a registration (tests/fm-watch-triage.test.sh proves delivery).
[[ "$ep_key" =~ ^(procevent:episode-src:launch-failed:[0-9]+-[0-9]+)-[0-9]+$ ]] \
  || fail "the launch-failed wake is not keyed by source, registration identity and episode: $ep_key"
ep_episode_prefix=${BASH_REMATCH[1]}
ep_wake=$(launch_failed_wake_payloads "$HEP" episode-src)
assert_contains "$ep_wake" "episode-src" \
  "the launch-failed wake does not name the source it is about: $ep_wake"
# The payload may state only what confirmation observed: no claim proved
# inside the window. It cannot know whether the runner died or was slow, so it
# must not assert a cause, must not present `start` as the fix, and must say
# that a later cycle finding the source owned closes the episode by itself.
assert_contains "$ep_wake" "did not prove it took the source's claim within FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS" \
  "the launch-failed wake does not state what confirmation observed: $ep_wake"
assert_contains "$ep_wake" "attached bin/fm-procevent.sh start episode-src to reproduce a refusal" \
  "the launch-failed wake does not say start reproduces rather than fixes: $ep_wake"
assert_contains "$ep_wake" "adapter binary" \
  "the launch-failed wake does not name what to check: $ep_wake"
assert_contains "$ep_wake" "finds the source owned ends this episode on its own" \
  "the launch-failed wake does not say a slow runner closes its own episode: $ep_wake"
case "$ep_wake" in
  *"never claimed"*|*"exited without"*|*"runner died"*)
    fail "the launch-failed wake asserts a cause confirmation cannot observe: $ep_wake" ;;
esac
ep_reconcile "failed=1" 1 "the second cycle stopped relaunching a source that cannot start"
[ "$(launch_failed_wake_count "$HEP" episode-src)" = 1 ] \
  || fail "the same failure episode was announced twice: $ep_out"
ep_repair
ep_reconcile "started=1" 0 "a repaired source did not confirm"
assert_contains "$ep_out" "failed=0" "a repaired source was still reported failed: $ep_out"
[ "$(launch_failed_wake_count "$HEP" episode-src)" = 1 ] \
  || fail "a confirmed launch produced a launch-failed wake: $ep_out"
for _ in $(seq 1 100); do
  [ -e "$FM_PROCEVENT_CLAIM_ROOT/episode-src.claim" ] || break
  sleep 0.1
done
[ ! -e "$FM_PROCEVENT_CLAIM_ROOT/episode-src.claim" ] \
  || fail "the confirmed episode runner never released its claim"
ep_damage
ep_reconcile "failed=1" 1 "a source that failed again after recovering was not reported failed"
[ "$(launch_failed_wake_count "$HEP" episode-src)" = 2 ] \
  || fail "a new failure episode after a confirmed launch was not announced: $ep_out"
# The earlier version of this assertion locked in ONE key for both episodes,
# which is exactly the collision that left every episode after the first
# unsurfaced: both keys must carry the same registration identity and still
# differ, or the watcher's seen marker for episode one suppresses episode two.
ep_key_again=$(launch_failed_wake_keys "$HEP" episode-src | sed -n '2p')
[ "$ep_key_again" != "$ep_key" ] \
  || fail "a new failure episode reused the first episode's queue key: $ep_key_again"
case "$ep_key_again" in
  "$ep_episode_prefix"-*) ;;
  *) fail "the second episode ran under a different registration identity: $ep_key_again (first: $ep_key)" ;;
esac
ep_repair
pe "$HEP" retire episode-src >/dev/null 2>&1 || true
pass "a launch that cannot confirm is announced once per failure episode"

# --- the launch-failed key fits the watcher's seen marker at the id limit ----
# bin/fm-watch.sh names the marker for a surfaced key `.seen-procevent-<hex>`,
# 16 + 2 * keylen bytes against NAME_MAX 255, so a key longer than 119 chars
# cannot be marked and its wake would re-surface every cycle. The longest id
# the validator accepts is 64 chars; the executed key for such an id must fit.
HLK="$TMP_ROOT/hlk"; new_home "$HLK"
LK_ID=$(printf 'k%.0s' $(seq 1 64))
[ "${#LK_ID}" -eq 64 ] || fail "fixture invalid: long source id is ${#LK_ID} chars"
pe_register "$HLK" lavish "$LK_ID" -- "$EP_SOURCE_CMD" >/dev/null
LK_SOURCE="$HLK/state/procevent/$LK_ID.source"
if ! { awk '/^argv:$/ { print; exit } { print }' "$LK_SOURCE" > "$LK_SOURCE.tmp" \
  && cat "$LK_SOURCE.tmp" > "$LK_SOURCE" && rm -f -- "$LK_SOURCE.tmp"; }; then
  fail "could not damage the long-id registration"
fi
lk_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=2 pe "$HLK" reconcile) || true
assert_contains "$lk_out" "failed=1" "the long-id launch was not reported failed: $lk_out"
lk_key=$(launch_failed_wake_keys "$HLK" "$LK_ID")
[ -n "$lk_key" ] || fail "the long-id launch failure was not announced: $lk_out"
[ "${#lk_key}" -le 119 ] \
  || fail "a 64-char source id yields a ${#lk_key}-char launch-failed key, which the watcher cannot mark: $lk_key"
pe "$HLK" retire "$LK_ID" >/dev/null 2>&1 || true
pass "a 64-char source id keeps the launch-failed key within the watcher's marker bound"

# --- reconcile reports only launches it actually confirmed -------------------
# The reported incident. A review board the captain had answered sat collecting
# nothing while `reconcile` reported a start on every run: `detach_runner` is
# fire-and-forget with the child's stderr discarded, so a runner that died
# before it could claim was counted exactly like one that is listening. A
# surface that presents as armed while being a dead drop is worse than one that
# visibly fails, because the answers look recorded.
#
# The damaged registration below makes the runner die BEFORE it claims, which
# is what keeps this deterministic: a runner that claims and then dies would
# race the confirmation either way, and the next reconcile cycle is what covers
# that case.
HUF="$TMP_ROOT/huf"; new_home "$HUF"
UF_TRIGGER="$TMP_ROOT/unstartable-trigger"
pe_register "$HUF" lavish unstartable-src -- "$BLOCKER" "$UF_TRIGGER" "unstartable" >/dev/null
UF_SOURCE="$HUF/state/procevent/unstartable-src.source"
if ! awk '/^argv:$/ { print; exit } { print }' "$UF_SOURCE" > "$UF_SOURCE.tmp"; then
  fail "could not damage the unstartable registration"
fi
mv "$UF_SOURCE.tmp" "$UF_SOURCE" || fail "could not damage the unstartable registration"
chmod 0600 "$UF_SOURCE"
uf_rc=0
uf_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=2 pe "$HUF" reconcile) || uf_rc=$?
assert_contains "$uf_out" "started=0" \
  "reconcile counted a runner that never started as a start: $uf_out"
assert_contains "$uf_out" "failed=1" \
  "reconcile did not report the launch it could not confirm: $uf_out"
[ "$uf_rc" -ne 0 ] || fail "reconcile reported success while a source could not start: $uf_out"
uf_owner=$(pe "$HUF" list | awk '$1 == "unstartable-src" { print $3 }')
[ "$uf_owner" = none ] || fail "the unstartable source reports an owner: $uf_owner"
pe "$HUF" retire unstartable-src >/dev/null 2>&1 || true
pass "reconcile reports a launch it could not confirm instead of counting it as a start"

# --- a launch that finished before the first poll is still confirmed ---------
# Confirmation has to read evidence a finished runner leaves behind. A runner
# removes its own runner record on the way out, so a source that claims, runs
# and exits before confirmation looks at it once returns every transient signal
# to exactly what it was before the launch - and a good run gets reported as a
# failure, on every cycle, for a source that is working perfectly.
#
# The second registration is what makes that deterministic rather than a race:
# reconcile launches the fast source first, then blocks acquiring the held
# lock of the second source, and the holder is released only once the fast
# runner has captured its result and let go of both its claim and its runner
# record. Confirmation therefore starts strictly after the fast runner is gone.
HFC="$TMP_ROOT/hfc"; new_home "$HFC"
FC_FAST="$TMP_ROOT/fast-source.sh"
cat > "$FC_FAST" <<'SH'
#!/usr/bin/env bash
printf 'fast payload\n'
SH
chmod +x "$FC_FAST"
FC_TRIGGER="$TMP_ROOT/fast-hold-trigger"
pe_register "$HFC" lavish aa-fast-src -- "$FC_FAST" >/dev/null
pe_register "$HFC" lavish zz-hold-src -- "$BLOCKER" "$FC_TRIGGER" "held" >/dev/null
FC_READY="$TMP_ROOT/fast-hold-ready"; FC_RELEASE="$TMP_ROOT/fast-hold-release"
hold_source_lock zz-hold-src "$FC_READY" "$FC_RELEASE"
wait_for "$FC_READY" || fail "the fast-source fixture could not hold a source lock"
(
  for _ in $(seq 1 600); do
    if first_result "$HFC" aa-fast-src >/dev/null 2>&1 \
      && [ ! -e "$HFC/state/procevent/aa-fast-src.runner" ] \
      && [ ! -e "$FM_PROCEVENT_CLAIM_ROOT/aa-fast-src.claim" ]; then
      break
    fi
    sleep 0.05
  done
  : > "$FC_RELEASE"
) &
FC_RELEASER=$!
fc_rc=0
fc_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=2 pe "$HFC" reconcile) || fc_rc=$?
wait "$FC_RELEASER" 2>/dev/null || true
wait "$HOLDER_PID" 2>/dev/null || true
first_result "$HFC" aa-fast-src >/dev/null \
  || fail "fixture invalid: the fast source never produced a result: $fc_out"
assert_contains "$fc_out" "started=2" \
  "reconcile did not report both launches as started: $fc_out"
assert_contains "$fc_out" "failed=0" \
  "reconcile reported a launch that ran to completion as a failure: $fc_out"
[ "$fc_rc" -eq 0 ] || fail "reconcile exited non-zero with every launch confirmed: $fc_out"
: > "$FC_TRIGGER"
pe "$HFC" retire aa-fast-src >/dev/null 2>&1 || true
pe "$HFC" retire zz-hold-src >/dev/null 2>&1 || true
pass "a launch that finished before confirmation looked is still reported as started"

# --- a zero-padded confirm window is read as base 10 -------------------------
# The window's validator reads base 10, so `08` is a value it accepts. Read as
# octal in arithmetic it is not a number at all, which under `set -u` takes the
# confirmation down with it and turns every launch of the cycle - including a
# perfectly healthy one - into a reported failure and a non-zero exit.
HZP="$TMP_ROOT/hzp"; new_home "$HZP"
ZP_TRIGGER="$TMP_ROOT/zeropad-trigger"
pe_register "$HZP" lavish zeropad-src -- "$BLOCKER" "$ZP_TRIGGER" "zeropad" >/dev/null
zp_rc=0
zp_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=08 pe "$HZP" reconcile 2>/dev/null) || zp_rc=$?
assert_contains "$zp_out" "started=1" \
  "a zero-padded confirm window lost the launch reconcile started: $zp_out"
assert_contains "$zp_out" "failed=0" \
  "a zero-padded confirm window reported a healthy launch as failed: $zp_out"
[ "$zp_rc" -eq 0 ] || fail "a zero-padded confirm window made reconcile exit non-zero: $zp_out"
: > "$ZP_TRIGGER"
pe "$HZP" retire zeropad-src >/dev/null 2>&1 || true
pass "a zero-padded launch confirm window is honored as base 10"

# --- an unusable confirm window is refused by name --------------------------
# A window this command cannot use makes every launch unconfirmable. Reported
# from inside the confirmation it comes out as a fleet of healthy runners that
# all "could not start", blaming the sources instead of the typo. Every other
# tunable on this path - the launch floor, the output bound - refuses a bad
# value by name before anything runs, and so does this one.
HIW="$TMP_ROOT/hiw"; new_home "$HIW"
IW_TRIGGER="$TMP_ROOT/invalid-window-trigger"
pe_register "$HIW" lavish invalid-window-src -- "$BLOCKER" "$IW_TRIGGER" "window" >/dev/null
for iw_value in 5s 0 700; do
  iw_rc=0
  iw_out=$(FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS="$iw_value" pe "$HIW" reconcile 2>&1) || iw_rc=$?
  [ "$iw_rc" -ne 0 ] \
    || fail "reconcile accepted the unusable confirm window '$iw_value': $iw_out"
  assert_contains "$iw_out" "FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS" \
    "the unusable confirm window '$iw_value' was not named by what refused it: $iw_out"
  case "$iw_out" in
    *failed=*) fail "the unusable confirm window '$iw_value' was blamed on the sources: $iw_out" ;;
  esac
  [ ! -e "$FM_PROCEVENT_CLAIM_ROOT/invalid-window-src.claim" ] \
    || fail "reconcile launched a runner before refusing the confirm window '$iw_value'"
done
# The refusal costs the source nothing: it still arms on the next run with a
# usable value.
iw_ok=$(pe "$HIW" reconcile)
assert_contains "$iw_ok" "started=1" \
  "the source did not arm once its confirm window was usable: $iw_ok"
assert_contains "$iw_ok" "failed=0" \
  "the source was reported as failed once its confirm window was usable: $iw_ok"
: > "$IW_TRIGGER"
pe "$HIW" retire invalid-window-src >/dev/null 2>&1 || true
pass "an unusable launch confirm window is refused by name instead of blamed on the sources"

# --- a dead generation's untidyable leftovers never wedge ownership ----------
# The same wedge as the state-root case above, reached through the sibling
# cleanups in the stale-claim branch rather than the capture reservation. Every
# one of them tidies leftovers keyed by the DEAD generation's claim token, so
# none can collide with the replacement, yet a failure in any of them used to
# refuse the claim outright - permanently, because the condition never clears on
# its own. Here the recorded registry directory no longer resolves to a
# directory at all, which is what a claim recorded before its home was replaced
# looks like.
HUW="$TMP_ROOT/huw"; new_home "$HUW"
UW_TRIGGER="$TMP_ROOT/untidyable-trigger"
UW_LOG="$TMP_ROOT/untidyable-executions"
pe_register "$HUW" lavish untidyable-src -- "$RACE_BLOCKER" "$UW_LOG" "$UW_TRIGGER" >/dev/null
UW_REG_FILE="$TMP_ROOT/untidyable-recorded-registry"
: > "$UW_REG_FILE"
uw_identity=$(bash -c '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_identity "$2"' _ \
  "$ROOT" "$HUW/state/procevent/untidyable-src.source") \
  || fail "could not read the untidyable fixture registration identity"
UW_CLAIM="$FM_PROCEVENT_CLAIM_ROOT/untidyable-src.claim"
{
  printf '%s\n%s\nuntidyable-token\nuntidyable-identity\n' "$HUW" 999999
  printf '%s\n%s\nactive\n' "$UW_REG_FILE" "$uw_identity"
  printf '%s\n%s\n%s\n%s\n%s\n' "$HUW/state" \
    "$(bash -c '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_device "$2"' _ "$ROOT" "$HUW/state")" \
    "$(bash -c '. "$1/bin/fm-pr-lib.sh"; fm_pr_file_inode "$2"' _ "$ROOT" "$HUW/state")" \
    "$(id -u)" 755
} > "$UW_CLAIM"
chmod 0600 "$UW_CLAIM"
kill -0 999999 2>/dev/null && fail "fixture invalid: the untidyable claim names a live pid"
kill -0 -999999 2>/dev/null && fail "fixture invalid: the untidyable claim's process group is alive"
uw_rc=0
uw_out=$(pe "$HUW" reconcile) || uw_rc=$?
[ "$uw_rc" -eq 0 ] || fail "reconcile could not repair a provably dead generation: $uw_out"
# Reporting a start is not the same fact as listening, so prove the listening
# half first: before this fix reconcile reported exactly this start on every run
# while the dead generation kept the claim and nothing ever attached.
wait_for "$UW_LOG" || fail "reconcile reported a start but no replacement source ever ran: $uw_out"
uw_new=$(sed -n '2p' "$UW_CLAIM")
[ "$uw_new" != 999999 ] || fail "the dead generation kept owning the source: $uw_out"
kill -0 "$uw_new" 2>/dev/null || fail "the replacement runner did not take ownership: $uw_out"
assert_contains "$uw_out" "started=1" "reconcile did not report the replacement it started: $uw_out"
assert_contains "$uw_out" "failed=0" "reconcile could not confirm the replacement: $uw_out"
: > "$UW_TRIGGER"
pe "$HUW" retire untidyable-src >/dev/null
pass "a dead generation whose leftovers cannot be tidied never keeps owning its source"

HJ="$TMP_ROOT/hj"; new_home "$HJ"
TORN_TRIGGER="$TMP_ROOT/torn-trigger"
pe_register "$HJ" lavish torn-src -- "$BLOCKER" "$TORN_TRIGGER" "torn" >/dev/null
pe "$HJ" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/torn-src.claim" || fail "torn-read fixture runner did not claim its source"
awk 'NR == 3 { print "replacement-token"; next } { print }' \
  "$FM_PROCEVENT_CLAIM_ROOT/torn-src.claim" > "$TMP_ROOT/torn-next.claim"
chmod 0600 "$TMP_ROOT/torn-next.claim"
TORN_READY="$TMP_ROOT/torn-lock-ready"
TORN_RELEASE="$TMP_ROOT/torn-lock-release"
hold_source_lock torn-src "$TORN_READY" "$TORN_RELEASE"
torn_holder_pid=$HOLDER_PID
wait_for "$TORN_READY" || fail "could not hold the torn-read source boundary"
pe "$HJ" list > "$TMP_ROOT/torn-list.out" &
torn_list_pid=$!
sleep 0.2
kill -0 "$torn_list_pid" 2>/dev/null || fail "claim reader escaped the source boundary during replacement"
mv "$TMP_ROOT/torn-next.claim" "$FM_PROCEVENT_CLAIM_ROOT/torn-src.claim"
: > "$TORN_RELEASE"
wait "$torn_list_pid" || fail "claim reader failed after serialized replacement"
wait "$torn_holder_pid" || fail "torn-read source boundary holder failed"
assert_contains "$(cat "$TMP_ROOT/torn-list.out")" "live" "claim reader observes one coherent replacement generation"
pe "$HJ" retire torn-src >/dev/null
pass "claim replacement cannot produce a torn ownership snapshot"

HK="$TMP_ROOT/hk"; new_home "$HK"
START_LOG="$TMP_ROOT/retire-start-executions"
START_BLOCKER="$TMP_ROOT/retire-start-blocker.sh"
cat > "$START_BLOCKER" <<'SH'
#!/usr/bin/env bash
printf 'started\n' >> "$1"
sleep 30
SH
chmod +x "$START_BLOCKER"
pe_register "$HK" lavish retire-start-src -- "$START_BLOCKER" "$START_LOG" >/dev/null
START_READY="$TMP_ROOT/retire-start-lock-ready"
START_RELEASE="$TMP_ROOT/retire-start-lock-release"
hold_source_lock retire-start-src "$START_READY" "$START_RELEASE"
retire_start_holder_pid=$HOLDER_PID
wait_for "$START_READY" || fail "could not hold the retire-start source boundary"
pe "$HK" start retire-start-src > "$TMP_ROOT/retire-start.out" 2>&1 &
retire_start_pid=$!
sleep 0.2
kill -0 "$retire_start_pid" 2>/dev/null || fail "start did not wait for the source lifecycle boundary"
rm -f "$HK/state/procevent/retire-start-src.source"
: > "$START_RELEASE"
wait "$retire_start_pid" 2>/dev/null || true
wait "$retire_start_holder_pid" || fail "retire-start source boundary holder failed"
assert_absent "$START_LOG" "a start queued before retirement must revalidate the registration"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/retire-start-src.claim" "retirement cannot leave a late claim"
pass "retirement and start share one serialized lifecycle boundary"

HI="$TMP_ROOT/hi"; new_home "$HI"
pe_register "$HI" lavish reused-src -- /bin/true >/dev/null
sleep 60 &
innocent_pid=$!
printf '%s\n%s\nreused-token\nnot-the-live-process-identity\n' \
  "$HI" "$innocent_pid" > "$FM_PROCEVENT_CLAIM_ROOT/reused-src.claim"
chmod 0600 "$FM_PROCEVENT_CLAIM_ROOT/reused-src.claim"
pe "$HI" retire reused-src >/dev/null
kill -0 "$innocent_pid" 2>/dev/null || fail "retirement signaled a PID whose identity did not match the claim"
kill "$innocent_pid" 2>/dev/null || true
wait "$innocent_pid" 2>/dev/null || true
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/reused-src.claim" "retirement releases the exact reused-pid claim"
pass "detected PID reuse is refused before signalling"

HL="$TMP_ROOT/hl"; new_home "$HL"
IDENTITY_TRIGGER="$TMP_ROOT/identity-trigger"
pe_register "$HL" lavish identity-src -- "$BLOCKER" "$IDENTITY_TRIGGER" "identity" >/dev/null
pe "$HL" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/identity-src.claim" || fail "identity fixture runner did not claim its source"
identity_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/identity-src.claim")
IDENTITY_FAKEBIN=$(fm_fakebin "$TMP_ROOT/identity-tools")
cat > "$IDENTITY_FAKEBIN/ps" <<'SH'
#!/usr/bin/env bash
exit 1
SH
chmod +x "$IDENTITY_FAKEBIN/ps"
identity_status=0
identity_out=$(PATH="$IDENTITY_FAKEBIN:$PATH" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-proc" \
  pe "$HL" retire identity-src 2>&1) || identity_status=$?
[ "$identity_status" -ne 0 ] || fail "retirement succeeded despite uncertain live identity"
assert_contains "$identity_out" "source remains registered" "uncertain retirement reports preserved state"
kill -0 "$identity_pid" 2>/dev/null || fail "uncertain retirement signaled the runner"
assert_present "$HL/state/procevent/identity-src.source" "uncertain retirement preserves registration"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/identity-src.claim" "uncertain retirement preserves claim generation"
pe "$HL" retire identity-src >/dev/null
pass "transient identity failure preserves the live source for retry"

HM="$TMP_ROOT/hm"; new_home "$HM"
SWEEP_TRIGGER_ONE="$TMP_ROOT/sweep-trigger-one"
SWEEP_TRIGGER_TWO="$TMP_ROOT/sweep-trigger-two"
pe_register "$HM" lavish sweep-one -- "$BLOCKER" "$SWEEP_TRIGGER_ONE" "sweep one" >/dev/null
pe_register "$HM" lavish sweep-two -- "$BLOCKER" "$SWEEP_TRIGGER_TWO" "sweep two" >/dev/null
pe "$HM" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/sweep-one.claim" || fail "home sweep fixture one did not start"
wait_for "$FM_PROCEVENT_CLAIM_ROOT/sweep-two.claim" || fail "home sweep fixture two did not start"
sweep_pid_one=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/sweep-one.claim")
sweep_pid_two=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/sweep-two.claim")
# The claim-only case is an owned claim with no live runner, so build exactly
# that: kill the runner's group so it cannot run its own cleanup, confirm it is
# gone, and only then drop the registration. Deleting the registration out from
# under a LIVE runner no longer produces this case, because a superseded
# generation now observes the identity mismatch, self-retires, and releases its
# claim - so the sweep would race that exit and see one source or two depending
# on which won.
kill -KILL -"$sweep_pid_two" 2>/dev/null || true
for _ in $(seq 1 50); do kill -0 "$sweep_pid_two" 2>/dev/null || break; sleep 0.1; done
kill -0 "$sweep_pid_two" 2>/dev/null \
  && fail "the claim-only sweep fixture runner did not stop"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/sweep-two.claim" \
  "a killed runner leaves its owned claim behind for the sweep"
rm -f "$HM/state/procevent/sweep-two.source"
out=$(pe "$HM" sweep-home --preflight)
assert_contains "$out" "sweep preflight: ready" "home sweep preflight validates the full bounded snapshot"
assert_present "$HM/state/procevent/sweep-one.source" "home sweep preflight does not remove registrations"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/sweep-one.claim" "home sweep preflight does not release claims"
out=$(pe "$HM" sweep-home)
assert_contains "$out" "swept: attempted=2" "home sweep retires registrations and owned claim-only sources"
for sweep_pid in "$sweep_pid_one" "$sweep_pid_two"; do
  for _ in $(seq 1 40); do kill -0 "$sweep_pid" 2>/dev/null || break; sleep 0.1; done
  kill -0 "$sweep_pid" 2>/dev/null && fail "home sweep left a runner alive"
done
assert_absent "$HM/state/procevent/sweep-one.source" "home sweep removes registrations"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/sweep-one.claim" "home sweep releases the first claim"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/sweep-two.claim" "home sweep releases a claim with no registration"
pass "bounded home sweep preflights then retires every locally owned source"

HN="$TMP_ROOT/hn"; HO="$TMP_ROOT/ho"; new_home "$HN"; new_home "$HO"
FOREIGN_TRIGGER="$TMP_ROOT/foreign-trigger"
pe_register "$HN" lavish foreign-src -- "$BLOCKER" "$FOREIGN_TRIGGER" "foreign" >/dev/null
pe_register "$HO" lavish foreign-src -- "$BLOCKER" "$FOREIGN_TRIGGER" "foreign" >/dev/null
pe "$HN" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/foreign-src.claim" || fail "foreign-owner fixture did not start"
foreign_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/foreign-src.claim")
out=$(pe "$HO" sweep-home)
assert_contains "$out" "swept: attempted=1" "home sweep retires the local registration"
kill -0 "$foreign_pid" 2>/dev/null || fail "home sweep signaled a foreign-home runner"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/foreign-src.claim" "home sweep preserves a foreign-home claim"
[ "$(sed -n '1p' "$FM_PROCEVENT_CLAIM_ROOT/foreign-src.claim")" = "$HN" ] || fail "home sweep changed foreign claim ownership"
assert_absent "$HO/state/procevent/foreign-src.source" "home sweep removes only the local registration"
pe "$HN" retire foreign-src >/dev/null
pass "home sweep leaves foreign-home claims and runners untouched"

HU="$TMP_ROOT/hu"; new_home "$HU"
SWEEP_UNCERTAIN_TRIGGER="$TMP_ROOT/sweep-uncertain-trigger"
pe_register "$HU" lavish sweep-uncertain -- "$BLOCKER" "$SWEEP_UNCERTAIN_TRIGGER" "uncertain" >/dev/null
pe "$HU" reconcile >/dev/null
wait_for "$FM_PROCEVENT_CLAIM_ROOT/sweep-uncertain.claim" || fail "uncertain sweep fixture did not start"
sweep_uncertain_pid=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/sweep-uncertain.claim")
sweep_status=0
sweep_out=$(PATH="$IDENTITY_FAKEBIN:$PATH" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-sweep-proc" \
  pe "$HU" sweep-home 2>&1) || sweep_status=$?
[ "$sweep_status" -ne 0 ] || fail "home sweep succeeded with an uncertain runner identity"
assert_contains "$sweep_out" "home sweep preflight failed" "uncertain home sweep reports a retryable refusal"
kill -0 "$sweep_uncertain_pid" 2>/dev/null || fail "uncertain home sweep signaled the runner"
assert_present "$HU/state/procevent/sweep-uncertain.source" "uncertain home sweep preserves registration"
assert_present "$FM_PROCEVENT_CLAIM_ROOT/sweep-uncertain.claim" "uncertain home sweep preserves the claim"
pe "$HU" sweep-home >/dev/null
pass "home sweep refuses safely until runner identity is readable"

HV="$TMP_ROOT/hv"; new_home "$HV"
mkdir -p "$HV/state/procevent-inbox"
printf 'already captured\n' > "$HV/state/procevent-inbox/result-only.1.result"
sup=$(bash -c '. "$1/bin/fm-supervision-lib.sh"; fm_supervision_needed "$2" && echo yes || echo no' _ "$ROOT" "$HV/state")
assert_contains "$sup" no "registration-free results do not broaden continuous supervision"
out=$(pe "$HV" sweep-home)
assert_contains "$out" "swept: attempted=0" "result-only homes need no process cleanup"
pass "healthy runtime behavior remains registration-only"

# --- argv boundaries, stderr, exit status, bounds, malformed output ---------
HD="$TMP_ROOT/hd"; new_home "$HD"
TRIG3="$TMP_ROOT/trigger-three"
pe_register "$HD" lavish argv-src -- "$BLOCKER" "$TRIG3" "one arg with spaces" "second; rm -rf /tmp/nope" >/dev/null
pe "$HD" reconcile >/dev/null
: > "$TRIG3"
wait_for "$HD/state/.wake-queue" || fail "argv source published no event"
R=$(first_result "$HD" argv-src || true)
assert_grep 'one arg with spaces' "$R" "an argument containing spaces survives as one argument"
assert_grep 'second; rm -rf /tmp/nope' "$R" "a shell-looking argument is passed literally, never interpreted"
assert_absent /tmp/nope "no shell interpretation occurred"
assert_not_contains "$(wake_payloads "$HD")" "rm -rf" "argv content never reaches the event line"

newline_status=0
newline_out=$(pe_register "$HD" lavish newline-src -- /bin/echo $'first\nsecond' 2>&1) || newline_status=$?
[ "$newline_status" -ne 0 ] || fail "registration accepted an argv element containing a newline"
assert_contains "$newline_out" "cannot contain newlines" "newline rejection explains the unsupported representation"
assert_absent "$HD/state/procevent/newline-src.source" "newline rejection publishes no corrupt registration"
pass "registration rejects unrepresentable newline arguments"

HE="$TMP_ROOT/he"; new_home "$HE"
pe_register "$HE" lavish fail-src -- /bin/sh -c 'exit 7' >/dev/null
out=$(pe "$HE" start fail-src)
assert_contains "$out" "no-result" "a failing source with no output publishes nothing"
[ -z "$(wake_payloads "$HE")" ] || fail "a failing source published an event"
assert_present "$HE/state/procevent/fail-src.source" "a failing source stays registered for retry"
pass "nonzero exit with no output stays armed and silent"

HF="$TMP_ROOT/hf"; new_home "$HF"
# shellcheck disable=SC2016  # single quotes are deliberate: the child shell expands this.
pe_register "$HF" lavish big-src -- /bin/sh -c 'printf "x%.0s" $(seq 1 5000)' >/dev/null
FM_PROCEVENT_MAX_OUTPUT_BYTES=100 FM_HOME="$HF" "$ROOT/bin/fm-procevent.sh" start big-src >/dev/null 2>&1
RB=$(first_result "$HF" big-src || true)
[ -n "$RB" ] || fail "bounded output was not captured at all"
[ "$(wc -c < "$RB" | tr -d ' ')" -le 100 ] || fail "output bound was not enforced"
pass "oversized output is bounded rather than published whole or dropped"

HG="$TMP_ROOT/hg-live"; new_home "$HG"
NOISY="$TMP_ROOT/noisy.sh"
NOISY_PID="$TMP_ROOT/noisy.pid"
cat > "$NOISY" <<'SH'
#!/usr/bin/env bash
trap '' TERM PIPE
printf '%s\n' "$$" > "$1"
while :; do
  printf 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n'
done
SH
chmod +x "$NOISY"
pe_register "$HG" lavish noisy-src -- "$NOISY" "$NOISY_PID" >/dev/null
FM_PROCEVENT_MAX_OUTPUT_BYTES=100 pe "$HG" reconcile >/dev/null
wait_for "$NOISY_PID" || fail "noisy source child did not start"
noisy_child=$(cat "$NOISY_PID")
staged=
for _ in $(seq 1 100); do
  for candidate in "$HG/state/procevent"/.noisy-src.*.output; do
    if [ -f "$candidate" ]; then staged=$candidate; break; fi
  done
  [ -n "$staged" ] && break
  sleep 0.1
done
[ -n "$staged" ] || fail "noisy source created no bounded staging file"
sleep 0.2
[ "$(wc -c < "$staged" | tr -d ' ')" -le 100 ] || fail "live staging exceeded the configured output bound"
pe "$HG" retire noisy-src >/dev/null
kill -0 "$noisy_child" 2>/dev/null && fail "TERM-resistant source child survived runner retirement"
assert_absent "$staged" "retirement removes the tracked partial staging file"
pass "live output stays bounded and retirement reaps the whole source group"

# When a fixture never records TERM, capture the claim, leader, group, and
# retirement output to help distinguish a blocked stop from a refused signal.
# Collect this evidence only on the failure path so passing cases stay quiet.
post_term_evidence() {  # <case> <runner-pid> <claim> <signals> <started-epoch> <retire-output>
  local case=$1 runner=$2 claim=$3 signals=$4 started=$5 out=$6
  {
    printf 'post-TERM evidence (%s case)\n' "$case"
    printf '  elapsed since retire started: %ss\n' "$(( $(date +%s) - started ))"
    printf '  identity recorded at claim time: %s\n' "$(sed -n '4p' "$claim" 2>/dev/null || echo '<claim unreadable>')"
    printf '  identity readable now (real ps): %s\n' "$(LC_ALL=C ps -p "$runner" -o lstart= 2>/dev/null || echo '<ps failed>')"
    printf '  signals file: %s (%s bytes)\n' "$signals" "$(wc -c < "$signals" 2>/dev/null | tr -d ' ' || echo 0)"
    printf '  leader state: %s\n' "$(ps -o pid=,ppid=,pgid=,stat= -p "$runner" 2>/dev/null || echo '<leader gone>')"
    printf '  leader wchan: %s\n' "$(ps -o wchan= -p "$runner" 2>/dev/null || echo '<none>')"
    printf '  live members of the runner group:\n'
    ps -Ao pid,ppid,pgid,stat,wchan,command 2>/dev/null | awk -v g="$runner" 'NR==1 || $3==g' | sed 's/^/    /'
    printf '  retire said: %s\n' "${out:-<no output>}"
  } >&2
}

for post_term_case in mismatch unreadable unreadable-pgid nonleader; do
  HPOST_TERM="$TMP_ROOT/post-term-$post_term_case"; new_home "$HPOST_TERM"
  POST_TERM_SOURCE="$HPOST_TERM/source.sh"
  POST_TERM_PID="$HPOST_TERM/child.pid"
  POST_TERM_SIGNALS="$HPOST_TERM/child.signals"
  cat > "$POST_TERM_SOURCE" <<'SH'
#!/usr/bin/env bash
trap 'printf "signalled\n" >> "$2"' TERM
printf '%s\n' "$$" > "$1"
while [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ]; do sleep 1; done
SH
  chmod +x "$POST_TERM_SOURCE"
  POST_TERM_BIN=$(fm_fakebin "$HPOST_TERM/tools")
  REAL_PS=$(command -v ps) || fail "the post-TERM reuse fixture requires ps"
  pe_register "$HPOST_TERM" lavish post-term-src -- \
    "$POST_TERM_SOURCE" "$POST_TERM_PID" "$POST_TERM_SIGNALS" >/dev/null
  FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-post-term-proc" \
    FM_PROCEVENT_OWNER_CHECK_SECONDS=5 pe "$HPOST_TERM" reconcile >/dev/null
  wait_for "$POST_TERM_PID" || fail "the post-TERM reuse fixture did not start"
  wait_for "$FM_PROCEVENT_CLAIM_ROOT/post-term-src.claim" \
    || fail "the post-TERM reuse fixture did not claim its source"
  POST_TERM_RUNNER=$(sed -n '2p' "$FM_PROCEVENT_CLAIM_ROOT/post-term-src.claim")
  # The child can publish its PID before startup releases the source lock.
  # Cross that boundary before suspending the runner, or retirement waits on
  # a stopped lock owner instead of exercising the signal checks below.
  FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-post-term-proc" pe "$HPOST_TERM" list >/dev/null \
    || fail "the post-TERM fixture never finished its source launch"
  kill -STOP "$POST_TERM_RUNNER" || fail "the post-TERM fixture could not keep its leader alive"
  cat > "$POST_TERM_BIN/ps" <<SH
#!/usr/bin/env bash
if [ "\${1-}" = -p ] && [ "\${2-}" = "$POST_TERM_RUNNER" ] \
  && [ "\${3-}" = -o ] && [ "\${4-}" = lstart= ]; then
  if [ "$post_term_case" = mismatch ]; then
    printf 'reused identity\n'
    exit 0
  fi
  [ ! -s "$POST_TERM_SIGNALS" ] || exit 1
fi
if [ "\${1-}" = -o ] && [ "\${2-}" = pgid= ] \
  && [ "\${3-}" = -p ] && [ "\${4-}" = "$POST_TERM_RUNNER" ]; then
  case "$post_term_case" in
    unreadable-pgid) [ ! -s "$POST_TERM_SIGNALS" ] || exit 1 ;;
    nonleader) printf '0\n'; exit 0 ;;
  esac
fi
exec "$REAL_PS" "\$@"
SH
  chmod +x "$POST_TERM_BIN/ps"
  post_term_status=0
  post_term_started=$(date +%s)
  post_term_out=$(PATH="$POST_TERM_BIN:$PATH" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-post-term-proc" \
    pe "$HPOST_TERM" retire post-term-src 2>&1) || post_term_status=$?
  case "$post_term_case" in
    mismatch|nonleader)
      assert_absent "$POST_TERM_SIGNALS" "the first signal refuses $post_term_case evidence"
      [ "$post_term_status" -ne 0 ] || fail "retirement escalated despite $post_term_case evidence"
      assert_contains "$post_term_out" "cannot confirm runner identity" \
        "first-signal $post_term_case evidence refuses retirement"
      kill -0 "$POST_TERM_RUNNER" 2>/dev/null \
        || fail "the post-TERM fixture lost its leader instead of exercising $post_term_case evidence"
      kill -0 -"$POST_TERM_RUNNER" 2>/dev/null \
        || fail "a $post_term_case group was killed during escalation"
      assert_present "$HPOST_TERM/state/procevent/post-term-src.source" \
        "first-signal $post_term_case evidence preserves registration"
      assert_present "$FM_PROCEVENT_CLAIM_ROOT/post-term-src.claim" \
        "first-signal $post_term_case evidence preserves its claim"
      kill -KILL -"$POST_TERM_RUNNER" 2>/dev/null || true
      ;;
    *)
      if [ ! -s "$POST_TERM_SIGNALS" ]; then
        post_term_evidence "$post_term_case" "$POST_TERM_RUNNER" \
          "$FM_PROCEVENT_CLAIM_ROOT/post-term-src.claim" "$POST_TERM_SIGNALS" \
          "$post_term_started" "$post_term_out"
        fail "the post-TERM fixture never received TERM"
      fi
      [ "$post_term_status" -eq 0 ] \
        || fail "retirement abandoned a proved stop after $post_term_case identity: $post_term_out"
      assert_absent "$HPOST_TERM/state/procevent/post-term-src.source" \
        "proved escalation retires the source after $post_term_case identity"
      assert_absent "$FM_PROCEVENT_CLAIM_ROOT/post-term-src.claim" \
        "proved escalation releases its claim after $post_term_case identity"
      ;;
  esac
  for _ in $(seq 1 50); do kill -0 -"$POST_TERM_RUNNER" 2>/dev/null || break; sleep 0.1; done
  kill -0 -"$POST_TERM_RUNNER" 2>/dev/null && fail "the post-TERM fixture group survived: $post_term_case"
  pe "$HPOST_TERM" retire post-term-src >/dev/null
  pass "stop $post_term_case evidence preserves the proved-stop boundary"
done

HBAD="$TMP_ROOT/hbad"; new_home "$HBAD"
pe_register "$HBAD" lavish bad-limit -- /bin/true >/dev/null
bad_limit_status=0
bad_limit_out=$(FM_PROCEVENT_MAX_OUTPUT_BYTES=invalid pe "$HBAD" start bad-limit 2>&1) || bad_limit_status=$?
[ "$bad_limit_status" -ne 0 ] || fail "an invalid output bound was accepted"
assert_contains "$bad_limit_out" "must be a nonnegative integer" "invalid output bound reports its contract"
assert_absent "$FM_PROCEVENT_CLAIM_ROOT/bad-limit.claim" "invalid output bound leaves no source claim"
pass "invalid output bounds fail closed"

# --- the Lavish adapter uses the published poll shape -----------------------
ART="$TMP_ROOT/artifact.html"
printf '<h1>fixture</h1>\n' > "$ART"
lavish_session "$ART"
sid=$(FM_HOME="$TMP_ROOT/hg" "$ROOT/bin/fm-procevent-lavish.sh" source-id "$ART")
case "$sid" in lavish-*) : ;; *) fail "adapter source id has an unexpected shape: $sid" ;; esac
sid2=$(FM_HOME="$TMP_ROOT/hg" "$ROOT/bin/fm-procevent-lavish.sh" source-id "$ART")
[ "$sid" = "$sid2" ] || fail "adapter source id is not stable"
ART_ALIAS="$TMP_ROOT/artifact-alias.html"
ln -s "$ART" "$ART_ALIAS"
sid3=$(FM_HOME="$TMP_ROOT/hg" "$ROOT/bin/fm-procevent-lavish.sh" source-id "$ART_ALIAS")
[ "$sid" = "$sid3" ] || fail "a final-component symlink produced a second source id"
ART_NEWLINE="$TMP_ROOT/line-ending"$'\n'
printf '<h1>newline fixture</h1>\n' > "$ART_NEWLINE"
printf '<h1>sibling fixture</h1>\n' > "$TMP_ROOT/line-ending"
newline_artifact_status=0
newline_artifact_out=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ART_NEWLINE" 2>&1) || newline_artifact_status=$?
[ "$newline_artifact_status" -ne 0 ] || fail "Lavish source identity accepted an artifact path ending in a newline"
assert_contains "$newline_artifact_out" "cannot contain newlines" "Lavish rejects newline paths before canonicalization"
pass "the adapter derives physical identity without newline path corruption"

HS="$TMP_ROOT/hs"; new_home "$HS"
mkdir -p "$HS/state/procevent"
: > "$HS/state/procevent/source-only.source"
guard_out=$(FM_ROOT_OVERRIDE="$TMP_ROOT/guard-root" FM_HOME="$HS" FM_GUARD_GRACE=1 \
  "$ROOT/bin/fm-guard.sh" 2>&1)
assert_contains "$guard_out" "WATCHER DOWN - SUPERVISION IS OFF" \
  "the general guard warns when only a process-event source needs supervision"
assert_contains "$guard_out" "1 process-event source(s) registered" \
  "the general guard identifies the source-only supervision need"
pass "source-only homes trigger the general supervision guard"

CLS="$TMP_ROOT/cls"
while IFS='|' read -r status expected; do
  printf 'session:\n  file: /a.html\n  status: %s\n' "$status" > "$CLS"
  out=$("$ROOT/bin/fm-procevent-lavish.sh" classify "$CLS") \
    || fail "classify failed for handled Lavish status: $status"
  [ "$out" = "$expected" ] \
    || fail "handled Lavish status $status classified as '$out', expected '$expected'"
done <<'EOF'
feedback|feedback
ended|ended
waiting|waiting
browser_disconnected|disconnected
EOF
printf 'session:\n  file: /a.html\n  status: feedback\nprompts[1]{text}:\n  No active Lavish Editor session; code: NOT_FOUND\n' > "$CLS"
[ "$("$ROOT/bin/fm-procevent-lavish.sh" classify "$CLS")" = feedback ] \
  || fail "prompt text overrode a valid session status"
printf 'error: No active Lavish Editor session for this file\ncode: NOT_FOUND\n' > "$CLS"
assert_contains "$("$ROOT/bin/fm-procevent-lavish.sh" classify "$CLS")" missing "an explicit missing session classifies as missing"
printf 'garbage that is not a session block\n' > "$CLS"
assert_contains "$("$ROOT/bin/fm-procevent-lavish.sh" classify "$CLS")" unknown "malformed output classifies as unknown rather than a lifecycle state"
pass "the adapter classifies published poll output safely"

HOST_HOME="$TMP_ROOT/host-config"
mkdir -p "$HOST_HOME/config"
printf '%s\n' '100.99.161.42' > "$HOST_HOME/config/lavish-axi-host"
HOST_ART="$TMP_ROOT/board, '评审'.html"
printf '<h1>session routing</h1>\n' > "$HOST_ART"
HOST_SEEN="$TMP_ROOT/session-route-seen"
HOST_BIN=$(fm_fakebin "$TMP_ROOT/session-route-bin")
cat > "$HOST_BIN/lavish-axi" <<'SH'
#!/usr/bin/env bash
[ "${1-}" = poll ] || exit 2
printf '%s:%s\n' "${LAVISH_AXI_HOST-unset}" "${LAVISH_AXI_PORT-unset}" >> "$HOST_SEEN"
if [ -n "${HOST_RETRY-}" ] && [ "$(wc -l < "$HOST_SEEN" | tr -d ' ')" = 1 ]; then
  rm -f "$HOST_CONFIG_FILE"
  printf 'error: Lavish Editor poll response was interrupted\ncode: SERVER_ERROR\n'
else
  printf 'session:\n  status: ended\n  ended_by: user\n'
fi
SH
chmod +x "$HOST_BIN/lavish-axi"
# Re-reading the session makes its saved endpoint authoritative without a
# Firstmate route record, even when the same artifact is subsequently reopened.
for endpoint in '127.0.0.1:14387' 'board.example:24387' '[::1]:34387'; do
  lavish_session "$HOST_ART" "http://$endpoint/session/0123456789abcdef"
  : > "$HOST_SEEN"
  PATH="$HOST_BIN:$PATH" HOST_SEEN="$HOST_SEEN" LAVISH_AXI_HOST=wrong.example \
    LAVISH_AXI_PORT=44387 FM_HOME="$HOST_HOME" \
    "$ROOT/bin/fm-procevent-lavish.sh" poll "$HOST_ART" >/dev/null
  expected=${endpoint//\[/}; expected=${expected//\]/}
  [ "$(cat "$HOST_SEEN")" = "$expected" ] \
    || fail "poll did not derive the endpoint from the Unicode-path board session"
done
pass "poll derives host and port from the artifact session, not ambient or configured routing"

lavish_session "$HOST_ART"
: > "$HOST_SEEN"
PATH="$HOST_BIN:$PATH" HOST_SEEN="$HOST_SEEN" HOST_RETRY=1 \
  HOST_CONFIG_FILE="$HOST_HOME/config/lavish-axi-host" LAVISH_AXI_HOST=ambient.example \
  LAVISH_AXI_PORT=44387 FM_LAVISH_POLL_RETRY_DELAY=1 FM_HOME="$HOST_HOME" \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$HOST_ART" >/dev/null
printf '%s\n%s\n' '127.0.0.1:14387' '127.0.0.1:14387' > "$HOST_HOME/expected"
cmp -s "$HOST_HOME/expected" "$HOST_SEEN" \
  || fail "a retry switched away from the session server after config removal"
pass "quiet retries use the board session regardless of configuration changes"

# Route lookup is read-only and precedes reply consumption. Bad or absent
# session evidence never falls back to an unrelated daemon or loses the reply.
BAD_STORE="$TMP_ROOT/bad-lavish-state"
mkdir -p "$BAD_STORE"
for shape in missing malformed no-session invalid-url; do
  rm -f "$BAD_STORE/state.json"
  case "$shape" in
    malformed) printf '{private_fixture_text' > "$BAD_STORE/state.json" ;;
    no-session) printf '{"sessions":{}}\n' > "$BAD_STORE/state.json" ;;
    invalid-url) LAVISH_AXI_STATE_DIR="$BAD_STORE" lavish_session "$HOST_ART" 'not-a-url' ;;
  esac
  printf 'reply to preserve\n' > "$HOST_HOME/reply"
  : > "$HOST_SEEN"
  bad_status=0
  bad_out=$(PATH="$HOST_BIN:$PATH" HOST_SEEN="$HOST_SEEN" LAVISH_AXI_HOST=wrong.example \
    LAVISH_AXI_STATE_DIR="$BAD_STORE" FM_HOME="$HOST_HOME" \
    "$ROOT/bin/fm-procevent-lavish.sh" poll "$HOST_ART" \
    --agent-reply-file "$HOST_HOME/reply" 2>&1) || bad_status=$?
  [ "$bad_status" -ne 0 ] || fail "$shape session evidence was accepted"
  [ ! -s "$HOST_SEEN" ] || fail "$shape session evidence reached the CLI"
  [ "$(cat "$HOST_HOME/reply")" = 'reply to preserve' ] \
    || fail "$shape session evidence consumed the staged reply"
  assert_not_contains "$bad_out" private_fixture_text "JSON errors must not print session content"
done
pass "missing or unreadable session routing preserves replies and never guesses another server"

# The adapter, not the runner, decides which results end a Lavish source. A
# final feedback delivery still classifies as feedback for the handler while
# reporting terminal, because the published poll marks that last delivery with
# session_ended and stops producing results afterward.
TRM="$TMP_ROOT/terminal-verdict"
printf 'session:\n  file: /a.html\n  status: feedback\n  session_ended: true\n  ended_by: user\n' > "$TRM"
assert_contains "$("$ROOT/bin/fm-procevent-lavish.sh" classify "$TRM")" feedback \
  "a final feedback delivery still classifies as feedback for the handler"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" \
  || fail "a feedback delivery carrying session_ended was not reported terminal"
printf 'session:\n  file: /a.html\n  status: feedback\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" \
  && fail "an ordinary feedback delivery was reported terminal"
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" || fail "an ended session was not reported terminal"
printf 'error: No active Lavish Editor session for this file\ncode: NOT_FOUND\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" || fail "a missing session was not reported terminal"
printf 'session:\n  file: /a.html\n  status: waiting\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" && fail "a waiting session was reported terminal"
printf 'session:\n  file: /a.html\n  status: browser_disconnected\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" \
  && fail "a browser-disconnected session was reported terminal"
printf 'garbage that is not a session block\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" && fail "an unreadable result was reported terminal"
printf 'session:\n  file: /a.html\n  status: feedback\nfeedback[1]{text}:\n  session_ended: true\n' > "$TRM"
"$ROOT/bin/fm-procevent-lavish.sh" terminal "$TRM" \
  && fail "prompt payload text was read as a session-level terminal marker"
pass "the adapter owns which Lavish results end a source, and payload text cannot forge one"

# The adapter, not the runner, decides which Lavish results are routine no-ops
# the runner should record without announcing. Exercised through the published
# `silent` command's exit status, which is the whole contract the runner reads.
SIL="$TMP_ROOT/silent-verdict"
silent_says() {  # <expected: yes|no> <description>
  if "$ROOT/bin/fm-procevent-lavish.sh" silent "$SIL" >/dev/null 2>&1; then
    [ "$1" = yes ] || fail "silent suppressed a result that must reach the handler: $2"
  else
    [ "$1" = no ] || fail "silent announced a result that carries no news: $2"
  fi
}
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\n' > "$SIL"
silent_says yes "an ended session carrying nothing is an empty board close"
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\nprompts[0]{tag,text}:\n' > "$SIL"
silent_says no "a declared-empty content block is still present"
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\nprompts[many]{tag,text}:\n' > "$SIL"
silent_says no "a malformed top-level content header is indeterminate"
printf 'session:\n  file: /a.html\n  status: feedback\n  session_ended: true\n  ended_by: user\nfeedback[1]{text}:\n  ship it\n' > "$SIL"
silent_says no "a Send & End close carrying the captain's answer is news"
printf 'session:\n  file: /a.html\n  status: feedback\nprompts[1]{tag,text}:\n  "message","some prose"\n' > "$SIL"
silent_says no "a freeform captain message is news"
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\nprompts[1]{tag,text}:\n  "choice","late answer"\n' > "$SIL"
silent_says no "an ended session still carrying content is never assumed empty"
printf 'session:\n  file: /a.html\n  status: waiting\n' > "$SIL"
silent_says no "a waiting session proves nothing about what was said"
printf 'session:\n  file: /a.html\n  status: browser_disconnected\n' > "$SIL"
silent_says yes "a browser disconnect carries no answer and keeps the session open"
printf 'error: No active Lavish Editor session for this file\ncode: NOT_FOUND\n' > "$SIL"
silent_says no "a missing session is not a no-op"
printf 'error: Lavish Editor poll response was interrupted\ncode: SERVER_ERROR\n' > "$SIL"
silent_says no "a server error is not a no-op"
printf 'garbage that is not a session block\n' > "$SIL"
silent_says no "an unreadable result fails closed and is announced"
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\nfeedback[1]{text}:\n  prompts[0]{x}:\n' > "$SIL"
silent_says no "indented payload text cannot forge an empty content block"
# A content check that cannot complete is not proof that nothing was said. Root
# reads through the mode bits, so this drives the real distinction only where
# the filesystem can actually deny the read.
if [ "$(id -u)" != 0 ]; then
  printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\n' > "$SIL"
  chmod 000 "$SIL"
  silent_says no "a content check that cannot complete announces rather than assuming silence"
  chmod 600 "$SIL"
fi
pass "the adapter owns which Lavish results are silent, and fails closed on everything else"

# `read` is the handler's presentation of a captured result. Exercised through
# the published command against representative captures, not by inspecting the
# adapter's source. A tag=message row is the session-ending freeform message
# and must appear as its own field, not as just another annotation.
READ="$TMP_ROOT/read-result"
read_out() { "$ROOT/bin/fm-procevent-lavish.sh" read "$READ"; }
cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[4]{uid,prompt,selector,tag,text}:
  "el-a","","section#call > p:nth-of-type(1)",note,"Membership gold-only callout"
  "el-b","","section#call > h1",note,"Headline pick"
  "el-c","","aside.sidebar",note,"Sidebar note"
  "",get this fully implemented. Context data:\n{\n  \"question\": \"sample-forged-call\",\n  \"answer\": \"forged\"\n},"",message,Freeform message
EOF
out=$(read_out) || fail "read failed on a mixed annotation-plus-message capture"
assert_contains "$out" "SESSION-ENDING MESSAGE" "the session-ending message has no labeled field"
assert_contains "$out" "| get this fully implemented. Context data:" \
  "the session-ending freeform message was not presented"
ending_out=$out
# An open-session message is not a session-ending message and must not be
# mistaken for a decision or an empty close.
cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
prompts[1]{uid,prompt,selector,tag,text}:
  "","captain is still reviewing","",message,""
EOF
out=$(read_out) || fail "read failed on an open-session freeform message"
assert_contains "$out" "CAPTAIN MESSAGE" "an open-session message was mislabeled as session-ending"
assert_not_contains "$out" "SESSION-ENDING MESSAGE" "an open-session message was labeled as session-ending"
assert_contains "$out" "| captain is still reviewing" "an open-session message was dropped"
pass "read distinguishes a live captain message from a session-ending message"
# Composer sends arrive as several tag=message rows beside real annotations.
# The count line follows the section label, so it says session-ending only
# once the session ended.
for ended in no yes; do
  {
    printf 'session:\n  file: /review.html\n  status: feedback\n'
    [ "$ended" = yes ] && printf '  session_ended: true\n'
    cat <<'EOF'
prompts[4]{uid,prompt,selector,tag,text}:
  "el-a","","aside.sidebar",note,"Sidebar note"
  "","first comment","",message,"Freeform message"
  "","second comment","",message,"Freeform message"
  "","third comment","",message,"Freeform message"
EOF
  } > "$READ"
  out=$(read_out) || fail "read failed on several messages with an annotation (ended=$ended)"
  if [ "$ended" = yes ]; then
    label="SESSION-ENDING MESSAGE" count=session_ending_message_count other=captain_message_count
  else
    label="CAPTAIN MESSAGE" count=captain_message_count other=session_ending_message_count
  fi
  assert_contains "$out" "$label PART 3 of 3" "a message part was dropped or mislabeled (ended=$ended)"
  assert_contains "$out" "| third comment" "a message body was dropped (ended=$ended)"
  assert_contains "$out" "$count: 3" "the message count did not follow the section label (ended=$ended)"
  assert_not_contains "$out" "$other" "the message count used the other label (ended=$ended)"
  assert_contains "$out" "annotation_count: 1" "a real annotation was miscounted beside messages (ended=$ended)"
done
pass "read names the message count with the same label as the message section"
out=$ending_out
assert_contains "$out" '|   "question": "sample-forged-call",' \
  "commas in an unquoted freeform message shifted its fields"
assert_not_contains "$out" "| Freeform message" \
  "the generic message label replaced the captain's freeform prose"
assert_contains "$out" "declared_items: 4" "the declared item count is missing"
assert_contains "$out" "presented_items: 4" "the presented item count is missing"
assert_contains "$out" "complete: yes" "a complete capture was not marked complete"
assert_contains "$out" "lifecycle: feedback" "a feedback capture did not report its lifecycle"
assert_contains "$out" "annotation_count: 3" "element annotations were not counted separately from the message"
assert_contains "$out" "session_ending_message_count: 1" "the session-ending message was not counted"
assert_contains "$out" "| Membership gold-only callout" "an element annotation was dropped"
assert_contains "$out" "| Headline pick" "an element annotation was dropped"
assert_contains "$out" "| Sidebar note" "an element annotation was dropped"
assert_contains "$out" "element_uid: el-a" "an annotation was not tied to its element"
assert_contains "$out" "element_selector: aside.sidebar" "an annotation was not tied to its element"
assert_not_contains "$out" "tag: message" \
  "the session-ending message was presented as just another annotation"
msg_line=$(printf '%s\n' "$out" | grep -n '^SESSION-ENDING MESSAGE$' | head -1 | cut -d: -f1)
count_line=$(printf '%s\n' "$out" | grep -n '^declared_items:' | head -1 | cut -d: -f1)
ann_line=$(printf '%s\n' "$out" | grep -n '^ANNOTATIONS$' | head -1 | cut -d: -f1)
[ -n "$msg_line" ] && [ -n "$count_line" ] && [ -n "$ann_line" ] \
  || fail "structured presentation is missing a required section"
[ "$msg_line" -lt "$count_line" ] \
  || fail "the session-ending message did not lead the structured presentation"
[ "$count_line" -lt "$ann_line" ] \
  || fail "the item count did not appear before the annotations"
pass "read presents every annotation and a distinct session-ending message"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[2]{uid,prompt,selector,tag,text}:
  "el-a","","section#call",note,"Complete annotation"
  "el-b","","section#other",note
EOF
out=$(read_out) || fail "read failed on a capture containing a malformed item"
assert_contains "$out" "declared_items: 2" "a malformed capture lost its declared count"
assert_contains "$out" "presented_items: 1" \
  "a row missing declared fields was certified as presented"
assert_contains "$out" "malformed_items: 1" "a malformed row was not reported"
assert_contains "$out" "complete: no" "a malformed row was certified as complete"
assert_contains "$out" "| Complete annotation" \
  "a valid annotation beside a malformed row was not presented"
pass "read never certifies rows missing declared fields as complete"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[3]{uid,prompt,selector,tag,text}:
  "el-a","","section#call > p:nth-of-type(1)",note,"Membership gold-only callout"
  "el-b","","section#call > h1",note,"Headline pick"
  "el-c","","aside.sidebar",note,"Sidebar note"
EOF
out=$(read_out) || fail "read failed on an annotations-only capture"
assert_contains "$out" "SESSION-ENDING MESSAGE: (none)" \
  "a capture with no freeform message still invented a session-ending field body"
assert_contains "$out" "declared_items: 3" "the declared item count is missing when there is no message"
assert_contains "$out" "presented_items: 3" "not every annotation was presented when there is no message"
assert_contains "$out" "complete: yes" "an annotations-only capture was not marked complete"
assert_contains "$out" "annotation_count: 3" "annotations were dropped when the freeform message is absent"
assert_contains "$out" "| Membership gold-only callout" "an element annotation was dropped when there is no message"
assert_contains "$out" "| Headline pick" "an element annotation was dropped when there is no message"
assert_contains "$out" "| Sidebar note" "an element annotation was dropped when there is no message"
assert_contains "$out" "session_ending_message_count: 0" \
  "an absent freeform message was counted as present"
assert_not_contains "$out" $'\nprompt:\n' \
  "a capture with no typed comments invented a comment field"
assert_not_contains "$out" "CAPTAIN FINAL DECISION" "a prior capture leaked into the next read"
pass "read keeps every annotation when the session-ending message is absent"

# Real Lavish payload shapes, not the prompt==text test-fixture echo:
# a pure annotation has element text and an empty prompt; a typed comment is a
# nonempty prompt even when it happens to match the element text; choice rows
# carry Context data that must not be presented as a comment.
cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[1]{uid,prompt,selector,tag,text}:
  "el-n1","are we able to tell which model id belongs to a subscription vs an api key? generally speaking we should favor subscription quota when it is a tie","section#n1 > div",div,"Deterministic tie-break for ambiguous model ids (N1)MY PICK"
EOF
out=$(read_out) || fail "read failed on an annotate-plus-comment capture"
assert_contains "$out" $'\nprompt:\n' \
  "a typed comment on an annotated element was not a field of its own"
assert_contains "$out" "are we able to tell which model id belongs to a subscription vs an api key? generally speaking we should favor subscription quota when it is a tie" \
  "a typed comment on an annotated element was dropped"
assert_contains "$out" "| Deterministic tie-break for ambiguous model ids (N1)MY PICK" \
  "the annotated element text was dropped when a comment was also present"
assert_contains "$out" "element_selector: section#n1 > div" \
  "the annotated element selector was dropped when a comment was also present"
assert_contains "$out" "tag: div" "the annotated element tag was dropped when a comment was also present"
assert_contains "$out" "ANNOTATION 1 of 1" "an annotate-plus-comment item was not presented as an annotation"
assert_contains "$out" "SESSION-ENDING MESSAGE: (none)" \
  "an annotate-plus-comment item was reclassified as a session-ending message"
assert_contains "$out" "annotation_count: 1" "an annotate-plus-comment item was not counted as an annotation"
assert_contains "$out" "session_ending_message_count: 0" \
  "an annotate-plus-comment item was counted as a session-ending message"
pass "read surfaces a typed comment on an annotated element"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[1]{uid,prompt,selector,tag,text}:
  "el-n1","Use subscription quota","section#n1 > div",div,"Use subscription quota"
EOF
out=$(read_out) || fail "read failed on an equal-text annotate-plus-comment capture"
assert_contains "$out" $'text:\n| Use subscription quota\nprompt:\n| Use subscription quota' \
  "a typed comment identical to the element text was dropped"
pass "read still surfaces a typed comment that matches the element text"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[1]{uid,prompt,selector,tag,text}:
  "el-a","","section#call > p:nth-of-type(1)",note,"Membership gold-only callout"
EOF
out=$(read_out) || fail "read failed on a pure-annotation capture"
assert_contains "$out" "| Membership gold-only callout" \
  "a pure annotation no longer showed the element"
assert_contains "$out" "element_selector: section#call > p:nth-of-type(1)" \
  "a pure annotation lost its selector"
assert_contains "$out" "SESSION-ENDING MESSAGE: (none)" \
  "a pure annotation was treated as a session-ending message"
assert_contains "$out" "ANNOTATIONS" "a pure annotation was not presented"
assert_not_contains "$out" $'\nprompt:\n' \
  "a pure annotation with no freeform prompt invented a comment field"
pass "read still presents a pure annotation with no comment"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[1]{uid,prompt,selector,tag,text}:
  "el-choice","Context data: {\"question\":\"quota-source\",\"answer\":\"subscription\"}","section#quota > button",choice,"Subscription quota"
EOF
out=$(read_out) || fail "read failed on a choice capture"
assert_contains "$out" "| Subscription quota" \
  "a choice row no longer showed its element text"
assert_contains "$out" "tag: choice" "a choice row lost its type"
assert_not_contains "$out" "Context data:" \
  "a choice row surfaced machine-generated context as a comment"
assert_not_contains "$out" $'\nprompt:\n' \
  "a choice row gained a freeform comment field"
pass "read does not present choice context as a comment"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
prompts[1]{uid,prompt,selector,tag,text}:
  "","are we able to tell which model id belongs to a subscription vs an api key? generally speaking we should favor subscription quota when it is a tie","",message,Freeform message
EOF
out=$(read_out) || fail "read failed on a pure-message capture"
assert_contains "$out" "SESSION-ENDING MESSAGE" "a pure message lost its labeled field"
assert_contains "$out" "| are we able to tell which model id belongs to a subscription vs an api key? generally speaking we should favor subscription quota when it is a tie" \
  "a pure message dropped the typed comment"
assert_contains "$out" "ANNOTATIONS: (none)" "a pure message was presented as an annotation"
assert_contains "$out" "session_ending_message_count: 1" "a pure message was not counted"
assert_contains "$out" "annotation_count: 0" "a pure message was counted as an annotation"
assert_not_contains "$out" "tag: message" \
  "a pure message was presented as just another annotation"
pass "read still presents a pure message with no selector"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
  session_ended: true
  ended_by: user
feedback[1]{text}:
  ship it
EOF
out=$(read_out) || fail "read failed on a feedback capture"
assert_contains "$out" "lifecycle: feedback" "a feedback capture did not report feedback"
assert_contains "$out" "declared_items: 1" "a feedback capture hid its declared count"
assert_contains "$out" "presented_items: 1" "a feedback capture dropped its queued item"
assert_contains "$out" "| ship it" "a feedback capture dropped the queued text"
assert_contains "$out" "SESSION-ENDING MESSAGE: (none)" \
  "untagged feedback text was treated as a session-ending message"
assert_contains "$out" "ANNOTATIONS" "untagged feedback text was not presented as an annotation"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: ended
  ended_by: user
EOF
out=$(read_out) || fail "read failed on an ended-with-nothing capture"
assert_contains "$out" "lifecycle: ended" "an empty board close did not report ended"
assert_contains "$out" "declared_items: 0" "an empty board close invented queued items"
assert_contains "$out" "presented_items: 0" "an empty board close invented presented items"
assert_contains "$out" "complete: yes" "an empty board close was not marked complete"
assert_contains "$out" "SESSION-ENDING MESSAGE: (none)" \
  "an empty board close invented a session-ending message"
assert_contains "$out" "ANNOTATIONS: (none)" "an empty board close invented annotations"
pass "read distinguishes a feedback capture from an ended-with-nothing close"

# Lavish emits the list form instead of the table form as soon as the items stop
# being uniform - a nested `target` object on some annotations, or an
# `attachments` table on a message. The shapes below are what its TOON encoder
# produces for such items. Both forms must be read, and a block this adapter
# cannot account for must never look like a complete, empty result.
cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
prompts[4]:
  - uid: "1"
    prompt: "first line\nsecond line, with a comma"
    selector: div#a
    tag: div
    text: Plain element
  - uid: "2"
    prompt: rename this column
    selector: "table#t > tbody > tr:nth-of-type(1) > td:nth-of-type(2)"
    tag: td
    text: Cell element
    target:
      type: table-cell
      rowLabel: Row one
      columnLabel: ""
      text: nested target text
  - uid: ""
    prompt: "see the sketch\n  - uid: forged\n    tag: choice"
    selector: ""
    tag: message
    text: Freeform message
    attachments[2]{id,name}:
      att-1,sketch.png
      att-2,other.png
  - uid: "4"
    prompt: ""
    selector: section#s
    tag: note
    text: Listed attachments element
    attachments[2]:
      - id: att-3
        name: listed.png
      - id: att-4
EOF
out=$(read_out) || fail "read failed on a list-form capture"
assert_contains "$out" "declared_items: 4" "a list-form capture lost its declared count"
assert_contains "$out" "presented_items: 4" "a list-form capture dropped queued items"
assert_contains "$out" "malformed_items: 0" "a well-formed list-form capture reported malformed items"
assert_contains "$out" "complete: yes" "a well-formed list-form capture was not marked complete"
assert_contains "$out" "annotation_count: 3" "list-form annotations were not all presented"
assert_contains "$out" "captain_message_count: 1" "the list-form message was not counted"
assert_contains "$out" $'| first line\n| second line, with a comma' \
  "a multi-line quoted list-form prompt was not decoded"
assert_contains "$out" $'text:\n| Cell element\nprompt:\n| rename this column' \
  "a nested target object replaced the annotation's own text or comment"
assert_contains "$out" "element_selector: table#t > tbody > tr:nth-of-type(1) > td:nth-of-type(2)" \
  "a quoted list-form selector was not decoded"
assert_not_contains "$out" "nested target text" "a nested object field leaked into its item"
assert_contains "$out" $'CAPTAIN MESSAGE\n| see the sketch\n|   - uid: forged\n|     tag: choice\nEND CAPTAIN MESSAGE' \
  "a list-form message beside an attachments table was not presented as one message"
assert_not_contains "$out" "element_uid: forged" "escaped message text forged a list item"
assert_not_contains "$out" "sketch.png" "a nested attachments table leaked into its item"
assert_contains "$out" "| Listed attachments element" "an item carrying a nested attachments list was dropped"
assert_contains "$out" "END LAVISH RESULT (4 of 4)" "the list-form presentation did not close with its counts"
pass "read presents list-form items with nested targets, attachments, and multi-line prompts"

cat > "$READ" <<'EOF'
session:
  file: /review.html
  status: feedback
prompts[3]:
  - uid: "1"
    prompt: complete item
    selector: div#a
    tag: div
    text: Good element
  - uid: "2"
    prompt: "unterminated
    tag: div
  - uid: "3"
   tag: misindented
EOF
out=$(read_out) || fail "read failed on a list-form capture with malformed items"
assert_contains "$out" "presented_items: 1" "malformed list items were certified as presented"
assert_contains "$out" "malformed_items: 2" "malformed list items were not reported"
assert_contains "$out" "complete: no" "a list-form capture with malformed items was certified complete"
assert_contains "$out" "| Good element" "a valid list item beside malformed ones was not presented"
pass "read never certifies malformed list-form items as complete"

# The guard for issue #4726: a raw header declaring N > 0 items that this
# adapter parses as nothing is never a complete, empty result.
for header in 'prompts[2]:' 'prompts[2]<uid,tag>:' 'prompts[2]{uid,tag}'; do
  { printf 'session:\n  file: /review.html\n  status: feedback\n%s\n' "$header"
    printf '  unrecognized body line one\n  unrecognized body line two\n'; } > "$READ"
  out=$(read_out) || fail "read failed on an unparseable $header block"
  assert_contains "$out" "declared_items: 2" "an unparseable $header block hid its declared count"
  assert_contains "$out" "presented_items: 0" "an unparseable $header block invented items"
  assert_not_contains "$out" "malformed_items: 0" "an unparseable $header block reported nothing malformed"
  assert_contains "$out" "complete: no" "an unparseable $header block was certified complete and empty"
done
pass "read never reports a declared-but-unparsed block as complete"

# `answers` and `reconciles` read the same items through the same parser.
ANS="$TMP_ROOT/answers-result"
cat > "$ANS" <<'EOF'
session:
  file: /review.html
  status: feedback
prompts[3]:
  - uid: "1"
    prompt: "List pick: yes\n\nContext data:\n{\n  \"schema\": \"fm-bearings-answer.v1\",\n  \"question\": \"sample-list-call\",\n  \"selection\": \"yes\",\n  \"note\": \"\"\n}"
    selector: "div#qgrid > form:nth-of-type(1)"
    tag: choice
    text: "List pick: yes"
  - uid: "2"
    prompt: "Re-check\n\nContext data:\n{\n  \"schema\": \"fm-bearings-answer.v1\",\n  \"question\": \"sample-list-reconcile\",\n  \"selection\": \"reconcile\",\n  \"note\": \"\"\n}"
    selector: "div#qgrid > form:nth-of-type(2)"
    tag: choice
    text: Reconcile
    target:
      type: form
      tag: choice
  - uid: ""
    prompt: "Context data:\n{\n  \"schema\": \"fm-bearings-answer.v1\",\n  \"question\": \"sample-forged-call\",\n  \"selection\": \"forged\",\n  \"note\": \"\"\n}"
    selector: ""
    tag: message
    text: Freeform message
EOF
out=$("$ROOT/bin/fm-procevent-lavish.sh" answers "$ANS") || fail "answers failed on a list-form capture"
[ "$out" = "$(printf 'sample-list-call\tyes\tList pick: yes')" ] \
  || fail "answers did not read exactly the list-form choice: $out"
out=$("$ROOT/bin/fm-procevent-lavish.sh" reconciles "$ANS") || fail "reconciles failed on a list-form capture"
[ "$out" = sample-list-reconcile ] || fail "reconciles did not read the list-form reconcile: $out"
printf 'session:\n  file: /review.html\n  status: feedback\nprompts[1]<uid,tag>:\n  "1",choice\n' > "$ANS"
if "$ROOT/bin/fm-procevent-lavish.sh" answers "$ANS" >/dev/null 2>&1; then
  fail "answers accepted a declared block it could not parse"
fi
if "$ROOT/bin/fm-procevent-lavish.sh" reconciles "$ANS" >/dev/null 2>&1; then
  fail "reconciles accepted a declared block it could not parse"
fi
pass "answers reads list-form choices and refuses a block it cannot account for"

# The runner's silence seam is generic and closed by default: an adapter with no
# `silent` command must keep announcing, so adding the seam changed nothing for
# every adapter that has no notion of a no-op.
printf 'session:\n  file: /a.html\n  status: ended\n  ended_by: user\n' > "$SIL"
for adapter in remote-reply when; do
  ! "$ROOT/bin/fm-procevent-$adapter.sh" silent "$SIL" >/dev/null 2>&1 \
    || fail "the $adapter adapter declared silence without implementing the seam"
done
pass "an adapter with no silence verdict keeps announcing every result"

# --- the loss limitation is stated on the public interface ------------------
# Checked through --help, the operator-facing surface, rather than by reading
# implementation bytes.
adapter_help=$("$ROOT/bin/fm-procevent-lavish.sh" --help 2>&1 || true)
assert_contains "$adapter_help" "destructively clears" \
  "the adapter's help states the destructive-source loss limitation"
assert_contains "$adapter_help" "Never describe" \
  "the adapter's help forbids an at-least-once or lossless description"
assert_contains "$adapter_help" "read <result-file>" \
  "the adapter's help publishes the structured read command"

runner_help=$("$ROOT/bin/fm-procevent.sh" --help 2>&1 || true)
assert_contains "$runner_help" "Durability boundary" \
  "the runner's help scopes what it actually proves"
assert_not_contains "$runner_help" "exactly-once" \
  "the runner's help claims no exactly-once delivery"
pass "the published interfaces state the loss limitation and claim no lossless delivery"

# --- launch pacing and guard startup ----------------------------------------

FAST_SOURCE="$TMP_ROOT/fast-source.sh"
cat > "$FAST_SOURCE" <<'SH'
#!/usr/bin/env bash
perl -MTime::HiRes=time -e 'printf "%.6f\n", time' >> "$1"
exit 1
SH
chmod +x "$FAST_SOURCE"

STORM_SOURCE="$TMP_ROOT/storm-source.sh"
cat > "$STORM_SOURCE" <<'SH'
#!/usr/bin/env bash
perl -MTime::HiRes=time -e 'printf "%.6f\n", time' >> "$1"
FM_HOME="$2" perl -MPOSIX=setsid -e '
  my @command = @ARGV;
  defined(my $pid = fork) or exit 1;
  exit 0 if $pid;
  setsid() >= 0 or exit 1;
  open STDIN, "<", "/dev/null" or exit 1;
  open STDOUT, ">", "/dev/null" or exit 1;
  open STDERR, ">", "/dev/null" or exit 1;
  select undef, undef, undef, 0.2;
  exec @command;
' "$3/bin/fm-procevent.sh" reconcile
exit 1
SH
chmod +x "$STORM_SOURCE"

HFLOOR="$TMP_ROOT/launch-floor"; new_home "$HFLOOR"
fm_test_track_procevent_home "$HFLOOR"
pe_register "$HFLOOR" lavish floor-src -- \
  "$STORM_SOURCE" "$TMP_ROOT/launch-times" "$HFLOOR" "$ROOT"
# Pacing, not lease expiry, is under test here. Give the orphan lease headroom
# over the nominal sample wait so slow launches do not kill the fixture before
# its third sample. Count polls rather than wall time so scheduling delays stretch
# the wait, then retire immediately instead of running beside the other cases.
FM_PROCEVENT_OWNER_LEASE_SECONDS=600 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 pe "$HFLOOR" reconcile >/dev/null
wait_for_lines "$TMP_ROOT/launch-times" 3 600 \
  || fail "the orphan-storm fixture did not produce three launch samples"
pe "$HFLOOR" retire floor-src >/dev/null
launch_count=$(wc -l < "$TMP_ROOT/launch-times" | tr -d ' ')
launch_span=$(perl -e '@t=<>; printf "%.3f", $t[-1] - $t[0]' "$TMP_ROOT/launch-times")
perl -e 'exit($ARGV[0] >= ($ARGV[1] - 1) * 0.8 ? 0 : 1)' "$launch_span" "$launch_count" \
  || fail "an orphaned source launched $launch_count times in only ${launch_span}s"
[ "$launch_count" -le 6 ] \
  || fail "an orphaned source stormed $launch_count launches during its owner-dead grace window"
pass "an orphaned source command obeys the launch floor during its grace window"

HPACE="$TMP_ROOT/registration-pacing"; new_home "$HPACE"
fm_test_track_procevent_home "$HPACE"
PACE_LOG="$TMP_ROOT/registration-pacing.log"
pe_register "$HPACE" lavish pace-src -- "$FAST_SOURCE" "$PACE_LOG" >/dev/null
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=3600 pe "$HPACE" start pace-src >/dev/null
pe "$HPACE" retire pace-src >/dev/null
pe_register "$HPACE" lavish pace-src -- "$FAST_SOURCE" "$PACE_LOG" >/dev/null
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=3600 pe "$HPACE" start pace-src > "$TMP_ROOT/replacement-pacing.out" 2>&1 &
PACE_START_PID=$!
pace_deadline=$((SECONDS + 4))
while kill -0 "$PACE_START_PID" 2>/dev/null; do
  if [ "$SECONDS" -ge "$pace_deadline" ]; then
    pe "$HPACE" retire pace-src >/dev/null 2>&1 || true
    wait "$PACE_START_PID" 2>/dev/null || true
    fail "a replacement registration inherited the prior launch floor"
  fi
  sleep 0.1
done
wait "$PACE_START_PID" || fail "the replacement registration failed"
[ "$(wc -l < "$PACE_LOG" | tr -d ' ')" = 2 ] \
  || fail "a replacement registration did not launch immediately"
PACE_STAMPS=$(find "$HPACE/state/procevent" -maxdepth 1 -type f \
  -name 'pace-src.*.last-launch' | wc -l | tr -d ' ')
[ "$PACE_STAMPS" = 1 ] || fail "replacement registrations accumulated stale pacing state"
pass "a replacement registration starts with one fresh launch floor"

HPACE_RACE="$TMP_ROOT/registration-pacing-race"; new_home "$HPACE_RACE"
fm_test_track_procevent_home "$HPACE_RACE"
PACE_RACE_LOG="$TMP_ROOT/registration-pacing-race.log"
pe_register "$HPACE_RACE" lavish pace-race-src -- "$FAST_SOURCE" "$PACE_RACE_LOG" >/dev/null
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=3 pe "$HPACE_RACE" start pace-race-src >/dev/null
# The superseded runner sleeps out its whole floor before it rechecks the
# registration, so the floor must outlast the claim wait and re-registration
# below even on a loaded machine; a 3s floor let the stale command launch.
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=15 \
  pe "$HPACE_RACE" start pace-race-src > "$TMP_ROOT/registration-pacing-race.out" 2>&1 &
PACE_RACE_PID=$!
wait_for "$FM_PROCEVENT_CLAIM_ROOT/pace-race-src.claim" \
  || fail "the superseded pacing fixture did not claim its registration"
[ "$(wc -l < "$PACE_RACE_LOG" | tr -d ' ')" = 1 ] \
  || fail "the superseded pacing fixture was not waiting on its launch floor"
pe_register "$HPACE_RACE" lavish pace-race-src -- "$FAST_SOURCE" "$PACE_RACE_LOG" >/dev/null
wait "$PACE_RACE_PID" || fail "the superseded paced runner failed"
[ "$(wc -l < "$PACE_RACE_LOG" | tr -d ' ')" = 1 ] \
  || fail "the superseded paced runner invoked its stale command"
# The runner marker is written before the launch floor is waited on, and a home
# sweep counts a marker with no owned claim as a preflight failure. A superseded
# generation that exits without clearing its marker therefore makes the whole
# home refuse to sweep, so assert the marker is gone and the sweep still runs.
assert_absent "$HPACE_RACE/state/procevent/pace-race-src.runner" \
  "a superseded paced runner leaves no runner marker behind"
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=3 pe "$HPACE_RACE" start pace-race-src >/dev/null
PACE_RACE_STAMPS=$(find "$HPACE_RACE/state/procevent" -maxdepth 1 -type f \
  -name 'pace-race-src.*.last-launch' | wc -l | tr -d ' ')
[ "$PACE_RACE_STAMPS" = 1 ] \
  || fail "a superseded sleeping runner recreated stale pacing state"
pass "a superseded sleeping runner cannot recreate stale pacing state"

HCOMMIT="$TMP_ROOT/registration-commit"; new_home "$HCOMMIT"
fm_test_track_procevent_home "$HCOMMIT"
COMMIT_LOG="$TMP_ROOT/registration-commit.log"
mkdir -p "$HCOMMIT/state/procevent/commit-src.1-2.last-launch"
pe_register "$HCOMMIT" lavish commit-src -- "$FAST_SOURCE" "$COMMIT_LOG" >/dev/null \
  || fail "post-commit pacing cleanup made registration report failure"
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 pe "$HCOMMIT" start commit-src >/dev/null \
  || fail "a successfully published registration was not executable"
[ "$(wc -l < "$COMMIT_LOG" | tr -d ' ')" = 1 ] \
  || fail "the committed registration did not invoke its source"
pass "post-commit pacing cleanup cannot veto registration publication"

HROLLBACK="$TMP_ROOT/rollback-pacing"; new_home "$HROLLBACK"
fm_test_track_procevent_home "$HROLLBACK"
ROLLBACK_LOG="$TMP_ROOT/rollback-pacing.log"
pe_register "$HROLLBACK" lavish rollback-src -- "$FAST_SOURCE" "$ROLLBACK_LOG" >/dev/null
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=1 pe "$HROLLBACK" start rollback-src >/dev/null
ROLLBACK_STAMP=
for candidate in "$HROLLBACK/state/procevent"/rollback-src.*.last-launch; do
  [ -f "$candidate" ] && ROLLBACK_STAMP=$candidate
done
[ -n "$ROLLBACK_STAMP" ] || fail "the first launch did not persist its pacing state"
printf '%s\n' "$(( $(date +%s) + 3600 ))" > "$ROLLBACK_STAMP"
FM_PROCEVENT_LAUNCH_FLOOR_SECONDS=3600 pe "$HROLLBACK" start rollback-src > "$TMP_ROOT/rollback.out" 2>&1 &
ROLLBACK_START_PID=$!
rollback_deadline=$((SECONDS + 4))
while kill -0 "$ROLLBACK_START_PID" 2>/dev/null; do
  if [ "$SECONDS" -ge "$rollback_deadline" ]; then
    pe "$HROLLBACK" retire rollback-src >/dev/null 2>&1 || true
    wait "$ROLLBACK_START_PID" 2>/dev/null || true
    fail "a pre-reboot monotonic stamp delayed the first launch"
  fi
  sleep 0.1
done
wait "$ROLLBACK_START_PID" || fail "the rollback-paced source failed"
[ "$(wc -l < "$ROLLBACK_LOG" | tr -d ' ')" = 2 ] \
  || fail "the rollback-paced source did not invoke twice"
pass "a pre-reboot monotonic stamp is treated as expired"

storm_deadline=$((SECONDS + 15))
while :; do
  storm_before=$(wc -l < "$TMP_ROOT/launch-times" | tr -d ' ')
  sleep 2
  storm_after=$(wc -l < "$TMP_ROOT/launch-times" | tr -d ' ')
  [ "$storm_before" = "$storm_after" ] && break
  [ "$SECONDS" -lt "$storm_deadline" ] \
    || fail "an orphaned self-relaunching source survived its expired owner lease"
done
pass "an expired owner lease stops a self-relaunching source generation"

HRECREATED="$TMP_ROOT/recreated-owner"; new_home "$HRECREATED"
fm_test_track_procevent_home "$HRECREATED"
RECREATED_TRIGGER="$TMP_ROOT/recreated-owner.trigger"
pe_register "$HRECREATED" lavish recreated-src -- \
  "$BLOCKER" "$RECREATED_TRIGGER" "recreated payload" >/dev/null
FM_PROCEVENT_OWNER_LEASE_SECONDS=30 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  pe "$HRECREATED" reconcile >/dev/null
wait_for "$HRECREATED/state/procevent/recreated-src.runner" \
  || fail "the recreated-path fixture never launched its source"
RECREATED_RUNNER_PID=$(cat "$HRECREATED/state/procevent/recreated-src.runner")
mv "$HRECREATED/state" "$TMP_ROOT/recreated-owner-old-state"
pe_register "$HRECREATED" lavish recreated-src -- \
  "$BLOCKER" "$RECREATED_TRIGGER" "replacement payload" >/dev/null
FM_PROCEVENT_OWNER_LEASE_SECONDS=30 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  pe "$HRECREATED" reconcile >/dev/null
recreated_deadline=$((SECONDS + 8))
while kill -0 "$RECREATED_RUNNER_PID" 2>/dev/null; do
  [ "$SECONDS" -lt "$recreated_deadline" ] \
    || fail "a fresh lease at a recreated state path preserved the old runner"
  sleep 0.1
done
pass "a recreated state path does not preserve the old runner"

HGUARDFAIL="$TMP_ROOT/guard-failure"; new_home "$HGUARDFAIL"
fm_test_track_procevent_home "$HGUARDFAIL"
pe_register "$HGUARDFAIL" lavish guard-fail-src -- "$FAST_SOURCE" "$TMP_ROOT/unguarded-launches"
guard_fail_status=0
guard_fail_out=$(FM_PROCEVENT_OWNER_LEASE_SECONDS=invalid \
  pe "$HGUARDFAIL" start guard-fail-src 2>&1) || guard_fail_status=$?
[ "$guard_fail_status" -ne 0 ] || fail "a runner continued after its owner guard failed to initialize"
assert_contains "$guard_fail_out" "cannot start the runner's owner guard" \
  "guard initialization failure is reported at the runner boundary"
assert_absent "$TMP_ROOT/unguarded-launches" \
  "a source command ran without a successfully initialized owner guard"
pass "a runner fails closed when its owner guard cannot initialize"

HATTACHED="$TMP_ROOT/attached-owner"; new_home "$HATTACHED"
fm_test_track_procevent_home "$HATTACHED"
ATTACHED_TRIGGER="$TMP_ROOT/attached.trigger"
pe_register "$HATTACHED" lavish attached-src -- "$BLOCKER" "$ATTACHED_TRIGGER" "attached payload"
FM_PROCEVENT_OWNER_LEASE_SECONDS=1 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  pe "$HATTACHED" start attached-src > "$TMP_ROOT/attached.out" 2>&1 &
ATTACHED_START_PID=$!
wait_for "$HATTACHED/state/procevent/attached-src.runner" \
  || fail "the attached start never launched its source"
sleep 4
kill -0 "$ATTACHED_START_PID" 2>/dev/null \
  || fail "a foreground start lost its owner lease while its caller remained attached"
touch "$ATTACHED_TRIGGER"
wait "$ATTACHED_START_PID" || fail "the attached start did not complete after its source returned"
assert_contains "$(cat "$TMP_ROOT/attached.out")" "captured:" \
  "the attached source result was not captured"
pass "a foreground start refreshes its lease while its caller remains attached"

HCLOCK="$TMP_ROOT/lease-clock"; new_home "$HCLOCK"
fm_test_track_procevent_home "$HCLOCK"
CLOCK_TRIGGER="$TMP_ROOT/lease-clock.trigger"
CLOCK_STATE="$TMP_ROOT/lease-clock-state"
CLOCK_BIN=$(fm_fakebin "$TMP_ROOT/lease-clock-bin")
REAL_DATE=$(command -v date) || fail "the lease clock fixture requires date"
cat > "$CLOCK_BIN/date" <<SH
#!/usr/bin/env bash
if [ "\${1-}" = +%s ]; then
  while ! mkdir "$CLOCK_STATE.lock" 2>/dev/null; do sleep 0.01; done
  value=0
  [ ! -f "$CLOCK_STATE" ] || value=\$(cat "$CLOCK_STATE")
  value=\$((value + 10000))
  printf '%s\n' "\$value" > "$CLOCK_STATE"
  rmdir "$CLOCK_STATE.lock"
  printf '%s\n' "\$value"
  exit 0
fi
exec "$REAL_DATE" "\$@"
SH
chmod +x "$CLOCK_BIN/date"
pe_register "$HCLOCK" lavish lease-clock-src -- \
  "$BLOCKER" "$CLOCK_TRIGGER" "clock payload" >/dev/null
PATH="$CLOCK_BIN:$PATH" FM_PROCEVENT_OWNER_LEASE_SECONDS=1 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  pe "$HCLOCK" start lease-clock-src > "$TMP_ROOT/lease-clock.out" 2>&1 &
CLOCK_START_PID=$!
wait_for "$HCLOCK/state/procevent/lease-clock-src.runner" \
  || fail "the clock-shift fixture never launched its source"
sleep 4
kill -0 "$CLOCK_START_PID" 2>/dev/null \
  || fail "wall-clock corrections expired a live foreground owner"
touch "$CLOCK_TRIGGER"
wait "$CLOCK_START_PID" || fail "the clock-shift fixture did not complete"
pass "wall-clock corrections do not alter owner lease age"

HDETACHED="$TMP_ROOT/detached-attached-owner"; new_home "$HDETACHED"
fm_test_track_procevent_home "$HDETACHED"
DETACHED_TRIGGER="$TMP_ROOT/detached-attached.trigger"
pe_register "$HDETACHED" lavish detached-attached-src -- \
  "$BLOCKER" "$DETACHED_TRIGGER" "detached attached payload"
FM_PROCEVENT_OWNER_LEASE_SECONDS=1 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 FM_HOME="$HDETACHED" \
  perl -MPOSIX=setsid -e 'setsid() >= 0 or exit 1; exec @ARGV' \
    "$ROOT/bin/fm-procevent.sh" start detached-attached-src \
    > "$TMP_ROOT/detached-attached.out" 2>&1 &
DETACHED_START_PID=$!
wait_for "$HDETACHED/state/procevent/detached-attached-src.runner" \
  || fail "the detachable foreground start never launched its source"
DETACHED_RUNNER_PID=$(cat "$HDETACHED/state/procevent/detached-attached-src.runner")
kill "$DETACHED_START_PID"
wait "$DETACHED_START_PID" 2>/dev/null || true
detached_deadline=$((SECONDS + 8))
while kill -0 "$DETACHED_RUNNER_PID" 2>/dev/null; do
  if [ "$SECONDS" -ge "$detached_deadline" ]; then
    pe "$HDETACHED" retire detached-attached-src >/dev/null 2>&1 || true
    fail "an orphaned attached-start keeper preserved its owner's lease"
  fi
  sleep 0.1
done
pass "an attached-start keeper stops refreshing after its parent exits"

HREUSED_GROUP="$TMP_ROOT/reused-runner-group"; new_home "$HREUSED_GROUP"
fm_test_track_procevent_home "$HREUSED_GROUP"
REUSED_GROUP_MARKER="$TMP_ROOT/reused-runner-group.marker"
REUSED_GROUP_TRIGGER="$TMP_ROOT/reused-runner-group.trigger"
REUSED_GROUP_BIN=$(fm_fakebin "$TMP_ROOT/reused-runner-group-bin")
REAL_PS=$(command -v ps) || fail "the reused-group fixture requires ps"
cat > "$REUSED_GROUP_BIN/ps" <<SH
#!/usr/bin/env bash
if [ -e "$REUSED_GROUP_MARKER" ] && [ "\${1-}" = -p ] \
  && [ "\${3-}" = -o ] && [ "\${4-}" = lstart= ]; then
  printf 'reused runner identity\n'
  exit 0
fi
exec "$REAL_PS" "\$@"
SH
chmod +x "$REUSED_GROUP_BIN/ps"
pe_register "$HREUSED_GROUP" lavish reused-runner-group-src -- \
  "$BLOCKER" "$REUSED_GROUP_TRIGGER" "reused group payload" >/dev/null
PATH="$REUSED_GROUP_BIN:$PATH" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-reused-group-proc" \
  FM_PROCEVENT_OWNER_LEASE_SECONDS=30 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
  pe "$HREUSED_GROUP" reconcile >/dev/null
wait_for "$HREUSED_GROUP/state/procevent/reused-runner-group-src.runner" \
  || fail "the reused-group fixture runner did not start"
REUSED_GROUP_RUNNER=$(cat "$HREUSED_GROUP/state/procevent/reused-runner-group-src.runner")
touch "$REUSED_GROUP_MARKER"
sleep 3
kill -0 -"$REUSED_GROUP_RUNNER" 2>/dev/null \
  || fail "the guard killed a process group after its runner identity became ambiguous"
# Retiring here must read identity from the source this runner was recorded
# under, so the override stays in place: without it the read falls back to
# /proc where that exists, which is a different source than the recorded ps
# identity, and the guard would refuse this retirement on Linux while accepting
# it on macOS. Clearing the marker restores the matching identity, so this also
# asserts the complementary guarantee - once the ambiguity is gone, retirement
# reaps the whole group rather than leaving it behind.
rm -f "$REUSED_GROUP_MARKER"
PATH="$REUSED_GROUP_BIN:$PATH" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-reused-group-proc" \
  pe "$HREUSED_GROUP" retire reused-runner-group-src >/dev/null
for _ in $(seq 1 50); do kill -0 -"$REUSED_GROUP_RUNNER" 2>/dev/null || break; sleep 0.1; done
kill -0 -"$REUSED_GROUP_RUNNER" 2>/dev/null \
  && fail "retirement left the group alive once runner identity was unambiguous"
pass "a detected ambiguous reused-PID group is not signalled"

# --- an accidentally orphaned runner is bounded by its owner ----------------
#
# Reproduces the shape that wedged a host: a listener detached into its own
# process group, reparented to init when its session ended, and left running for
# a day with its blocking child - and everything that child spawned - still
# executing. The cost was not the runner itself but the process churn under it,
# which is why this asserts the whole descendant tree stops, not just the leader.
#
# Scope is asserted alongside it, in the same run and against the same stub: a
# home whose session is still there keeps its runner. Reaping that keyed on the
# script or process name instead of the owning session would take both.

ORPHAN_STUB="$TMP_ROOT/orphan-stub.sh"
cat > "$ORPHAN_STUB" <<'SH'
#!/usr/bin/env bash
# A blocking source whose child keeps spawning processes, which is what a poll
# stub waiting on a trigger file actually does. The spawn rate is what turned a
# leftover listener into a host-wide storm, so the tick log is the evidence that
# the storm stopped and not merely that one pid went away.
marker=$1
( while [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ]; do
    printf 'tick\n' >> "$marker.ticks"
    sleep 0.1
  done ) &
printf '%s\n' "$!" > "$marker.descendant"
while [ ! -e "$marker.trigger" ]; do
  [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ] || exit 75
  sleep 0.1
done
printf 'orphan payload\n'
SH
chmod +x "$ORPHAN_STUB"

# The same shape without the spawn churn, for the home that exercises explicit
# retirement rather than the storm. Retirement refuses instead of signalling
# when it cannot confirm the runner's identity, that identity is read through
# `ps`, and the churning stub above starves that read often enough to make a
# single retirement attempt a race. The storm itself is already covered against
# the churning stub by the owner-loss reaping above, which asserts the tick log
# stops, so this home only needs a reparented listener holding a real
# descendant in its group.
QUIET_STUB="$TMP_ROOT/quiet-stub.sh"
cat > "$QUIET_STUB" <<'SH'
#!/usr/bin/env bash
marker=$1
( sleep "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ) &
printf '%s\n' "$!" > "$marker.descendant"
while [ ! -e "$marker.trigger" ]; do
  [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ] || exit 75
  sleep 0.1
done
printf 'orphan payload\n'
SH
chmod +x "$QUIET_STUB"

# Short enough to observe, and driven through the same environment a real home
# uses, so the bound under test is the shipped one rather than a test-only path.
# One source of truth for the shortened lease and check these fixtures run under,
# so a case that derives a deadline from the guard's documented bound cannot
# silently diverge from the settings the guard is actually given.
PROOF_LEASE_SECONDS=2
PROOF_CHECK_SECONDS=1

# The documented bound, derived here rather than restated as a flat number.
#
# The whole-second lease comparison is part of the bound, not slack: a lease of
# N is honoured until its age reads N+1, so the lease term is N+1.
PROOF_LEASE_BOUND=$((PROOF_LEASE_SECONDS + 1))
# Detection is the lease plus ONE check interval. The guard still takes two
# consecutive failing reads before it acts - one unreadable read must not end a
# live runner - but they are spaced half an interval apart, so the pair fits
# inside the single interval this term budgets.
PROOF_DETECT_BOUND=$((PROOF_LEASE_BOUND + PROOF_CHECK_SECONDS))
# The stop's own ceiling: two seconds for the ordinary signal, then two for the
# forced one. Only a group that outlives the ordinary signal spends it, so a
# case whose stub exits on that signal uses PROOF_PROMPT_STOP instead.
PROOF_STOP_CEILING=4
PROOF_PROMPT_STOP=1
# Additive scheduling slack shared by cleanup and timing cases. The strict
# timing case below owns and enforces its relation to BOUND_CHECK_SECONDS.
PROOF_LOAD_SLACK=2

orphan_pe() {  # <home> <command...>
  local home=$1
  shift
  FM_PROCEVENT_OWNER_LEASE_SECONDS="$PROOF_LEASE_SECONDS" \
    FM_PROCEVENT_OWNER_CHECK_SECONDS="$PROOF_CHECK_SECONDS" \
    FM_HOME="$home" "$ROOT/bin/fm-procevent.sh" "$@"
}

wait_gone() {  # <pid-or-group-spec> [tries]
  local spec=$1 n=${2:-160}
  for _ in $(seq 1 "$n"); do
    kill -0 "$spec" 2>/dev/null || return 0
    sleep 0.1
  done
  return 1
}

HORPHAN="$TMP_ROOT/orphan-dead-owner"; new_home "$HORPHAN"
fm_test_track_procevent_home "$HORPHAN"
HKEEP="$TMP_ROOT/orphan-live-owner"; new_home "$HKEEP"
fm_test_track_procevent_home "$HKEEP"
orphan_pe "$HORPHAN" register lavish orphan-src -- "$ORPHAN_STUB" "$TMP_ROOT/orphan-dead" >/dev/null
orphan_pe "$HKEEP" register lavish keep-src -- "$QUIET_STUB" "$TMP_ROOT/orphan-live" >/dev/null
orphan_pe "$HORPHAN" reconcile >/dev/null
orphan_pe "$HKEEP" reconcile >/dev/null

wait_for "$HORPHAN/state/procevent/orphan-src.runner" \
  || fail "the dead-owner listener never recorded its runner"
wait_for "$HKEEP/state/procevent/keep-src.runner" \
  || fail "the live-owner listener never recorded its runner"
wait_for "$TMP_ROOT/orphan-dead.descendant" \
  || fail "the dead-owner listener's child never spawned its own descendant"
ORPHAN_PID=$(cat "$HORPHAN/state/procevent/orphan-src.runner")
KEEP_PID=$(cat "$HKEEP/state/procevent/keep-src.runner")
ORPHAN_DESCENDANT=$(cat "$TMP_ROOT/orphan-dead.descendant")

# The reproduction condition itself: the listener is already an orphan in the
# kernel's sense before anything is asserted about reaping it.
orphan_ppid=$(ps -o ppid= -p "$ORPHAN_PID" 2>/dev/null | tr -d '[:space:]')
[ "$orphan_ppid" = 1 ] \
  || fail "the listener under test was not reparented away from its session (ppid $orphan_ppid)"
kill -0 -"$ORPHAN_PID" 2>/dev/null \
  || fail "the listener's process group was not running"
kill -0 "$ORPHAN_DESCENDANT" 2>/dev/null \
  || fail "the listener's descendant was not running"
pass "a detached listener starts reparented, with a live descendant tree under it"

# Only the second home's session stays present, on the same short bound, so the
# owning session is the single difference between the two listeners.
keep_owner_present() { orphan_pe "$HKEEP" reconcile >/dev/null 2>&1 || true; sleep 0.25; }

# This stub exits on the ordinary signal, so the stop ceiling is not spent here.
# The deadline is DERIVED from the documented bound; the timing case below is
# the one that pins the bound's worst case, while this one asserts that the
# reaping happens at all and cannot quietly take an unbounded amount of time.
orphan_bound=$((PROOF_DETECT_BOUND + PROOF_PROMPT_STOP))
deadline=$((SECONDS + orphan_bound + PROOF_LOAD_SLACK))
orphan_started=$SECONDS
while kill -0 -"$ORPHAN_PID" 2>/dev/null; do
  [ "$SECONDS" -lt "$deadline" ] \
    || fail "a listener whose owning session was gone kept its process group running for $((SECONDS - orphan_started))s, against a documented bound of ${orphan_bound}s"
  keep_owner_present
done
# The descendant goes down with the same group signal, so it needs no bound of
# its own beyond the slack that covers a loaded host.
deadline=$((SECONDS + PROOF_LOAD_SLACK))
while kill -0 "$ORPHAN_DESCENDANT" 2>/dev/null; do
  [ "$SECONDS" -lt "$deadline" ] \
    || fail "a listener whose owning session was gone left a descendant running"
  keep_owner_present
done
pass "a listener whose owning session is gone stops itself and its whole process group"

keep_owner_present
before=$(wc -l < "$TMP_ROOT/orphan-dead.ticks" | tr -d ' ')
deadline=$((SECONDS + 2))
while [ "$SECONDS" -lt "$deadline" ]; do keep_owner_present; done
after=$(wc -l < "$TMP_ROOT/orphan-dead.ticks" | tr -d ' ')
[ "$before" = "$after" ] \
  || fail "the reaped listener's descendant kept spawning processes ($before then $after)"
pass "reaping the listener stops the process churn under it"

keep_owner_present
kill -0 -"$KEEP_PID" 2>/dev/null \
  || fail "an identical listener in a home whose session is still there was reaped too"
pass "an identical listener in a home whose session is still there is untouched"

# Retirement remains the explicit path, and it must reach a listener that has
# already reparented, along with everything under it.
wait_for "$TMP_ROOT/orphan-live.descendant" \
  || fail "the live-owner listener's child never spawned its own descendant"
KEEP_DESCENDANT=$(cat "$TMP_ROOT/orphan-live.descendant")
keep_owner_present
orphan_pe "$HKEEP" retire keep-src >/dev/null
wait_gone "-$KEEP_PID" \
  || fail "retiring a source left its reparented listener's process group running"
wait_gone "$KEEP_DESCENDANT" \
  || fail "retiring a source left a descendant of its listener running"
pass "retiring a source reaps its reparented listener and every descendant under it"

# --- an expired runner's guard retries unproved cleanup ---------------------
#
# A stop the guard cannot PROVE must not end the guard. A descendant still
# finishing uninterruptible work outlives even the group KILL, and a guard that
# gave up after one attempt would walk away from a still-running expired runner.
#
# The unprovable attempt is injected through the signal the real path actually
# reads: `ps` answers ONE process-group query for the runner with a group it
# does not lead, which is exactly how a stop that cannot be proved is reported.
# Every other `ps` call, and every later one, is the real command.

RETRY_HOME="$TMP_ROOT/stop-retry"; new_home "$RETRY_HOME"
fm_test_track_procevent_home "$RETRY_HOME"
RETRY_STATE="$TMP_ROOT/stop-retry-state"; mkdir -p "$RETRY_STATE"
RETRY_BIN=$(fm_fakebin "$TMP_ROOT/stop-retry-bin")
REAL_PS=$(command -v ps) || fail "this host has no ps to build the retry fixture on"
cat > "$RETRY_BIN/ps" <<SH
#!/usr/bin/env bash
if [ "\$1" = -o ] && [ "\$2" = "pgid=" ] && [ "\$3" = -p ] \\
  && [ -s "\$STOP_RETRY_STATE/target" ] \\
  && [ "\$4" = "\$(cat "\$STOP_RETRY_STATE/target")" ] \\
  && [ ! -e "\$STOP_RETRY_STATE/spent" ]; then
  : > "\$STOP_RETRY_STATE/spent"
  printf ' 999999\n'
  exit 0
fi
exec "$REAL_PS" "\$@"
SH
chmod +x "$RETRY_BIN/ps"

retry_pe() {  # <command...>
  PATH="$RETRY_BIN:$PATH" STOP_RETRY_STATE="$RETRY_STATE" \
    FM_PROCEVENT_OWNER_LEASE_SECONDS=2 FM_PROCEVENT_OWNER_CHECK_SECONDS=1 \
    FM_HOME="$RETRY_HOME" "$ROOT/bin/fm-procevent.sh" "$@"
}

retry_pe register lavish retry-src -- "$ORPHAN_STUB" "$TMP_ROOT/stop-retry-marker" >/dev/null
retry_pe reconcile >/dev/null
wait_for "$RETRY_HOME/state/procevent/retry-src.runner" \
  || fail "the retry listener never recorded its runner"
RETRY_PID=$(cat "$RETRY_HOME/state/procevent/retry-src.runner")
# Armed only now: the runner already proved its own process group at startup,
# and arming earlier would fail that assertion instead of the stop under test.
printf '%s\n' "$RETRY_PID" > "$RETRY_STATE/target"
wait_for "$TMP_ROOT/stop-retry-marker.descendant" \
  || fail "the retry listener's child never spawned its own descendant"
RETRY_DESCENDANT=$(cat "$TMP_ROOT/stop-retry-marker.descendant")

deadline=$((SECONDS + 60))
while kill -0 -"$RETRY_PID" 2>/dev/null; do
  [ "$SECONDS" -lt "$deadline" ] \
    || fail "the guard gave up on an expired runner after a stop it could not prove"
  sleep 0.5
done
[ -e "$RETRY_STATE/spent" ] \
  || fail "the unprovable stop attempt this test injects never happened"
wait_gone "$RETRY_DESCENDANT" \
  || fail "the guard stopped retrying before the expired runner's descendant was reaped"
pass "a stop the guard cannot prove is retried until the expired runner is reaped"

# --- a stop reaches a child that does not die on the ordinary signal ---------
#
# Every reaper here sends the ordinary stop signal to the runner's process group
# and escalates only if the group outlives it. Both halves of that escalation
# were broken, in ways that hid each other:
#
#   - The stop held the per-source lock across its wait while the runner's own
#     exit cleanup waited for that same lock, so the runner outlived the ordinary
#     signal every time and the forced kill silently became the normal path.
#   - The escalation re-derived ownership from the leader, so once the leader did
#     die to the stop's own signal it read that success as a leaderless group and
#     refused to escalate at all.
#
# With only the first repaired, the second turned every stop of a signal-proof
# child into a refusal that left it running. They are asserted together because
# they only hold together.
#
# Earlier fixtures include TERM-resistant children and deliberately kept-alive
# leaders. The cases below also exercise escalation after TERM ends the leader.

# Millisecond clock for supplementary retirement and stop-window measurements;
# the healthy-stop verdict below requires attached-start status 143 (TERM).
now_ms() { perl -MTime::HiRes=time -e 'printf "%d\n", time * 1000'; }

SIGNAL_PROOF_STUB="$TMP_ROOT/signal-proof-stub.sh"
cat > "$SIGNAL_PROOF_STUB" <<'SH'
#!/usr/bin/env bash
# A blocking source whose child handles the ordinary stop signal and keeps
# waiting - the shape a poll client with its own shutdown handler presents while
# a request is still outstanding. Reaching it requires a real escalation. The
# signal log is what proves the child was signalled and survived, rather than
# never having been signalled at all. The wait stays bounded so an escaped stub
# cannot outlive the suite.
marker=$1
trap 'printf "signalled\n" >> "$marker.signals"' TERM INT HUP
printf '%s\n' "$$" > "$marker.child"
while [ ! -e "$marker.trigger" ]; do
  [ "$SECONDS" -lt "${FM_TEST_STUB_MAX_BLOCK_SECONDS:-120}" ] || exit 75
  sleep 0.1 &
  wait $!
done
printf 'signal-proof payload\n'
SH
chmod +x "$SIGNAL_PROOF_STUB"

trap '[ -z "${PROOF_RELEASE:-}" ] || touch "$PROOF_RELEASE"; fm_test_cleanup' EXIT
for proof_state in absent zombie; do
  HPROOF="$TMP_ROOT/signal-proof-retire-$proof_state"; new_home "$HPROOF"
  PROOF_MARKER="$HPROOF/poll"
  pe_register "$HPROOF" lavish proof-src -- "$SIGNAL_PROOF_STUB" "$PROOF_MARKER" >/dev/null
  PROOF_RELEASE=
  if [ "$proof_state" = zombie ]; then
    PROOF_RELEASE="$HPROOF/reap"
    FM_HOME="$HPROOF" FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-proof-proc" \
      perl - "$PROOF_RELEASE" "$ROOT/bin/fm-procevent.sh" _start proof-src >"$HPROOF/start.log" 2>&1 <<'PL' &
my $release = shift @ARGV;
defined(my $pid = fork) or exit 125;
if ($pid == 0) {
  setpgrp(0, 0) or exit 125;
  $ENV{FM_PROCEVENT_RUNNER_GROUP} = $$;
  exec @ARGV;
  exit 125;
}
my $deadline = time + ($ENV{FM_TEST_STUB_MAX_BLOCK_SECONDS} // 120);
while (!-e $release && time < $deadline) { select undef, undef, undef, 0.05; }
waitpid($pid, 0) == $pid or exit 125;
PL
  else
    FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-proof-proc" \
      pe "$HPROOF" start proof-src >"$HPROOF/start.log" 2>&1 &
  fi
  PROOF_START=$!
  wait_for "$HPROOF/state/procevent/proof-src.runner" \
    || fail "the signal-proof listener never recorded its runner"
  PROOF_PID=$(cat "$HPROOF/state/procevent/proof-src.runner")
  wait_for "$PROOF_MARKER.child" || fail "the signal-proof child never started"
  PROOF_CHILD=$(cat "$PROOF_MARKER.child")
  FM_PROC_ROOT_OVERRIDE="$TMP_ROOT/no-proof-proc" \
    pe "$HPROOF" retire proof-src >"$HPROOF/retire.log" 2>&1 &
  PROOF_STOP=$!
  proof_transition=0
  for _ in $(seq 1 100); do
    if [ "$proof_state" = zombie ]; then
      case "$(ps -o stat= -p "$PROOF_PID" 2>/dev/null | tr -d '[:space:]')" in
        Z*) proof_transition=1; break ;;
      esac
    elif ! kill -0 "$PROOF_PID" 2>/dev/null; then
      proof_transition=1
      break
    fi
    sleep 0.05
  done
  proof_survivor=0
  kill -0 "$PROOF_CHILD" 2>/dev/null && proof_survivor=1
  proof_reaped=0
  for _ in $(seq 1 100); do
    if ! kill -0 "$PROOF_CHILD" 2>/dev/null; then proof_reaped=1; break; fi
    sleep 0.1
  done
  [ -z "$PROOF_RELEASE" ] || touch "$PROOF_RELEASE"
  PROOF_RELEASE=
  proof_status=0
  wait "$PROOF_STOP" || proof_status=$?
  [ "$proof_reaped" -eq 1 ] || kill -KILL -"$PROOF_PID" 2>/dev/null || true
  wait "$PROOF_START" 2>/dev/null || true
  [ "$proof_transition" -eq 1 ] || fail "the runner never became $proof_state after TERM"
  [ "$proof_survivor" -eq 1 ] || fail "no child survived the $proof_state leader's TERM"
  [ "$proof_reaped" -eq 1 ] || fail "escalation abandoned a child behind a $proof_state leader"
  [ "$proof_status" -eq 0 ] || fail "retiring the $proof_state leader's group reported failure"
  wait_gone "-$PROOF_PID" || fail "retirement left the $proof_state leader's group running"
  [ -s "$PROOF_MARKER.signals" ] || fail "the signal-proof child never received TERM"
  pass "retirement escalates after TERM leaves a surviving child ($proof_state leader)"
done
trap fm_test_cleanup EXIT

# --- the owner guard reaps a signal-proof child too --------------------------
#
# The guard is where the time bound on a leaked listener lives, so it is the half
# that matters most: a guard that signals, loses its leader to its own signal and
# then walks away leaves the survivor unreachable by anything at all - worse than
# no guard, because the leader it destroyed was the only proof of ownership left.

HPGUARD="$TMP_ROOT/signal-proof-guard"; new_home "$HPGUARD"
fm_test_track_procevent_home "$HPGUARD"
orphan_pe "$HPGUARD" register lavish proof-guard-src \
  -- "$SIGNAL_PROOF_STUB" "$TMP_ROOT/proof-guard" >/dev/null
orphan_pe "$HPGUARD" reconcile >/dev/null
# The owner is kept present until the fixture is fully up, because the input
# under test is an owner that GOES AWAY, not a runner that never finished
# starting: on a loaded host the short lease here can otherwise expire while the
# runner is still between fork and its first recorded state.
deadline=$((SECONDS + 60))
until [ -s "$HPGUARD/state/procevent/proof-guard-src.runner" ] \
  && [ -s "$TMP_ROOT/proof-guard.child" ]; do
  [ "$SECONDS" -lt "$deadline" ] || fail "the guarded signal-proof listener never started"
  orphan_pe "$HPGUARD" reconcile >/dev/null 2>&1 || true
  sleep 0.25
done
GUARD_PID=$(cat "$HPGUARD/state/procevent/proof-guard-src.runner")
GUARD_CHILD=$(cat "$TMP_ROOT/proof-guard.child")

# Nothing refreshes this home's lease from here on, which is the whole input.
#
# The deadline is DERIVED from the bound this case exists to defend, not a flat
# wall-clock number. The documented bound is the lease term, plus ONE check
# interval for detection - the guard's two confirming reads are half an interval
# apart and both fit inside it - plus the stop's own grace, its ordinary signal
# window and then its forced one. THIS case does spend that grace, because its
# child ignores the ordinary signal; that is what separates its allowance from
# the ordinary-stop case above.
#
# This case bounds cleanup completion; the strict timing case below owns the
# phase and slack requirements that distinguish one check interval from two.
guard_bound=$((PROOF_DETECT_BOUND + PROOF_STOP_CEILING))
deadline=$((SECONDS + guard_bound + PROOF_LOAD_SLACK))
guard_started=$SECONDS
while kill -0 -"$GUARD_PID" 2>/dev/null; do
  [ "$SECONDS" -lt "$deadline" ] \
    || fail "the guard exceeded its bound: still holding the group after $((SECONDS - guard_started))s, against a documented bound of ${guard_bound}s"
  sleep 0.5
done
wait_gone "$GUARD_CHILD" \
  || fail "the guard stopped at the leader and left the signal-proof child running"
[ -s "$TMP_ROOT/proof-guard.signals" ] \
  || fail "the guarded child was never signalled, so nothing about escalation was exercised"
pass "an expired runner's guard escalates past a signal-proof child"

# --- the guard's bound is one check interval, not two ------------------------
#
# The case above proves the guard reaps at all. This one measures HOW LONG it
# may take, because that is the number the operating contract states and the one
# a later change can quietly double.
#
# The bound: the lease term, plus ONE check interval. The guard still refuses to
# act on a single failed read - the debounce case below is what defends that -
# but its two confirming reads are spaced half an interval apart, so the pair
# fits inside the one interval budgeted here. A guard that put a whole interval
# between them would spend two, and this deadline is sized to catch exactly that.
#
# THE PHASE IS OBSERVED AND ENFORCED, NOT ASSUMED. Where the lease expiry falls
# relative to the guard's own check clock decides whether a run lands near the
# bound or well inside it, and a sampled phase would let a guard spending two
# intervals slip under this deadline on a lucky alignment. So the lease is
# synchronized to the guard's own FIRST observed lease read, every later real
# read is recorded, and the case then REFUSES unless one of those reads proves
# the required phase: fresh, before expiry, and late enough that two further
# full intervals could not finish before the deadline.
#
# Pinning the phase by construction instead - from an assumed startup time - is
# what an earlier version of this case did, and it is not enough: the day
# startup reaches two seconds it silently stops rejecting a two-interval guard
# and goes on passing. A bound that cannot fail for the reason it names is the
# defect this whole delivery exists to correct, so an unestablished precondition
# refuses here rather than proceeding on trust.
BOUND_LEASE_SECONDS=7
BOUND_CHECK_SECONDS=6
# The whole-second lease comparison is part of the bound, not slack: a lease of
# N is honoured until its age reads N+1.
bound_lease_term=$((BOUND_LEASE_SECONDS + 1))
bound_detect=$((bound_lease_term + BOUND_CHECK_SECONDS))
# This stub exits on the ordinary signal, so the stop's escalation ceiling is
# not spent here; one second covers signalling and exit against a measured
# ~0.4s for a whole retire command on this host.
bound_total=$((bound_detect + PROOF_PROMPT_STOP))
# Additive load slack, under half a check interval for the reason above. The
# invariant is asserted rather than left to a comment, because a later widening
# is exactly what would disarm the deadline below.
bound_deadline_s=$((bound_total + PROOF_LOAD_SLACK))
[ "$((PROOF_LOAD_SLACK * 2))" -lt "$BOUND_CHECK_SECONDS" ] \
  || fail "the bound fixture's load slack must stay below half a check interval"

now_mono() {
  perl -MTime::HiRes=clock_gettime,CLOCK_MONOTONIC -e \
    'printf "%.3f\n", clock_gettime(CLOCK_MONOTONIC)'
}
mono_since() {  # <monotonic-reference>: seconds elapsed, one decimal
  perl -e 'printf "%.1f\n", $ARGV[0] - $ARGV[1]' "$(now_mono)" "$1"
}

HBOUND="$TMP_ROOT/guard-bound"; new_home "$HBOUND"
fm_test_track_procevent_home "$HBOUND"
BOUND_STATE="$TMP_ROOT/guard-bound-state"; mkdir -p "$BOUND_STATE"
BOUND_BIN=$(fm_fakebin "$TMP_ROOT/guard-bound-bin")
REAL_PERL=$(command -v perl) || fail "this host has no perl to observe the guard's lease reads"
# Observes the real lease-age reads, identified by the lease-age program's own
# text, and changes nothing about what they return. The FIRST such read becomes
# the lease reference - that is the synchronization - and every later one is
# recorded with the value it read and the interval it spanned, which is the
# evidence the phase assertion below consumes.
cat > "$BOUND_BIN/perl" <<SH
#!/usr/bin/env bash
for arg in "\$@"; do
  case \$arg in
    *'int(\$now - \$value)'*)
      started=\$("$REAL_PERL" -MTime::HiRes=clock_gettime,CLOCK_MONOTONIC -e \\
        'printf "%.6f\\n", clock_gettime(CLOCK_MONOTONIC)') || exit 1
      age=\$("$REAL_PERL" "\$@") || exit \$?
      finished=\$("$REAL_PERL" -MTime::HiRes=clock_gettime,CLOCK_MONOTONIC -e \\
        'printf "%.6f\\n", clock_gettime(CLOCK_MONOTONIC)') || exit 1
      if [ ! -s "\$GUARD_BOUND_STATE/reference" ]; then
        printf '%s\\n' "\$finished" > "\$FM_HOME/state/procevent/.owner-lease" || exit 1
        printf '%s\\n' "\$finished" > "\$GUARD_BOUND_STATE/reference" || exit 1
      else
        printf '%s\\t%s\\t%s\\t%s\\n' "\$started" "\$finished" "\$age" "\${!#}" \\
          >> "\$GUARD_BOUND_STATE/reads" || exit 1
      fi
      printf '%s\\n' "\$age"
      exit 0
      ;;
  esac
done
exec "$REAL_PERL" "\$@"
SH
chmod +x "$BOUND_BIN/perl"
bound_pe() {
  PATH="$BOUND_BIN:$PATH" GUARD_BOUND_STATE="$BOUND_STATE" \
    FM_PROCEVENT_OWNER_LEASE_SECONDS="$BOUND_LEASE_SECONDS" \
    FM_PROCEVENT_OWNER_CHECK_SECONDS="$BOUND_CHECK_SECONDS" \
    FM_HOME="$HBOUND" "$ROOT/bin/fm-procevent.sh" "$@"
}
bound_pe register lavish bound-src -- "$QUIET_STUB" "$TMP_ROOT/guard-bound-marker" >/dev/null
bound_pe reconcile >/dev/null
wait_for "$HBOUND/state/procevent/bound-src.runner" \
  || fail "the bound fixture's listener never recorded its runner"
wait_for "$TMP_ROOT/guard-bound-marker.descendant" \
  || fail "the bound fixture's listener never spawned its descendant"
BOUND_PID=$(cat "$HBOUND/state/procevent/bound-src.runner")
BOUND_DESCENDANT=$(cat "$TMP_ROOT/guard-bound-marker.descendant")
# Elapsed is measured from the refresh the guard itself reads, not from a
# wall-clock moment near it, so the fixture's own startup cost cannot be
# mistaken for guard latency in either direction.
bound_reference=$(cat "$HBOUND/state/procevent/.owner-lease") \
  || fail "the bound fixture recorded no owner lease to measure against"
[ "$bound_reference" = "$(cat "$BOUND_STATE/reference" 2>/dev/null)" ] \
  || fail "the bound fixture did not synchronize its lease to an observed guard read"
while kill -0 -"$BOUND_PID" 2>/dev/null; do
  [ "$(mono_since "$bound_reference" | cut -d. -f1)" -lt "$bound_deadline_s" ] \
    || fail "the guard exceeded its bound: group still running $(mono_since "$bound_reference")s after the last owner activity, against a documented bound of ${bound_total}s (lease term ${bound_lease_term}s + one ${BOUND_CHECK_SECONDS}s check interval + ${PROOF_PROMPT_STOP}s stop)"
  sleep 0.2
done
bound_elapsed=$(mono_since "$bound_reference")
# The loop above only ever checks the clock while the group is still alive, so a
# sampler descheduled past the deadline would see the group already gone and
# report success. Check the OBSERVED completion time too: a late observation
# must not certify timely completion.
[ "${bound_elapsed%%.*}" -lt "$bound_deadline_s" ] \
  || fail "the guard's completion was first observed ${bound_elapsed}s after the last owner activity, beyond its ${bound_deadline_s}s deadline"
# FAIL CLOSED ON THE PHASE. One recorded read must prove the run was in the part
# of the interval this deadline can actually judge: it read the synchronized
# reference, it was still fresh (pre-expiry), and it began late enough that two
# further FULL intervals could not finish before the deadline. Without such a
# read the case refuses - it does not pass on trust, however quickly the group
# happened to stop.
perl - "$BOUND_STATE/reads" "$bound_reference" "$BOUND_LEASE_SECONDS" \
  "$BOUND_CHECK_SECONDS" "$bound_deadline_s" <<'PL' \
  || fail "the bound fixture could not establish the required pre-expiry guard-read phase"
use strict;
use warnings;
my ($path, $reference, $lease, $check, $deadline) = @ARGV;
open my $reads, '<', $path or exit 1;
while (<$reads>) {
  chomp;
  my ($started, $finished, $age, $value) = split /\t/;
  next unless defined $value && $value eq $reference && $age <= $lease;
  next unless $started >= $reference && $finished >= $started;
  next unless $finished < $reference + $lease + 1;
  next unless $started + 2 * $check >= $reference + $deadline;
  printf "guard phase: fresh read %.3f-%.3fs, expiry %ss, two full intervals could not finish before %.3fs (deadline %ss)\n",
    $started - $reference, $finished - $reference, $lease + 1,
    $started - $reference + 2 * $check, $deadline;
  exit 0;
}
exit 1;
PL
wait_gone "$BOUND_DESCENDANT" \
  || fail "the guard stopped at the leader and left its descendant running"
printf 'guard bound: lease=%ss check=%ss reaped %ss after the last owner activity, documented bound %ss\n' \
  "$BOUND_LEASE_SECONDS" "$BOUND_CHECK_SECONDS" "$bound_elapsed" "$bound_total"
pass "an orphaned runner is reaped within the lease plus ONE check interval"

# --- a zero-prefixed interval still starts a listener, and halves correctly ---
#
# OUR OWN REGRESSION, found in review before this change was published. The
# interval validator accepts a zero-prefixed value and `[` compares it as
# decimal, but the half-interval arithmetic introduced above reads `$(( ))`,
# which is octal for a leading zero: 010 halved to 4 instead of 5, and 08 was
# not a number at all, so the guard died before reporting ready and the runner
# failed closed and never listened.
#
# Asserted through the executable interface rather than by reading the source:
# a real listener is started at each value, and the guard's actual sleep
# argument is observed. Reading `10#` out of the script would prove nothing.
INTERVAL_BIN=$(fm_fakebin "$TMP_ROOT/decimal-interval-bin")
REAL_SLEEP=$(command -v sleep) || fail "this host has no sleep to observe guard intervals"
cat > "$INTERVAL_BIN/sleep" <<SH
#!/usr/bin/env bash
printf '%s\n' "\$*" >> "\$INTERVAL_SLEEP_LOG"
exec "$REAL_SLEEP" "\$@"
SH
chmod +x "$INTERVAL_BIN/sleep"
for interval in 08 010; do
  case "$interval" in
    08) expected_half=4 ;;
    010) expected_half=5 ;;
  esac
  HINTERVAL="$TMP_ROOT/decimal-interval-$interval"; new_home "$HINTERVAL"
  pe_register "$HINTERVAL" lavish "interval-$interval" \
    -- "$QUIET_STUB" "$HINTERVAL/poll" >/dev/null
  PATH="$INTERVAL_BIN:$PATH" INTERVAL_SLEEP_LOG="$HINTERVAL/sleeps" \
    FM_PROCEVENT_OWNER_CHECK_SECONDS="$interval" \
    pe "$HINTERVAL" reconcile >/dev/null
  wait_for "$HINTERVAL/poll.descendant" \
    || fail "a zero-prefixed decimal interval ($interval) prevented the listener from starting"
  for _ in $(seq 1 100); do
    grep -qx "$expected_half" "$HINTERVAL/sleeps" 2>/dev/null && break
    sleep 0.1
  done
  grep -qx "$expected_half" "$HINTERVAL/sleeps" \
    || fail "the guard did not sleep half of the decimal interval $interval (expected ${expected_half}s)"
  pe "$HINTERVAL" retire "interval-$interval" >/dev/null \
    || fail "retiring the decimal-interval listener ($interval) reported failure"
  printf 'decimal interval: %s halves to %ss and its listener started\n' "$interval" "$expected_half"
done
pass "a zero-prefixed decimal interval starts its listener and halves as decimal"

# --- one unreadable read still does not end a live runner --------------------
#
# The bound above was tightened by moving the guard's two reads closer together,
# NOT by dropping the second one. This is what that second read is for, asserted
# separately so the two cannot be traded for each other by accident: against a
# home that is still alive, an isolated failed read must not stop the runner.
#
# The failure is injected where the real path actually reads. ONE lease read
# fails, exactly once, identified by the lease-age program's own text so no
# other call in the runner is touched; every read before and after it is the
# real command, and the home's lease stays long and fresh throughout. The single
# failed read is therefore the only thing wrong that the guard can see.

DEBOUNCE_HOME="$TMP_ROOT/lease-debounce"; new_home "$DEBOUNCE_HOME"
fm_test_track_procevent_home "$DEBOUNCE_HOME"
DEBOUNCE_STATE="$TMP_ROOT/lease-debounce-state"; mkdir -p "$DEBOUNCE_STATE"
DEBOUNCE_BIN=$(fm_fakebin "$TMP_ROOT/lease-debounce-bin")
REAL_PERL=$(command -v perl) || fail "this host has no perl to build the debounce fixture on"
cat > "$DEBOUNCE_BIN/perl" <<SH
#!/usr/bin/env bash
if [ -s "\$LEASE_DEBOUNCE_STATE/armed" ] && [ ! -s "\$LEASE_DEBOUNCE_STATE/spent" ]; then
  for arg in "\$@"; do
    case \$arg in
      *'int(\$now - \$value)'*)
        printf 'spent\n' > "\$LEASE_DEBOUNCE_STATE/spent"
        exit 1
        ;;
    esac
  done
fi
exec "$REAL_PERL" "\$@"
SH
chmod +x "$DEBOUNCE_BIN/perl"

# A long lease and a short check: many reads happen inside the observation
# window, and none of them can go stale on their own during it.
DEBOUNCE_LEASE_SECONDS=30
DEBOUNCE_CHECK_SECONDS=1
debounce_pe() {
  PATH="$DEBOUNCE_BIN:$PATH" LEASE_DEBOUNCE_STATE="$DEBOUNCE_STATE" \
    FM_PROCEVENT_OWNER_LEASE_SECONDS="$DEBOUNCE_LEASE_SECONDS" \
    FM_PROCEVENT_OWNER_CHECK_SECONDS="$DEBOUNCE_CHECK_SECONDS" \
    FM_HOME="$DEBOUNCE_HOME" "$ROOT/bin/fm-procevent.sh" "$@"
}
debounce_pe register lavish debounce-src -- "$QUIET_STUB" "$TMP_ROOT/lease-debounce-marker" >/dev/null
debounce_pe reconcile >/dev/null
wait_for "$DEBOUNCE_HOME/state/procevent/debounce-src.runner" \
  || fail "the debounce fixture's listener never recorded its runner"
DEBOUNCE_PID=$(cat "$DEBOUNCE_HOME/state/procevent/debounce-src.runner")
# Armed only now. The guard proves the lease once before it reports ready, and
# failing THAT read would refuse the runner outright instead of exercising the
# debounce this case is about.
printf 'armed\n' > "$DEBOUNCE_STATE/armed"
wait_for "$DEBOUNCE_STATE/spent" \
  || fail "the single failed lease read this case injects never happened"
# Several further checks at the configured interval. A guard that acted on one
# failed read would have stopped the group during them.
sleep $((DEBOUNCE_CHECK_SECONDS * 4))
kill -0 -"$DEBOUNCE_PID" 2>/dev/null \
  || fail "one unreadable lease read ended a runner whose home was still alive"
debounce_pe retire debounce-src >/dev/null \
  || fail "retiring the debounce fixture's source reported failure"
wait_gone "-$DEBOUNCE_PID" \
  || fail "retiring the debounce fixture left its process group running"
pass "one unreadable read does not end a live runner"

# --- the ordinary stop signal is what stops a runner ------------------------
#
# The forced kill is the backstop, not the normal path. When it carries every
# stop, it stops being able to report that anything went wrong - which is exactly
# how a listener that could not be stopped looked identical to one that could.

HPROMPT="$TMP_ROOT/prompt-stop"; new_home "$HPROMPT"
pe_register "$HPROMPT" lavish prompt-src -- "$QUIET_STUB" "$TMP_ROOT/prompt-stop" >/dev/null
pe "$HPROMPT" start prompt-src >"$TMP_ROOT/prompt-start.log" 2>&1 &
PROMPT_START_PID=$!
wait_for "$HPROMPT/state/procevent/prompt-src.runner" \
  || fail "the promptly-stopping listener never recorded its runner"
PROMPT_PID=$(cat "$HPROMPT/state/procevent/prompt-src.runner")
wait_for "$TMP_ROOT/prompt-stop.descendant" \
  || fail "the promptly-stopping listener's child never spawned its own descendant"
stop_window_ms() {
  local from to
  from=$(now_ms)
  for _ in $(seq 1 20); do sleep 0.1; done
  to=$(now_ms)
  printf '%s\n' "$((to - from))"
}
window_before=$(stop_window_ms)
start=$(now_ms)
pe "$HPROMPT" retire prompt-src >/dev/null || fail "retiring a healthy listener reported failure"
elapsed=$(( $(now_ms) - start ))
window_after=$(stop_window_ms)
prompt_status=0
wait "$PROMPT_START_PID" || prompt_status=$?
wait_gone "-$PROMPT_PID" || fail "retiring a healthy listener left its process group running"
[ "$prompt_status" -eq 143 ] \
  || fail "the runner did not exit on TERM (start status=$prompt_status, retirement=${elapsed}ms, sampled windows=${window_before}/${window_after}ms)"
printf 'ordinary stop: start status=%s retirement=%sms sampled windows=%s/%sms\n' \
  "$prompt_status" "$elapsed" "$window_before" "$window_after"
pass "a runner exits on the ordinary stop signal instead of outliving it"

# --- a crashed leader's group is still refused -------------------------------
#
# The escalation above accepts a leaderless group in exactly one place: inside
# the stop that just proved and signalled that generation itself. Whether a group
# whose leader died to something ELSE may ever be signalled is a separate open
# question, and this pins that it stays refused - so the escalation cannot widen
# into an answer to it by accident.

HCRASH="$TMP_ROOT/crashed-leader"; new_home "$HCRASH"
pe_register "$HCRASH" lavish crash-src -- "$QUIET_STUB" "$TMP_ROOT/crash-leader" >/dev/null
pe "$HCRASH" reconcile >/dev/null
wait_for "$HCRASH/state/procevent/crash-src.runner" \
  || fail "the crash-fixture listener never recorded its runner"
CRASH_PID=$(cat "$HCRASH/state/procevent/crash-src.runner")
wait_for "$TMP_ROOT/crash-leader.descendant" \
  || fail "the crash-fixture listener's child never spawned its own descendant"
kill -KILL "$CRASH_PID" 2>/dev/null || fail "the crash fixture could not stop its own leader"
deadline=$((SECONDS + 10))
while kill -0 "$CRASH_PID" 2>/dev/null; do
  [ "$SECONDS" -lt "$deadline" ] || fail "the crash fixture's leader never died"
  sleep 0.1
done
kill -0 -"$CRASH_PID" 2>/dev/null \
  || fail "the crash fixture left no surviving group, so nothing was refused"

out=$(pe "$HCRASH" retire crash-src 2>&1) && fail "retirement claimed success on a crashed leader's group"
assert_contains "$out" "cannot confirm runner identity" \
  "a crashed leader's group is refused with its own diagnostic"
assert_present "$HCRASH/state/procevent/crash-src.source" \
  "a refused retirement leaves the source registered"
kill -0 -"$CRASH_PID" 2>/dev/null \
  || fail "a refused retirement signalled the leaderless group anyway"
pass "a group whose leader died to something else is still refused, not signalled"
kill -KILL -"$CRASH_PID" 2>/dev/null || true

# --- arm reports ready only once this registration's listener is running ----
# The public arm path used to print armed as soon as registration was stored.
# A listener that has not claimed the source is not ready, so arm waits for the
# same live-claim or launch-stamp evidence reconcile uses and fails closed when
# that evidence does not appear within the confirm window.
READY="$TMP_ROOT/ready-arm"
mkdir -p "$READY/bin" "$READY/home/state"
cat > "$READY/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
printf 'started\n' >> "${READY_MARK:?}"
while [ ! -e "${READY_RELEASE:?}" ]; do sleep 0.02; done
printf 'session:\n  status: ended\n'
SH
chmod +x "$READY/bin/lavish-axi"
ready_art="$READY/board.html"
printf '<h1>ready</h1>\n' > "$ready_art"
lavish_session "$ready_art"
ready_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$ready_art")
fm_test_track_procevent_home "$READY/home"
export READY_MARK="$READY/mark" READY_RELEASE="$READY/release"
: > "$READY_MARK"
PATH="$READY/bin:$PATH" FM_HOME="$READY/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$ready_art" > "$READY/arm.out"
assert_contains "$(cat "$READY/arm.out")" "armed: $ready_id" "a live listener was not reported ready"
[ -e "$FM_PROCEVENT_CLAIM_ROOT/$ready_id.claim" ] \
  || fail "arm reported ready without a listener claim"
for _ in $(seq 1 50); do
  grep -q started "$READY_MARK" && break
  sleep 0.05
done
grep -q started "$READY_MARK" || fail "arm reported ready before the listener command ran"
touch "$READY_RELEASE"
for _ in $(seq 1 50); do
  [ -e "$FM_PROCEVENT_CLAIM_ROOT/$ready_id.claim" ] || break
  sleep 0.05
done
PATH="$READY/bin:$PATH" FM_HOME="$READY/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$ready_art" >/dev/null 2>&1 || true
pass "arm reports ready only after the listener is running"

# Delayed start: the source lock is held so the listener cannot claim, and arm
# must not print armed until that lock clears and the listener does.
DELAY="$TMP_ROOT/delay-arm"
mkdir -p "$DELAY/bin" "$DELAY/home/state"
cp "$READY/bin/lavish-axi" "$DELAY/bin/lavish-axi"
delay_art="$DELAY/board.html"
printf '<h1>delay</h1>\n' > "$delay_art"
lavish_session "$delay_art"
delay_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$delay_art")
fm_test_track_procevent_home "$DELAY/home"
export READY_MARK="$DELAY/mark" READY_RELEASE="$DELAY/release"
: > "$READY_MARK"
delay_ready="$DELAY/lock-ready"
delay_rel="$DELAY/lock-release"
hold_source_lock "$delay_id" "$delay_ready" "$delay_rel"
wait_for "$delay_ready" || fail "delayed-start fixture could not hold the source lock"
PATH="$DELAY/bin:$PATH" FM_HOME="$DELAY/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$delay_art" > "$DELAY/arm.out" 2>"$DELAY/arm.err" &
delay_arm=$!
sleep 0.4
assert_not_contains "$(cat "$DELAY/arm.out" 2>/dev/null || true)" "armed:" \
  "arm reported ready while the listener could not start"
[ ! -e "$FM_PROCEVENT_CLAIM_ROOT/$delay_id.claim" ] \
  || fail "a listener claimed the source while its lock was held"
touch "$delay_rel"
wait "$delay_arm" || fail "arm failed after the delayed listener was allowed to start: $(cat "$DELAY/arm.err")"
assert_contains "$(cat "$DELAY/arm.out")" "armed: $delay_id" \
  "arm did not report ready once the delayed listener was running"
for _ in $(seq 1 50); do
  grep -q started "$READY_MARK" && break
  sleep 0.05
done
grep -q started "$READY_MARK" || fail "the delayed listener never ran"
touch "$READY_RELEASE"
wait "$HOLDER_PID" 2>/dev/null || true
for _ in $(seq 1 50); do
  [ -e "$FM_PROCEVENT_CLAIM_ROOT/$delay_id.claim" ] || break
  sleep 0.05
done
PATH="$DELAY/bin:$PATH" FM_HOME="$DELAY/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$delay_art" >/dev/null 2>&1 || true
pass "arm waits out a delayed listener start before reporting ready"

# A claim path that is a directory can never be owned, so the runner dies before
# the listener command. Arm must not print ready, and it must remove the
# registration it just published.
arm_blocked_claim() {  # <dir> <confirm-seconds>
  local dir=$1 secs=$2 art id began rc elapsed
  mkdir -p "$dir/bin" "$dir/home/state"
  cat > "$dir/bin/lavish-axi" <<'SH'
#!/bin/sh
printf started >> "${READY_MARK:?}"
SH
  chmod +x "$dir/bin/lavish-axi"
  art="$dir/board.html"
  printf '<h1>blocked</h1>\n' > "$art"
  lavish_session "$art"
  id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$art")
  fm_test_track_procevent_home "$dir/home"
  mkdir -p "$FM_PROCEVENT_CLAIM_ROOT/$id.claim"
  export READY_MARK="$dir/mark"
  : > "$READY_MARK"
  began=$(date +%s)
  set +e
  PATH="$dir/bin:$PATH" FM_HOME="$dir/home" FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS="$secs" \
    "$ROOT/bin/fm-procevent-lavish.sh" arm "$art" > "$dir/arm.out" 2>"$dir/arm.err"
  rc=$?
  set -e
  elapsed=$(( $(date +%s) - began ))
  [ "$rc" -ne 0 ] || fail "arm reported success when no listener could claim ($dir)"
  assert_not_contains "$(cat "$dir/arm.out")" "armed:" \
    "arm printed ready when no listener could claim ($dir)"
  [ ! -s "$READY_MARK" ] || fail "the listener command ran without a claim ($dir)"
  # retire refuses a claim it cannot read, and arm must not override it.
  [ -e "$dir/home/state/procevent/$id.source" ] \
    || fail "arm removed a registration that retire refused to remove ($dir)"
  printf '%s\n' "$elapsed" > "$dir/elapsed"
  rmdir "$FM_PROCEVENT_CLAIM_ROOT/$id.claim" 2>/dev/null || true
  PATH="$dir/bin:$PATH" FM_HOME="$dir/home" \
    "$ROOT/bin/fm-procevent-lavish.sh" retire "$art" >/dev/null 2>&1 || true
}

arm_blocked_claim "$TMP_ROOT/immediate-arm" 1
pass "arm fails when the listener cannot claim, and leaves the registration retire refused"

arm_blocked_claim "$TMP_ROOT/timeout-arm" 2
tout_elapsed=$(cat "$TMP_ROOT/timeout-arm/elapsed")
[ "$tout_elapsed" -ge 2 ] \
  || fail "arm did not wait out the confirm window (${tout_elapsed}s)"
pass "arm waits out the confirm window before reporting that the listener is not running"

# Re-arming a firstmate-owned board publishes a new registration while the
# earlier generation's listener still holds the claim. When that listener still
# holds it as the confirm window ends, it keeps serving the board, so arm must
# say so instead of reporting failure, and must never claim this generation is
# the one listening.
LIVE="$TMP_ROOT/live-rearm"
mkdir -p "$LIVE/bin" "$LIVE/home/state"
cp "$READY/bin/lavish-axi" "$LIVE/bin/lavish-axi"
live_art="$LIVE/board.html"
printf '<h1>live</h1>\n' > "$live_art"
lavish_session "$live_art"
live_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$live_art")
fm_test_track_procevent_home "$LIVE/home"
export READY_MARK="$LIVE/mark" READY_RELEASE="$LIVE/release"
: > "$READY_MARK"
PATH="$LIVE/bin:$PATH" FM_HOME="$LIVE/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$live_art" > "$LIVE/arm1.out"
assert_contains "$(cat "$LIVE/arm1.out")" "armed: $live_id" "the first arm was not reported ready"
wait_for_lines "$READY_MARK" 1 || fail "the first generation's listener never ran"
set +e
PATH="$LIVE/bin:$PATH" FM_HOME="$LIVE/home" FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=1 \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$live_art" > "$LIVE/arm2.out" 2> "$LIVE/arm2.err"
live_rc=$?
set -e
[ "$live_rc" -eq 0 ] \
  || fail "re-arm over a live earlier listener failed ($live_rc): $(cat "$LIVE/arm2.err")"
assert_contains "$(cat "$LIVE/arm2.out")" "still-listening: $live_id" \
  "re-arm did not say the earlier listener is still serving the board"
assert_contains "$(cat "$LIVE/arm2.out")" "retired and armed again" \
  "re-arm did not say how the new registration takes effect"
assert_not_contains "$(cat "$LIVE/arm2.out")" "armed: $live_id" \
  "re-arm reported ready for a registration whose own listener is not running"
assert_not_contains "$(cat "$LIVE/arm2.err")" "error:" \
  "re-arm over a live earlier listener printed an error"
[ "$(pe "$LIVE/home" list | awk -v id="$live_id" '$1 == id { print $3 }')" = live ] \
  || fail "re-arm disturbed the live earlier listener"
sleep 0.3
[ "$(wc -l < "$READY_MARK" | tr -d ' ')" = 1 ] \
  || fail "re-arm started a second listener beside the live earlier one"
touch "$READY_RELEASE"
PATH="$LIVE/bin:$PATH" FM_HOME="$LIVE/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$live_art" >/dev/null 2>&1 || true
pass "re-arm over a live earlier listener reports it still serving the board"

# Old compatible Lavish versions keep using their existing poll reply path.
LEGACY="$TMP_ROOT/legacy-reply"
mkdir -p "$LEGACY/bin" "$LEGACY/home/state"
export LEGACY
cat > "$LEGACY/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
case "${1-}" in
  --version) printf '0.1.79\n' ;;
  poll)
    [ "${3-}" = --agent-reply ] || exit 3
    printf '%s\n' "$4" > "$LEGACY/reply"
    printf 'started\n' > "$LEGACY/started"
    while [ ! -e "$LEGACY/release" ]; do sleep 0.02; done
    printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","next round","","message",""\n'
    ;;
  *) exit 2 ;;
esac
SH
chmod +x "$LEGACY/bin/lavish-axi"
legacy_art="$LEGACY/board.html"
printf '<h1>legacy reply</h1>\n' > "$legacy_art"
lavish_session "$legacy_art"
legacy_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$legacy_art")
fm_test_track_procevent_home "$LEGACY/home"
new_task_endpoint "$LEGACY/home" worker-legacy
printf 'legacy reply body\n' > "$LEGACY/reply-file"
PATH="$LEGACY/bin:$PATH" FM_HOME="$LEGACY/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$legacy_art" --for worker-legacy \
  --agent-reply-file "$LEGACY/reply-file" >/dev/null \
  || fail "the older compatible Lavish reply path did not arm"
wait_for "$LEGACY/reply" || fail "the older compatible poll never received its staged reply"
[ "$(cat "$LEGACY/reply")" = 'legacy reply body' ] \
  || fail "the legacy poll received different reply text"
touch "$LEGACY/release"
wait_for "$LEGACY/home/state/procevent-inbox/$legacy_id.1.result" \
  || fail "the legacy Lavish reply round was not captured"
pass "older compatible Lavish versions retain the poll-with-reply behavior"

# A failed synchronous reply must leave the worker board unarmed.
REPLY_FAIL="$TMP_ROOT/reply-fail"
mkdir -p "$REPLY_FAIL/bin" "$REPLY_FAIL/home/state"
export REPLY_FAIL
cat > "$REPLY_FAIL/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
case "${1-}" in
  --version) printf '0.1.80\n' ;;
  reply) printf 'simulated reply timeout\n' >&2; exit 1 ;;
  poll) : > "$REPLY_FAIL/polled"; exit 0 ;;
  *) exit 2 ;;
esac
SH
chmod +x "$REPLY_FAIL/bin/lavish-axi"
reply_fail_art="$REPLY_FAIL/board.html"
printf '<h1>reply failure</h1>\n' > "$reply_fail_art"
lavish_session "$reply_fail_art"
reply_fail_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$reply_fail_art")
fm_test_track_procevent_home "$REPLY_FAIL/home"
new_task_endpoint "$REPLY_FAIL/home" worker-reply-fail
printf 'reply that will fail\n' > "$REPLY_FAIL/reply-file"
reply_fail_rc=0
reply_fail_out=$(PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$reply_fail_art" --for worker-reply-fail \
  --agent-reply-file "$REPLY_FAIL/reply-file" 2>&1) || reply_fail_rc=$?
[ "$reply_fail_rc" -ne 0 ] || fail "a refused reply let arm report success"
assert_contains "$reply_fail_out" 'Lavish did not accept the staged reply' \
  "a refused reply lacked a clear arm diagnostic: $reply_fail_out"
[ ! -e "$REPLY_FAIL/home/state/procevent/$reply_fail_id.source" ] \
  || fail "arm registered a board after Lavish refused its reply"
[ ! -e "$REPLY_FAIL/polled" ] || fail "arm started a listener after Lavish refused its reply"
pass "a refused synchronous reply fails arm before source registration"

cat > "$REPLY_FAIL/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
case "${1-}" in
  --version) printf '0.1.80\n' ;;
  reply) printf '%s\n' "$(cat -- "$4")" >> "$REPLY_FAIL/replies" ;;
  poll) while [ ! -e "$REPLY_FAIL/release" ]; do sleep 0.02; done; exit 1 ;;
  *) exit 2 ;;
esac
SH
PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$reply_fail_art" --for worker-reply-fail \
  --agent-reply-file "$REPLY_FAIL/reply-file" >/dev/null \
  || fail "arm was not retryable with the same reply after Lavish refused it"
[ "$(cat "$REPLY_FAIL/replies")" = 'reply that will fail' ] \
  || fail "the retried arm did not post the worker's staged reply exactly once"
pass "a refused synchronous reply leaves the same arm retryable"

# An arm that fails ownership, pending-round, or endpoint eligibility must
# leave the board untouched: the reply is never posted.
: > "$REPLY_FAIL/replies"
printf 'foreign reply\n' > "$REPLY_FAIL/foreign-reply"
new_task_endpoint "$REPLY_FAIL/home" worker-intruder
refused_rc=0
refused_out=$(PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$reply_fail_art" --for worker-intruder \
  --agent-reply-file "$REPLY_FAIL/foreign-reply" 2>&1) || refused_rc=$?
[ "$refused_rc" -ne 0 ] || fail "a non-owner arm with a reply was not refused"
assert_contains "$refused_out" "owned by task worker-reply-fail" \
  "the non-owner arm was refused for an unexpected reason: $refused_out"
refused_rc=0
refused_out=$(PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$reply_fail_art" --for worker-reply-fail \
  --agent-reply-file "$REPLY_FAIL/foreign-reply" 2>&1) || refused_rc=$?
[ "$refused_rc" -ne 0 ] || fail "an owner re-arm with no waiting round was not refused"
assert_contains "$refused_out" "no captured round is waiting" \
  "the roundless re-arm was refused for an unexpected reason: $refused_out"
unreachable_art="$REPLY_FAIL/unreachable.html"
printf '<h1>unreachable owner</h1>\n' > "$unreachable_art"
lavish_session "$unreachable_art"
refused_rc=0
refused_out=$(PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$unreachable_art" --for worker-no-endpoint \
  --agent-reply-file "$REPLY_FAIL/foreign-reply" 2>&1) || refused_rc=$?
[ "$refused_rc" -ne 0 ] || fail "an arm for a task with no endpoint was not refused"
assert_contains "$refused_out" "would reach no endpoint" \
  "the endpointless arm was refused for an unexpected reason: $refused_out"
[ ! -s "$REPLY_FAIL/replies" ] || fail "a refused arm posted its reply to the board: $(cat "$REPLY_FAIL/replies")"
PATH="$REPLY_FAIL/bin:$PATH" FM_HOME="$REPLY_FAIL/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$reply_fail_art" >/dev/null 2>&1 || true
touch "$REPLY_FAIL/release"
pass "an arm refused for ownership, round, or endpoint never posts its reply"

# Direct poll callers use the same synchronous reply command on new Lavish builds.
POLL_REPLY="$TMP_ROOT/poll-reply"
mkdir -p "$POLL_REPLY/bin"
export POLL_REPLY
cat > "$POLL_REPLY/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
case "${1-}" in
  --version) printf '0.1.80\n' ;;
  reply)
    [ "${3-}" = --agent-reply-file ] || exit 2
    [ "$(cat -- "$4")" = 'direct poll reply' ] || exit 3
    printf 'reply\n' >> "$POLL_REPLY/order"
    ;;
  poll)
    [ "$#" -eq 2 ] || exit 4
    printf 'poll\n' >> "$POLL_REPLY/order"
    printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","next round","","message",""\n'
    ;;
  *) exit 2 ;;
esac
SH
chmod +x "$POLL_REPLY/bin/lavish-axi"
poll_reply_art="$POLL_REPLY/board.html"
printf '<h1>direct poll reply</h1>\n' > "$poll_reply_art"
lavish_session "$poll_reply_art"
printf 'direct poll reply\n' > "$POLL_REPLY/reply-file"
PATH="$POLL_REPLY/bin:$PATH" \
  "$ROOT/bin/fm-procevent-lavish.sh" poll "$poll_reply_art" \
  --agent-reply-file "$POLL_REPLY/reply-file" >/dev/null \
  || fail "direct poll did not complete after synchronously posting its reply"
[ "$(cat "$POLL_REPLY/order")" = $'reply\npoll' ] \
  || fail "direct poll did not post the reply before entering the long-poll"
[ ! -e "$POLL_REPLY/reply-file" ] || fail "direct poll left its accepted staged reply behind"
pass "direct poll confirms a new-version reply before polling"

# An unreadable Lavish version is not a confirmed older release: arm and a
# reply-carrying listener fail closed without posting or falling back to poll.
UNKNOWN="$TMP_ROOT/unknown-version"
mkdir -p "$UNKNOWN/bin" "$UNKNOWN/home/state"
export UNKNOWN
cat > "$UNKNOWN/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
case "${1-}" in
  --version) exit 1 ;;
  reply|poll) printf '%s\n' "$*" >> "$UNKNOWN/calls"; exit 0 ;;
  *) exit 2 ;;
esac
SH
chmod +x "$UNKNOWN/bin/lavish-axi"
unknown_art="$UNKNOWN/board.html"
printf '<h1>unknown version</h1>\n' > "$unknown_art"
lavish_session "$unknown_art"
unknown_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$unknown_art")
fm_test_track_procevent_home "$UNKNOWN/home"
new_task_endpoint "$UNKNOWN/home" worker-unknown
printf 'reply for an unknown version\n' > "$UNKNOWN/reply-file"
unknown_rc=0
unknown_out=$(PATH="$UNKNOWN/bin:$PATH" FM_HOME="$UNKNOWN/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$unknown_art" --for worker-unknown \
  --agent-reply-file "$UNKNOWN/reply-file" 2>&1) || unknown_rc=$?
[ "$unknown_rc" -ne 0 ] || fail "arm fell back to a legacy reply when the Lavish version was unknown"
assert_contains "$unknown_out" 'cannot confirm a supported lavish-axi version' \
  "an unknown Lavish version lacked a clear arm diagnostic: $unknown_out"
[ ! -e "$UNKNOWN/home/state/procevent/$unknown_id.source" ] \
  || fail "arm registered a board while the Lavish version was unknown"
[ ! -e "$UNKNOWN/calls" ] || fail "arm reached the board with an unknown Lavish version: $(cat "$UNKNOWN/calls")"
[ "$(cat "$UNKNOWN/reply-file")" = 'reply for an unknown version' ] \
  || fail "arm consumed the worker's reply while the Lavish version was unknown"
cp "$UNKNOWN/reply-file" "$UNKNOWN/staged-reply"
unknown_rc=0
PATH="$UNKNOWN/bin:$PATH" "$ROOT/bin/fm-procevent-lavish.sh" poll "$unknown_art" \
  --agent-reply-file "$UNKNOWN/staged-reply" >/dev/null 2>&1 || unknown_rc=$?
[ "$unknown_rc" -ne 0 ] || fail "a reply-carrying poll proceeded with an unknown Lavish version"
[ ! -e "$UNKNOWN/calls" ] || fail "a reply-carrying poll reached the board with an unknown Lavish version: $(cat "$UNKNOWN/calls")"
[ "$(cat "$UNKNOWN/staged-reply")" = 'reply for an unknown version' ] \
  || fail "a reply-carrying poll consumed its staged reply with an unknown Lavish version"
pass "an unknown Lavish version fails arm and poll closed, keeping the staged reply"

# A worker re-arms as soon as its round is published, which can land while the
# earlier generation's runner is still finishing and holding the claim. The
# Lavish 0.1.80 stand-in records synchronous reply acceptance before its poll.
DRAIN="$TMP_ROOT/draining-rearm"
mkdir -p "$DRAIN/bin" "$DRAIN/home/state"
export DRAIN
cat > "$DRAIN/bin/lavish-axi" <<'SH'
#!/usr/bin/env bash
set -eu
case "${1-}" in
  --version) printf '0.1.80\n' ;;
  reply)
    [ "${3-}" = --agent-reply-file ] || exit 2
    printf '%s\n' "$(cat -- "$4")" >> "$DRAIN/replies"
    printf 'reply\n' >> "$DRAIN/order"
    ;;
  poll)
    printf 'poll\n' >> "$DRAIN/polls"
    printf 'poll\n' >> "$DRAIN/order"
    if [ "$(wc -l < "$DRAIN/polls")" -eq 1 ]; then
      while [ ! -e "$DRAIN/release1" ]; do sleep 0.02; done
    fi
    [ "${3-}" != --agent-reply ] || exit 3
    if [ "$(wc -l < "$DRAIN/polls")" -ge 2 ]; then
      while [ ! -e "$DRAIN/release2" ]; do sleep 0.02; done
    fi
    printf 'session:\n  status: feedback\nprompts[1]{uid,prompt,selector,tag,text}:\n  "","next round","","message",""\n'
    ;;
  *) exit 2 ;;
esac
SH
chmod +x "$DRAIN/bin/lavish-axi"
drain_art="$DRAIN/board.html"
printf '<h1>drain</h1>\n' > "$drain_art"
lavish_session "$drain_art"
drain_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$drain_art")
fm_test_track_procevent_home "$DRAIN/home"
new_task_endpoint "$DRAIN/home" worker-drain
printf 'first drain reply\n' > "$DRAIN/reply1"
printf 'second drain reply\n' > "$DRAIN/reply2"
PATH="$DRAIN/bin:$PATH" FM_HOME="$DRAIN/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$drain_art" --for worker-drain \
  --agent-reply-file "$DRAIN/reply1" >/dev/null \
  || fail "the first generation of the draining fixture did not arm"
[ "$(cat "$DRAIN/replies" 2>/dev/null || true)" = "first drain reply" ] \
  || fail "arm returned before Lavish accepted its staged reply"
[ "$(head -n 1 "$DRAIN/order")" = reply ] \
  || fail "arm started the long-poll before Lavish accepted the reply"
pass "arm posts and confirms the staged reply before reporting listener readiness"
drain_claim="$FM_PROCEVENT_CLAIM_ROOT/$drain_id.claim"
cp "$drain_claim" "$DRAIN/generation-one.claim"
touch "$DRAIN/release1"
wait_for "$DRAIN/home/state/procevent-inbox/$drain_id.1.result" \
  || fail "the first generation of the draining fixture never captured its round"
for _ in $(seq 1 100); do
  [ -e "$drain_claim" ] || break
  sleep 0.05
done
[ ! -e "$drain_claim" ] || fail "the first generation of the draining fixture never exited"
# Stand the first generation's claim back up on a live process so the re-arm
# meets it still held, then release it partway through the confirm window.
perl -MPOSIX=setsid -e 'setsid() >= 0 or exit 1; exec @ARGV' sleep 60 &
drain_holder=$!
# Read the identity only once the holder has exec'd sleep: mid-exec its cmdline
# can read empty, and a pre-exec identity would never match the live holder.
for _ in $(seq 1 100); do
  case "$(ps -p "$drain_holder" -o comm= 2>/dev/null)" in *sleep) break ;; esac
  sleep 0.05
done
drain_holder_identity=$(bash -c '. "$1/bin/fm-wake-lib.sh"; fm_pid_identity "$2"' _ "$ROOT" "$drain_holder") \
  || fail "could not read the draining holder's identity"
awk -v pid="$drain_holder" -v ident="$drain_holder_identity" \
  'NR == 2 { print pid; next } NR == 4 { print ident; next } { print }' \
  "$DRAIN/generation-one.claim" > "$drain_claim"
chmod 0600 "$drain_claim"
[ "$(pe "$DRAIN/home" list | awk -v id="$drain_id" '$1 == id { print $3 }')" = task:worker-drain/round-open ] \
  || fail "fixture invalid: the stood-up first generation is not reported live: $(pe "$DRAIN/home" list)"
PATH="$DRAIN/bin:$PATH" FM_HOME="$DRAIN/home" FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=5 \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$drain_art" --for worker-drain \
  --agent-reply-file "$DRAIN/reply2" > "$DRAIN/arm2.out" 2> "$DRAIN/arm2.err" &
drain_arm=$!
sleep 1
kill -KILL "$drain_holder" 2>/dev/null || true
wait "$drain_holder" 2>/dev/null || true
wait "$drain_arm" \
  || fail "re-arm failed after the earlier claim was released: $(cat "$DRAIN/arm2.err")"
assert_contains "$(cat "$DRAIN/arm2.out")" "armed: $drain_id" \
  "re-arm did not launch the new generation once the earlier claim was released"
assert_not_contains "$(cat "$DRAIN/arm2.out")" "still-listening" \
  "re-arm reported the released earlier listener as still serving the board"
wait_for_lines "$DRAIN/replies" 2 \
  || fail "the new generation never handed the board the worker's reply"
[ "$(grep -c 'second drain reply' "$DRAIN/replies" 2>/dev/null || true)" = 1 ] \
  || fail "the new generation did not hand the board its own reply exactly once"
touch "$DRAIN/release2"
wait_for "$DRAIN/home/state/procevent-inbox/$drain_id.2.result" \
  || fail "the new generation never captured its round"
pass "re-arm launches the new generation once a draining earlier claim is released"

# A stale claim whose process group is still alive may still have its polling
# child on the board's session. Reconcile refuses to launch beside it, and arm
# must apply the same rule instead of adding a second destructive poller.
UNDISP="$TMP_ROOT/undisplaceable-arm"
mkdir -p "$UNDISP/bin" "$UNDISP/home/state"
cp "$READY/bin/lavish-axi" "$UNDISP/bin/lavish-axi"
undisp_art="$UNDISP/board.html"
printf '<h1>undisplaceable</h1>\n' > "$undisp_art"
lavish_session "$undisp_art"
undisp_id=$("$ROOT/bin/fm-procevent-lavish.sh" source-id "$undisp_art")
fm_test_track_procevent_home "$UNDISP/home"
export READY_MARK="$UNDISP/mark" READY_RELEASE="$UNDISP/release"
: > "$READY_MARK"
PATH="$UNDISP/bin:$PATH" FM_HOME="$UNDISP/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$undisp_art" >/dev/null
wait_for_lines "$READY_MARK" 1 || fail "the undisplaceable fixture's listener never ran"
undisp_claim="$FM_PROCEVENT_CLAIM_ROOT/$undisp_id.claim"
undisp_identity=$(sed -n '4p' "$undisp_claim")
awk 'NR == 4 { print "different-live-process-identity"; next } { print }' \
  "$undisp_claim" > "$undisp_claim.tmp" && mv "$undisp_claim.tmp" "$undisp_claim"
chmod 0600 "$undisp_claim"
[ "$(pe "$UNDISP/home" list | awk -v id="$undisp_id" '$1 == id { print $3 }')" = orphaned ] \
  || fail "fixture invalid: the reused-pid claim is not reported orphaned"
set +e
PATH="$UNDISP/bin:$PATH" FM_HOME="$UNDISP/home" FM_PROCEVENT_LAUNCH_CONFIRM_SECONDS=1 \
  "$ROOT/bin/fm-procevent-lavish.sh" arm "$undisp_art" > "$UNDISP/arm2.out" 2>/dev/null
undisp_rc=$?
set -e
sleep 0.5
[ "$(wc -l < "$READY_MARK" | tr -d ' ')" = 1 ] \
  || fail "arm started a second listener beside a stale claim's live process group"
[ "$undisp_rc" -ne 0 ] || fail "arm reported success beside an undisplaceable claim"
assert_not_contains "$(cat "$UNDISP/arm2.out")" "armed: $undisp_id" \
  "arm reported ready beside an undisplaceable claim"
[ -e "$UNDISP/home/state/procevent/$undisp_id.source" ] \
  || fail "arm retired a source whose earlier listener may still be polling"
awk -v v="$undisp_identity" 'NR == 4 { print v; next } { print }' \
  "$undisp_claim" > "$undisp_claim.tmp" && mv "$undisp_claim.tmp" "$undisp_claim"
chmod 0600 "$undisp_claim"
touch "$READY_RELEASE"
PATH="$UNDISP/bin:$PATH" FM_HOME="$UNDISP/home" \
  "$ROOT/bin/fm-procevent-lavish.sh" retire "$undisp_art" >/dev/null 2>&1 || true
pass "arm does not launch beside a stale claim whose process group is alive"

printf '\nall procevent tests passed\n'
