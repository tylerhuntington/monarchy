#!/usr/bin/env bash
# tests/fm-composer-lib.test.sh - the shared composer-content classifier
# (bin/fm-composer-lib.sh), the ONE fleet-wide owner every backend adapter
# delegates its empty|pending|unknown verdict to.
#
# The load-bearing contract, task fm-composer-shellglyph-safety:
#   1. A BARE shell prompt glyph (`>`/`$`/`%`/`#`) on an unstructured row is a
#      dead shell, NOT an empty agent composer - it must read `unknown`
#      (unsafe-for-injection), never `empty`. This is the safety fix.
#   2. The SAME shell glyph INSIDE a bordered composer box is the harness's own
#      prompt and still reads `empty` (existing behavior preserved).
#   3. The AGENT prompt glyphs `❯` (claude), `›` (codex), `⟩` (muse), and `→`
#      (cursor) are a genuine empty agent composer either way, bordered or bare.
#   4. Real unsubmitted text reads `pending`; a known idle placeholder reads
#      `empty`.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

# shellcheck source=/dev/null
. "$ROOT/bin/fm-composer-lib.sh"

# classify <bordered> <content> [idle_re] -> echoes the verdict.
classify() { fm_composer_classify_content "$@"; }

# --- Safety fix: bare shell prompt is NOT an empty agent composer -----------

test_bare_shell_glyphs_are_unknown() {
  local g out
  for g in '>' '$' '%' '#'; do
    out=$(classify 0 "$g")
    [ "$out" = unknown ] \
      || fail "bare shell glyph '$g' must read unknown (dead shell, unsafe), got '$out'"
  done
  pass "fm_composer_classify_content: a bare shell prompt glyph (>/\$/%/#) reads unknown, never empty"
}

test_stripped_unbordered_content_uses_plain_content() {
  local plain out
  for plain in '$' 'user@host $'; do
    out=$(classify 0 '' '' sensitive "$plain")
    [ "$out" = unknown ] \
      || fail "stripped unbordered content '$plain' must retain its unknown safety verdict, got '$out'"
  done
  # muse draws `⟩` at luminance ~150, the tightest margin over the 128 ghost
  # threshold in the fleet, so a raised threshold really can strip it to empty
  # and leave only the plain row. This branch is what keeps that pane readable.
  for plain in '❯' '›' '⟩'; do
    out=$(classify 0 '' '' sensitive "$plain")
    [ "$out" = empty ] \
      || fail "a stripped agent glyph '$plain' must remain empty, got '$out'"
  done
  pass "fm_composer_classify_content: stripped unbordered content is unknown except verified agent glyphs"
}

test_bare_shell_prompt_with_command_is_not_empty() {
  local out
  # A dead shell showing a typed command must not read empty either.
  out=$(classify 0 '$ ls -la')
  [ "$out" != empty ] || fail "a bare shell prompt with a command must not read empty, got '$out'"
  pass "fm_composer_classify_content: a bare shell prompt carrying a command is not empty"
}

# --- Preserved: shell glyph inside a composer box is the harness prompt ------

test_bordered_shell_glyph_is_empty() {
  local g out
  for g in '>' '$' '%' '#'; do
    out=$(classify 1 "$g")
    [ "$out" = empty ] \
      || fail "a shell glyph '$g' inside a bordered composer box must read empty, got '$out'"
  done
  pass "fm_composer_classify_content: a bare prompt glyph inside a bordered composer box reads empty (claude's own idle composer)"
}

# --- Agent glyphs are empty either way --------------------------------------

test_agent_glyphs_are_empty_bordered_and_bare() {
  local out
  out=$(classify 0 '❯'); [ "$out" = empty ] || fail "bare claude '❯' should read empty, got '$out'"
  out=$(classify 0 '›'); [ "$out" = empty ] || fail "bare codex '›' should read empty, got '$out'"
  out=$(classify 1 '❯'); [ "$out" = empty ] || fail "bordered claude '❯' should read empty, got '$out'"
  out=$(classify 1 '›'); [ "$out" = empty ] || fail "bordered codex '›' should read empty, got '$out'"
  out=$(classify 0 '⟩'); [ "$out" = empty ] || fail "bare muse '⟩' should read empty, got '$out'"
  out=$(classify 1 '⟩'); [ "$out" = empty ] || fail "bordered muse '⟩' should read empty, got '$out'"
  pass "fm_composer_classify_content: agent prompt glyphs (❯ claude, › codex, ⟩ muse) read empty bordered or bare"
}

# --- Empty content and idle placeholder -------------------------------------

test_empty_content_is_empty() {
  local out
  out=$(classify 0 ''); [ "$out" = empty ] || fail "empty bare content should read empty, got '$out'"
  out=$(classify 1 ''); [ "$out" = empty ] || fail "empty bordered content should read empty, got '$out'"
  pass "fm_composer_classify_content: an empty composer reads empty"
}

test_idle_placeholder_is_empty() {
  local idle='^Type a message\.\.\.$' out
  out=$(classify 1 'Type a message...' "$idle" sensitive 'Type a message...' 1 1)
  [ "$out" = pending ] || fail "placeholder-like text surviving a styled box capture should read pending, got '$out'"
  out=$(classify 1 '❯ Type a message...' "$idle" sensitive '❯ Type a message...' 1 0)
  [ "$out" = empty ] || fail "a glyph-bearing plain box placeholder should read empty, got '$out'"
  out=$(classify 0 '❯ Type a message...' "$idle" sensitive '❯ Type a message...' 0 1)
  [ "$out" = pending ] || fail "placeholder text on a styled bare input row must be pending, got '$out'"
  out=$(classify 0 '❯ Type a message...' "$idle" sensitive '❯ Type a message...' 0 0)
  [ "$out" = unknown ] || fail "placeholder text on a plain bare input row must be unknown, got '$out'"
  out=$(classify 1 'Type a message...')
  [ "$out" = pending ] || fail "without an idle regex the placeholder text is pending, got '$out'"
  pass "fm_composer_classify_content: idle matching is limited to proven placeholder positions"
}

test_idle_placeholder_case_mode_is_explicit() {
  local idle='^Type a message\.\.\.$' out
  out=$(classify 1 'type a message...' "$idle" sensitive 'type a message...' 1 0)
  [ "$out" = pending ] || fail "a case-variant idle placeholder should remain pending by default, got '$out'"
  out=$(classify 1 'type a message...' "$idle" insensitive 'type a message...' 1 0)
  [ "$out" = empty ] || fail "an explicitly insensitive plain placeholder should read empty, got '$out'"
  pass "fm_composer_classify_content: idle matching preserves the caller's case mode"
}

# --- Real text is pending ---------------------------------------------------

test_real_text_is_pending() {
  local out
  out=$(classify 0 '❯ fix findings 1 and 3'); [ "$out" = pending ] || fail "bare '❯ <text>' should be pending, got '$out'"
  out=$(classify 1 '> deploy staging now'); [ "$out" = pending ] || fail "bordered '> <text>' should be pending, got '$out'"
  # muse restores the interrupted prompt into its composer after Escape, as real
  # bright text. Reading that as pending is correct - it really is unsubmitted.
  out=$(classify 0 '⟩ second turn to interrupt'); [ "$out" = pending ] || fail "bare '⟩ <text>' should be pending, got '$out'"
  # A slash-command popup argument-hint placeholder is still unsubmitted text.
  out=$(classify 1 '/compact compaction instructions'); [ "$out" = pending ] || fail "a popup placeholder fill should be pending, got '$out'"
  pass "fm_composer_classify_content: real unsubmitted text reads pending (including a popup argument-hint fill)"
}

# =============================================================================
# fm_composer_classify_screen: the adapter-facing screen classifier and the
# correctness matrix (audit data/fm-composer-consolidation-audit-s1, task
# fm-composer-thin-adapter-refactor-r1).
#
# Fixtures are the audit's byte-level captures of six REAL idle harnesses:
# claude 2.1.226 (bare `❯` + U+00A0 NO-BREAK SPACE), codex 0.146.0 (bold `›`
# + SGR-2 dim hint), codex 0.154.0 (the same `›` amid a braille starfield over
# a status footer, captured through Herdr on 2026-09-15), muse (truecolor `⟩`, 38;2;90;160;255), pi (blank row
# between solid `─` rules), opencode 1.14.46 (left-bar `┃` rows), and grok
# 1.0.0 (bordered box with a TITLED bottom border), plus claude captured
# inside zellij through `dump-screen --ansi` (`ESC[m` `❯` U+00A0).
#
# Capability profiles mirror the real adapters' descriptors: tmux
# (styled+cursor+identity), herdr/zellij (styled), cmux/orca (plain). Every
# emptiness verdict is asserted under the ambient UTF-8 locale AND LC_ALL=C,
# pinning the locale-safe Unicode-space normalization (issue #1988).
# =============================================================================

ESC=$(printf '\033')
NBSP=$(printf '\302\240')
CAPS_TMUX=$'styled=1\ncursor=1\nidentity=1\nrows=0'
CAPS_STYLED=$'styled=1\ncursor=0\nidentity=1\nrows=20'      # herdr
CAPS_STYLED_NOID=$'styled=1\ncursor=0\nidentity=0\nrows=20' # zellij
CAPS_PLAIN=$'styled=0\ncursor=0\nidentity=0\nrows=20'       # cmux, orca

# assert_screen <label> <want> <caps> <screen> [cursor] [identity]: one
# verdict, asserted under the ambient locale AND LC_ALL=C.
assert_screen() {
  local label=$1 want=$2 out
  shift 2
  out=$(fm_composer_classify_screen "$@")
  [ "$out" = "$want" ] || fail "$label: expected $want, got '$out'"
  out=$(LC_ALL=C fm_composer_classify_screen "$@")
  [ "$out" = "$want" ] || fail "$label under LC_ALL=C: expected $want, got '$out'"
}

test_matrix_claude_bare_nbsp_row() {
  # Real idle claude: `❯` + U+00A0, borderless, between horizontal rules.
  # The audit's headline defect: this row read `pending` under LC_ALL=C
  # (issue #1988), deferring every away-mode escalation in daemon contexts.
  local screen typed
  screen=$'transcript line\n────────────────────────\n❯'"$NBSP"$'\n────────────────────────\n  bypass permissions'
  assert_screen "claude idle on tmux" empty "$CAPS_TMUX" "$screen" 2 probe-absent
  assert_screen "claude idle on herdr" empty "$CAPS_STYLED" "$screen" '' probe-absent
  assert_screen "claude idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "claude idle on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  typed=$'────────────────────────\n❯ fix the login bug\n────────────────────────'
  assert_screen "claude typed on tmux" pending "$CAPS_TMUX" "$typed" 1 probe-absent
  # Plain capture cannot tell typed text from claude's rotating suggestion:
  # the styled=0 degradation defers instead of fabricating pending.
  assert_screen "claude typed on plain backends" unknown "$CAPS_PLAIN" "$typed"
  pass "matrix: claude's ❯+NBSP row reads empty on every profile in both locales (#1988)"
}

test_matrix_claude_named_session_titled_rule() {
  # Real claude 2.1.284 started as `claude -n <name>` (captured live through
  # Herdr 0.9.1): the session name is right-aligned inside the rule ABOVE the
  # composer, `───…─── <name> ─`, at the same width as the solid rule below.
  # Herdr gives no cursor, so before the titled rule was recognized the
  # cursorless path saw only the lower rule, read the idle composer `unknown`,
  # and the away-mode injector deferred every escalation on a named primary.
  local rule titled multi idle ghost typed out claude_idle pi_idle
  claude_idle=$(printf 'claude\tidle'); pi_idle=$(printf 'pi\tidle')
  rule='────────────────────────────────'
  titled='─────────────────────── Andrew ─'
  idle="transcript line"$'\n'"$titled"$'\n'"❯$NBSP"$'\n'"$rule"$'\n  ⏵⏵ auto mode on (shift+tab to cycle)'
  assert_screen "named claude idle on herdr" empty "$CAPS_STYLED" "$idle" '' "$claude_idle"
  assert_screen "named claude idle on zellij" empty "$CAPS_STYLED_NOID" "$idle"
  assert_screen "named claude idle on cmux/orca" empty "$CAPS_PLAIN" "$idle"
  assert_screen "named claude idle on tmux" empty "$CAPS_TMUX" "$idle" 2 "$claude_idle"
  # A multiword session name renders the same way, at the same width.
  multi='────────────────── Andrew Chen ─'
  assert_screen "multiword named claude idle on herdr" empty "$CAPS_STYLED" \
    "${idle/"$titled"/"$multi"}" '' "$claude_idle"
  assert_screen "multiword named claude typed on herdr" pending "$CAPS_STYLED" \
    "transcript line"$'\n'"$multi"$'\n'"❯ fix the login bug"$'\n'"$rule" '' "$claude_idle"
  # Claude's prompt suggestion is dim ghost text, not input.
  ghost="transcript line"$'\n'"$titled"$'\n'"❯$NBSP${ESC}[0m${ESC}[2mTry \"fix lint errors\"${ESC}[0m"$'\n'"$rule"
  assert_screen "named claude ghost suggestion on herdr" empty "$CAPS_STYLED" "$ghost" '' "$claude_idle"
  out=$(fm_composer_classify_screen "$CAPS_STYLED" "${ghost/ Andrew ─/─────────}" '' "$claude_idle")
  [ "$out" = empty ] || fail "unnamed claude ghost suggestion on herdr: expected empty, got '$out'"
  # The protection that must not move: typed text in the named composer.
  typed="transcript line"$'\n'"$titled"$'\n'"❯ fix the login bug"$'\n'"$rule"
  assert_screen "named claude typed on herdr" pending "$CAPS_STYLED" "$typed" '' "$claude_idle"
  assert_screen "named claude typed on tmux" pending "$CAPS_TMUX" "$typed" 2 "$claude_idle"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED" "$typed")
  [ "$out" = 'fix the login bug' ] \
    || fail "named claude composer content should extract the typed text, got '$out'"
  # Pi non-regression: a titled rule over a blank row never proves a pi
  # composer, even with a live idle pi identity.
  assert_screen "titled pair over a blank row is not pi" unknown "$CAPS_STYLED" \
    "transcript"$'\n'"$titled"$'\n\n'"$rule"$'\n footer' '' "$pi_idle"
  pass "matrix: a named claude session's titled top rule proves its composer; pi stays unchanged"
}

test_matrix_claude_arrow_statusline_footer() {
  # Real claude 2.x on herdr (captured live 2026-09-20, herdr 0.8.0): the
  # composer is a bare `❯`+U+00A0 row between two solid rules, and the harness
  # draws a user statusLine plus its permission-mode hint directly BELOW the
  # closing rule. That statusLine opened with `→`, which is Cursor's own agent
  # prompt glyph, so the bottom-most-candidate rule selected the statusLine as
  # a bare composer, swallowed the hint row beneath it as wrapped input, and
  # every steer to a claude worker was refused with a `pending` verdict on a
  # visibly empty composer. A pair that closed over a bare agent-glyph row is
  # a proven composer container, so its contiguous non-blank footer rows are
  # furniture and cannot outrank the composer they sit under.
  local pair footer screen typed residue claude_idle
  claude_idle=$(printf 'claude\tidle')
  pair=$'transcript line\n────────────────────────\n❯'"$NBSP"$'\n────────────────────────'
  footer=$'\n  → repo git:(fm/branch)× | Opus 5 | ctx 15%\n  ⏵⏵ bypass permissions on (shift+tab to cycle)'
  screen="$pair$footer"
  assert_screen "claude idle under an arrow statusline on herdr" empty "$CAPS_STYLED" "$screen" '' "$claude_idle"
  assert_screen "claude idle under an arrow statusline on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "claude idle under an arrow statusline on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  # The protection this must NOT remove: real unsubmitted text in that same
  # composer, under that same statusline, still refuses.
  typed=$'transcript line\n────────────────────────\n❯ fix the login bug\n────────────────────────'"$footer"
  assert_screen "claude typed under an arrow statusline" pending "$CAPS_STYLED" "$typed" '' "$claude_idle"
  # The live second defect: a stray SGR mouse report left in the composer by
  # a click in the pane is real pending content, not furniture.
  residue=$'transcript line\n────────────────────────\n❯ <65;77;27M\n────────────────────────'"$footer"
  assert_screen "stray mouse report in the composer" pending "$CAPS_STYLED" "$residue" '' "$claude_idle"
  pass "matrix: claude's arrow statusline is footer furniture, not a composer holding text"
}

test_composer_footer_demotion_needs_a_proven_pair() {
  # The demotion is bounded in three directions, and each bound is a case
  # where a lower glyph row IS the live composer.
  local screen out claude_idle pi_idle
  claude_idle=$(printf 'claude\tidle'); pi_idle=$(printf 'pi\tidle')
  # 1. Contiguity: a blank row ends the footer zone, so a composer redrawn
  #    below an old rule pair still wins.
  screen=$'────────────────────────\n❯ old draft\n────────────────────────\n  → repo git:(main)\n\n→'
  assert_screen "blank row reopens lower candidates" empty "$CAPS_STYLED_NOID" "$screen"
  # 2. Proof: a pair that closed over NO agent-glyph row proves no composer,
  #    so nothing below it is demoted. pi's own blank pair is exactly that.
  screen=$'────────────────────────\n\n────────────────────────\n→'
  assert_screen "an unproven pair demotes nothing" empty "$CAPS_STYLED_NOID" "$screen"
  # 3. No pair at all: Cursor draws its `→` composer between half-block rules,
  #    which are not separator rules, so its footer rows change nothing.
  screen=$' ▄▄▄▄▄▄▄▄\n  →\n ▀▀▀▀▀▀▀▀\n  Cursor Grok 4.5 High · 6.7%   Run Everything\n  ~/wt · 64cdd3a'
  assert_screen "cursor keeps its own bare composer" empty "$CAPS_STYLED_NOID" "$screen"
  # A later pair WITHOUT a glyph row must reopen candidates the earlier proven
  # pair had closed, so the zone cannot leak down a screen.
  screen=$'────────────────────────\n❯'"$NBSP"$'\n────────────────────────\n  → repo git:(main)\n────────────────────────\n────────────────────────\n→'
  assert_screen "a later unproven pair reopens candidates" empty "$CAPS_STYLED_NOID" "$screen"
  # And the strict posture is untouched: a footer row alone proves nothing.
  out=$(fm_composer_classify_screen "$CAPS_STYLED_NOID" $'transcript\n  → repo git:(main) | Opus 5')
  [ "$out" != empty ] \
    || fail "an unanchored statusline row must never prove an empty composer, got '$out'"
  pass "fm_composer_classify_screen: footer demotion needs a contiguous, glyph-proven pair"
}

test_composer_footer_zone_is_shape_independent() {
  # The same captain-facing failure on the BORDERED composer: claude 2.x
  # renders its composer inside a rounded box on a wide pane, and this home's
  # statusLine (opening with `→`, Cursor's prompt glyph) plus the permission
  # hint still land on the two contiguous rows below the closing border. The
  # footer-zone invariant is a property of an envelope proven by a glyph row
  # inside it, not of the pi separator pair, so it must hold here too.
  local box footer screen out claude_idle
  claude_idle=$(printf 'claude\tidle')
  box=$'transcript line\n╭───────────────────────────╮\n│ ❯'"$NBSP"$'                        │\n╰───────────────────────────╯'
  footer=$'\n → repo git:(fm/branch)× | Opus 5 | ctx 15%\n ⏵⏵ bypass permissions on'
  screen="$box$footer"
  assert_screen "boxed claude idle under an arrow statusline on herdr" empty "$CAPS_STYLED" "$screen" '' "$claude_idle"
  assert_screen "boxed claude idle under an arrow statusline on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "boxed claude idle under an arrow statusline on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED" "$screen")
  case "$out" in
    *'repo git:'*|*'bypass permissions'*)
      fail "the statusline footer must never be extracted as composer content, got '$out'" ;;
  esac
  # The protection this must NOT remove: real unsubmitted text inside that same
  # bordered composer, under that same footer, still refuses.
  screen=$'transcript line\n╭───────────────────────────╮\n│ ❯ half-typed draft        │\n╰───────────────────────────╯'"$footer"
  assert_screen "boxed claude typed under an arrow statusline" pending "$CAPS_STYLED" "$screen" '' "$claude_idle"
  # The deliberate counterexample, pinned as such: codex's startup banner has
  # no glyph row inside it, so it proves no composer, opens no footer zone, and
  # the live bare row contiguously below it keeps winning.
  screen=$'╭────────────────────────╮\n│ permissions: YOLO mode │\n╰────────────────────────╯\n❯'"$NBSP"
  assert_screen "unproven banner still yields to the bare row below it" empty "$CAPS_PLAIN" "$screen"
  pass "fm_composer_classify_screen: the footer zone holds for boxes, not only separator pairs"
}

test_composer_footer_zone_refuses_rather_than_allows() {
  # The footer-zone demotion is ASYMMETRIC: `empty` is the only verdict that
  # authorizes fm-send to type into the pane, so the rule may move a verdict
  # toward refusing but never toward `empty`. Every screen below classified
  # `pending` before the footer zone existed and must never read `empty`.
  local screen out
  # 1. Draft loss. A row leading with the SAME glyph the envelope was proven by
  #    is a live composer, not furniture, and must keep winning - otherwise the
  #    doorbell types over a draft the worker can see.
  screen=$'────────────────────────\n❯'"$NBSP"$'\n────────────────────────\n❯ my typed draft'
  assert_screen "separated: a live draft below the pair keeps winning" pending "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'my typed draft' ] \
    || fail "the live draft must be the extracted composer content, got '$out'"
  screen=$'╭────────────────────────╮\n│ ❯'"$NBSP"$'                     │\n╰────────────────────────╯\n❯ my typed draft'
  assert_screen "boxed: a live draft below the box keeps winning" pending "$CAPS_STYLED_NOID" "$screen"
  # 2. Working agent. Unclaimed activity below a proven envelope is not
  #    furniture in EITHER row order, even when one of the rows leads with a
  #    foreign agent glyph, so the envelope above it stays stale.
  for screen in \
    $'╭────────────────────────╮\n│ ❯                      │\n╰────────────────────────╯\nWorking on request...\n→ ran npm test (3 failures)' \
    $'╭────────────────────────╮\n│ ❯                      │\n╰────────────────────────╯\n→ ran npm test (3 failures)\nWorking on request...' \
    $'────────────────────────\n❯'"$NBSP"$'\n────────────────────────\nWorking on request...\n→ ran npm test (3 failures)' \
    $'────────────────────────\n❯'"$NBSP"$'\n────────────────────────\n→ ran npm test (3 failures)\nWorking on request...'
  do
    out=$(fm_composer_classify_screen "$CAPS_STYLED_NOID" "$screen")
    [ "$out" != empty ] \
      || fail "a working agent below a proven envelope must never read empty, got '$out'"
    out=$(LC_ALL=C fm_composer_classify_screen "$CAPS_STYLED_NOID" "$screen")
    [ "$out" != empty ] \
      || fail "a working agent below a proven envelope must never read empty under LC_ALL=C, got '$out'"
  done
  # 3. The other direction, which the demotion must not invert either: a pair
  #    holding a QUOTED prompt in the transcript above a live, visibly empty
  #    composer row reads empty, and the quoted text is never composer content.
  screen=$'────────────────────────\ntranscript one\ntranscript two\n❯ some quoted prompt in the transcript\n────────────────────────\n❯'"$NBSP"
  assert_screen "a quoted prompt above a live empty row stays empty" empty "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  case "$out" in
    *'some quoted prompt'*) fail "a quoted transcript prompt must never be composer content, got '$out'" ;;
  esac
  pass "fm_composer_classify_screen: the footer zone only ever refuses, never allows"
}

# Claude Code 2.1.291 marks the selected row of its slash-command popup with the
# same `❯` its composer uses, where 2.1.289 drew that row unmarked. The popup
# renders below the composer's closing rule, so the marked row became a second
# bare composer and the typed command's own read-back was the whole popup list.
# The screens are real captures (Herdr 0.8.2, Claude Code 2.1.291 on Haiku 4.5),
# reduced to the composer, its rules, and the first popup rows with their SGR
# bytes intact. `slash-only` is the case where the selected row is NOT the typed
# text, `truncated-name` the one where the row opens with `…` instead of `/`,
# and `exit-typed-with-notice` carries the notification row Claude draws between
# the rule and the popup when it runs inside another Claude session.
test_claude_slash_popup_marked_row_is_not_a_second_composer() {
  local dir=$ROOT/tests/captures/claude-2.1.291-slash-popup pair name want screen out
  local claude_idle
  claude_idle=$(printf 'claude\tidle')
  for pair in \
    'exit-typed:/exit' \
    'exit-typed-with-notice:/exit' \
    'no-mistakes-typed:/no-mistakes' \
    'slash-only:/' \
    'truncated-name:/claude-md-management:claude-md-improver'
  do
    name=${pair%%:*}
    want=${pair#*:}
    screen=$(cat "$dir/$name.ansi")
    out=$(FM_COMPOSER_GHOST_LUMA_MAX=0 fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
    [ "$out" = "$want" ] || fail "$name: the composer content must be '$want', not the popup list, got '$out'"
    out=$(LC_ALL=C FM_COMPOSER_GHOST_LUMA_MAX=0 fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
    [ "$out" = "$want" ] || fail "$name under LC_ALL=C: the composer content must be '$want', got '$out'"
    assert_screen "$name typed on herdr" pending "$CAPS_STYLED" "$screen" '' "$claude_idle"
    assert_screen "$name typed on zellij" pending "$CAPS_STYLED_NOID" "$screen"
  done
  screen=$(cat "$dir/idle.ansi")
  assert_screen "an idle composer with no popup stays empty" empty "$CAPS_STYLED" "$screen" '' "$claude_idle"
  pass "fm_composer_extract_selected_content: Claude 2.1.291's marked popup row is not read as the composer"
}

test_claude_slash_popup_demotion_only_ever_refuses() {
  # The popup demotion falls back to the envelope above the marked row, so it
  # may only fire when that envelope holds typed `/` text and the row has the
  # popup shape (`/name` or a truncated `…name`, a gap, then a description).
  # Anything else keeps the old reading, and none of these may ever read empty.
  local screen out style claude_idle original
  local rule='────────────────────────'
  local dir=$ROOT/tests/captures/claude-2.1.291-slash-popup
  local typed=$'\e[38;2;177;185;249m/exit\e[0m'
  claude_idle=$(printf 'claude\tidle')
  original=$(cat "$dir/exit-typed.ansi")
  # 1. An EMPTY composer with a popup-shaped row below it: a popup cannot be
  #    open over an empty composer, so the row is not demoted to the empty
  #    envelope above it.
  screen=$rule$'\n❯'"$NBSP"$'\n'"$rule"$'\n  ❯ /exit    Exit the CLI\n    /context    Visualize context'
  assert_screen "an empty composer above a popup-shaped row" pending "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  case "$out" in
    '/exit Exit the CLI'*) ;;
    *) fail "the lower row must stay the composer read when the envelope is empty, got '$out'" ;;
  esac
  # 2. A numbered-choice dialog row has neither the `/` opening nor the gap.
  screen=$rule$'\n❯'"$NBSP"$'/exit\n'"$rule"$'\n  ❯ 1. Yes\n    2. No'
  assert_screen "a numbered choice below a typed command" pending "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  case "$out" in
    '1. Yes'*) ;;
    *) fail "a numbered-choice row must stay a bare candidate, got '$out'" ;;
  esac
  # 3. A single-spaced `/draft` row has no description gap: a live draft.
  screen=$rule$'\n❯'"$NBSP"$'/exit\n'"$rule"$'\n  ❯ /draft'
  assert_screen "a one-word slash draft below a typed command" pending "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = '/draft' ] || fail "a one-word slash draft must stay the composer read, got '$out'"
  # 4. The envelope's typed text must itself open with `/`.
  screen=$rule$'\n❯ fix the login bug\n'"$rule"$'\n  ❯ /exit    Exit the CLI'
  assert_screen "typed prose above a popup-shaped row" pending "$CAPS_STYLED_NOID" "$screen"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  case "$out" in
    '/exit Exit the CLI'*) ;;
    *) fail "typed prose must not license the popup demotion, got '$out'" ;;
  esac
  # 5. The envelope's `/` must survive the ghost strip the verdict reads. The
  #    real 2.1.291 capture with its typed `/exit` restyled dark grey (the
  #    112;112;112 Claude 2.1.283 drew it in) or SGR 2 dim strips to a bare
  #    `❯`, so that envelope is no fallback and the marked row keeps its read.
  for style in $'\e[38;2;112;112;112m' $'\e[2m'; do
    screen=${original/"$typed"/"$style/exit"$'\e[0m'}
    [ "$screen" != "$original" ] || fail "the capture's typed /exit was not restyled"
    assert_screen "a ghost-styled typed command on herdr" pending "$CAPS_STYLED" "$screen" '' "$claude_idle"
    assert_screen "a ghost-styled typed command on zellij" pending "$CAPS_STYLED_NOID" "$screen"
  done
  # 6. A bordered box is no borderless row to fall back to, so a marked row
  #    directly below one still reads pending.
  screen=$'transcript line\n╭───────────────────────────╮\n│ ❯ /exit                   │\n╰───────────────────────────╯\n  ❯ /exit    Exit the CLI\n    /context    Visualize context'
  assert_screen "a typed command in a box above a marked row on herdr" pending "$CAPS_STYLED" "$screen" '' "$claude_idle"
  assert_screen "a typed command in a box above a marked row on zellij" pending "$CAPS_STYLED_NOID" "$screen"
  pass "fm_composer_classify_screen: the popup demotion needs typed slash text and the popup row shape, and never reads empty"
}

test_matrix_codex_dim_hint_row() {
  # Real idle codex: bold `›`, reset, then an SGR-2 dim hint. Styled captures
  # strip the ghost and prove empty; plain captures must defer as unknown -
  # NEVER the old false `pending` that read the hint as unsent text.
  local styled plain
  styled=$'banner\n'"${ESC}[1m›${ESC}[0m ${ESC}[2mUse /skills to list available skills${ESC}[0m"
  plain=$'banner\n› Use /skills to list available skills'
  assert_screen "codex idle on tmux" empty "$CAPS_TMUX" "$styled" 1
  assert_screen "codex idle on herdr" empty "$CAPS_STYLED" "$styled"
  assert_screen "codex idle on zellij" empty "$CAPS_STYLED_NOID" "$styled"
  assert_screen "codex idle on plain backends" unknown "$CAPS_PLAIN" "$plain"
  pass "matrix: codex's dim hint is empty when styling proves it, unknown (never pending) when it cannot"
}

test_matrix_muse_truecolor_glyph_survives_signal_loss() {
  # Real idle muse: truecolor `⟩` (38;2;90;160;255, luminance ~149.9) under a
  # TITLED rule. Two independent signals prove emptiness: the glyph surviving
  # the ghost strip, and the UNSTRIPPED plain row carrying an agent glyph.
  # Drive them apart: with the luma threshold raised past the glyph's
  # luminance, the ghost strip erases it, and the verdict must survive on the
  # plain-row signal alone.
  local screen plain out
  screen=$'── Voice input (⌥ + v to start) ─────\n'"${ESC}[0m${ESC}[38;2;90;160;255m⟩${ESC}[0m"
  plain=$'── Voice input (⌥ + v to start) ─────\n⟩'
  assert_screen "muse idle on tmux" empty "$CAPS_TMUX" "$screen" 1
  assert_screen "muse idle on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "muse idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "muse idle on cmux/orca" empty "$CAPS_PLAIN" "$plain"
  out=$(FM_COMPOSER_GHOST_LUMA_MAX=200 fm_composer_classify_screen "$CAPS_STYLED" "$screen")
  [ "$out" = empty ] || fail "muse must stay empty when the ghost strip eats its glyph (plain-row signal), got '$out'"
  pass "matrix: muse's ⟩ reads empty everywhere and survives losing the styled-glyph signal"
}

test_matrix_cursor_reverse_video_placeholder_remnant() {
  # Real idle cursor-agent (2026.08.11-e8db854), captured byte-for-byte from a
  # live pane: the `→ ` glyph and the placeholder tail are dim (SGR 2), but the
  # cell under the terminal cursor is REVERSE VIDEO (SGR 0;7). Reverse video is
  # neither dim nor a dark foreground, so the ghost stripper keeps that one
  # character and an idle composer reduces to a lone `P`.
  local row screen plain out stripped
  row="${ESC}[48;2;21;21;21m ${ESC}[2m→ ${ESC}[0;7m${ESC}[48;2;21;21;21mP"
  row="${row}${ESC}[0;2m${ESC}[48;2;21;21;21mlan, search, build anything${ESC}[0m"
  screen=$'transcript\n\n'"$row"
  plain=$'transcript\n\n  → Plan, search, build anything'

  # NON-VACUOUSNESS: prove the remnant really survives stripping. If the ghost
  # stripper ever learned SGR 7, `stripped` would be empty and the verdict below
  # would come from the empty-content path instead, silently retiring the
  # plain-row branch this case exists to cover.
  stripped=$(printf '%s' "$row" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var stripped
  [ "$stripped" = P ] \
    || fail "cursor's reverse-video remnant must survive ghost stripping as 'P', got '$stripped'"

  assert_screen "cursor idle on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "cursor idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  # An UNSTYLED capture carries no ghost-strip proof, so a bare row matching a
  # placeholder is indistinguishable from typed text and must stay unknown -
  # the same degradation every other bare-row placeholder already takes.
  assert_screen "cursor idle on cmux/orca" unknown "$CAPS_PLAIN" "$plain"

  # The dangerous direction: text a user actually TYPED is uniformly bright, so
  # stripping leaves it EQUAL to the plain row. Even when that text is exactly
  # the placeholder, it must stay pending - never a false empty.
  local typed typed_plain
  typed="${ESC}[48;2;21;21;21m ${ESC}[2m→ ${ESC}[0m${ESC}[38;2;224;222;244mAdd a follow-up${ESC}[0m"
  typed_plain=$'transcript\n\n  → Add a follow-up'
  assert_screen "cursor typed placeholder text stays pending" pending \
    "$CAPS_STYLED" $'transcript\n\n'"$typed"
  # Without styling there is no proof either way, so it must not read empty.
  out=$(fm_composer_classify_screen "$CAPS_PLAIN" "$typed_plain")
  [ "$out" != empty ] \
    || fail "an unstyled cursor row matching the placeholder must not read empty, got '$out'"
  pass "matrix: cursor's reverse-video placeholder remnant reads empty; real typed text stays pending"
}

test_matrix_cursor_fully_dim_placeholder() {
  # cursor-agent 2026.10.19-6bbf2c4, tmux, idle pane. The glyph and the whole
  # placeholder are one SGR 2 run on a truecolor background. The terminal
  # cursor sits below the footer (cursor_flag 0), so nothing on this row is
  # reverse video. Ghost stripping therefore empties the row instead of
  # leaving the lone-character remnant the case above covers. Half-block
  # rules are the live frame; they are edges, not a cornered box.
  local row screen plain stripped typed
  row="${ESC}[48;2;42;44;57m ${ESC}[2m→ Add a follow-up${ESC}[0m"
  row="${row}${ESC}[48;2;42;44;57m        ${ESC}[49m"
  screen=$'transcript\n '"${ESC}[38;2;42;44;57m▄▄▄▄▄▄▄▄${ESC}[39m"$'\n'"$row"
  screen="$screen"$'\n '"${ESC}[38;2;42;44;57m▀▀▀▀▀▀▀▀${ESC}[39m"
  screen="$screen"$'\n  Auto · 64%                                                                   Run Everything\n  ~/wt · <branch>\n'
  plain=$'transcript\n ▄▄▄▄▄▄▄▄\n  → Add a follow-up\n ▀▀▀▀▀▀▀▀\n  Auto · 64%                                                                   Run Everything\n  ~/wt · <branch>'

  # NON-VACUOUSNESS: this row must strip to nothing. A surviving remnant would
  # be the older case, and this one would no longer prove the empty-content path.
  stripped=$(printf '%s' "$row" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var stripped
  [ -z "$stripped" ] \
    || fail "the fully dim cursor row must ghost-strip to empty, got '$stripped'"

  assert_screen "cursor 2026.10 fully dim idle on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "cursor 2026.10 fully dim idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  # The cursor-anchored read stays blind: the cursor is on the blank row under
  # the footer, not on the composer. The tmux adapter reclassifies only after
  # process identity; this owner must not treat that blank row as empty.
  assert_screen "cursor 2026.10 anchored blank row stays unknown" unknown \
    "$CAPS_TMUX" "$screen" 6
  assert_screen "cursor 2026.10 unstyled placeholder stays unknown" unknown \
    "$CAPS_PLAIN" "$plain"

  # Bright typed text, including text that is exactly the placeholder, survives
  # stripping and must stay pending.
  typed="${ESC}[48;2;42;44;57m ${ESC}[2m→ ${ESC}[0m${ESC}[38;2;224;222;244mAdd a follow-up${ESC}[0m"
  assert_screen "cursor 2026.10 typed placeholder stays pending" pending \
    "$CAPS_STYLED" $'transcript\n '"${ESC}[38;2;42;44;57m▄▄▄▄▄▄▄▄${ESC}[39m"$'\n'"$typed"$'\n '"${ESC}[38;2;42;44;57m▀▀▀▀▀▀▀▀${ESC}[39m"$'\n'

  # Dim text that is not an anchored placeholder is not proof of an empty
  # composer. Unknown keeps the injection guard closed.
  row="${ESC}[48;2;42;44;57m ${ESC}[2m→ ship the fix${ESC}[0m"
  assert_screen "cursor 2026.10 dim non-placeholder stays unknown" unknown \
    "$CAPS_STYLED" $'transcript\n '"${ESC}[38;2;42;44;57m▄▄▄▄▄▄▄▄${ESC}[39m"$'\n'"$row"$'\n '"${ESC}[38;2;42;44;57m▀▀▀▀▀▀▀▀${ESC}[39m"$'\n'
  pass "matrix: cursor's fully dim placeholder reads empty; typed text stays pending"
}

test_matrix_herdr_halfblock_rule_bounds_bare_wrap() {
  # Herdr draws a composer's rules with half-block glyphs (▄ above, ▀ below)
  # rather than the box-drawing family. Without treating those as edges, a bare
  # composer's WRAP region walks through its own closing rule and swallows the
  # footer, whose real content turns an idle pane into a false `pending`.
  # Captured live from a herdr cursor pane.
  local screen plain out
  plain=$'transcript\n ▄▄▄▄▄▄▄▄\n  → Add a follow-up\n ▀▀▀▀▀▀▀▀\n  Cursor Grok 4.5 High · 6.7%   Run Everything\n  ~/wt · 64cdd3a'
  # The closing rule must bound the region, so the footer below is not input.
  fm_composer_row_has_edge ' ▀▀▀' \
    || fail "a half-block rule row must count as a structural edge"
  fm_composer_row_has_edge ' ▄▄▄' \
    || fail "the upper half-block rule must count as a structural edge"
  # Non-vacuousness: the footer rows really are non-blank content that would be
  # swallowed if the rule did not bound the region.
  case "$plain" in *"Run Everything"*) : ;; *) fail "fixture lost its footer content" ;; esac
  ESC_LOCAL=$(printf '\033')
  screen=$'transcript\n ▄▄▄▄▄▄▄▄\n'"  ${ESC_LOCAL}[2m→ ${ESC_LOCAL}[0;7mA${ESC_LOCAL}[0;2mdd a follow-up${ESC_LOCAL}[0m"$'\n ▀▀▀▀▀▀▀▀\n  Cursor Grok 4.5 High · 6.7%   Run Everything\n  ~/wt · 64cdd3a'
  out=$(fm_composer_classify_screen "$CAPS_STYLED" "$screen")
  [ "$out" = empty ] \
    || fail "an idle cursor composer inside herdr half-block rules must read empty, got '$out'"
  pass "matrix: herdr half-block rules bound a bare composer's wrap region"
}

test_matrix_omp_status_row_bounds_bare_composer() {
  # omp (Oh My Pi) draws its status line directly BELOW the borderless `❯`
  # composer. Captured live through Herdr on omp 18.1.11 under the captain's
  # unicode preset (idle), plus the nerd-preset idle row and the busy spinner
  # row from the 18.1.2 investigation. Without the status-row rule the bare
  # wrap region swallows that row and an idle omp pane reads `pending`, which
  # skipped the doorbell on the first live omp worker.
  local idle_unicode idle_nerd busy typed wrapped
  idle_unicode=$'transcript line

❯
 π  · ◔ GPT-6-Astra · 🌳 …-workspace · ⑂ detached · ◫ 15.4%/272K ⟲ · (sub)'
  idle_nerd=$'transcript line

❯
 󰵗  ·  qwen3:8b ·  kun-agent-workspace/… ·  detached ?1 ·  36.7%/41K'
  busy=$'transcript line

  ⎋ Working…

❯
 ⠧ 11s  · ◔ GPT-6-Astra · ◫ 15.4%/272K'
  typed=$'transcript line

❯ fix the flaky test
 π  · ◔ GPT-6-Astra · 🌳 …-workspace · ⑂ detached · ◫ 15.4%/272K ⟲ · (sub)'
  # Non-vacuousness: each status row is real non-blank content that the wrap
  # region would otherwise take as typed input.
  _fm_composer_row_is_omp_status ' π  · ◔ GPT-6-Astra · 🌳 …-workspace' \
    || fail "the unicode-preset omp status row must be recognized as furniture"
  _fm_composer_row_is_omp_status ' 󰵗  ·  qwen3:8b ·  kun-agent-workspace/… ·  detached ?1 ·  36.7%/41K' \
    || fail "the nerd-preset omp status row must be recognized as furniture"
  _fm_composer_row_is_omp_status ' ⠧ 11s  · ◔ GPT-6-Astra' \
    || fail "the busy omp spinner row must be recognized as furniture"
  _fm_composer_row_is_omp_status 'fix the flaky test' \
    && fail "ordinary typed text must not be mistaken for omp status furniture"
  _fm_composer_row_is_omp_status 'please rerun the suite and report' \
    && fail "ordinary prose must not be mistaken for omp status furniture"
  # Only omp's identity cell opens the row: a wrapped typed row that happens
  # to begin with a short word and a spaced middle dot is composer input.
  _fm_composer_row_is_omp_status 'fix · tests before pushing' \
    && fail "wrapped typed text with a middle dot must not be mistaken for omp status furniture"
  # The ascii preset's identity cell is `pi`, but that preset separates its
  # cells with ` - `, so a row opening `pi ·` is never omp furniture.
  _fm_composer_row_is_omp_status 'pi · e · phi as the three constants' \
    && fail "typed text opening 'pi ·' must not be mistaken for omp status furniture"
  _fm_composer_row_is_omp_status ' ⣾ 3s  · ◔ GPT-6-Astra' \
    || fail "the status-set omp spinner row must be recognized as furniture"
  assert_screen "idle omp (unicode preset)" empty "$CAPS_STYLED" "$idle_unicode"
  assert_screen "idle omp (nerd preset)" empty "$CAPS_STYLED" "$idle_nerd"
  assert_screen "busy omp keeps an empty composer" empty "$CAPS_STYLED" "$busy"
  assert_screen "typed omp text is pending" pending "$CAPS_STYLED" "$typed"
  assert_screen "idle omp on a plain capture" empty "$CAPS_PLAIN" "$idle_unicode"
  # The boundary must not cut a bare composer's own wrapped input: with the
  # cursor on a continuation row that opens `fix · tests`, the composer is a
  # proven wrap region and reads pending, exactly as it did before the rule.
  wrapped=$'transcript line\n\n❯ please run the suite and then\nfix · tests before pushing'
  assert_screen "wrapped typed text with a middle dot stays pending" pending "$CAPS_TMUX" "$wrapped" 3
  wrapped=$'transcript line\n\n❯ document the constants in the order\npi · e · phi with one example each'
  assert_screen "wrapped typed text opening 'pi ·' stays pending" pending "$CAPS_TMUX" "$wrapped" 3
  pass "matrix: omp's status row bounds the bare composer's wrap region"
}

# codex_cell <grey> <glyph>: one codex 0.154 starfield cell exactly as the
# harness draws it - a truecolor grey foreground, the composer's grey
# background, the braille glyph, then a reset.
codex_cell() {
  printf '%s[38;2;%s;%s;%sm%s[48;2;57;57;57m%s%s[0m' "$ESC" "$1" "$1" "$1" "$ESC" "$2" "$ESC"
}

test_matrix_codex_idle_starfield_furniture() {
  # Real idle codex-cli 0.154.0 (gpt-6-astra, fast mode) captured byte-for-byte
  # through Herdr (`pane read --format ansi`) from the first codex second mate:
  # an animated braille "starfield" on the row above the bold `›`, on the `›`
  # row behind the SGR-2 dim `Ask Codex to do anything` placeholder, and on
  # the row below, then a bright model/path/title status footer. The cells are
  # truecolor greys on BOTH sides of the 128 ghost-luma ceiling, so the
  # brighter ones survive the ghost strip, and the rows below the glyph carry
  # no structural edge. The bare shape therefore extended its wrap region over
  # the two rows beneath the glyph and read the survivors as wrapped typed
  # input: `pending`, which deferred every steering doorbell for that pane.
  local bg="${ESC}[48;2;57;57;57m" above glyph glyph2 below footer
  local screen screen2 plain plain2 ascii_screen stripped out
  above="${ESC}[0m${bg}                         ${ESC}[0m$(codex_cell 82 ⢀)${bg}      ${ESC}[0m$(codex_cell 136 ⠂)${bg} ${ESC}[0m$(codex_cell 163 ⠄)${bg}     ${ESC}[0m$(codex_cell 118 ⠈)"
  glyph="${ESC}[0m${ESC}[1m${bg}›${ESC}[0m${bg} ${ESC}[0m${ESC}[2m${bg}Ask Codex to do anything${ESC}[0m$(codex_cell 117 ⡀)${bg}  ${ESC}[0m$(codex_cell 88 ⠈)${bg}       ${ESC}[0m$(codex_cell 156 ⠂)${bg}        ${ESC}[0m$(codex_cell 71 ⠁)$(codex_cell 161 ⠐)${bg} ${ESC}[0m$(codex_cell 165 ⠁)"
  # A second live sample of the same pane, minutes later: the animation had
  # placed a bright cell BETWEEN the glyph and the placeholder.
  glyph2="${ESC}[0m${ESC}[1m${bg}›${ESC}[0m$(codex_cell 138 ⠁)${ESC}[2m${bg}Ask Codex to do anything${ESC}[0m$(codex_cell 163 ⡀)${bg}  ${ESC}[0m$(codex_cell 132 ⠈)"
  below="${ESC}[0m${bg}        ${ESC}[0m$(codex_cell 101 ⠐)${bg}    ${ESC}[0m$(codex_cell 111 ⠄)${bg}   ${ESC}[0m$(codex_cell 165 ⠠)${bg}  ${ESC}[0m$(codex_cell 121 ⢀)$(codex_cell 122 ⠠)$(codex_cell 81 ⡀)$(codex_cell 150 ⠄⠂)"
  footer="  ${ESC}[0m${ESC}[38;2;246;226;183mgpt-6-astra high fast${ESC}[0m${ESC}[2m · ${ESC}[0m${ESC}[38;2;171;223;167m~/Projects/purser${ESC}[0m${ESC}[2m · ${ESC}[0m${ESC}[38;2;156;222;211mLaunch Purser desk brief${ESC}[0m"
  screen=$'transcript line\n\n'"$above"$'\n'"$glyph"$'\n'"$below"$'\n'"$footer"
  screen2=$'transcript line\n\n'"$above"$'\n'"$glyph2"$'\n'"$below"$'\n'"$footer"
  plain=$(printf '%s\n' "$screen" | fm_composer_strip_ansi)
  plain2=$(printf '%s\n' "$screen2" | fm_composer_strip_ansi)

  # NON-VACUOUSNESS: the ghost strip really leaves braille survivors behind the
  # placeholder and on the row below (cells above the luma ceiling), and the
  # footer really is non-blank, edge-free content the wrap region would take.
  stripped=$(printf '%s\n' "$glyph" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var stripped
  [ "$stripped" != '›' ] \
    || fail "the glyph row's starfield cells must survive ghost stripping, or the furniture case is vacuous"
  stripped=$(printf '%s\n' "$stripped" | fm_composer_strip_braille)
  fm_composer_normalize_trim_var stripped
  [ "$stripped" = '›' ] \
    || fail "everything surviving ghost stripping behind the glyph must be braille, got '$stripped'"
  stripped=$(printf '%s\n' "$below" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var stripped
  [ -n "$stripped" ] \
    || fail "the row below the glyph must keep starfield cells after ghost stripping"
  _fm_composer_row_is_braille_furniture "$stripped" \
    || fail "the row below the glyph must be recognized as braille furniture"
  fm_composer_row_has_edge '  gpt-6-astra high fast · ~/Projects/purser · Launch Purser desk brief' \
    && fail "fixture drift: the footer must carry no structural edge, or the boundary rule is untested"

  # The verdicts: empty wherever styling can prove the placeholder ghost, on
  # both live samples, in both locales; unknown (never pending) on a plain
  # capture, exactly as the codex dim-hint row above.
  assert_screen "codex 0.154 idle on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "codex 0.154 idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "codex 0.154 idle on tmux (cursor on the glyph row)" empty "$CAPS_TMUX" "$screen" 3
  assert_screen "codex 0.154 idle on cmux/orca" unknown "$CAPS_PLAIN" "$plain"
  assert_screen "codex 0.154 idle (second sample) on herdr" empty "$CAPS_STYLED" "$screen2"
  assert_screen "codex 0.154 idle (second sample) on tmux" empty "$CAPS_TMUX" "$screen2" 3
  assert_screen "codex 0.154 idle (second sample) on cmux/orca" unknown "$CAPS_PLAIN" "$plain2"
  # A cursor parked on the starfield row below the glyph is not inside a wrap
  # region, so the strict blank-row posture keeps it unknown.
  assert_screen "codex 0.154 cursor on the starfield row" unknown "$CAPS_TMUX" "$screen" 4

  # DIVERGENCE: the same screen with every starfield cell replaced by a letter
  # is wrapped typed input and must stay pending, so the furniture verdict
  # above cannot come from anything but the braille rule.
  ascii_screen=$(printf '%s\n' "$screen" | LC_ALL=C sed 's/⢀/x/g; s/⠂/x/g; s/⠄/x/g; s/⠈/x/g; s/⡀/x/g; s/⠁/x/g; s/⠐/x/g; s/⠠/x/g')
  case "$ascii_screen" in *'⠂'*|*'⠁'*) fail "fixture drift: the divergence screen still carries braille" ;; esac
  assert_screen "starfield replaced by letters on herdr" pending "$CAPS_STYLED" "$ascii_screen"
  assert_screen "starfield replaced by letters on tmux" pending "$CAPS_TMUX" "$ascii_screen" 3

  # NEGATIVES that keep the rule from over-stripping:
  # (i) a real message wrapped below the `›` row, footer beneath, stays pending.
  out=$'transcript line\n\n› please run the suite and then\ncontinue with the docs\n'"$footer"
  assert_screen "wrapped typed input above the codex footer on herdr" pending "$CAPS_STYLED" "$out"
  assert_screen "wrapped typed input above the codex footer on tmux" pending "$CAPS_TMUX" "$out" 3
  # (ii) braille mixed with typed text is typed text, on the glyph row and on
  # a wrapped row alike.
  assert_screen "braille mixed into the glyph row" pending "$CAPS_STYLED" $'transcript line\n\n› fix ⠂ the tests'
  assert_screen "braille mixed into a wrapped row" pending "$CAPS_STYLED" $'transcript line\n\n› please\nfix ⠂ the tests'
  # (iii) a typed row carrying a spaced middle dot is composer input.
  assert_screen "wrapped typed row with a middle dot on herdr" pending "$CAPS_STYLED" $'transcript line\n\n› deploy\nfix · tests before pushing'
  assert_screen "wrapped typed row with a middle dot on tmux" pending "$CAPS_TMUX" $'transcript line\n\n› deploy\nfix · tests before pushing' 3
  # (iv) the footer or a starfield row alone, with no bare glyph above, gains
  # no new verdict: still no container proof.
  assert_screen "codex footer alone on herdr" unknown "$CAPS_STYLED" $'transcript line\n\n'"$footer"
  assert_screen "codex footer alone on tmux" unknown "$CAPS_TMUX" $'transcript line\n\n'"$footer" 2
  assert_screen "starfield row alone on herdr" unknown "$CAPS_STYLED" $'transcript line\n\n'"$below"
  pass "matrix: codex 0.154's starfield rows are furniture; typed, mixed, and unanchored rows keep their verdicts"
}

test_matrix_pi_separated_needs_identity() {
  # Real idle pi: a blank row between two solid rules. The blank row alone is
  # exactly what the strict rule refuses; only structure PLUS a live
  # idle/done pi identity proves the composer (herdr's rule, now
  # fleet-wide; tmux supplies identity from its foreground-process probe).
  local screen typed pi_idle pi_working pi_blocked none
  screen=$'transcript\n────────────────────────\n\n────────────────────────\n footer'
  pi_idle=$(printf 'pi\tidle'); pi_working=$(printf 'pi\tworking'); none=$(printf 'zsh\t')
  pi_blocked=$(printf 'pi\tblocked')
  assert_screen "pi idle with identity" empty "$CAPS_STYLED" "$screen" '' "$pi_idle"
  assert_screen "pi idle on tmux with identity" empty "$CAPS_TMUX" "$screen" 2 "$pi_idle"
  assert_screen "pi idle on zellij" unknown "$CAPS_STYLED_NOID" "$screen"
  # Identity-capable but unfetched: the adapter is asked to probe lazily.
  [ "$(fm_composer_classify_screen "$CAPS_STYLED" "$screen")" = need-identity ] \
    || fail "an identity-capable profile should request the lazy identity probe"
  # No identity capability (cmux/orca/zellij): the shape is unprovable.
  assert_screen "pi pair without identity capability" unknown "$CAPS_PLAIN" "$screen"
  # A working pi cannot authorize injection into the blank region.
  assert_screen "working pi defers" unknown "$CAPS_STYLED" "$screen" '' "$pi_working"
  # A pi parked on an interactive prompt reports `blocked`: it is waiting on a
  # human keystroke, so the blank region is a menu's, not a free composer's.
  # Typing there answers the prompt and the text is discarded (issue #2797).
  assert_screen "blocked pi defers" unknown "$CAPS_STYLED" "$screen" '' "$pi_blocked"
  # The audit's live counterexample: a plain shell running sleep, cursor
  # parked on a blank line between two rules, NO pi process. The permissive
  # rule read this `empty`; identity+structure refuses it.
  assert_screen "sleep-pane counterexample" unknown "$CAPS_TMUX" "$screen" 2 "$none"
  assert_screen "absent identity cannot prove blank pi pair" unknown "$CAPS_TMUX" "$screen" 2 probe-absent
  typed=$'────────────────────────\nfix the flaky test\n────────────────────────'
  assert_screen "pi typed" pending "$CAPS_STYLED" "$typed" '' "$pi_idle"
  typed=$'────────────────────────\n❯\n────────────────────────'
  assert_screen "pi lone-glyph draft with identity" pending "$CAPS_STYLED" "$typed" '' "$pi_idle"
  assert_screen "pi lone-glyph draft on tmux" pending "$CAPS_TMUX" "$typed" 1 "$pi_idle"
  assert_screen "lone glyph without identity capability" empty "$CAPS_STYLED_NOID" "$typed"
  assert_screen "lone glyph on plain backend" empty "$CAPS_PLAIN" "$typed"
  assert_screen "lone glyph with non-pi identity" empty "$CAPS_STYLED" "$typed" '' "$none"
  pass "matrix: pi's separated composer needs identity + structure; the blank row alone never proves it"
}

test_matrix_pi_dollar_status_footer_is_empty() {
  # Pi's status row `$0.000 (sub) 5.4%/272k (auto)` at column 0 used to read
  # as a dead-shell prompt, so an idle separated composer classified unknown.
  # A counters-first footer never took that path. A real `$` or `$ ls` prompt,
  # and the same cost string typed between the separators, still refuse.
  local dollar typed dead_shell dead_cmd spaced footer_only inside wrap dollar_status
  local pi_idle pi_working none out
  pi_idle=$(printf 'pi\tidle'); pi_working=$(printf 'pi\tworking'); none=$(printf 'zsh\t')
  dollar_status=$'$0.000 (sub) 5.4%/272k (auto)'
  dollar=$'transcript\n────────────────────────\n\n────────────────────────\n'"$dollar_status"

  assert_screen "pi dollar-first status on herdr" empty "$CAPS_STYLED" "$dollar" '' "$pi_idle"
  assert_screen "pi dollar-first status on tmux" empty "$CAPS_TMUX" "$dollar" 2 "$pi_idle"

  [ "$(fm_composer_classify_screen "$CAPS_STYLED" "$dollar")" = need-identity ] \
    || fail "a dollar-first Pi footer must still request the lazy identity probe"
  assert_screen "dollar-first status without identity capability" unknown "$CAPS_PLAIN" "$dollar"
  assert_screen "working pi with dollar-first status defers" unknown \
    "$CAPS_STYLED" "$dollar" '' "$pi_working"
  assert_screen "non-pi identity with dollar-first status defers" unknown \
    "$CAPS_STYLED" "$dollar" '' "$none"

  typed=$'────────────────────────\nfix the flaky test\n────────────────────────\n'"$dollar_status"
  assert_screen "pi typed text above dollar-first status" pending \
    "$CAPS_STYLED" "$typed" '' "$pi_idle"
  inside=$'────────────────────────\n'"$dollar_status"$'\n────────────────────────'
  assert_screen "dollar-first string typed into the pi composer" pending \
    "$CAPS_STYLED" "$inside" '' "$pi_idle"

  dead_shell=$'transcript\n────────────────────────\n\n────────────────────────\n$'
  dead_cmd=$'transcript\n────────────────────────\n\n────────────────────────\n$ ls -la'
  spaced=$'transcript\n────────────────────────\n\n────────────────────────\n$ 0.000 (sub)'
  assert_screen "real dead shell below a pi pair" unknown "$CAPS_STYLED" "$dead_shell" '' "$pi_idle"
  assert_screen "dead-shell command below a pi pair" unknown "$CAPS_STYLED" "$dead_cmd" '' "$pi_idle"
  assert_screen "spaced dollar below a pi pair" unknown "$CAPS_STYLED" "$spaced" '' "$pi_idle"

  footer_only=$'transcript\n'"$dollar_status"
  assert_screen "dollar-first status with no pi pair" unknown \
    "$CAPS_STYLED" "$footer_only" '' "$pi_idle"

  wrap=$'❯\n$ ls -la'
  out=$(fm_composer_classify_screen "$CAPS_STYLED" "$wrap")
  [ "$out" = unknown ] \
    || fail "a real dead shell below a bare glyph must still invalidate cursorless selection, got '$out'"
  wrap=$'❯\n$ '
  out=$(fm_composer_classify_screen "$CAPS_STYLED" "$wrap")
  [ "$out" = unknown ] \
    || fail "a bare dollar prompt below a glyph must still invalidate cursorless selection, got '$out'"
  pass "matrix: a dollar-first pi status footer reads empty; dead shells still refuse"
}

test_matrix_opencode_leftbar_signals() {
  # Real idle opencode: `┃`-prefixed rows holding an "Ask anything" hint,
  # blanks, and a Build-mode footer. Two independent idle signals: the shared
  # idle-placeholder pattern (works on plain captures) and the ghost strip
  # (works on styled captures even if the pattern is overridden away).
  local screen typed dim_screen captured_idle captured_pending out
  local footer_119 cwd_119 captured_119_idle captured_119_pending
  local mode_cell separator_cell model_cell provider_cell effort_cell branch_cell reset_cell
  reset_cell="${ESC}[38;2;255;255;255m"
  screen=$'  ┃\n  ┃  Ask anything... "What is the tech stack?"\n  ┃\n  ┃  Build · GPT-5.5 Fast OpenAI · high\n  ╹▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'
  dim_screen=$'  ┃\n  ┃  '"${ESC}[2mAsk anything...${ESC}[0m"$'\n  ┃\n  ┃  Build · GPT-5.5 Fast OpenAI · high\n  ╹▀▀▀▀'
  assert_screen "opencode idle on tmux (cursor on hint)" empty "$CAPS_TMUX" "$dim_screen" 1
  assert_screen "opencode idle on herdr" empty "$CAPS_STYLED" "$dim_screen"
  assert_screen "opencode idle on zellij" empty "$CAPS_STYLED_NOID" "$dim_screen"
  assert_screen "opencode idle on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  # This sanitized live OpenCode 1.18.30 capture preserves its U+2026 hint and
  # RGB 128 styling. RGB 128 is deliberately outside the ghost threshold, so
  # the placeholder spelling is the independent empty signal. The completed-
  # turn row above the active composer also pins the incident's idle layout.
  # The capture omits the directory footer this task recognises: no cwd:branch
  # rail is drawn in it (the capture predates an active session or the
  # sanitisation removed the rail).
  captured_idle=$'  ▣ Build · Big Pickle · 3.4s\n\n  ┃\n  ┃  '"${ESC}[38;2;128;128;128mAsk anything… \"Fix a TODO in the codebase\"${ESC}[38;2;255;255;255m"$'\n  ┃\n  ┃  Build · Big Pickle OpenCode Zen\n  ╹▀▀▀▀▀▀▀▀'
  assert_screen "opencode 1.18.30 completed-turn idle hint on tmux" empty "$CAPS_TMUX" "$captured_idle" 3
  captured_pending=$'  ▣ Build · Big Pickle · 3.4s\n\n  ┃\n  ┃  '"${ESC}[38;2;255;255;255mReply with OK.${ESC}[38;2;255;255;255m"$'\n  ┃\n  ┃  Build · Big Pickle OpenCode Zen\n  ╹▀▀▀▀▀▀▀▀'
  assert_screen "opencode 1.18.30 completed-turn typed composer on tmux" pending "$CAPS_TMUX" "$captured_pending" 3
  # Signal separation: with the idle pattern overridden to something that
  # cannot match, a DIM-styled hint still proves empty through the ghost strip.
  out=$(FM_COMPOSER_IDLE_RE='^NEVER-MATCHES$' fm_composer_classify_screen "$CAPS_TMUX" "$dim_screen" 1)
  [ "$out" = empty ] || fail "a dim opencode hint must stay empty via the ghost strip alone, got '$out'"
  typed=$'┃\n┃  refactor the parser please\n┃\n┃  Build · GPT-5.5 Fast OpenAI · high\n╹▀▀▀▀'
  assert_screen "opencode typed on tmux" pending "$CAPS_TMUX" "$typed" 1
  assert_screen "opencode typed on plain backends" unknown "$CAPS_PLAIN" "$typed"
  typed=$'┃  Ask anything... please investigate\n┃\n┃  Build · GPT-5.5 Fast OpenAI · high\n╹▀▀▀▀'
  assert_screen "opencode placeholder-like input on tmux" pending "$CAPS_TMUX" "$typed" 0
  assert_screen "opencode placeholder-like input on plain backends" unknown "$CAPS_PLAIN" "$typed"
  typed=$'┃  refactor the parser please\n┃\n┃  Build · GPT-5.5 Fast OpenAI · high'
  assert_screen "opencode multiline draft above blank cursor row" pending "$CAPS_TMUX" "$typed" 1
  # The opencode 1.19.0 regression, carried over from an idle live pane
  # captured through tmux -e on 2026-10-14 with an installed opencode 1.19.0.
  # The footer row's mode word is RGB 67;133;190 and its separators are
  # 111;110;105 - luminances 119.8 and 109.7, both under the 128 ghost
  # threshold - so fm_composer_strip_ghost deleted them and left the row
  # opening at the BRIGHT model cell instead of at `Build`. The
  # `^(Build|Plan)·` exemption was therefore unreachable on every styled
  # backend, this idle composer read `pending`, and `pending` is the verdict
  # that refuses every fm-send, refuses every interrupt/exit/relaunch, and
  # skips every fm-task-inbox-lib doorbell - the cost measured was three
  # manual interventions into worker panes in one day. Only the foreground
  # truecolor triples and the drawn glyphs are carried over; the background
  # runs and pane padding are dropped, so this is not a byte-for-byte copy of
  # the capture, matching captured_idle above. The cwd
  # row opencode 1.19.0 also draws inside the box is de-emphasised too, so it
  # is empty under the ghost strip and never reaches this verdict.
  mode_cell="${ESC}[38;2;67;133;190mBuild${reset_cell}"
  separator_cell="${ESC}[38;2;111;110;105m·${reset_cell} "
  provider_cell="${ESC}[38;2;111;110;105mOpenCode Go${reset_cell} "
  model_cell="${ESC}[38;2;206;205;195mSpace Bunny${reset_cell} "
  effort_cell="${ESC}[1m${ESC}[38;2;218;112;44mmax${ESC}[0m${reset_cell}"
  branch_cell="${ESC}[38;2;206;205;195mfm-composer-footer${reset_cell}"
  footer_119="  ┃  ${mode_cell} ${separator_cell}${model_cell}${provider_cell}${separator_cell}${effort_cell}  ${branch_cell}"$'\n'
  cwd_119="  ┃  ${ESC}[38;2;111;110;105m~/.treehouse/fm001-b8697d/1/fm001:fm/${reset_cell}"$'\n'
  captured_119_idle=$'  ▣ Build · Space Bunny · 1.2s\n\n  ┃\n  ┃  '"${ESC}[2m"$'\n  ┃\n'
  captured_119_idle+="$cwd_119"
  captured_119_idle+="$footer_119"
  captured_119_idle+=$'  ╹▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'
  assert_screen "opencode 1.19.0 de-emphasised footer row" empty "$CAPS_TMUX" "$captured_119_idle" 3
  # The half that matters: the same de-emphasised footer must not buy a false
  # `empty` over a composer holding unsent work. A bright input row above it
  # stays pending on every styled backend.
  captured_119_pending=$'  ▣ Build · Space Bunny · 1.2s\n\n  ┃\n  ┃  '"${ESC}[38;2;255;255;255mfix the doorbell skip${ESC}[38;2;255;255;255m"$'\n  ┃\n'
  captured_119_pending+="$cwd_119"
  captured_119_pending+="$footer_119"
  captured_119_pending+=$'  ╹▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'
  assert_screen "opencode 1.19.0 typed composer above the de-emphasised footer" \
    pending "$CAPS_TMUX" "$captured_119_pending" 3
  assert_screen "opencode 1.19.0 typed composer on herdr" \
    pending "$CAPS_STYLED" "$captured_119_pending"
  assert_screen "opencode 1.19.0 de-emphasised footer row on herdr" \
    empty "$CAPS_STYLED" "$captured_119_idle"
  assert_screen "opencode 1.19.0 de-emphasised footer row on zellij" \
    empty "$CAPS_STYLED_NOID" "$captured_119_idle"
  # Plain backends keep the strict posture on the SAME bytes: opencode's cwd
  # row survives an unstyled capture, and an unrecognized shape must defer
  # rather than read empty, because firstmate types into an `empty` verdict.
  assert_screen "opencode 1.19.0 idle on plain backends" unknown "$CAPS_PLAIN" "$captured_119_idle"
  assert_screen "opencode 1.19.0 typed on plain backends" unknown "$CAPS_PLAIN" "$captured_119_pending"
  # Signal separation for the fix itself: the exemption is proved from the row
  # ghost stripping cannot reach, so an override that removes that proof must
  # put the false `pending` straight back.
  out=$(FM_COMPOSER_LEFTBAR_FOOTER_RE='^NEVER-MATCHES$' \
    fm_composer_classify_screen "$CAPS_TMUX" "$captured_119_idle" 3)
  [ "$out" = pending ] \
    || fail "the 1.19.0 footer exemption must be the only reason this idle pane reads empty, got '$out'"
  # The extractor reads the same run with the same rule, so a classified-empty
  # pane must not hand back the footer as composer text: zellij's append proof
  # requires the typed text and nothing else.
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED" "$captured_119_idle")
  [ -z "$out" ] \
    || fail "the de-emphasised 1.19.0 footer must not be extracted as composer text, got '$out'"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED" "$captured_119_pending")
  [ "$out" = 'fix the doorbell skip' ] \
    || fail "extracting above the de-emphasised 1.19.0 footer must yield only the typed row, got '$out'"
  pass "matrix: opencode's left-bar composer reads empty everywhere and scans the full active run"
}

test_matrix_opencode_leftbar_cwd_furniture() {
  # Real idle OpenCode 1.18.31, captured live on 2026-09-18 from a firstmate
  # tmux worker pane (fixtures/opencode-1.18.31-cwd/opencode-1.18.31-idle-cwd.ansi,
  # the styled 20-row tail exactly as fm_tmux_composer_capture feeds it, real
  # cursor_y shifted by the 50 rows above the tail). The left-bar composer holds
  # NO typed text: the pane's working directory and branch are drawn
  # RIGHT-ALIGNED inside the composer rows above the Build footer, wrapped over
  # three rail-width fragments ("~/.treehouse/harness-engineering-",
  # "presentation-a32ea0/7/harness-", "engineering-presentation:fm/deck-07-")
  # whose final fragment ("failure-modes") is drawn at the right end of the
  # footer row itself. The fragments are RGB 128 grey - luminance exactly 128,
  # ON the ghost-luma ceiling - so they survive ghost stripping and the
  # classifier used to read them as unsent typed text: every idle 1.18.31 pane
  # answered `pending`, which skipped the steering doorbell, the watcher's
  # re-ring ladder, and fm-control.sh's typed /exit.
  local screen composer fixture typed typed_row strip start expected_fragment diverge out typed_composer
  fixture="$ROOT/tests/fixtures/opencode-1.18.31-cwd/opencode-1.18.31-idle-cwd.ansi"
  screen=$(<"$fixture")
  # Cursor 14 = the real #{cursor_y} (64) minus the 50 rows above the tail:
  # the cursor sits inside the composer's furniture rows, so the cursor-anchored
  # left-bar read is the verdict the tmux adapter supplies.
  assert_screen "opencode 1.18.31 idle cwd:branch furniture on tmux" empty "$CAPS_TMUX" "$screen" 14
  # Cursorless profiles see the same furniture through the plain, style-free
  # recognition, until the version's separate status rail below the floor row
  # (which the classifier does not own here) invalidates the shape on a full
  # capture; the cropped composer tail pins the furniture verdict itself.
  composer=$(printf '%s\n' "$screen" | tail -n 9 | head -n 6)
  assert_screen "opencode 1.18.31 cwd furniture on herdr" empty "$CAPS_STYLED" "$composer"
  assert_screen "opencode 1.18.31 cwd furniture on zellij" empty "$CAPS_STYLED_NOID" "$composer"
  assert_screen "opencode 1.18.31 cwd furniture on cmux/orca" empty "$CAPS_PLAIN" "$composer"
  # Non-vacuousness: the fragments really survive ghost stripping (RGB 128 has
  # luminance exactly 128, not below the ceiling) and the run really reaches the
  # top furniture row, so the verdict above cannot come from blank rows alone.
  expected_fragment="$(printf '~')/.treehouse/harness-engineering-"
  strip=$(printf '%s\n' "$(_fm_composer_screen_row 2 "$composer")" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var strip
  case "$strip" in
    '┃'*) strip=${strip#┃} ;;
  esac
  fm_composer_normalize_trim_var strip
  [ "$strip" = "$expected_fragment" ] \
    || fail "the top furniture fragment must survive ghost stripping intact, got '$strip'"
  start=$(_fm_composer_leftbar_cwd_start "$composer" 0 5)
  [ "$start" = 2 ] || fail "the fixture's furniture run must be recognised from its top row, got '$start'"

  # Position decides, never shape alone: the same furniture with a LEFT-EDGE
  # typed line directly above it keeps the composer pending, and a path-shaped
  # string typed at the left edge is typed text even when the footer keeps its
  # right-hand tail.
  typed_row="  ${ESC}[38;2;92;156;245m┃${ESC}[38;2;255;255;255m${ESC}[48;2;30;30;30m  ${ESC}[38;2;238;238;238mReply with OK.${ESC}[0m"
  typed="${typed_row}"$'\n'"$(tail -n 4 <<< "$composer")"
  assert_screen "opencode 1.18.31 typed above cwd furniture on tmux" pending "$CAPS_TMUX" "$typed" 0
  typed="  ${ESC}[38;2;92;156;245m┃${ESC}[38;2;255;255;255m${ESC}[48;2;30;30;30m  ${ESC}[38;2;238;238;238m/usr/local/bin/some/tool${ESC}[0m"$'\n'"$(tail -n 4 <<< "$composer")"
  assert_screen "opencode left-edge typed path above cwd furniture on tmux" pending "$CAPS_TMUX" "$typed" 0
  # The extraction change is asserted on the cropped composer too: the same
  # selector that classifies the cwd furniture must scope extracted user
  # content to the typed row above the rail, excluding the furniture run and
  # the footer.
  typed_composer="${typed_row}"$'\n'"$(tail -n 4 <<< "$composer")"
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$typed_composer")
  [ "$out" = 'Reply with OK.' ] \
    || fail "cropped-composer extraction must scope user content to the typed row above the rail, got '$out'"

  # A composer holding only "/" - the first keystroke of a slash command -
  # must never read empty. Its single character trivially clears the position
  # gate, so only the path-start check keeps it typed text: a lone "/" with no
  # name after it is not accepted as the cwd rail, on the row directly above
  # the footer and on top of the short-cwd rail alike.
  # Styled profiles prove it real (pending); the unstyled profile keeps the
  # leftbar's existing unknown deferral - never empty either way.
  typed_row="  ${ESC}[38;2;92;156;245m┃${ESC}[38;2;255;255;255m${ESC}[48;2;30;30;30m  ${ESC}[38;2;238;238;238m/${ESC}[0m"
  typed=$'transcript line\n'"${typed_row}"$'\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode lone slash above the footer stays pending on tmux" pending "$CAPS_TMUX" "$typed" 1
  assert_screen "opencode lone slash above the footer stays pending on herdr" pending "$CAPS_STYLED" "$typed"
  [ -z "$(_fm_composer_leftbar_cwd_start "$typed" 1 2)" ] \
    || fail "a lone '/' above the footer must not be recognised as cwd furniture"
  typed=$'transcript line\n  ┃  /\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode lone slash above the footer defers unstyled on cmux/orca" unknown "$CAPS_PLAIN" "$typed"

  # The path-prefix check is load-bearing: a right-aligned single token that
  # is not part of such a path, and a fragment run whose start is not a path
  # prefix, stay typed content.
  diverge=$'transcript line\n  ┃                                                              50.8K\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode right-aligned non-path token stays typed on tmux" pending "$CAPS_TMUX" "$diverge" 1
  diverge=$'transcript line\n  ┃                                                                                                                     deck-07-\n  ┃  Build · gpt-oss-120b Internal OVHcloud                                                                          failure-modes'
  assert_screen "opencode bare branch fragment without a path start stays typed" pending "$CAPS_TMUX" "$diverge" 1
  # The topmost fragment's OWN bytes decide the path start: a typed lone "~"
  # directly above a rail whose top fragment is absolute (an outside-$HOME
  # cwd) is not absorbed into the run, so the rail is furniture and the typed
  # "~" row keeps the composer pending.
  diverge=$'transcript line\n  ┃  ~\n  ┃                                                            /Volumes/Data/worktree:fm/branch\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode typed lone tilde above outside-HOME rail stays typed on tmux" pending "$CAPS_TMUX" "$diverge" 1
  assert_screen "opencode typed lone tilde above outside-HOME rail stays typed on herdr" pending "$CAPS_STYLED" "$diverge"
  start=$(_fm_composer_leftbar_cwd_start "$diverge" 1 3)
  [ "$start" = 2 ] \
    || fail "a typed lone '~' must stay outside the absolute rail run, got '$start'"

  # The position gate measures the gap against the REGION's width (the widest
  # trimmed plain row across first..last), never against the gated row's own
  # length: a short, space-prefixed home path typed into an otherwise empty
  # composer must not clear a position gate its own short row sets.
  diverge=$'transcript line\n  ┃    ~/a\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode space-prefixed short home path stays typed on tmux" pending "$CAPS_TMUX" "$diverge" 1
  assert_screen "opencode space-prefixed short home path stays typed on herdr" pending "$CAPS_STYLED" "$diverge"
  assert_screen "opencode space-prefixed short home path defers unstyled" unknown "$CAPS_PLAIN" "$diverge"

  # Accepted residual, pinned so it cannot drift silently: a lone whitespace-free
  # "~/..." token whose text starts beyond the region's midpoint still clears the
  # region-width gate and reads empty. Every misfire except this right-half
  # residual defers; tightening the gate further is a deliberate classifier
  # change, not a drift.
  long_gap=$(printf '%0.s ' $(seq 1 200))
  diverge=$'transcript line\n  ┃'"$long_gap"$'~/notes.md\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode right-half lone tilde-slash token is the accepted residual on tmux" empty "$CAPS_TMUX" "$diverge" 1
  assert_screen "opencode right-half lone tilde-slash token is the accepted residual on herdr" empty "$CAPS_STYLED" "$diverge"
  # A left-edge typed row above such a token rescues the verdict: the walk
  # breaks on the left-edge row and the token's rows keep their ordinary
  # content verdict.
  diverge=$'transcript line\n  ┃  reply to the captain\n  ┃'"$long_gap"$'~/notes.md\n  ┃  Build · gpt-oss-120b Internal OVHcloud'
  assert_screen "opencode right-half token under a left-edge row stays typed on tmux" pending "$CAPS_TMUX" "$diverge" 1

  # A second live pane, same day and version, whose cwd:branch is SHORTER than
  # the rail (fixtures/opencode-1.18.31-cwd/opencode-1.18.31-idle-short-cwd.ansi,
  # tmux window 0:fm-anvil-backlog-docs-hygiene, 272x70, captured read-only with
  # the adapter's own capture-pane call; real #{cursor_y} 64 = 14 in the 20-row
  # tail). The string wraps BOTTOM-aligned: the two upper composer rows are
  # blank rail and the single fragment "~/.treehouse/anvil-99d6f9/2/anvil:fm/"
  # sits directly above the footer row, whose right end carries
  # "anvil-backlog-docs-hygiene". A different path shape classifies by
  # structure, and the contiguous-above-footer walk needs no blank-row
  # tolerance.
  fixture="$ROOT/tests/fixtures/opencode-1.18.31-cwd/opencode-1.18.31-idle-short-cwd.ansi"
  screen=$(<"$fixture")
  assert_screen "opencode 1.18.31 idle short cwd:branch furniture on tmux" empty "$CAPS_TMUX" "$screen" 14
  composer=$(printf '%s\n' "$screen" | tail -n 9 | head -n 6)
  assert_screen "opencode 1.18.31 short cwd furniture on herdr" empty "$CAPS_STYLED" "$composer"
  assert_screen "opencode 1.18.31 short cwd furniture on zellij" empty "$CAPS_STYLED_NOID" "$composer"
  assert_screen "opencode 1.18.31 short cwd furniture on cmux/orca" empty "$CAPS_PLAIN" "$composer"
  expected_fragment="$(printf '~')/.treehouse/anvil-99d6f9/2/anvil:fm/"
  strip=$(printf '%s\n' "$(_fm_composer_screen_row 4 "$composer")" | fm_composer_strip_ghost)
  fm_composer_normalize_trim_var strip
  case "$strip" in
    '┃'*) strip=${strip#┃} ;;
  esac
  fm_composer_normalize_trim_var strip
  [ "$strip" = "$expected_fragment" ] \
    || fail "the short fixture's one fragment must survive ghost stripping intact, got '$strip'"
  start=$(_fm_composer_leftbar_cwd_start "$composer" 0 5)
  [ "$start" = 4 ] || fail "the short fixture's run must start on the row directly above the footer, got '$start'"
  typed="$(head -n 2 <<< "$composer")"$'\n'"${typed_row}"$'\n'"$(tail -n 3 <<< "$composer")"
  assert_screen "opencode lone slash typed above the short cwd rail stays pending on tmux" pending "$CAPS_TMUX" "$typed" 2
  pass "matrix: opencode 1.18.31's right-aligned cwd:branch furniture reads empty; left-edge text stays pending"
}

test_matrix_opencode_leftbar_abs_cwd_furniture() {
  # Real OpenCode 1.18.31 worker pane captured read-only on 2026-10-14 through
  # the tmux adapter's capture (308 columns, #{cursor_y} 62 = 14 in the 20-row
  # tail), sanitized: transcript rows, model name, and path were rewritten
  # with equal visible widths. The worker's cwd lies OUTSIDE $HOME, so the
  # rail is absolute: "/srv/pool/.workspace/project-0a1b2c/" sits directly
  # above the footer row and its tail continues at the footer row's right
  # end. The busy fixture carries the "esc interrupt" status line below the
  # composer floor; the idle twin blanks that and the spinner. The left-bar
  # region ends at the floor row, so busy and idle read alike.
  local busy idle composer start typed typed_row long_gap out rail_row footer_row
  busy=$(<"$ROOT/tests/fixtures/opencode-1.18.31-cwd/opencode-1.18.31-busy-wide-abs-cwd.ansi")
  idle=$(<"$ROOT/tests/fixtures/opencode-1.18.31-cwd/opencode-1.18.31-idle-wide-abs-cwd.ansi")
  assert_screen "opencode 1.18.31 busy wide absolute cwd rail on tmux" empty "$CAPS_TMUX" "$busy" 14
  assert_screen "opencode 1.18.31 idle wide absolute cwd rail on tmux" empty "$CAPS_TMUX" "$idle" 14
  composer=$(printf '%s\n' "$busy" | sed -n '14,17p')
  assert_screen "opencode wide absolute cwd rail on herdr" empty "$CAPS_STYLED" "$composer"
  assert_screen "opencode wide absolute cwd rail on cmux/orca" empty "$CAPS_PLAIN" "$composer"
  start=$(_fm_composer_leftbar_cwd_start "$composer" 0 3)
  [ "$start" = 2 ] || fail "the absolute rail must be recognised on the row above the footer, got '$start'"
  rail_row=$(_fm_composer_screen_row 2 "$composer")
  footer_row=$(_fm_composer_screen_row 3 "$composer")

  # Negatives on the same wide geometry: each stays pending.
  long_gap=$(printf '%0.s ' $(seq 1 260))
  typed=$'transcript line\n  ┃'"$long_gap"$'/\n  ┃  Build · Example Model 1 Pro'
  assert_screen "opencode right-aligned lone slash stays pending on tmux" pending "$CAPS_TMUX" "$typed" 1
  [ -z "$(_fm_composer_leftbar_cwd_start "$typed" 1 2)" ] \
    || fail "a right-aligned lone '/' must not be recognised as cwd furniture"
  typed=$'transcript line\n  ┃'"$long_gap"$'///\n  ┃  Build · Example Model 1 Pro'
  [ -z "$(_fm_composer_leftbar_cwd_start "$typed" 1 2)" ] \
    || fail "a right-aligned slash-only token must not be recognised as cwd furniture"
  typed_row="  ${ESC}[38;5;75m┃${ESC}[48;5;234m  ${ESC}[38;5;255m/exit${ESC}[0m"
  typed=$(printf '%s\n' "$composer" | sed -n 1p)$'\n'"$typed_row"$'\n'"$footer_row"
  assert_screen "opencode /exit at the left edge of a wide pane stays pending" pending "$CAPS_TMUX" "$typed" 1
  typed_row="  ${ESC}[38;5;75m┃${ESC}[48;5;234m  ${ESC}[38;5;255m/srv/pool/notes.md${ESC}[0m"
  typed=$(printf '%s\n' "$composer" | sed -n 1p)$'\n'"$typed_row"$'\n'"$footer_row"
  assert_screen "opencode absolute path typed at the left edge stays pending" pending "$CAPS_TMUX" "$typed" 1
  typed_row="  ${ESC}[38;5;75m┃${ESC}[48;5;234m  ${ESC}[38;5;255mReply with OK.${ESC}[0m"
  typed="${typed_row}"$'\n'"$rail_row"$'\n'"$footer_row"
  assert_screen "opencode typed text above the absolute rail stays pending on tmux" pending "$CAPS_TMUX" "$typed" 0
  assert_screen "opencode typed text above the absolute rail stays pending on herdr" pending "$CAPS_STYLED" "$typed"
  # Extraction scopes user content to the typed row, never the rail fragment.
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$typed")
  [ "$out" = 'Reply with OK.' ] \
    || fail "extraction must exclude the absolute rail fragment, got '$out'"
  pass "matrix: opencode's absolute cwd rail on a wide pane reads empty busy and idle; typed text stays pending"
}

test_matrix_grok_titled_bottom_border() {
  # Grok 1.0.5 widened its titled BOTTOM border three columns past the top and
  # content rows. This is the idle capture from issue #3436; Herdr has no
  # cursor anchor, so the geometry mismatch used to make the proven box
  # ambiguous and the verdict unknown, stranding away-mode injection.
  local titled plain_border typed malformed placeholder_draft
  titled=$'  ╭──────────────────────────────────────────────────────────────────────────╮\n  │ ❯                                                                        │\n  ╰────────────────────────────────────────────────────────── Grok 4.6 (xhigh) ─╯\n\n  Shift+Tab:mode  │  Ctrl+x:shortcuts'
  plain_border=$'  ╭──────────────────────────────────────╮\n  │ ❯                                    │\n  ╰──────────────────────────────────────╯'
  assert_screen "grok titled on tmux" empty "$CAPS_TMUX" "$titled" 1
  assert_screen "grok titled on tmux bottom-border cursor" empty "$CAPS_TMUX" "$titled" 2
  assert_screen "issue #3436 idle grok 1.0.5 on herdr" empty "$CAPS_STYLED" "$titled"
  placeholder_draft=$'  ╭──────────────────────────────────────────────────────────────────────────╮\n  │ ❯ Type a message...                                                      │\n  ╰────────────────────────────────────────────────────────── Grok 4.6 (xhigh) ─╯'
  assert_screen "grok bright placeholder-like draft on tmux" pending "$CAPS_TMUX" "$placeholder_draft" 1
  assert_screen "grok placeholder on plain backends" empty "$CAPS_PLAIN" "$placeholder_draft"
  assert_screen "grok titled on cmux/orca" empty "$CAPS_PLAIN" "$titled"
  assert_screen "grok titled on zellij" empty "$CAPS_STYLED_NOID" "$titled"
  # The tolerance is additive: an untitled border still proves the same box.
  assert_screen "grok untitled border" empty "$CAPS_TMUX" "$plain_border" 1
  typed=$'  ╭──────────────────────────────────────────────────────────────────────────╮\n  │ ❯ deploy the fix                                                         │\n  ╰────────────────────────────────────────────────────────── Grok 4.6 (xhigh) ─╯'
  assert_screen "grok typed on tmux" pending "$CAPS_TMUX" "$typed" 1
  assert_screen "grok typed on herdr" pending "$CAPS_STYLED" "$typed"
  malformed=$'  ╭──────────────────────────────────────────────────────────────────────────╮\n  │ ❯                                                                        │\n  ╰────────────────────────────────────────────────────────── unknown surface ─╯'
  assert_screen "oversized unknown title on herdr" unknown "$CAPS_STYLED" "$malformed"
  pass "matrix: grok's real oversized titled bottom is empty while typed and unproved panes stay safe"
}

test_matrix_claude_titled_top_rule() {
  # A named Claude Code session draws its title into the composer's TOP rule
  # (issues #5601 and #5558; observed on herdr as
  # `─── Firstmate operational input 1790546042 ─`). The strict separator
  # predicate rejects that row, so the pair never opened, the closing rule
  # read as a lower unmatched separator, and a visibly empty composer read
  # `unknown` on every cursorless backend, refusing steers, exit, and relaunch.
  local rule title top bottom footer screen ansi typed claude_idle
  local scrollback short nonascii flush blank
  claude_idle=$(printf 'claude\tidle')
  rule='────────────────────────────────────────────────────────────'
  title=' Firstmate operational input 1790546042 '
  top="${rule}───${title}─"
  bottom="${rule}────────────────────────────────────────────"
  footer='  ⏵⏵ bypass permissions on (shift+tab to cycle)'
  screen="recap: earlier work"$'\n'"$top"$'\n❯'"$NBSP"$'\n'"$bottom"$'\n'"$footer"
  ansi="${ESC}[38;2;128;130;131mrecap: earlier work${ESC}[0m"$'\n'
  ansi+="${ESC}[0m${ESC}[38;2;121;129;134m${rule}─── ${ESC}[38;2;177;185;249m${title# }${ESC}[38;2;121;129;134m─${ESC}[0m"$'\n'
  ansi+="${ESC}[0m${ESC}[38;2;128;130;131m❯${NBSP}${ESC}[0m"$'\n'
  ansi+="${ESC}[0m${ESC}[38;2;121;129;134m${bottom}${ESC}[0m"$'\n'"$footer"
  assert_screen "titled claude idle on herdr" empty "$CAPS_STYLED" "$screen" '' "$claude_idle"
  assert_screen "titled claude idle on herdr (ansi)" empty "$CAPS_STYLED" "$ansi" '' "$claude_idle"
  assert_screen "titled claude idle on zellij (ansi)" empty "$CAPS_STYLED_NOID" "$ansi"
  assert_screen "titled claude idle on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  assert_screen "titled claude idle on tmux" empty "$CAPS_TMUX" "$ansi" 2 probe-absent
  typed="$top"$'\n❯ fix the login bug\n'"$bottom"$'\n'"$footer"
  assert_screen "titled claude typed on herdr" pending "$CAPS_STYLED" "$typed" '' "$claude_idle"
  assert_screen "titled claude typed on zellij" pending "$CAPS_STYLED_NOID" "$typed"
  assert_screen "titled claude typed on tmux" pending "$CAPS_TMUX" "$typed" 1 probe-absent
  assert_screen "titled claude typed on plain backends" unknown "$CAPS_PLAIN" "$typed"
  # The staleness rule still holds: a titled sandwich stranded in scrollback,
  # with transcript rows between it and a lower unmatched rule, stays unknown.
  scrollback="$top"$'\n❯'"$NBSP"$'\n'"$bottom"$'\nlater transcript output\n'"$bottom"$'\nmore output'
  assert_screen "titled sandwich in scrollback" unknown "$CAPS_STYLED_NOID" "$scrollback"
  # Width is proven, not assumed: a titled rule narrower than its closing rule
  # is not that composer's top edge.
  short="${rule}${title}─"$'\n❯'"$NBSP"$'\n'"$bottom"
  assert_screen "mismatched titled rule width" unknown "$CAPS_STYLED_NOID" "$short"
  # A non-ASCII title leaves residue and refuses rather than guessing width.
  nonascii="${rule}─── ✳ Firstmate operational input 179054604 ─"$'\n❯'"$NBSP"$'\n'"$bottom"
  assert_screen "non-ASCII titled rule" unknown "$CAPS_STYLED_NOID" "$nonascii"
  # The rule must open with the strict separator's dash run.
  flush=" Firstmate operational input 1790546042 ${rule}────"$'\n❯'"$NBSP"$'\n'"$bottom"
  assert_screen "title flush at the rule's start" unknown "$CAPS_STYLED_NOID" "$flush"
  # The strict blank-row posture is untouched: no glyph row, no proof.
  blank="$top"$'\n\n'"$bottom"
  assert_screen "titled rule over a blank row" unknown "$CAPS_STYLED_NOID" "$blank"
  # The untitled pair keeps its verdict alongside the new shape.
  assert_screen "untitled claude idle on herdr" empty "$CAPS_STYLED" \
    "$bottom"$'\n❯'"$NBSP"$'\n'"$bottom"$'\n'"$footer" '' "$claude_idle"
  pass "matrix: claude's titled top rule proves an idle composer empty and a draft pending (#5601, #5558)"
}

test_matrix_grok_144_approval_titled_bottom_border() {
  # Grok 1.0.44 draws the title inside a bottom border exactly as wide as the
  # top border and appends its approval mode (` · always-approve`). The mid-dot
  # used to survive the geometry residue test, so an idle pane read unknown and
  # the guarded exit/relaunch refused to type /exit.
  local top empty_row typed_row bottom idle typed
  top='  ╭'$(_grok_rule 74)'╮'
  empty_row='  │ ❯'"$(printf '%*s' 72 '')"'│'
  typed_row='  │ ❯ deploy the fix'"$(printf '%*s' 57 '')"'│'
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 (high) · always-approve')
  idle="$top"$'\n'"$empty_row"$'\n'"$bottom"
  typed="$top"$'\n'"$typed_row"$'\n'"$bottom"
  assert_screen "grok 1.0.44 idle on tmux content row" empty "$CAPS_TMUX" "$idle" 1
  assert_screen "grok 1.0.44 idle on tmux bottom border" empty "$CAPS_TMUX" "$idle" 2
  assert_screen "grok 1.0.44 idle on herdr" empty "$CAPS_STYLED" "$idle"
  assert_screen "grok 1.0.44 idle on cmux/orca" empty "$CAPS_PLAIN" "$idle"
  assert_screen "grok 1.0.44 typed on tmux" pending "$CAPS_TMUX" "$typed" 1
  assert_screen "grok 1.0.44 typed on herdr" pending "$CAPS_STYLED" "$typed"
  # The approval title is proven only on Grok's rounded box. An otherwise
  # aligned box from another family must not grant permission to type.
  local family tl tr bl br edge dash unobserved
  for family in light heavy double ascii; do
    case "$family" in
      light) tl=┌; tr=┐; bl=└; br=┘; edge=│; dash=─ ;;
      heavy) tl=┏; tr=┓; bl=┗; br=┛; edge=┃; dash=━ ;;
      double) tl=╔; tr=╗; bl=╚; br=╝; edge=║; dash=═ ;;
      ascii) tl=+; tr=+; bl=+; br=+; edge='|'; dash=- ;;
    esac
    unobserved=${idle//╭/$tl}; unobserved=${unobserved//╮/$tr}
    unobserved=${unobserved//╰/$bl}; unobserved=${unobserved//╯/$br}
    unobserved=${unobserved//│/$edge}; unobserved=${unobserved//─/$dash}
    assert_screen "grok approval title rejects $family on tmux" unknown "$CAPS_TMUX" "$unobserved" 1
    assert_screen "grok approval title rejects $family on herdr" unknown "$CAPS_STYLED" "$unobserved"
    assert_screen "grok approval title rejects $family on cmux/orca" unknown "$CAPS_PLAIN" "$unobserved"
  done
  for effort in low medium high xhigh; do
    bottom=$(_grok_titled_bottom 74 "Grok 4.6 ($effort) · always-approve")
    assert_screen "grok 1.0.44 $effort effort" empty "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  done
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 (high) · auto-approve')
  assert_screen "grok unknown approval suffix" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 (high) · always-approve now')
  assert_screen "grok approval suffix with trailing text" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Other 4.7 (high) · always-approve')
  assert_screen "unknown surface title with approval suffix" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 (turbo) · always-approve')
  assert_screen "unknown effort with approval suffix" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'unknown surface · mode')
  assert_screen "mid-dot title outside the known shape" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 (high) · always-approve · extra')
  assert_screen "second mid-dot after the known suffix" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  # The approval title is only known at the aligned width.
  bottom=$(_grok_titled_bottom 77 'Grok 4.7 (high) · always-approve')
  assert_screen "approval title with 1.0.5 overhang" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  # The 1.0.5 overhang shape keeps proving empty beside the new equal-width one.
  bottom=$(_grok_titled_bottom 77 'Grok 4.6 (xhigh)')
  assert_screen "grok 1.0.5 overhang still empty" empty "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Grok 4.6 (xhigh)')
  assert_screen "grok typed title at equal width" empty "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  pass "matrix: grok 1.0.44's approval-titled equal-width bottom is empty while typed and unknown titles stay safe"
}

test_matrix_grok_1077_fast_model_title() {
  # Grok 1.0.77 (50ca579fa996) launched with --always-approve --model
  # grok-4.7-build-fast, captured live on 2026-11-12 through the Rex adapter's
  # styled viewport read (24 rows, cursor row 19) after one turn and a Ctrl+C
  # interrupt. Its bottom title `Grok 4.7 Fast (medium) · always-approve`
  # carries a two-word model name, which read unknown, so exit and relaunch
  # refused the idle pane (#8388).
  local fixtures idle typed top empty_row bottom
  fixtures="$ROOT/tests/fixtures/rex-grok-1.0.77"
  idle=$(<"$fixtures/grok-1.0.77-fast-idle-after-interrupt.vt")
  typed=$(<"$fixtures/grok-1.0.77-fast-typed.vt")
  assert_screen "grok 1.0.77 fast idle with cursor" empty "$CAPS_TMUX" "$idle" 19
  assert_screen "grok 1.0.77 fast idle cursorless" empty "$CAPS_STYLED" "$idle"
  assert_screen "grok 1.0.77 fast idle plain" empty "$CAPS_PLAIN" "$(printf '%s' "$idle" | fm_composer_strip_ansi)"
  assert_screen "grok 1.0.77 fast typed with cursor" pending "$CAPS_TMUX" "$typed" 19
  assert_screen "grok 1.0.77 fast typed cursorless" pending "$CAPS_STYLED" "$typed"
  top='  ╭'$(_grok_rule 74)'╮'
  empty_row='  │ ❯'"$(printf '%*s' 72 '')"'│'
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 Fast Mini (medium) · always-approve')
  assert_screen "grok second model word after Fast" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 74 'Grok 4.7 Turbo (medium) · always-approve')
  assert_screen "grok model word other than Fast" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  bottom=$(_grok_titled_bottom 77 'Grok 4.7 Fast (medium)')
  assert_screen "grok Fast title with 1.0.5 overhang" unknown "$CAPS_TMUX" "$top"$'\n'"$empty_row"$'\n'"$bottom" 1
  pass "matrix: grok 1.0.77's Fast-model approval title is empty while typed and unobserved titles stay safe"
}

# <count> box-drawing rule glyphs, one glyph per iteration so the emitted width
# never depends on whether ${#} counts bytes or characters in the ambient locale.
_grok_rule() {  # <count>
  local n=$1 i=0 out=
  while [ "$i" -lt "$n" ]; do out+='─'; i=$((i + 1)); done
  printf '%s' "$out"
}

# Bottom border of total inner width <width> carrying <title> before a trailing rule.
# Every non-ASCII glyph these fixtures use is one column wide, so the width is
# measured on an ASCII twin: the rule stays byte-exact and ${#} equals the column
# count under any locale, including LC_ALL=C.
_grok_titled_bottom() {  # <width> <title>
  local width=$1 title=" $2 " cols lead
  cols=${title//·/.}
  lead=$((width - ${#cols} - 1))
  printf '  ╰%s%s─╯' "$(_grok_rule "$lead")" "$title"
}

test_matrix_kimi_bordered_shell_glyph_box() {
  # Kimi's bordered `│ > │` composer - the shape fm-spawn.sh's retired
  # spawn-local regex used to own. Now the shared owner proves it everywhere,
  # which is what kimi launch-readiness and delivery route through.
  local screen
  screen=$'╭────────────────────────╮\n│ >                      │\n╰────────────────────────╯'
  assert_screen "kimi idle on tmux" empty "$CAPS_TMUX" "$screen" 1
  assert_screen "kimi idle on cmux/orca" empty "$CAPS_PLAIN" "$screen"
  assert_screen "kimi idle on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "kimi idle on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  pass "matrix: kimi's bordered shell-glyph box reads empty through the shared owner (spawn's fourth copy retired)"
}

test_matrix_claude_inside_zellij_ansi_dump() {
  # Real claude captured through `zellij action dump-screen --ansi`
  # (capability established by the audit): `ESC[m` `❯` U+00A0.
  local screen plain
  screen=$'zellij pane transcript\n'"${ESC}[m❯${NBSP}"
  plain=$'zellij pane transcript\n❯'"$NBSP"
  assert_screen "claude-in-zellij on tmux" empty "$CAPS_TMUX" "$screen" 1
  assert_screen "claude-in-zellij on herdr" empty "$CAPS_STYLED" "$screen"
  assert_screen "claude-in-zellij on zellij" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "claude-in-zellij on plain backends" empty "$CAPS_PLAIN" "$plain"
  pass "matrix: the real claude-in-zellij --ansi dump reads empty in both locales"
}

test_strict_blank_row_divergence() {
  # THE STRICT POSTURE PIN (captain decision blank-row-injection-posture,
  # 2026-08-09): a blank or otherwise unidentified input row with no positive
  # container proof is `unknown`. Each case below read `empty` (or `pending`)
  # under the replaced permissive rule; if any of them drifts back, the
  # permissive posture has silently returned and away-mode injection would
  # again type escalations into unproven panes.
  local out
  # Permissive read this blank cursor row as empty = safe to inject.
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'some output\nmore output\n' 2)
  [ "$out" = unknown ] || fail "a blank unidentified cursor row must be unknown (was permissive empty), got '$out'"
  # A dead shell's prompt row.
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'output\n$ ' 1)
  [ "$out" = unknown ] || fail "a dead-shell prompt row must be unknown, got '$out'"
  # A bare busy-footer row is not a composer container.
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'Working...' 0)
  [ "$out" = unknown ] || fail "a bare busy-footer row must be unknown (was permissive empty), got '$out'"
  # An unidentified free-text cursor row carries no container proof either.
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'output\nhuman draft text' 1)
  [ "$out" = unknown ] || fail "an unidentified text row must be unknown under strict, got '$out'"
  # A blank screen with no cursor capability.
  out=$(fm_composer_classify_screen "$CAPS_PLAIN" $'\n\n')
  [ "$out" = unknown ] || fail "a blank screen must be unknown, got '$out'"
  pass "strict posture: blank and unidentified rows are unknown, never injectable empty"
}

test_bare_wrap_region_classifies() {
  # Long typed input wraps below the glyph row; the cursor rides the wrapped
  # continuation. The region is IDENTIFIED (glyph row + contiguous non-blank,
  # non-structural rows), so a swallowed Enter still reads pending and earns
  # its retry; a wrapped GHOST suggestion still proves empty.
  local wrapped ghost_wrapped out
  wrapped=$'❯ a very long steer message that\nwraps onto the following line'
  assert_screen "wrapped typed input" pending "$CAPS_TMUX" "$wrapped" 1
  wrapped=$'❯ wrapped typed input\ncontinues without a terminal-inserted glyph'
  assert_screen "ordinary wrapped input" pending "$CAPS_TMUX" "$wrapped" 1
  ghost_wrapped=$'❯ '"${ESC}[2ma long rotating suggestion that${ESC}[0m"$'\n'"${ESC}[2mwraps onto the next line${ESC}[0m"
  out=$(fm_composer_classify_screen "$CAPS_TMUX" "$ghost_wrapped" 1)
  [ "$out" = empty ] || fail "a wrapped ghost suggestion should still prove empty, got '$out'"
  # A structural row between the glyph and the cursor breaks the wrap claim.
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'❯ text\n────────────────\nbelow the rule' 2)
  [ "$out" = unknown ] || fail "a rule between glyph and cursor must break the wrap region, got '$out'"
  out=$(fm_composer_classify_screen "$CAPS_TMUX" $'❯ text\n$ live shell' 1)
  [ "$out" = unknown ] || fail "a shell prompt below a glyph row must not become wrapped input, got '$out'"
  pass "fm_composer_classify_screen: the bare composer's wrap region stays identified; structure breaks it"
}

test_contiguous_transcript_reanchors_on_live_prompt() {
  local screen
  screen=$'❯ hi\nHello!\n❯'
  assert_screen "contiguous transcript live prompt on cursorless styled backend" empty "$CAPS_STYLED_NOID" "$screen"
  assert_screen "contiguous transcript live prompt on cursorless plain backend" empty "$CAPS_PLAIN" "$screen"
  assert_screen "contiguous transcript live prompt with cursor" empty "$CAPS_TMUX" "$screen" 2
  pass "fm_composer_classify_screen: a row-leading agent glyph reanchors the live composer"
}

test_lower_dead_shell_invalidates_cursorless_candidate() {
  local stale live out
  stale=$'old transcript\n❯\nprocess exited\n$'
  assert_screen "stale composer above dead shell on herdr" unknown "$CAPS_STYLED" "$stale"
  assert_screen "stale composer above dead shell on zellij" unknown "$CAPS_STYLED_NOID" "$stale"
  assert_screen "stale composer above dead shell on cmux/orca" unknown "$CAPS_PLAIN" "$stale"
  out=$(fm_composer_classify_screen "$CAPS_TMUX" "$stale" 1)
  [ "$out" = empty ] \
    || fail "cursor mode must keep the cursor-anchored composer verdict, got '$out'"

  live=$'transcript shell snippet\n$ echo old output\nmore transcript\n❯'
  assert_screen "shell transcript above live composer on herdr" empty "$CAPS_STYLED" "$live"
  assert_screen "shell transcript above live composer on zellij" empty "$CAPS_STYLED_NOID" "$live"
  assert_screen "shell transcript above live composer on cmux/orca" empty "$CAPS_PLAIN" "$live"
  pass "fm_composer_classify_screen: a lower dead shell invalidates only cursorless stale composers"
}

test_cursorless_bare_wrap_region_classifies() {
  local activity status bounded ghost out
  activity=$'❯\nWorking on request...'
  assert_screen "cursorless activity below bare row on herdr" pending "$CAPS_STYLED" "$activity"
  assert_screen "cursorless activity below bare row on zellij" pending "$CAPS_STYLED_NOID" "$activity"
  assert_screen "cursorless activity below bare row on cmux/orca" unknown "$CAPS_PLAIN" "$activity"

  status=$'›\n\ncodex status line'
  assert_screen "blank-separated codex status on herdr" empty "$CAPS_STYLED" "$status"
  assert_screen "blank-separated codex status on zellij" empty "$CAPS_STYLED_NOID" "$status"
  assert_screen "blank-separated codex status on cmux/orca" empty "$CAPS_PLAIN" "$status"

  bounded=$'────────────────────────\n❯\n────────────────────────\nClaude 4.1'
  assert_screen "rule-bounded claude footer on herdr" empty "$CAPS_STYLED" "$bounded" '' probe-absent
  assert_screen "rule-bounded claude footer on zellij" empty "$CAPS_STYLED_NOID" "$bounded"
  assert_screen "rule-bounded claude footer on cmux/orca" empty "$CAPS_PLAIN" "$bounded"

  ghost=$'❯ '"${ESC}[2ma long rotating suggestion that${ESC}[0m"$'\n'"${ESC}[2mwraps onto the next line${ESC}[0m"
  out=$(fm_composer_classify_screen "$CAPS_STYLED" "$ghost")
  [ "$out" = empty ] || fail "cursorless ghost wrap on herdr should be empty, got '$out'"
  out=$(fm_composer_classify_screen "$CAPS_STYLED_NOID" "$ghost")
  [ "$out" = empty ] || fail "cursorless ghost wrap on zellij should be empty, got '$out'"
  pass "fm_composer_classify_screen: cursorless bare wrap regions participate in verdicts"
}

test_cursorless_container_rejects_contiguous_lower_activity() {
  local box leftbar grok kimi opencode
  box=$'╭────────────────────────╮\n│ ❯                      │\n╰────────────────────────╯\nWorking on request...'
  assert_screen "stale box above activity on herdr" unknown "$CAPS_STYLED" "$box"
  assert_screen "stale box above activity on zellij" unknown "$CAPS_STYLED_NOID" "$box"
  assert_screen "stale box above activity on cmux/orca" unknown "$CAPS_PLAIN" "$box"

  leftbar=$'┃\n┃  Ask anything...\n┃\n┃  Build · GPT-5.5 Fast OpenAI · high\n╹▀▀▀▀▀▀▀▀\nWorking on request...'
  assert_screen "stale left-bar above activity on herdr" unknown "$CAPS_STYLED" "$leftbar"
  assert_screen "stale left-bar above activity on zellij" unknown "$CAPS_STYLED_NOID" "$leftbar"
  assert_screen "stale left-bar above activity on cmux/orca" unknown "$CAPS_PLAIN" "$leftbar"

  grok=$'╭────────────────────────╮\n│ ❯                      │\n╰──────── Grok 4.5 ──────╯\n\nGrok status'
  kimi=$'╭────────────────────────╮\n│ >                      │\n╰────────────────────────╯\n\nKimi status'
  opencode=$'┃\n┃  Ask anything...\n┃\n┃  Build · GPT-5.5 Fast OpenAI · high\n╹▀▀▀▀▀▀▀▀\n\nOpenCode status'
  assert_screen "blank-separated grok footer" empty "$CAPS_STYLED_NOID" "$grok"
  assert_screen "blank-separated kimi footer" empty "$CAPS_PLAIN" "$kimi"
  assert_screen "left-bar floor and blank-separated footer" empty "$CAPS_STYLED_NOID" "$opencode"
  pass "fm_composer_classify_screen: cursorless containers reject only contiguous unclaimed activity"
}

test_bottom_most_candidate_wins() {
  # The one ranking rule: the live composer is bottom-anchored, so a stale
  # decorative box (codex's startup banner) can never outrank the real row
  # below it - the confidently-wrong orca case from the audit.
  local screen out
  screen=$'╭────────────────────────╮\n│ permissions: YOLO mode │\n╰────────────────────────╯\n❯'"$NBSP"
  assert_screen "banner above live claude row" empty "$CAPS_PLAIN" "$screen"
  out=$(fm_composer_classify_screen "$CAPS_PLAIN" $'╭────────────────────────╮\n│ permissions: YOLO mode │\n╰────────────────────────╯\n› Use /skills to list available skills')
  [ "$out" != pending ] || fail "a stale banner must never classify as pending composer text"
  screen=$'❯ old draft\n\n❯'
  assert_screen "blank-separated newer bare composer" empty "$CAPS_STYLED_NOID" "$screen"
  pass "fm_composer_classify_screen: the bottom-most candidate wins; stale banners cannot"
}

test_incomplete_lower_box_invalidates_stale_candidate() {
  local screen out
  screen=$'╭────────────────────────╮\n│ ❯                      │\n╰────────────────────────╯\nstartup complete\n╭────────────────────────╮\n│ ❯ clipped live draft  '
  out=$(fm_composer_classify_screen "$CAPS_PLAIN" "$screen")
  [ "$out" = unknown ] \
    || fail "an incomplete lower box must invalidate an earlier empty box, got '$out'"
  pass "fm_composer_classify_screen: incomplete lower structure invalidates stale boxes"
}

test_titled_bottom_requires_matching_width() {
  local screen out
  screen=$'╭────────────────────────╮\n│ ❯                      │\n╰─ Grok ─╯'
  out=$(fm_composer_classify_screen "$CAPS_TMUX" "$screen" 1)
  [ "$out" = unknown ] \
    || fail "a short titled bottom must not prove an empty box, got '$out'"
  pass "fm_composer_classify_screen: titled bottoms retain full box geometry"
}

test_cursor_on_proven_box_bottom_classifies_content() {
  local screen out
  screen=$'╭────────────────────────╮\n│ ❯                      │\n╰────────────────────────╯'
  out=$(fm_composer_classify_screen "$CAPS_TMUX" "$screen" 2)
  [ "$out" = empty ] \
    || fail "a cursor on a proven box bottom must classify its content, got '$out'"
  pass "fm_composer_classify_screen: a proven box tolerates a bottom-border cursor"
}

test_selected_content_is_composer_scoped_and_wrap_normalized() {
  local screen out
  screen=$'hello captain in transcript\n╭────────────────────╮\n│ unrelated          │\n│ draft               │\n╰────────────────────╯'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'unrelated draft' ] \
    || fail "box extraction should contain only normalized selected composer rows, got '$out'"
  screen=$'hello captain in transcript\n┃ hello\n┃ captain\n┃ Build · GPT-5.5 Fast OpenAI · high'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'hello captain' ] \
    || fail "left-bar extraction should join user rows without footer furniture, got '$out'"
  screen=$'╭────────────────────╮\n│ ❯ '"${ESC}[2mType a message...${ESC}[0m"$'│\n╰────────────────────╯'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ -z "$out" ] \
    || fail "ghost agent-prompt placeholders should be excluded from extracted user content, got '$out'"
  screen=$'╭────────────────────╮\n│ > '"${ESC}[2mType a message...${ESC}[0m"$'│\n╰────────────────────╯'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ -z "$out" ] \
    || fail "ghost shell-prompt placeholders should be excluded from boxed user content, got '$out'"
  screen=$'╭────────────────────╮\n│ ❯ Type a message...│\n╰────────────────────╯'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'Type a message...' ] \
    || fail "surviving placeholder-like input should remain extracted user content, got '$out'"
  screen=$'❯ a legitimately long steer that\nwraps across the next bare row\n\ntranscript below the break'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'a legitimately long steer that wraps across the next bare row' ] \
    || fail "bare extraction should include only its contiguous wrap region, got '$out'"
  screen=$'❯ wrapped user content\ncontinuation preserves a mid-row ❯ glyph'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'wrapped user content continuation preserves a mid-row ❯ glyph' ] \
    || fail "bare extraction should preserve mid-row agent glyph bytes, got '$out'"
  screen=$'❯ stale composer\n$ live shell'
  if out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen"); then
    fail "a lower live shell must invalidate composer extraction, got '$out'"
  fi
  screen=$'╭──────────────────────────────╮\n│ > wrapped user content       │\n│ ❯ preserves its leading glyph│\n╰──────────────────────────────╯'
  out=$(fm_composer_extract_selected_content "$CAPS_STYLED_NOID" "$screen")
  [ "$out" = 'wrapped user content ❯ preserves its leading glyph' ] \
    || fail "box extraction should strip only its actual prompt-row glyph, got '$out'"
  pass "fm_composer_extract_selected_content: scopes user content and excludes furniture"
}

# KIRO-ONLY near-gray ghost text: kiro draws its idle placeholder in a
# NEAR-ACHROMATIC truecolor above the 128 ghost ceiling, so it survived the strip
# and read as real typed content - a composer that never reports empty, which
# makes every steer defer forever on the exact `pending` skip. The wider ceiling
# applies only when the caller names the harness kiro (FM_COMPOSER_HARNESS);
# test_composer_widening_is_kiro_only below proves every other read is unchanged.
#   kiro ghost      38;2;158;158;158  luma 158.0  spread   0  -> must STRIP
#   grey real text  38;2;206;207;210  luma 207.0  spread   4  -> must SURVIVE
#   muse real glyph 38;2;90;160;255   luma 149.9  spread 165  -> must SURVIVE
test_kiro_near_gray_ghost_is_stripped_and_real_text_survives() {
  local out
  out=$(printf '%s' "${ESC}[38;2;158;158;158mask a question or describe a task${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "kiro's near-gray placeholder (luma 158.0, spread 0) must strip as ghost text, got '$out'"

  # NON-REGRESSION: near-gray REAL typed text is separated from the placeholder
  # by luminance alone (207.0 vs 158.0). Stripping it would delete input.
  out=$(printf '%s' "${ESC}[38;2;206;207;210mdeploy the thing${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = 'deploy the thing' ] \
    || fail "NON-REGRESSION: near-gray real text (luma 207.0, spread 4) must survive the kiro strip, got '$out'"

  # NON-REGRESSION: a strongly chromatic glyph (muse's, spread 165) is out of the
  # near-gray ceiling's reach at any luminance.
  out=$(printf '%s' "${ESC}[38;2;90;160;255m⟩${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = '⟩' ] \
    || fail "NON-REGRESSION: a chromatic glyph (luma 149.9, spread 165) must survive the kiro strip, got '$out'"

  # The gray ceiling raises the applicable ceiling and never lowers an
  # operator-set one: luma 190 is above the 180 gray default but below a raised
  # FM_COMPOSER_GHOST_LUMA_MAX, so the knob keeps applying to gray text.
  out=$(printf '%s' "${ESC}[38;2;190;190;190mplaceholder text${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro FM_COMPOSER_GHOST_LUMA_MAX=200 fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "a near-gray run at luma 190 must strip under FM_COMPOSER_GHOST_LUMA_MAX=200, got '$out'"

  pass "fm_composer_strip_ghost: on kiro, near-gray ghost strips while near-gray real text and a chromatic glyph survive"
}

# A kiro pane with no COLORTERM gets the SAME grey in the 256-colour encoding:
# 38;5;247, xterm grey level 158, where a truecolor pane gets 38;2;158;158;158.
# Only palette indices with a fixed grey RGB are tested, and only on kiro.
test_kiro_palette_gray_ghost_is_stripped_and_chromatic_indexes_survive() {
  local out
  out=$(printf '%s' "${ESC}[38;5;247mask a question or describe a task${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "kiro's 256-colour placeholder (38;5;247, grey level 158) must strip as ghost text, got '$out'"

  out=$(printf '%s' "${ESC}[38:5:247mask a question or describe a task${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "the colon form 38:5:247 must strip the same grey on kiro, got '$out'"

  # SCOPE GUARD: only the 232-255 ramp is luminance-tested. The 6x6x6 cube's
  # r==g==b diagonal is arithmetically grey (145 computes to level 175) and is
  # deliberately NOT tested, because kiro has not been measured drawing ghost
  # text there and widening the predicate reintroduces the palette-dependence
  # problem the 38;5 carve-out exists for.
  out=$(printf '%s' "${ESC}[38;5;145mplaceholder text${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = 'placeholder text' ] \
    || fail "SCOPE GUARD: a cube-diagonal grey outside 232-255 (38;5;145) must be untouched, got '$out'"

  # NON-REGRESSION: a grey above the ceiling is real input, and a CHROMATIC or
  # theme-remapped (0-15) index carries no fixed grey to measure.
  out=$(printf '%s' "${ESC}[38;5;253mdeploy the thing${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = 'deploy the thing' ] \
    || fail "NON-REGRESSION: a bright palette grey (38;5;253, level 218) must survive, got '$out'"
  out=$(printf '%s' "${ESC}[38;5;33mdeploy the thing${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = 'deploy the thing' ] \
    || fail "NON-REGRESSION: a chromatic palette index (38;5;33) must survive, got '$out'"
  out=$(printf '%s' "${ESC}[38;5;8mdeploy the thing${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ "$out" = 'deploy the thing' ] \
    || fail "NON-REGRESSION: a theme-remapped index (38;5;8) must survive, got '$out'"

  pass "fm_composer_strip_ghost: on kiro, palette greys strip while bright, chromatic and theme-remapped indexes survive"
}

# The kiro widening must not reach any other harness, nor a read that names no
# harness: Claude draws a typed slash command in grey 38;2;112;112;112, which the
# herdr payload proof reads with FM_COMPOSER_GHOST_LUMA_MAX=0, and the wider gray
# ceiling stripped it, so a typed /exit was judged unsent. Each case is first
# shown to diverge under the kiro scope, so none of them can pass vacuously.
test_composer_widening_is_kiro_only() {
  local out h hinted screen
  local saved=${FM_COMPOSER_HARNESS-__unset__}
  unset FM_COMPOSER_HARNESS

  out=$(printf '%s' "${ESC}[38;2;112;112;112m/exit${ESC}[0m" \
    | FM_COMPOSER_HARNESS=kiro FM_COMPOSER_GHOST_LUMA_MAX=0 fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "fixture drift: the kiro scope must strip grey 112 at FM_COMPOSER_GHOST_LUMA_MAX=0, or the Claude case is vacuous, got '$out'"
  for h in '' claude codex rovo grok; do
    out=$(printf '%s' "${ESC}[38;2;112;112;112m/exit${ESC}[0m" \
      | FM_COMPOSER_HARNESS=$h FM_COMPOSER_GHOST_LUMA_MAX=0 fm_composer_strip_ghost)
    [ "$out" = '/exit' ] \
      || fail "harness '${h:-none}': Claude's grey typed /exit must survive with FM_COMPOSER_GHOST_LUMA_MAX=0, got '$out'"
    out=$(printf '%s' "${ESC}[38;2;158;158;158mask a question${ESC}[0m" | FM_COMPOSER_HARNESS=$h fm_composer_strip_ghost)
    [ "$out" = 'ask a question' ] \
      || fail "harness '${h:-none}': a near-gray run above the shared ceiling must survive outside kiro, got '$out'"
    out=$(printf '%s' "${ESC}[38;5;240mask a question${ESC}[0m" | FM_COMPOSER_HARNESS=$h fm_composer_strip_ghost)
    [ "$out" = 'ask a question' ] \
      || fail "harness '${h:-none}': a dark palette grey must stay untested outside kiro, got '$out'"
  done
  out=$(printf '%s' "${ESC}[38;5;240mask a question${ESC}[0m" | FM_COMPOSER_HARNESS=kiro fm_composer_strip_ghost)
  [ -z "${out//[[:space:]]/}" ] \
    || fail "fixture drift: the kiro scope must strip a dark palette grey, got '$out'"

  # The hinted idle row reads empty only on kiro; on every other read it is
  # ordinary bare-composer text, exactly as before kiro existed.
  hinted=$'transcript line\n'"${ESC}[39m›  ask a question or describe a task ↵"
  screen="$hinted"$'\n /copy to clipboard'
  FM_COMPOSER_HARNESS=kiro assert_screen "kiro hinted idle row on tmux" empty "$CAPS_TMUX" "$hinted" 1
  FM_COMPOSER_HARNESS=kiro assert_screen "kiro hinted idle row cursorless" empty "$CAPS_STYLED" "$screen"
  for h in '' claude codex; do
    FM_COMPOSER_HARNESS=$h assert_screen "hinted row on tmux, harness '${h:-none}'" pending "$CAPS_TMUX" "$hinted" 1
    FM_COMPOSER_HARNESS=$h assert_screen "hinted row cursorless, harness '${h:-none}'" pending "$CAPS_STYLED" "$screen"
  done

  [ "$saved" = __unset__ ] || FM_COMPOSER_HARNESS=$saved
  pass "composer widening: the near-gray ceiling, palette greys, and hinted idle row apply on kiro only"
}

test_bare_shell_glyphs_are_unknown
test_stripped_unbordered_content_uses_plain_content
test_bare_shell_prompt_with_command_is_not_empty
test_bordered_shell_glyph_is_empty
test_agent_glyphs_are_empty_bordered_and_bare
test_empty_content_is_empty
test_idle_placeholder_is_empty
test_idle_placeholder_case_mode_is_explicit
test_real_text_is_pending
test_matrix_claude_bare_nbsp_row
test_matrix_claude_named_session_titled_rule
test_matrix_claude_arrow_statusline_footer
test_composer_footer_demotion_needs_a_proven_pair
test_composer_footer_zone_is_shape_independent
test_composer_footer_zone_refuses_rather_than_allows
test_claude_slash_popup_marked_row_is_not_a_second_composer
test_claude_slash_popup_demotion_only_ever_refuses
test_matrix_codex_dim_hint_row
test_matrix_muse_truecolor_glyph_survives_signal_loss
test_matrix_cursor_reverse_video_placeholder_remnant
test_matrix_cursor_fully_dim_placeholder
test_matrix_herdr_halfblock_rule_bounds_bare_wrap
test_matrix_omp_status_row_bounds_bare_composer
test_matrix_codex_idle_starfield_furniture
test_matrix_pi_separated_needs_identity
test_matrix_pi_dollar_status_footer_is_empty
test_matrix_opencode_leftbar_signals
test_matrix_opencode_leftbar_cwd_furniture
test_matrix_opencode_leftbar_abs_cwd_furniture
test_matrix_grok_titled_bottom_border
test_matrix_claude_titled_top_rule
test_matrix_grok_144_approval_titled_bottom_border
test_matrix_grok_1077_fast_model_title
test_matrix_kimi_bordered_shell_glyph_box
test_matrix_claude_inside_zellij_ansi_dump
test_strict_blank_row_divergence
test_bare_wrap_region_classifies
test_contiguous_transcript_reanchors_on_live_prompt
test_lower_dead_shell_invalidates_cursorless_candidate
test_cursorless_bare_wrap_region_classifies
test_cursorless_container_rejects_contiguous_lower_activity
test_bottom_most_candidate_wins
test_incomplete_lower_box_invalidates_stale_candidate
test_titled_bottom_requires_matching_width
test_cursor_on_proven_box_bottom_classifies_content
test_selected_content_is_composer_scoped_and_wrap_normalized

test_queued_enter_verdict_busy_pending_is_empty() {
  local out
  out=$(fm_composer_queued_enter_verdict pending busy)
  [ "$out" = empty ] || fail "busy + proven pending must be queued delivery (empty), got '$out'"
  pass "fm_composer_queued_enter_verdict: pending + busy returns empty (queued Enter)"
}

test_queued_enter_verdict_idle_pending_stays_pending() {
  local out
  out=$(fm_composer_queued_enter_verdict pending idle)
  [ "$out" = pending ] || fail "idle + proven pending must stay a genuine swallow, got '$out'"
  out=$(fm_composer_queued_enter_verdict pending unknown)
  [ "$out" = pending ] || fail "unknown busy is not proof of a queue, got '$out'"
  pass "fm_composer_queued_enter_verdict: pending + idle/unknown stays pending"
}

test_queued_enter_verdict_does_not_convert_other_states() {
  local state out
  for state in empty pending-unproven unknown send-failed future-state; do
    out=$(fm_composer_queued_enter_verdict "$state" busy)
    [ "$out" = "$state" ] || fail "busy must not convert '$state', got '$out'"
    out=$(fm_composer_queued_enter_verdict "$state" idle)
    [ "$out" = "$state" ] || fail "idle must not convert '$state', got '$out'"
  done
  pass "fm_composer_queued_enter_verdict: only proven pending is converted"
}

test_queued_enter_verdict_busy_pending_is_empty
test_queued_enter_verdict_idle_pending_stays_pending
test_queued_enter_verdict_does_not_convert_other_states

# The selected row sits on cursor row 1 so a tmux read whose cursor is that
# row, and a cursorless read, both still see unsubmitted text.
exit_picker_screen() {
  printf '%s\n' \
    'Background work is running' \
    '❯ 1. Exit and stop tasks' \
    'The following will stop when you exit:' \
    'shell · sleep 300' \
    '  2. Move to background and exit' \
    '  3. Stay' \
    'Enter to confirm · Esc to cancel'
}

fm_test_picker_send() {
  printf 'Enter\n' >> "$FM_TEST_PICKER_ENTERS"
}

fm_test_picker_state() {
  fm_composer_classify_screen 'styled=1' "$FM_TEST_PICKER_SCREEN" 1
}

test_background_exit_picker_stays_pending_and_blocks_retry() {
  local screen out rc sink enters
  screen=$(exit_picker_screen)
  out=$(fm_composer_blocking_dialog "$screen"); rc=$?
  [ "$rc" -eq 0 ] || fail "the recorded picker should match"
  [ "$out" = 'Claude background-task exit picker' ] || fail "dialog name was '$out'"
  out=$(fm_composer_blocking_dialog 'Background work is running'); rc=$?
  [ "$rc" -eq 1 ] || fail "a heading alone must not match"
  [ -z "$out" ] || fail "a miss must print nothing, got '$out'"
  out=$(fm_composer_blocking_dialog "$(printf '%s\n' 'Background work is running' 'Exit and stop tasks')"); rc=$?
  [ "$rc" -eq 1 ] || fail "two of the three strings must not match"
  out=$(fm_composer_blocking_dialog "$(printf '%s\n' "$screen" '' '')"); rc=$?
  [ "$rc" -eq 0 ] || fail "blank rows below the footer should still match"
  sink=$(mktemp)
  FM_COMPOSER_DIALOG_SINK=$sink
  out=$(fm_composer_classify_screen 'styled=1' "$screen" 1)
  [ "$out" = pending ] || fail "cursor on the selected row should stay pending, got '$out'"
  [ "$(cat "$sink")" = 'Claude background-task exit picker' ] || fail "classify should note the dialog, got '$(cat "$sink")'"
  out=$(fm_composer_classify_screen 'styled=1' "$screen")
  [ "$out" = pending ] || fail "a styled cursorless picker should stay pending, got '$out'"
  unset FM_COMPOSER_DIALOG_SINK
  rm -f "$sink"
  FM_TEST_PICKER_SCREEN=$screen
  FM_TEST_PICKER_ENTERS=$(mktemp)
  : > "$FM_TEST_PICKER_ENTERS"
  fm_composer_dialog_sink_prepare || fail "the dialog sink could not be prepared"
  sink=$FM_COMPOSER_DIALOG_SINK
  out=$(fm_composer_submit_retry_core fm_test_picker_send fm_test_picker_state win 3 0)
  fm_composer_dialog_sink_release
  [ ! -e "$sink" ] || fail "the release should remove a sink that prepare created"
  [ -z "${FM_COMPOSER_DIALOG_SINK:-}" ] || fail "the release should unset a sink that prepare created"
  enters=$(grep -c '^Enter$' "$FM_TEST_PICKER_ENTERS" || true)
  [ "$out" = unknown ] || fail "a picker must stop the retry as unknown, got '$out'"
  [ "$enters" -eq 1 ] || fail "a picker must receive one Enter, got $enters"
  rm -f "$FM_TEST_PICKER_ENTERS"
  unset FM_TEST_PICKER_SCREEN FM_TEST_PICKER_ENTERS
  pass "the Claude background-task exit picker stays pending and receives no confirming Enter"
}

# The picker's own text, shown the way a worker pane shows it when it prints
# this repository's diff, verification note, or a test fixture: quoted above a
# normal composer. No picker is open, so the next Enter confirms nothing.
quoted_exit_picker_screen() {
  printf '%s\n' \
    '● Here is the fixture the test uses:' \
    "+    'Background work is running' \\" \
    "+    '❯ 1. Exit and stop tasks' \\" \
    "+    'Enter to confirm · Esc to cancel'" \
    '  The selected row is "❯ 1. Exit and stop tasks" and the footer is "Enter to confirm · Esc to cancel".' \
    'Background work is running' \
    '❯ 1. Exit and stop tasks' \
    'Enter to confirm · Esc to cancel' \
    '' \
    '╭──────────────╮' \
    '│ > next steer │' \
    '╰──────────────╯'
}

test_dialog_heading_and_footer_must_be_the_recorded_lines() {
  local screen out rc
  screen=$(printf '%s\n' \
    'The fixture mentions Background work is running in a sentence' \
    '❯ 1. Exit and stop tasks' \
    'Enter to confirm · Esc to cancel')
  out=$(fm_composer_blocking_dialog "$screen"); rc=$?
  [ "$rc" -eq 1 ] || fail "a heading buried in a sentence must not match"
  [ -z "$out" ] || fail "a miss must print nothing, got '$out'"
  screen=$(printf '%s\n' \
    'Background work is running' \
    '❯ 1. Exit and stop tasks' \
    'Enter to confirm the deployment')
  out=$(fm_composer_blocking_dialog "$screen"); rc=$?
  [ "$rc" -eq 1 ] || fail "a last line that only starts with the confirm words must not match"
  [ -z "$out" ] || fail "a miss must print nothing, got '$out'"
  pass "a buried heading or a different last line is not the exit picker"
}

test_dialog_note_skips_the_match_when_no_sink_is_set() {
  local screen out rc before after
  screen=$(exit_picker_screen)
  unset FM_COMPOSER_DIALOG_SINK
  out=$(fm_composer_note_blocking_dialog "$screen"); rc=$?
  [ "$rc" -eq 1 ] || fail "a note without a sink should return 1, got $rc"
  [ -z "$out" ] || fail "a note without a sink should print nothing, got '$out'"
  [ -z "${FM_COMPOSER_DIALOG_SINK:-}" ] || fail "a note without a sink must not create one"
  out=$(fm_composer_classify_screen 'styled=1' "$screen" 1)
  [ "$out" = pending ] || fail "classify without a sink should stay pending, got '$out'"
  trap 'true' RETURN
  before=$(trap -p RETURN)
  fm_composer_dialog_sink_prepare || fail "the dialog sink could not be prepared"
  fm_composer_dialog_sink_release
  after=$(trap -p RETURN)
  trap - RETURN
  [ "$before" = "$after" ] || fail "release replaced the caller RETURN trap: $after"
  pass "a dialog note without a sink skips the match, and release leaves a caller RETURN trap"
}

test_quoted_exit_picker_text_is_not_a_dialog() {
  local screen out rc sink enters
  screen=$(quoted_exit_picker_screen)
  out=$(fm_composer_blocking_dialog "$screen"); rc=$?
  [ "$rc" -eq 1 ] || fail "picker text quoted above a normal composer must not match"
  [ -z "$out" ] || fail "a miss must print nothing, got '$out'"
  out=$(fm_composer_blocking_dialog "$(printf '%s\n' \
    'Background work is running' \
    "+    '❯ 1. Exit and stop tasks' \\" \
    'Enter to confirm · Esc to cancel')"); rc=$?
  [ "$rc" -eq 1 ] || fail "a selected row that is not alone on its row must not match"
  out=$(fm_composer_blocking_dialog "$(printf '%s\n' \
    '❯ 1. Exit and stop tasks' \
    'Background work is running' \
    'Enter to confirm · Esc to cancel')"); rc=$?
  [ "$rc" -eq 1 ] || fail "a selected row above the heading must not match"
  FM_TEST_PICKER_SCREEN=$screen
  FM_TEST_PICKER_ENTERS=$(mktemp)
  : > "$FM_TEST_PICKER_ENTERS"
  fm_composer_dialog_sink_prepare || fail "the dialog sink could not be prepared"
  sink=$FM_COMPOSER_DIALOG_SINK
  out=$(fm_composer_submit_retry_core fm_test_picker_send fm_test_picker_state win 3 0)
  [ ! -s "$sink" ] || fail "quoted picker text must not be noted as a dialog, got '$(cat "$sink")'"
  fm_composer_dialog_sink_release
  enters=$(grep -c '^Enter$' "$FM_TEST_PICKER_ENTERS" || true)
  [ "$out" = pending ] || fail "quoted picker text must keep the ordinary pending verdict, got '$out'"
  [ "$enters" -eq 3 ] || fail "quoted picker text must keep the ordinary Enter retries, got $enters"
  rm -f "$FM_TEST_PICKER_ENTERS"
  unset FM_TEST_PICKER_SCREEN FM_TEST_PICKER_ENTERS
  pass "picker text quoted above a normal composer is not read as a live picker"
}

test_background_exit_picker_stays_pending_and_blocks_retry
test_dialog_heading_and_footer_must_be_the_recorded_lines
test_dialog_note_skips_the_match_when_no_sink_is_set
test_quoted_exit_picker_text_is_not_a_dialog
test_kiro_near_gray_ghost_is_stripped_and_real_text_survives
test_kiro_palette_gray_ghost_is_stripped_and_chromatic_indexes_survive
test_composer_widening_is_kiro_only
