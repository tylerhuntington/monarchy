#!/usr/bin/env bash
# tests/fm-afk-launch.test.sh - the script-owned, backend-aware away-daemon
# launch (bin/fm-afk-launch.sh) and the away-mode stale-artifact lifecycle fixes
# (bin/fm-afk-start.sh). Two layers:
#
#   UNIT (always run, no backend): the session-scoped stale-artifact clear on a
#   fresh entry vs a refresh, and the correct-ordered stop (daemon SIGTERM'd
#   while state/.afk is still present, .afk cleared last).
#
#   E2E TOPOLOGY (per backend, skipped when its tool is absent): the anti-
#   regression for the pane split/shrink - entering AND exiting away mode leaves
#   the captain's active tab topology UNCHANGED, because the daemon lands in a
#   NON-VISIBLE separate terminal (a herdr dedicated workspace, a detached tmux
#   session), never a split of the captain's pane. The herdr path runs on a
#   throwaway, NEVER-default HERDR_SESSION and asserts the default session is
#   byte-identical via the fm-herdr-lab.sh fleet-state tripwire; the tmux path
#   uses uniquely-named throwaway sessions killed by exact name. A harmless
#   sleeper replaces the real daemon (FM_AFK_LAUNCH_ENTRY) so the test observes
#   only the terminal lifecycle.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAUNCH="$ROOT/bin/fm-afk-launch.sh"
START="$ROOT/bin/fm-afk-start.sh"
CONTRACT="$ROOT/bin/fm-afk-contract.sh"
# The daemon paths refuse on a Pi primary, so pin a daemon-running harness for
# every unit below; the Pi refusal has its own units (unit_pi_never_launches_the_daemon).
# FM_TEST_HARNESS is the launch path's test-only seam (bin/fm-afk-launch.sh
# fm_afk_launch_primary_harness): the suite calls the entrypoints directly, so a
# real harness ancestor - a no-mistakes gate agent run under Pi - would outrank
# the CLAUDECODE=1 marker below and refuse the daemon paths under test.
unset PI_CODING_AGENT FM_PI_HARNESS CURSOR_AGENT CURSOR_INVOKED_AS GEMINI_CLI ATLASSIAN_AGENT_TYPE ROVODEV_CLI
export CLAUDECODE=1 FM_TEST_HARNESS=claude FM_TEST_SEAM=1
# A Claude home runs the supervision host unless config/supervision-host-off
# opts it out (docs/configuration.md "Supervision host"), and the host is that home's
# away session, so the daemon units run on a Claude home that opted out; the
# supervision-host units point FM_CONFIG_OVERRIDE at their own home's config.
OFF_CONFIG=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-off-config.XXXXXX")
: > "$OFF_CONFIG/supervision-host-off"
export FM_CONFIG_OVERRIDE="$OFF_CONFIG"

FAILED=0
fail() { printf 'not ok - %s\n' "$1" >&2; FAILED=1; }
pass() { printf 'ok - %s\n' "$1"; }

SLEEPER=$(mktemp "${TMPDIR:-/tmp}/fm-afk-sleeper.XXXXXX")
printf '#!/usr/bin/env bash\nexec sleep 600\n' > "$SLEEPER"
chmod +x "$SLEEPER"
TRACK_TMUX_SESSIONS=""
GLOBAL_CLEANUP() {
  declare -F rex_test_cleanup >/dev/null 2>&1 && rex_test_cleanup
  rm -f "$SLEEPER" 2>/dev/null || true
  rm -rf "$OFF_CONFIG" 2>/dev/null || true
  local s
  for s in $TRACK_TMUX_SESSIONS; do
    tmux kill-session -t "$s" 2>/dev/null || true
  done
}
trap GLOBAL_CLEANUP EXIT

enter_posture() {  # <home>
  FM_HOME="$1" FM_STATE_OVERRIDE="$1/state" "$CONTRACT" enter >/dev/null 2>&1
}

# ---------------------------------------------------------------------------
# UNIT 0: /afk is itself the go. `enter` writes the away-posture record in the
# same call, with no separate confirmation, and prints the announcement and the
# read-back after the record exists; on Pi the entry ends there, and every
# daemon path requires that record.
# ---------------------------------------------------------------------------
unit_enter_records_the_posture_in_one_step_without_a_daemon() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-enter.XXXXXX")
  mkdir -p "$st/state"
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter \
    --words 'merge the windows fix when green' --expected-return 2026-09-08T08:00Z --spend 2 2>&1)
  rc=$?
  if [ "$rc" -eq 0 ] && [ -f "$st/state/.afk-contract" ] && [ ! -e "$st/state/.afk-contract.proposed" ] \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" words)" = 'merge the windows fix when green' ] \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" field expected_return)" = 2026-09-08T08:00Z ] \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" field spend_max_concurrent_workers)" = 2 ] \
    && [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ] \
    && printf '%s' "$out" | grep -F 'hold-for-return only. No phone channel is configured; anything that needs you waits for your return.' >/dev/null \
    && printf '%s' "$out" | grep -F '    merge the windows fix when green' >/dev/null \
    && ! printf '%s' "$out" | grep -iE 'say go|to confirm|not yet confirmed' >/dev/null; then
    pass "enter: one call writes the record with the words, expected return, and spend cap, reads it back without asking for a go, and launches no daemon"
  else
    fail "enter: record, read-back, or daemon state wrong (rc=$rc): $out"
  fi
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter --words 'merge it' --grant fix-windows 2>&1)
  rc=$?
  if [ "$rc" -eq 2 ] && printf '%s' "$out" | grep -F -- '--grant was retired' >/dev/null \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" words)" = 'merge the windows fix when green' ]; then
    pass "enter: the retired --grant flag is refused by name and leaves the standing record alone"
  else
    fail "enter: --grant was not refused by name (rc=$rc): $out"
  fi
  printf 'schema\tfm-afk-return.v1\nphase\tblocked\n' > "$st/state/.afk-return-catchup"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter --words 'merge task a PR when green' >/dev/null 2>&1; then
    fail "enter: accepted a new mandate while the prior return catch-up was pending"
  elif [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" words)" = 'merge the windows fix when green' ]; then
    pass "enter: refuses while the prior return catch-up is pending"
  else
    fail "enter: a refused entry changed the standing record"
  fi
  rm -rf "$st"
}

# No launch path waits for a separate go: the retired two-step subcommands are
# refused by name and write nothing, so no caller can stage a mandate that then
# waits on a human response before it binds.
unit_retired_two_step_entry_is_refused() {
  local st cmd out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-retired.XXXXXX")
  mkdir -p "$st/state"
  for cmd in propose confirm; do
    out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" "$cmd" --words 'merge it when green' 2>&1)
    rc=$?
    if [ "$rc" -eq 2 ] && printf '%s' "$out" | grep -F "'$cmd' was retired" >/dev/null \
      && [ ! -e "$st/state/.afk-contract" ] && [ ! -e "$st/state/.afk-contract.proposed" ] \
      && [ ! -d "$st/state/.afk-launch.lock" ]; then
      pass "$cmd: the retired wait-for-go step is refused by name, writes nothing, and releases the launcher lock"
    else
      fail "$cmd: the retired step was not refused cleanly (rc=$rc): $out"
    fi
  done
  rm -rf "$st"
}

unit_pi_never_launches_the_daemon() {
  local st harness out rc
  for harness in pi pi-signed; do
    st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-pi.XXXXXX")
    mkdir -p "$st/state"
    out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_TEST_HARNESS="$harness" \
      FM_SUPERVISOR_TARGET=unused FM_SUPERVISOR_BACKEND=tmux FM_AFK_LAUNCH_ENTRY="$SLEEPER" \
      bash -c '. "$1"; fm_afk_launch_primary_harness() { printf "%s" "$FM_TEST_HARNESS"; }; fm_afk_launch_main start' _ "$LAUNCH" 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ] && printf '%s' "$out" | grep -F "the away daemon is no longer launched on $harness" >/dev/null \
      && [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ] && [ ! -e "$st/state/.afk-contract" ]; then
      pass "$harness: start refuses to launch the daemon and writes no state"
    else
      fail "$harness: start did not refuse cleanly (rc=$rc): $out"
    fi
    out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_TEST_HARNESS="$harness" \
      bash -c '. "$1"; fm_afk_launch_primary_harness() { printf "%s" "$FM_TEST_HARNESS"; }; fm_afk_launch_main start-native' _ "$LAUNCH" 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ] && [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ]; then
      pass "$harness: start-native refuses to prepare a daemon"
    else
      fail "$harness: start-native did not refuse (rc=$rc): $out"
    fi
    rm -rf "$st"
  done
}

# A leaked FM_TEST_HARNESS in a real primary's environment must stay inert: the
# seam fires only alongside the FM_TEST_SEAM marker that test suites set.
unit_test_harness_seam_requires_the_marker() {
  local ref stray pinned
  # shellcheck disable=SC2016 # positional params expand in the child shell.
  ref=$(env -u FM_TEST_SEAM -u FM_TEST_HARNESS CLAUDECODE=1 \
    bash -c '. "$1"; fm_afk_launch_primary_harness' _ "$LAUNCH")
  # shellcheck disable=SC2016 # positional params expand in the child shell.
  stray=$(env -u FM_TEST_SEAM CLAUDECODE=1 FM_TEST_HARNESS=omp \
    bash -c '. "$1"; fm_afk_launch_primary_harness' _ "$LAUNCH")
  [ "$stray" = "$ref" ] \
    || fail "FM_TEST_HARNESS without FM_TEST_SEAM changed harness detection ($stray != $ref)"
  # shellcheck disable=SC2016 # positional params expand in the child shell.
  stray=$(env -u FM_TEST_SEAM CLAUDECODE=1 FM_TEST_HARNESS='1 omp' \
    bash -c '. "$1"; fm_afk_launch_primary_harness' _ "$LAUNCH")
  [ "$stray" = "$ref" ] \
    || fail "a marker-shaped FM_TEST_HARNESS without FM_TEST_SEAM changed harness detection ($stray != $ref)"
  # shellcheck disable=SC2016 # positional params expand in the child shell.
  pinned=$(FM_TEST_SEAM=1 CLAUDECODE=1 FM_TEST_HARNESS=omp \
    bash -c '. "$1"; fm_afk_launch_primary_harness' _ "$LAUNCH")
  [ "$pinned" = omp ] \
    || fail "FM_TEST_SEAM-armed FM_TEST_HARNESS did not pin the harness ($pinned)"
  pass "FM_TEST_HARNESS seam is inert without the test marker"
}

unit_pi_enter_stop_does_not_claim_a_daemon_terminal() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-pi-stop.XXXXXX")
  mkdir -p "$st/state"
  enter_posture "$st" || fail "pi stop: could not enter fixture posture"
  [ ! -e "$st/state/.afk" ] || fail "pi stop: fixture error: enter wrote the away flag"
  [ ! -e "$st/state/.afk-daemon-terminal" ] || fail "pi stop: fixture error: enter recorded a daemon terminal"
  [ ! -e "$st/state/.supervise-daemon.log" ] || fail "pi stop: fixture error: a daemon log already existed"
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop 2>&1)
  rc=$?
  if [ "$rc" -eq 0 ] \
    && printf '%s' "$out" | grep -F 'no daemon terminal was running' >/dev/null \
    && ! printf '%s' "$out" | grep -F 'daemon terminal torn down' >/dev/null \
    && [ ! -e "$st/state/.afk-contract" ]; then
    pass "pi enter stop: reports that no daemon terminal was running"
  else
    fail "pi enter stop: claimed a daemon teardown or failed (rc=$rc): $out"
  fi
  rm -rf "$st"
}

unit_daemon_entry_requires_the_record() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-entry-record.XXXXXX")
  mkdir -p "$st/state"
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" start-native 2>&1)
  rc=$?
  if [ "$rc" -ne 0 ] && [ ! -e "$st/state/.afk-contract" ] && [ ! -e "$st/state/.afk" ] \
    && printf '%s' "$out" | grep -F 'an away-posture record is required; run enter' >/dev/null; then
    pass "daemon entry: no daemon lifecycle starts without the away-posture record"
  else
    fail "daemon entry: started without a record or the refusal was unclear (rc=$rc): $out"
  fi
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter --words 'merge task a PR when green' >/dev/null 2>&1 \
    && FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" start-native >/dev/null 2>&1 \
    && [ -e "$st/state/.afk" ]; then
    pass "daemon entry: enter then start-native run back to back with no confirmation between them"
  else
    fail "daemon entry: the record enter wrote did not permit lifecycle preparation"
  fi
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1
  rm -rf "$st"
}

unit_failed_daemon_launch_preserves_the_record() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-failed-record.XXXXXX")
  mkdir -p "$st/state"
  enter_posture "$st" || fail "failed start: could not enter fixture posture"
  if ! FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET=unused \
    FM_SUPERVISOR_BACKEND=unsupported "$LAUNCH" start >/dev/null 2>&1 \
    && [ -f "$st/state/.afk-contract" ] && [ ! -e "$st/state/afk-contracts" ]; then
    pass "failed start: preserves the posture record enter wrote"
  else
    fail "failed start: changed the posture record enter wrote"
  fi
  rm -rf "$st"
}

unit_stop_archives_the_record_last() {
  local st epoch
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop-archive.XXXXXX")
  mkdir -p "$st/state"
  enter_posture "$st" || fail "stop archive: could not enter fixture posture"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" start-native >/dev/null 2>&1 || fail "stop archive: native entry failed"
  epoch=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" field entered_epoch)
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1 \
    && [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-contract" ] \
    && [ -f "$st/state/afk-contracts/$epoch.afk-contract" ]; then
    pass "stop: clears the away flag and archives the posture record under its entry time"
  else
    fail "stop: the posture record was not archived (state: $(ls -a "$st/state"))"
  fi
  rm -rf "$st"
}

# ---------------------------------------------------------------------------
# UNIT 1: fm_afk_clear_stale_artifacts removes exactly the four delivery
# artifacts plus the prior session's five per-task marker families.
# ---------------------------------------------------------------------------
unit_clear_stale() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-clear.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.subsuper-escalations"
  : > "$st/state/.subsuper-escalations.since"
  : > "$st/state/.subsuper-inject-wedged"
  : > "$st/state/.subsuper-unknown-acked"
  : > "$st/state/.subsuper-stale-task1"
  : > "$st/state/.subsuper-reported-stale-task1"
  : > "$st/state/.subsuper-dialog-task1"
  : > "$st/state/.subsuper-paused-task1"
  : > "$st/state/.subsuper-pause-until-due-task1"
  : > "$st/state/.subsuper-seen-status-task1"  # classification position must be kept
  : > "$st/state/.wake-queue"          # durable queue must be untouched
  # Source fm-afk-start.sh inside a child bash (it sets `set -eu` and would
  # otherwise leak that into this test shell) and call the clear helper.
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" \
    bash -c '. "$1"; fm_afk_clear_stale_artifacts "$2"' _ "$START" "$st/state"
  if [ ! -e "$st/state/.subsuper-escalations" ] \
     && [ ! -e "$st/state/.subsuper-escalations.since" ] \
     && [ ! -e "$st/state/.subsuper-inject-wedged" ] \
     && [ ! -e "$st/state/.subsuper-unknown-acked" ]; then
    pass "clear-stale: removes escalations buffer, sidecar, wedge marker, and unknown-wake acknowledgements"
  else
    fail "clear-stale: stale artifacts survived"
  fi
  if ! compgen -G "$st/state/.subsuper-stale-*" >/dev/null \
     && ! compgen -G "$st/state/.subsuper-reported-stale-*" >/dev/null \
     && ! compgen -G "$st/state/.subsuper-dialog-*" >/dev/null \
     && ! compgen -G "$st/state/.subsuper-paused-*" >/dev/null \
     && ! compgen -G "$st/state/.subsuper-pause-until-due-*" >/dev/null; then
    pass "clear-stale: removes the prior session's five per-task marker families"
  else
    fail "clear-stale: per-task session markers survived"
  fi
  if [ -e "$st/state/.subsuper-seen-status-task1" ]; then
    pass "clear-stale: keeps the durable classification position"
  else
    fail "clear-stale: removed the classification position"
  fi
  if [ -e "$st/state/.wake-queue" ]; then
    pass "clear-stale: leaves the durable wake-queue intact (no pending work dropped)"
  else
    fail "clear-stale: removed the durable wake-queue"
  fi
  rm -rf "$st"
}

# ---------------------------------------------------------------------------
# The per-task away markers are session-scoped episode state: the return path
# (fm_afk_launch_stop) and the fresh-entry cleanup must both drop all five
# families, or the next session's first housekeeping reads a dead session's
# idle clock as its own and reports a wedge whose duration never happened.
# The last pass replays the implicit-state-machines audit's reproduction: a
# hand-written prior-session clock, an idle pane read, delivery stubbed off.
# ---------------------------------------------------------------------------
unit_per_task_markers_session_scoped() {
  local st state now
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-marker-scope.XXXXXX")
  state="$st/state"
  mkdir -p "$state"
  now=$(date +%s)
  # One finished ship task, as the audit's scratch home: a terminal status and
  # a meta that still maps its window.
  printf 'done [at=%s]: PR https://example.test/o/r/pull/1 checks green\n' "$now" > "$state/demo.status"
  printf 'window=%s\nbackend=tmux\nharness=claude\n' 'fmaudit-none:fm-demo' > "$state/demo.meta"
  printf '0:fixture\n' > "$state/.subsuper-seen-status-demo"
  printf '%s\n' "$now" > "$state/.subsuper-last-scan"
  seed_markers() {
    # Same path and content as the daemon's stale_marker_record: the epoch the
    # pane was first seen idle, mid-episode when the session ended.
    printf '%s\n' $(( now - 172801 )) > "$state/.subsuper-stale-demo"
    : > "$state/.subsuper-reported-stale-demo"
    : > "$state/.subsuper-dialog-demo"
    : > "$state/.subsuper-paused-demo"
    : > "$state/.subsuper-pause-until-due-demo"
  }
  markers_gone() {
    ! compgen -G "$state/.subsuper-stale-*" >/dev/null \
      && ! compgen -G "$state/.subsuper-reported-stale-*" >/dev/null \
      && ! compgen -G "$state/.subsuper-dialog-*" >/dev/null \
      && ! compgen -G "$state/.subsuper-paused-*" >/dev/null \
      && ! compgen -G "$state/.subsuper-pause-until-due-*" >/dev/null
  }

  # The return path drops the session's markers with the away flag.
  seed_markers
  : > "$state/.afk"
  FM_HOME="$st" FM_STATE_OVERRIDE="$state" "$LAUNCH" stop >/dev/null 2>&1
  if markers_gone && [ ! -e "$state/.afk" ] && [ -e "$state/.subsuper-seen-status-demo" ]; then
    pass "return: stop drops all five per-task marker families, keeps the classification position"
  else
    fail "return: per-task markers survived stop ($(compgen -G "$state/.subsuper-*" | tr '\n' ' '))"
  fi

  # The fresh-entry cleanup drops them alongside the delivery artifacts.
  seed_markers
  FM_HOME="$st" FM_STATE_OVERRIDE="$state" \
    bash -c '. "$1"; fm_afk_clear_stale_artifacts "$2"' _ "$START" "$state"
  if markers_gone; then
    pass "entry: fresh-session cleanup drops all five per-task marker families"
  else
    fail "entry: per-task markers survived fresh-session cleanup ($(compgen -G "$state/.subsuper-*" | tr '\n' ' '))"
  fi

  # The audit narrative end to end: session one's clock goes through stop and
  # the next entry's cleanup, then the new daemon's first housekeeping pass.
  # Reset to the audit's repro shape first: ONLY the stale clock, because
  # housekeeping's pause migration retires the episode before the wedge check
  # whenever a paused marker is also present.
  rm -f "$state"/.subsuper-stale-* "$state"/.subsuper-reported-stale-* \
    "$state"/.subsuper-dialog-* "$state"/.subsuper-paused-* \
    "$state"/.subsuper-pause-until-due-*
  printf '%s\n' $(( now - 172801 )) > "$state/.subsuper-stale-demo"
  : > "$state/.afk"
  FM_HOME="$st" FM_STATE_OVERRIDE="$state" "$LAUNCH" stop >/dev/null 2>&1
  : > "$state/.afk"   # a fresh entry, two days later in the audit's telling
  printf '%s\n' "$(date +%s)" > "$state/.subsuper-last-scan"
  FM_HOME="$st" FM_STATE_OVERRIDE="$state" \
    bash -c '. "$1"; fm_afk_clear_stale_artifacts "$2"' _ "$START" "$state"
  FM_HOME="$st" FM_STATE_OVERRIDE="$state" FM_DAEMON_PRIMARY_HARNESS=claude \
    bash -c '
      . "$1"
      stale_window_is_busy() { return 1; }
      escalate_flush() { return 0; }
      inject_msg() { return 0; }
      inject_wedge_alarm() { return 0; }
      housekeeping "$2"
    ' _ "$ROOT/bin/fm-supervise-daemon.sh" "$state"
  if ! grep -q 'possible wedge' "$state/.subsuper-escalations" 2>/dev/null; then
    pass "session scope: a dead session's idle clock cannot report 'possible wedge' in the next session"
  else
    fail "session scope: first housekeeping reported a wedge that never happened ($(cat "$state/.subsuper-escalations"))"
  fi
  rm -rf "$st"
}

unit_relative_paths_are_absolute_before_daemon_launch() {
  local root home state out status linked_home
  root=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-relative-home.XXXXXX")
  mkdir -p "$root/home/state" "$root/cdpath/home/state"
  home=$(cd "$root/home" && pwd -P)
  state="$home/state"
  out=$(
    cd "$root" || exit 1
    CDPATH="$root/cdpath" FM_HOME=home FM_STATE_OVERRIDE=home/state \
      bash -c '. "$1"; printf "%s\n%s\n" "$FM_HOME" "$FM_AFK_LAUNCH_STATE"' _ "$LAUNCH"
  )
  if [ "$out" = "$home"$'\n'"$state" ]; then
    pass "launcher paths: relative home and state ignore CDPATH before daemon command construction"
  else
    fail "launcher paths: relative home or state remained cwd-dependent ($out)"
  fi
  linked_home="$root/home-link"
  ln -s "$root/home" "$linked_home"
  out=$(FM_HOME="$linked_home" FM_STATE_OVERRIDE="$linked_home/state" \
    bash -c '. "$1"; printf "%s\n%s\n" "$FM_HOME" "$FM_AFK_LAUNCH_STATE"' _ "$LAUNCH")
  if [ "$out" = "$linked_home"$'\n'"$linked_home/state" ]; then
    pass "launcher paths: absolute symlink spellings are preserved"
  else
    fail "launcher paths: absolute symlink spelling changed ($out)"
  fi
  out=$(
    cd "$root" || exit 1
    FM_HOME=missing-home "$LAUNCH" help 2>&1
  )
  status=$?
  if [ "$status" -ne 0 ] && printf '%s\n' "$out" | grep -F "FM_HOME directory cannot be resolved: missing-home" >/dev/null; then
    pass "launcher paths: unresolved relative FM_HOME fails loudly"
  else
    fail "launcher paths: unresolved relative FM_HOME did not name the bad input ($out)"
  fi
  out=$(
    cd "$root" || exit 1
    FM_HOME=home FM_STATE_OVERRIDE=missing-state "$LAUNCH" help 2>&1
  )
  status=$?
  if [ "$status" -ne 0 ] && printf '%s\n' "$out" | grep -F "FM_STATE_OVERRIDE directory cannot be resolved: missing-state" >/dev/null; then
    pass "launcher paths: unresolved relative FM_STATE_OVERRIDE fails loudly"
  else
    fail "launcher paths: unresolved relative FM_STATE_OVERRIDE did not name the bad input ($out)"
  fi
  rm -rf "$root"
}

# ---------------------------------------------------------------------------
# UNIT 2: a FRESH entry clears; a REFRESH (daemon already alive) preserves the
# current session's buffered escalations.
# ---------------------------------------------------------------------------
unit_fresh_vs_refresh() {
  local st sleep_pid lock
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-refresh.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.subsuper-escalations"
  : > "$st/state/.subsuper-inject-wedged"
  : > "$st/state/.subsuper-unknown-acked"
  # A live "daemon": a real process whose identity the lock records, so
  # daemon_lock_held_by_live_daemon returns true (a refresh).
  sleep 600 &
  sleep_pid=$!
  lock="$st/state/.supervise-daemon.lock"
  mkdir -p "$lock"
  printf '%s' "$sleep_pid" > "$lock/pid"
  # shellcheck source=/dev/null
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$sleep_pid" > "$lock/pid-identity" 2>/dev/null ) || true
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$START" >/dev/null 2>&1
  if [ -e "$st/state/.subsuper-escalations" ] && [ -e "$st/state/.subsuper-inject-wedged" ] \
     && [ -e "$st/state/.subsuper-unknown-acked" ]; then
    pass "refresh: daemon already alive - stale artifacts preserved (current session's buffer kept)"
  else
    fail "refresh: incorrectly cleared the current session's buffered escalations"
  fi
  kill "$sleep_pid" 2>/dev/null || true
  wait "$sleep_pid" 2>/dev/null || true
  rm -rf "$st"
}

# ---------------------------------------------------------------------------
# UNIT 2a: away/quiet mode plumbing (kunchenguid/firstmate#2356). fm_afk_mode
# is the single owner of reading the mode; these pin its write side
# (fm_afk_launch_flag_write / fm_afk_flag_write) against the exact double-
# write risk a live entry hits - the launcher writes the flag, then the
# terminal-side fm-afk-start.sh entry re-writes it a second time on every
# real (non-native) entry, per UNIT 2 above.
# ---------------------------------------------------------------------------
read_mode() {  # <state-dir>
  bash -c '. "$1"; fm_afk_mode "$2"' _ "$ROOT/bin/fm-wake-lib.sh" "$1"
}

unit_mode_explicit_write() {
  local st out
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-mode-explicit.XXXXXX")
  mkdir -p "$st/state"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_MODE=quiet \
    bash -c '. "$1"; fm_afk_launch_flag_write' _ "$LAUNCH"
  out=$(read_mode "$st/state")
  if [ "$out" = quiet ]; then
    pass "mode: a fresh entry with FM_AFK_MODE=quiet writes quiet"
  else
    fail "mode: explicit FM_AFK_MODE=quiet fresh entry wrote '$out' instead of quiet"
  fi
  rm -rf "$st"
}

unit_mode_fresh_defaults_away() {
  local st out
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-mode-default.XXXXXX")
  mkdir -p "$st/state"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" \
    bash -c '. "$1"; fm_afk_launch_flag_write' _ "$LAUNCH"
  out=$(read_mode "$st/state")
  if [ "$out" = away ]; then
    pass "mode: a fresh entry with FM_AFK_MODE unset defaults to away"
  else
    fail "mode: fresh unset-mode entry wrote '$out' instead of away"
  fi
  rm -rf "$st"
}

unit_mode_refresh_preserves_quiet() {
  local st sleep_pid lock out
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-mode-preserve.XXXXXX")
  mkdir -p "$st/state"
  printf 'quiet\n%s\n' "$(date '+%s')" > "$st/state/.afk"
  sleep 600 &
  sleep_pid=$!
  lock="$st/state/.supervise-daemon.lock"
  mkdir -p "$lock"
  printf '%s' "$sleep_pid" > "$lock/pid"
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$sleep_pid" > "$lock/pid-identity" 2>/dev/null ) || true
  # The exact real-entry shape: a bare direct re-write with no explicit mode,
  # simulating the terminal-side fm-afk-start.sh redundant write that would
  # silently clobber quiet back to away if it were not preserve-on-refresh.
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$START" >/dev/null 2>&1
  out=$(read_mode "$st/state")
  if [ "$out" = quiet ]; then
    pass "mode: a bare refresh (FM_AFK_MODE unset) of an already-running quiet daemon preserves quiet, never resets to away"
  else
    fail "mode: refresh incorrectly changed quiet mode to '$out'"
  fi
  kill "$sleep_pid" 2>/dev/null || true
  wait "$sleep_pid" 2>/dev/null || true
  rm -rf "$st"
}

# A live quiet daemon must follow the record when /afk turns it into away;
# a refresh before that entry must not silently turn quiet into away.
unit_mode_quiet_daemon_to_away() {
  local command st sleep_pid lock mode rc
  for command in start start-native; do
    st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet-to-away.XXXXXX")
    mkdir -p "$st/state"
    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_MODE=quiet "$LAUNCH" enter >/dev/null 2>&1 \
      || fail "$command: could not enter quiet mode"
    printf 'quiet\n%s\n' "$(date '+%s')" > "$st/state/.afk"
    sleep 600 &
    # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
    sleep_pid=$!
    lock="$st/state/.supervise-daemon.lock"
    mkdir -p "$lock"
    printf '%s' "$sleep_pid" > "$lock/pid"
    ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$sleep_pid" > "$lock/pid-identity" 2>/dev/null ) || true

    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET=unused \
      FM_SUPERVISOR_BACKEND=tmux "$LAUNCH" "$command" >/dev/null 2>&1
    rc=$?
    mode=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" mode)
    if [ "$rc" -eq 0 ] && [ "$mode" = quiet ] && [ "$(head -n 1 "$st/state/.afk")" = quiet ]; then
      pass "$command: an unset-mode quiet refresh preserves the quiet record and flag"
    else
      fail "$command: quiet refresh changed the record or flag (rc=$rc, record=$mode)"
    fi

    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter >/dev/null 2>&1
    rc=$?
    mode=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" mode)
    if [ "$rc" -ne 0 ] || [ "$mode" != away ]; then
      fail "$command: /afk did not convert the live quiet record to away (rc=$rc, record=$mode)"
    fi
    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET=unused \
      FM_SUPERVISOR_BACKEND=tmux "$LAUNCH" "$command" >/dev/null 2>&1
    rc=$?
    if [ "$rc" -eq 0 ] && [ "$(head -n 1 "$st/state/.afk")" = away ] \
      && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" mode)" = away ]; then
      pass "$command: /afk over a running quiet daemon refreshes the flag to away"
    else
      fail "$command: /afk record and daemon flag disagree after refresh (rc=$rc)"
    fi
    kill "$sleep_pid" 2>/dev/null || true
    wait "$sleep_pid" 2>/dev/null || true
    rm -rf "$st"
  done
}

unit_mode_garbage_and_legacy_content_reads_away() {
  local st out
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-mode-garbage.XXXXXX")
  mkdir -p "$st/state"

  : > "$st/state/.afk"
  out=$(read_mode "$st/state")
  if [ "$out" = away ]; then
    pass "mode: an empty (legacy pre-mode) flag reads as away"
  else
    fail "mode: empty flag read as '$out' instead of away"
  fi

  date '+%s' > "$st/state/.afk"
  out=$(read_mode "$st/state")
  if [ "$out" = away ]; then
    pass "mode: a bare-epoch-timestamp (legacy pre-mode) flag reads as away"
  else
    fail "mode: legacy timestamp flag read as '$out' instead of away"
  fi

  printf 'nonsense-mode\n' > "$st/state/.afk"
  out=$(read_mode "$st/state")
  if [ "$out" = away ]; then
    pass "mode: unrecognized content falls back to away"
  else
    fail "mode: unrecognized content read as '$out' instead of away"
  fi

  out=$(read_mode "$st/state/missing")
  if [ "$out" = away ]; then
    pass "mode: a missing flag reads as away"
  else
    fail "mode: missing flag read as '$out' instead of away"
  fi
  rm -rf "$st"
}

# ---------------------------------------------------------------------------
# UNIT 3: exit ordering - fm_afk_launch_stop SIGTERMs the daemon WHILE .afk is
# still present (so its flush is not a no-op), and clears .afk last.
# ---------------------------------------------------------------------------
unit_stop_ordering() {
  local st lock marker daemon_pid
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop.XXXXXX")
  mkdir -p "$st/state"
  date '+%s' > "$st/state/.afk"
  marker="$st/afk-at-term"
  # A fake daemon: on SIGTERM, record whether .afk was still present, then exit.
  bash -c '
    trap "if [ -f \"$1/state/.afk\" ]; then echo present > \"$2\"; else echo absent > \"$2\"; fi; exit 0" TERM
    while :; do sleep 0.2; done
  ' _ "$st" "$marker" &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  daemon_pid=$!
  lock="$st/state/.supervise-daemon.lock"
  mkdir -p "$lock"
  printf '%s' "$daemon_pid" > "$lock/pid"
  # shellcheck source=/dev/null
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$daemon_pid" > "$lock/pid-identity" 2>/dev/null ) || true
  printf 'none\t-\tnative\n' > "$st/state/.afk-daemon-terminal"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1
  # shellcheck disable=SC2031 # The background daemon writes this shared file; no shell variable is reassigned.
  if [ "$(cat "$marker" 2>/dev/null || echo missing)" = present ]; then
    pass "stop-ordering: daemon SIGTERM'd while .afk still present (flush is not a no-op)"
  else
    fail "stop-ordering: .afk was already cleared when the daemon got SIGTERM"
  fi
  if [ ! -e "$st/state/.afk" ]; then
    pass "stop-ordering: .afk cleared last"
  else
    fail "stop-ordering: .afk not cleared"
  fi
  if [ ! -e "$st/state/.afk-daemon-terminal" ]; then
    pass "stop-ordering: daemon-terminal record removed"
  else
    fail "stop-ordering: record not removed"
  fi
  kill "$daemon_pid" 2>/dev/null || true
  wait "$daemon_pid" 2>/dev/null || true
  rm -rf "$st"
}

unit_stop_rejects_reused_pid() {
  local st lock sleeper_pid
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-pid-reuse.XXXXXX")
  mkdir -p "$st/state"
  date '+%s' > "$st/state/.afk"
  sleep 600 &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  sleeper_pid=$!
  lock="$st/state/.supervise-daemon.lock"
  mkdir -p "$lock"
  printf '%s' "$sleeper_pid" > "$lock/pid"
  printf 'different-process-identity' > "$lock/pid-identity"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1
  if kill -0 "$sleeper_pid" 2>/dev/null; then
    pass "stop identity: stale lock cannot signal an unrelated live process"
  else
    fail "stop identity: stale lock signaled an unrelated live process"
  fi
  kill "$sleeper_pid" 2>/dev/null || true
  wait "$sleeper_pid" 2>/dev/null || true
  rm -rf "$st"
}

unit_failed_start_rolls_back_state() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-failed-start.XXXXXX")
  mkdir -p "$st/state"
  printf 'pending\n' > "$st/state/.subsuper-escalations"
  printf 'wedged\n' > "$st/state/.subsuper-inject-wedged"
  enter_posture "$st" || fail "failed start: could not enter fixture posture"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET=unused \
    FM_SUPERVISOR_BACKEND=unsupported "$LAUNCH" start >/dev/null 2>&1; then
    fail "failed start: unsupported backend unexpectedly succeeded"
  elif [ ! -e "$st/state/.afk" ] \
    && [ "$(cat "$st/state/.subsuper-escalations")" = pending ] \
    && [ "$(cat "$st/state/.subsuper-inject-wedged")" = wedged ]; then
    pass "failed start: away flag and delivery artifacts roll back"
  else
    fail "failed start: left false away state or discarded delivery artifacts"
  fi
  rm -rf "$st"
}

unit_concurrent_start_serialized() {
  command -v tmux >/dev/null 2>&1 || { echo "skip: tmux not found (concurrent start)"; return 0; }
  local st cap_session cap_pane first second rec count
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-concurrent.XXXXXX")
  cap_session="fm-afk-concurrent-cap-$$"
  tmux new-session -d -s "$cap_session" 2>/dev/null || { fail "concurrent start: captain session creation failed"; rm -rf "$st"; return 0; }
  TRACK_TMUX_SESSIONS="$TRACK_TMUX_SESSIONS $cap_session"
  cap_pane=$(tmux display-message -p -t "$cap_session" '#{pane_id}')
  enter_posture "$st" || fail "concurrent start: could not enter fixture posture"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET="$cap_pane" \
    FM_SUPERVISOR_BACKEND=tmux FM_AFK_LAUNCH_ENTRY="$SLEEPER" "$LAUNCH" start >/dev/null 2>&1 &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  first=$!
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET="$cap_pane" \
    FM_SUPERVISOR_BACKEND=tmux FM_AFK_LAUNCH_ENTRY="$SLEEPER" "$LAUNCH" start >/dev/null 2>&1 &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  second=$!
  wait "$first"; wait "$second"
  rec=$(cut -f2 "$st/state/.afk-daemon-terminal" 2>/dev/null || true)
  count=$(tmux list-sessions -F '#{session_name}' 2>/dev/null | awk -v expected="$rec" '$0 == expected {n++} END{print n+0}')
  TRACK_TMUX_SESSIONS="$TRACK_TMUX_SESSIONS $rec"
  if [ -n "$rec" ] && tmux has-session -t "$rec" 2>/dev/null && [ "$count" -eq 1 ]; then
    pass "concurrent start: one serialized daemon terminal remains tracked"
  else
    fail "concurrent start: leaked or lost daemon terminal (count $count, record $rec)"
  fi
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1
  tmux kill-session -t "$cap_session" 2>/dev/null || true
  rm -rf "$st"
}

unit_lock_initialization_grace() {
  local st marker initializer
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-lock-init.XXXXXX")
  marker="$st/initialized"
  mkdir -p "$st/state/.afk-launch.lock"
  (
    sleep 0.15
    if [ -d "$st/state/.afk-launch.lock" ]; then
      printf '%s' "$$" > "$st/state/.afk-launch.lock/pid"
      # shellcheck source=/dev/null
      ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$$" > "$st/state/.afk-launch.lock/pid-identity" 2>/dev/null ) || true
      # shellcheck disable=SC2031 # The subshell writes the path value; it does not reassign the variable.
      : > "$marker"
      sleep 0.15
      rm -rf "$st/state/.afk-launch.lock"
    fi
  ) &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  initializer=$!
  # shellcheck disable=SC2031 # The initializer communicates through this shared file path.
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_lock_acquire
    fm_afk_launch_lock_release
  ' _ "$LAUNCH" && [ -e "$marker" ]; then
    pass "launcher lock: incomplete publication receives initialization grace"
  else
    fail "launcher lock: contender removed a lock during initialization"
  fi
  wait "$initializer" 2>/dev/null || true
  rm -rf "$st"
}

unit_signal_exits_with_lock_cleanup() {
  local st marker child
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-signal.XXXXXX")
  marker="$st/resumed"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_start() { sleep 30; }
    fm_afk_launch_main start
    : > "$2"
  ' _ "$LAUNCH" "$marker" &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  child=$!
  # Signal only once the lifecycle actually holds its lock. Killing before the
  # lock exists tests nothing, and on a loaded machine it used to race: the
  # lock could be created just after the kill and outlive the process.
  local locked=0 _
  for _ in $(seq 1 100); do
    if [ -d "$st/state/.afk-launch.lock" ]; then locked=1; break; fi
    sleep 0.05
  done
  [ "$locked" = 1 ] || fail "launcher signal: lifecycle never acquired its lock to interrupt"
  kill -TERM "$child" 2>/dev/null || true
  wait "$child" 2>/dev/null || true
  # The signal handler releases the lock as it exits; give that removal a
  # bounded settle rather than sampling the instant `wait` returns.
  for _ in $(seq 1 100); do
    [ -e "$st/state/.afk-launch.lock" ] || break
    sleep 0.05
  done
  if [ ! -e "$marker" ] && [ ! -e "$st/state/.afk-launch.lock" ]; then
    pass "launcher signal: TERM exits and releases the lifecycle lock"
  else
    fail "launcher signal: interrupted lifecycle resumed or retained its lock"
  fi
  rm -rf "$st"
}

unit_herdr_partial_create_recovery() {
  local st recorded
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-herdr-partial.XXXXXX")
  recorded="$st/recorded"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_LAUNCH_ENTRY=/bin/true \
    FM_AFK_LAUNCH_LABEL=afk-exact-label RECORDED="$recorded" bash -c '
    . "$1"
    fm_backend_source() { return 0; }
    fm_backend_herdr_server_ensure() { return 0; }
    fm_backend_herdr_cli() {
      if [ "$2 $3" = "workspace create" ]; then
        printf %s '\''truncated'\''
        return 1
      elif [ "$2 $3" = "workspace list" ]; then
        printf %s '\''{"result":{"workspaces":[{"workspace_id":"ws-partial","label":"afk-exact-label"}]}}'\''
      else
        printf %s '\''{"result":{"panes":[{"pane_id":"pane-exact"}]}}'\''
      fi
    }
    fm_afk_launch_record_write() { printf "%s:%s:%s" "$1" "$2" "$3" > "$RECORDED"; }
    fm_afk_launch_create_herdr lab:captain herdr
  ' _ "$LAUNCH"
  if [ "$(cat "$recorded" 2>/dev/null || true)" = "herdr:lab:pane-exact:ws-partial" ]; then
    pass "herdr create: malformed response recovers durable exact ownership"
  else
    fail "herdr create: malformed response left terminal ownership unknown"
  fi
  rm -rf "$st"
}

unit_herdr_error_with_exact_ids_closes_exact() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-herdr-error-exact.XXXXXX")
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_backend_source() { return 0; }
    fm_backend_herdr_server_ensure() { return 0; }
    fm_backend_herdr_cli() {
      if [ "$2 $3" = "workspace create" ]; then
        printf %s '\''{"result":{"workspace":{"workspace_id":"ws-exact"},"root_pane":{"pane_id":"pane-exact"}}}'\''
        return 1
      elif [ "$2 $3" = "pane get" ]; then
        printf %s '\''{"error":{"code":"transport_error"}}'\''
        return 2
      fi
      return 2
    }
    ! fm_afk_launch_create_herdr lab:captain herdr
  ' _ "$LAUNCH"
  if [ "$(cut -f2 "$st/state/.afk-daemon-terminal" 2>/dev/null || true)" = "lab:pane-exact" ]; then
    pass "herdr create error: unconfirmed exact id is persisted for reconciliation"
  else
    fail "herdr create error: unconfirmed exact cleanup id was discarded"
  fi
  rm -rf "$st"
}

unit_herdr_run_failure_preserves_unconfirmed_record() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-herdr-run-fail.XXXXXX")
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_backend_source() { return 0; }
    fm_backend_herdr_server_ensure() { return 0; }
    fm_backend_herdr_cli() {
      if [ "$2 $3" = "workspace create" ]; then
        printf %s '\''{"result":{"workspace":{"workspace_id":"ws-exact"},"root_pane":{"pane_id":"pane-exact"}}}'\''
        return 0
      elif [ "$2 $3" = "pane run" ]; then
        return 1
      elif [ "$2 $3" = "pane get" ]; then
        printf %s '\''{"error":{"code":"transport_error"}}'\''
        return 2
      fi
      return 2
    }
    ! fm_afk_launch_create_herdr lab:captain herdr
  ' _ "$LAUNCH"
  if [ "$(cut -f2 "$st/state/.afk-daemon-terminal" 2>/dev/null || true)" = "lab:pane-exact" ]; then
    pass "herdr run failure: unconfirmed exact id remains reconcilable"
  else
    fail "herdr run failure: unconfirmed exact id was discarded"
  fi
  rm -rf "$st"
}

# The daemon terminal is outside the captain's process tree, so it cannot detect
# the captain's harness itself; each backend's launch must hand it over.
unit_daemon_terminal_receives_the_primary_harness() {
  local st entry backend got
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-daemon-harness.XXXXXX")
  entry="$st/entry"
  # shellcheck disable=SC2016 # expands in the entry script.
  printf '#!/usr/bin/env bash\nprintf "%%s" "${FM_DAEMON_PRIMARY_HARNESS-unset}" > "$FM_HOME/daemon-harness"\n' > "$entry"
  chmod +x "$entry"
  # shellcheck disable=SC2016 # positional params expand in the child shell.
  for backend in herdr tmux; do
    rm -f "$st/daemon-harness"
    env -u FM_DAEMON_PRIMARY_HARNESS FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_LAUNCH_ENTRY="$entry" \
      FM_TEST_HARNESS=claude bash -c '
      . "$1"
      fm_backend_source() { return 0; }
      fm_backend_herdr_server_ensure() { return 0; }
      fm_backend_herdr_cli() {
        if [ "$2 $3" = "workspace create" ]; then
          printf %s '\''{"result":{"workspace":{"workspace_id":"ws-exact"},"root_pane":{"pane_id":"pane-exact"}}}'\''
        elif [ "$2 $3" = "pane run" ]; then
          bash -c "$5"
        fi
      }
      tmux() { [ "$1" = new-session ] && bash -c "$5"; }
      fm_afk_launch_record_write() { return 0; }
      fm_afk_launch_commit_terminal() { return 0; }
      fm_afk_launch_create_"$2" lab:captain "$2"
    ' _ "$LAUNCH" "$backend" >/dev/null 2>&1
    got=$(cat "$st/daemon-harness" 2>/dev/null || true)
    if [ "$got" = claude ]; then
      pass "$backend daemon terminal: runs with the captain's primary harness"
    else
      fail "$backend daemon terminal: primary harness not handed over (got '${got:-nothing}')"
    fi
  done
  rm -rf "$st"
}

unit_record_failure_closes_terminal() {
  local st closed
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-record-fail.XXXXXX")
  closed="$st/closed"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" CLOSED="$closed" bash -c '
    . "$1"
    fm_afk_launch_record_write() { return 1; }
    fm_afk_launch_close_terminal() { printf "%s:%s" "$1" "$2" > "$CLOSED"; }
    ! fm_afk_launch_commit_terminal tmux exact-session ""
  ' _ "$LAUNCH"
  if [ "$(cat "$closed" 2>/dev/null || true)" = "tmux:exact-session" ]; then
    pass "record failure: newly created terminal is closed by exact id"
  else
    fail "record failure: newly created terminal leaked"
  fi
  rm -rf "$st"
}

unit_readiness_failure_rolls_back_terminal() {
  local st closed
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-not-ready.XXXXXX")
  closed="$st/closed"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" CLOSED="$closed" bash -c '
    . "$1"
    fm_afk_launch_wait_ready() { return 1; }
    fm_afk_launch_close_terminal() { printf "%s:%s" "$1" "$2" > "$CLOSED"; }
    fm_afk_launch_terminal_absent() { [ -e "$CLOSED" ]; }
    ! fm_afk_launch_commit_terminal tmux exact-session ""
  ' _ "$LAUNCH"
  if [ "$(cat "$closed" 2>/dev/null || true)" = "tmux:exact-session" ] \
    && [ ! -e "$st/state/.afk-daemon-terminal" ]; then
    pass "readiness failure: exact terminal and durable record roll back"
  else
    fail "readiness failure: terminal or record survived"
  fi
  rm -rf "$st"
}

unit_readiness_failure_preserves_unconfirmed_record() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-not-ready-unconfirmed.XXXXXX")
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_wait_ready() { return 1; }
    fm_afk_launch_close_terminal() { return 1; }
    fm_afk_launch_terminal_absent() { return 1; }
    ! fm_afk_launch_commit_terminal tmux exact-session ""
  ' _ "$LAUNCH"
  if [ "$(cut -f2 "$st/state/.afk-daemon-terminal" 2>/dev/null || true)" = exact-session ]; then
    pass "readiness failure: unconfirmed terminal retains its reconciliation id"
  else
    fail "readiness failure: unconfirmed terminal lost its reconciliation id"
  fi
  rm -rf "$st"
}

unit_tmux_absence_distinguishes_probe_failure() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-tmux-probe.XXXXXX")
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    tmux() { printf "%s" "can'\''t find session: exact-session" >&2; return 1; }
    fm_afk_launch_terminal_absent tmux exact-session
    tmux() { printf "%s" "error connecting to /tmp/tmux.sock" >&2; return 1; }
    ! fm_afk_launch_terminal_absent tmux exact-session
  ' _ "$LAUNCH"; then
    pass "tmux absence: clean missing differs from transport probe failure"
  else
    fail "tmux absence: probe failure was treated as confirmed absence"
  fi
  rm -rf "$st"
}

unit_native_lifecycle() {
  local st out
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-native.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.subsuper-escalations"
  enter_posture "$st" || fail "native lifecycle: could not enter fixture posture"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" start-native >/dev/null 2>&1 \
    && [ "$(cut -f1 "$st/state/.afk-daemon-terminal")" = none ] \
    && [ -e "$st/state/.afk" ] \
    && [ ! -e "$st/state/.subsuper-escalations" ]; then
    pass "native lifecycle: launcher owns state with no terminal"
  else
    fail "native lifecycle: state preparation or no-terminal record failed"
  fi
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop 2>&1)
  if [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ] \
    && printf '%s' "$out" | grep -F 'no daemon terminal was running' >/dev/null \
    && ! printf '%s' "$out" | grep -F 'daemon terminal torn down' >/dev/null; then
    pass "native lifecycle: uniform stop clears state without closing a terminal"
  else
    fail "native lifecycle: uniform stop retained state or claimed a teardown: $out"
  fi
  rm -rf "$st"
}

# A Claude home runs the supervision host by default and it is the home's away
# session, so away mode launches no daemon there with no file or any file but
# off; quiet mode still does, a plain refresh of a running quiet daemon is
# still allowed, and an off file keeps the away daemon.
unit_supervision_host_claude_home_runs_no_away_daemon() {
  local st out rc line
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-host.XXXXXX")
  mkdir -p "$st/state" "$st/config"
  for line in - ''; do
    rm -f "$st/config/supervision-host" "$st/state/.afk-contract"
    [ "$line" = - ] || printf '%s\n' "$line" > "$st/config/supervision-host"
    FM_CONFIG_OVERRIDE="$st/config" enter_posture "$st" || fail "supervision host: could not enter fixture posture"
    out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" "$LAUNCH" start-native 2>&1)
    rc=$?
    if [ "$rc" -ne 0 ] && printf '%s' "$out" | grep -F 'runs the supervision host (docs/supervision-host.md)' >/dev/null \
      && [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ] && [ -f "$st/state/.afk-contract" ]; then
      pass "supervision host: away start-native on a claude home (config file: ${line:-empty}) refuses the daemon and keeps the record"
    else
      fail "supervision host: away start-native did not refuse cleanly with config file ${line:-empty} (rc=$rc): $out"
    fi
  done
  rm -f "$st/state/.afk-contract"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_MODE=quiet "$CONTRACT" enter >/dev/null 2>&1 \
    || fail "supervision host: could not enter quiet fixture posture"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" FM_AFK_MODE=quiet "$LAUNCH" start-native >/dev/null 2>&1 \
    && [ "$(head -n 1 "$st/state/.afk")" = quiet ] \
    && FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" "$LAUNCH" start-native >/dev/null 2>&1 \
    && [ "$(head -n 1 "$st/state/.afk")" = quiet ]; then
    pass "supervision host: quiet start-native and a plain refresh of the quiet daemon still prepare the daemon"
  else
    fail "supervision host: quiet mode was refused or lost its mode on a claude host home"
  fi
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" "$LAUNCH" stop >/dev/null 2>&1 || true
  : > "$st/config/supervision-host-off"
  FM_CONFIG_OVERRIDE="$st/config" enter_posture "$st" || fail "supervision host: could not enter the off fixture posture"
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" "$LAUNCH" start-native 2>&1)
  rc=$?
  if [ "$rc" -eq 0 ] && [ "$(head -n 1 "$st/state/.afk" 2>/dev/null)" = away ]; then
    pass "supervision host: config/supervision-host-off keeps the away daemon on a claude home"
  else
    fail "supervision host: config/supervision-host-off did not keep the away daemon (rc=$rc): $out"
  fi
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" "$LAUNCH" stop >/dev/null 2>&1 || true
  rm -rf "$st"
}

# Every non-Pi primary with an arm owner runs the host under the same file, so
# away mode launches no daemon there, quiet mode still does, and a harness with
# no arm owner (kimi) keeps the daemon. `enter` says so when the file selects
# no engine for that primary.
unit_supervision_host_other_harnesses_run_no_away_daemon() {
  local st harness out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-host-harness.XXXXXX")
  mkdir -p "$st/state" "$st/config"
  daemon_allowed() {  # <harness> [mode]
    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" FM_TEST_HARNESS="$1" FM_AFK_MODE="${2:-}" \
      bash -c '. "$1"; fm_afk_launch_primary_harness() { printf "%s" "$FM_TEST_HARNESS"; }; fm_afk_launch_daemon_allowed' _ "$LAUNCH" 2>&1
  }
  for harness in cursor opencode omp grok codex agy; do
    daemon_allowed "$harness" >/dev/null || fail "$harness: a home without config/supervision-host must keep the away daemon"
  done
  daemon_allowed claude >/dev/null && fail "claude: a home without config/supervision-host runs the host, so it must refuse the away daemon"
  : > "$st/config/supervision-host-off"
  for harness in claude cursor opencode omp grok codex agy; do
    daemon_allowed "$harness" >/dev/null || fail "$harness: a home opted out by config/supervision-host-off must keep the away daemon"
  done
  rm -f "$st/config/supervision-host-off"
  : > "$st/config/supervision-host"
  for harness in cursor opencode omp grok codex agy; do
    out=$(daemon_allowed "$harness"); rc=$?
    [ "$rc" -ne 0 ] || fail "$harness: an opted-in home must refuse the away daemon"
    printf '%s' "$out" | grep -F "not launched on this $harness home, which runs the supervision host" >/dev/null \
      || fail "$harness: the refusal must name the host: $out"
    daemon_allowed "$harness" quiet >/dev/null || fail "$harness: quiet mode must still launch the daemon on an opted-in home"
  done
  daemon_allowed kimi >/dev/null || fail "kimi has no arm owner to run the host, so it must keep the away daemon"
  pass "supervision host: away mode on an opted-in cursor, opencode, omp, grok, codex, or agy home launches no daemon"

  enter_with() {  # <harness> <config line, off for the opt-out, or ->
    rm -f "$st/state/.afk-contract" "$st/config/supervision-host" "$st/config/supervision-host-off"
    case "$2" in
      -) ;;
      off) : > "$st/config/supervision-host-off" ;;
      *) printf '%s\n' "$2" > "$st/config/supervision-host" ;;
    esac
    FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_CONFIG_OVERRIDE="$st/config" FM_TEST_HARNESS="$1" \
      bash -c '. "$1"; fm_afk_launch_primary_harness() { printf "%s" "$FM_TEST_HARNESS"; }; fm_afk_launch_main enter --words "watch the fleet"' _ "$LAUNCH" 2>&1
  }
  out=$(enter_with cursor ''); rc=$?
  [ "$rc" -eq 0 ] && [ -f "$st/state/.afk-contract" ] || fail "enter on an opted-in cursor home failed (rc=$rc): $out"
  printf '%s' "$out" | grep -F "Supervision host: no engine runs the away session on this home (the primary harness 'cursor' has no verified supervision engine)" >/dev/null \
    || fail "enter must say when the host has no engine for this primary: $out"
  out=$(enter_with cursor claude)
  printf '%s' "$out" | grep -F 'Supervision host: no engine' >/dev/null && fail "enter must stay quiet when the file names a verified engine: $out"
  out=$(enter_with cursor -)
  printf '%s' "$out" | grep -F 'Supervision host' >/dev/null && fail "enter must stay quiet on a home without the file: $out"
  out=$(enter_with claude '')
  printf '%s' "$out" | grep -F 'Supervision host: no engine' >/dev/null && fail "a claude home's own engine must count as an engine: $out"
  out=$(enter_with claude -)
  printf '%s' "$out" | grep -F 'Supervision host: no engine' >/dev/null && fail "a claude home without the file runs its own engine: $out"
  out=$(enter_with cursor off)
  printf '%s' "$out" | grep -F 'Supervision host' >/dev/null && fail "enter must stay quiet on a home that opted out: $out"
  pass "supervision host: enter names a missing engine on an opted-in home and says nothing otherwise"
  rm -rf "$st"
}

# An opted-in Claude home for the /quiet units: the verified engine (a stub),
# this shell as the main session's lock holder, and a valid dialog mirror, so
# the attended supervision host runs. quiet_in <home> runs a command there.
QUIET_MIRROR='{"seq":1,"key":"k","tag":"captain","text":"watch the fleet"}'
quiet_home() {  # <home>
  mkdir -p "$1/state" "$1/config"
  printf '#!/usr/bin/env bash\nexit 0\n' > "$1/claude-engine"
  chmod +x "$1/claude-engine"
  printf 'claude\n' > "$1/config/supervision-host"
  printf '%s\n' "$$" > "$1/state/.lock"
  printf '%s\n' "$QUIET_MIRROR" > "$1/state/.host-mirror.jsonl"
}
# Judge the last quiet command's $rc and $out: <status> and a <fragment> of its output.
quiet_expect() {  # <status> <fragment> <failure>
  if [ "$rc" -ne "$1" ] || ! printf '%s' "$out" | grep -F -- "$2" >/dev/null; then
    fail "$3 (rc=$rc): $out"
  fi
}
quiet_in() {  # <home> <command...>
  local home=$1
  shift
  FM_SUPERVISION_ENGINE_CLAUDE_BIN="${QUIET_ENGINE-$home/claude-engine}" FM_HOME="$home" \
    FM_STATE_OVERRIDE="$home/state" FM_CONFIG_OVERRIDE="$home/config" "$@" 2>&1
}

# Daemon-backed quiet mode (no supervision host) writes the record through the
# same entry, and the captain is present: the entry the main session reads must
# not say hold-for-return, the live finding where a present captain's requested
# local landing was held until /quiet off. A later /afk makes the record away.
unit_daemon_quiet_entry_holds_nothing_for_a_return() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet-entry.XXXXXX")
  mkdir -p "$st/state"
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_MODE=quiet "$LAUNCH" enter 2>&1)
  rc=$?
  if [ "$rc" -eq 0 ] \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" mode)" = quiet ] \
    && printf '%s' "$out" | grep -F 'Quiet mode recorded at ' >/dev/null \
    && printf '%s' "$out" | grep -F 'nothing waits for your return' >/dev/null \
    && ! printf '%s' "$out" | grep -F 'hold-for-return' >/dev/null \
    && ! printf '%s' "$out" | grep -F 'Away posture' >/dev/null; then
    pass "quiet entry: the daemon-backed quiet record announces a present captain with nothing held for a return"
  else
    fail "quiet entry: the quiet record read as away or hold-for-return (rc=$rc): $out"
  fi
  out=$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" enter 2>&1)
  rc=$?
  if [ "$rc" -eq 0 ] \
    && [ "$(FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$CONTRACT" mode)" = away ] \
    && printf '%s' "$out" | grep -F 'hold-for-return only' >/dev/null; then
    pass "quiet entry: a later /afk entry turns the quiet record into the away posture, which holds for the return"
  else
    fail "quiet entry: /afk over quiet mode did not record away (rc=$rc): $out"
  fi
  rm -rf "$st"
}

# /quiet where the attended supervision host runs is a statement: quiet-check
# says quiet mode needs nothing, or that the session is paused while its
# broken-session latch holds, and a quiet enter writes nothing. Without the
# opt-in, or on Pi, quiet-check says nothing and quiet mode is the daemon's.
unit_supervision_host_quiet_statement() {
  local st out rc key harness
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet.XXXXXX")
  quiet_home "$st"
  : > "$st/config/supervision-host-off"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  [ "$rc" -eq 1 ] && [ -z "$out" ] || fail "quiet-check on a claude home opted out by config/supervision-host-off must exit 1 silently (rc=$rc): $out"
  rm -f "$st/config/supervision-host" "$st/config/supervision-host-off"
  out=$(FM_TEST_HARNESS=cursor quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  [ "$rc" -eq 1 ] && [ -z "$out" ] || fail "quiet-check on a cursor home without config/supervision-host must exit 1 silently (rc=$rc): $out"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  quiet_expect 0 'Quiet mode needs nothing on this home' "quiet-check on a claude home without config/supervision-host must say quiet mode needs nothing"
  printf 'claude\n' > "$st/config/supervision-host"
  out=$(FM_TEST_HARNESS=pi quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  [ "$rc" -eq 1 ] && [ -z "$out" ] || fail "quiet-check on a pi home must exit 1 silently (rc=$rc): $out"

  for harness in claude cursor; do
    out=$(FM_TEST_HARNESS=$harness quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
    quiet_expect 0 'Quiet mode needs nothing on this home' "$harness: quiet-check must say quiet mode needs nothing where the attended host runs"
  done
  out=$(quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet"); rc=$?
  if [ "$rc" -ne 3 ] || [ -e "$st/state/.afk-contract" ] || [ -e "$st/state/.afk" ] \
    || ! printf '%s' "$out" | grep -F 'quiet mode writes no away-posture record on this home' >/dev/null; then
    fail "a quiet enter where the attended host runs must write no record that would park a present captain (rc=$rc): $out"
  fi
  [ ! -e "$st/state/.host-mirror-cursor.next" ] || fail "quiet-check must stage no mirror cursor"
  pass "supervision host: /quiet is a statement where the attended host runs, and a quiet enter writes nothing there"

  # The host's broken-session latch, as the host persists it after two engine
  # errors, under the engine library's own latch key.
  # shellcheck disable=SC2016 # $1 and $2 expand in the inner shell.
  key=$(quiet_in "$st" bash -c '. "$1/bin/fm-wake-lib.sh" && . "$1/bin/fm-supervision-engine-lib.sh" && fm_supervision_host_config "$2/config" claude && fm_supervision_host_health_key "$2/state"' _ "$ROOT" "$st")
  printf 'key=%s\nerrors=2\ncooldown=300\nretry_after=%s\n' "$key" "$(( $(date +%s) + 300 ))" > "$st/state/.supervision-host-health"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  quiet_expect 0 'paused after repeated engine errors: routine wakes reach this conversation until it recovers, and its next retry is due at' "quiet-check during the latch's cooldown must say the session is paused"
  out=$(quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet"); rc=$?
  [ "$rc" -eq 3 ] && [ ! -e "$st/state/.afk-contract" ] || fail "a quiet enter while the latch holds must write nothing (rc=$rc): $out"
  printf 'key=%s\nerrors=2\ncooldown=300\nretry_after=%s\n' "$key" "$(( $(date +%s) - 10 ))" > "$st/state/.supervision-host-health"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check)
  printf '%s' "$out" | grep -F 'until it recovers, and its next wake retries it' >/dev/null \
    || fail "quiet-check past the retry time but before a successful probe must still say the session is paused: $out"
  printf 'key=%s\nerrors=0\ncooldown=0\nretry_after=0\n' "$key" > "$st/state/.supervision-host-health"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check)
  printf '%s' "$out" | grep -F 'Quiet mode needs nothing on this home' >/dev/null \
    || fail "quiet-check once the latch clears must say quiet mode needs nothing again: $out"
  [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ] || fail "quiet-check must start nothing"
  pass "supervision host: quiet-check says the supervision session is paused while its latch holds, and starts nothing"
  rm -rf "$st"
}

# Where the home opted in but the attended host lacks a part, quiet-check names
# it and quiet mode enters through the daemon. The quiet enter records its
# mode, so the daemon start needs no FM_AFK_MODE, while an explicit away start
# is refused in away wording; a later /quiet refreshes the running quiet daemon.
unit_supervision_host_quiet_fallback() {
  local st out rc bad
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet-fallback.XXXXXX")
  quiet_home "$st"
  unready() {  # <reason fragment> [<harness>]
    out=$(FM_TEST_HARNESS="${2:-claude}" quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
    quiet_expect 1 "Quiet mode is not already the ordinary posture on this home, because $1" "quiet-check must name '$1' and exit 1"
  }
  QUIET_ENGINE="$st/no-claude" unready 'the claude engine executable is missing'
  printf 'codex\n' > "$st/config/supervision-host"
  unready "no supervision engine: config/supervision-host names 'codex', which is not a verified supervision engine"
  : > "$st/config/supervision-host"
  unready "no supervision engine: the primary harness 'cursor' has no verified supervision engine" cursor
  printf 'claude\n' > "$st/config/supervision-host"
  for bad in opencode omp grok codex; do
    unready "no verified dialog mirror for $bad" "$bad"
  done
  printf '999999999\n' > "$st/state/.lock"
  unready 'the main session could not be identified'
  printf '%s\n' "$$" > "$st/state/.lock"
  rm -f "$st/state/.host-mirror.jsonl"
  unready 'the dialog mirror is missing or could not be read'
  # A mirror the attended feed would refuse: a malformed entry, a sequence
  # number that is not a positive integer or does not rise, or an unterminated
  # final record.
  for bad in "$QUIET_MIRROR"$'\n''{"seq":"two","tag":"captain"}'$'\n' \
    '{"seq":0,"key":"k","tag":"captain","text":"one"}'$'\n' \
    '{"seq":1.5,"key":"k","tag":"captain","text":"one"}'$'\n' \
    '{"seq":2,"key":"k","tag":"captain","text":"one"}'$'\n''{"seq":2,"key":"k","tag":"main","text":"two"}'$'\n' \
    "$QUIET_MIRROR"; do
    printf '%s' "$bad" > "$st/state/.host-mirror.jsonl"
    unready 'the dialog mirror is missing or could not be read'
  done
  [ ! -e "$st/state/.host-mirror-cursor.next" ] || fail "quiet-check must stage no mirror cursor"
  pass "supervision host: quiet-check names what the attended host lacks"

  out=$(quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet"); rc=$?
  [ "$rc" -eq 0 ] && [ "$(quiet_in "$st" "$CONTRACT" field mode)" = quiet ] \
    || fail "a quiet enter where the attended host is unready must record quiet mode for the daemon (rc=$rc): $out"
  out=$(quiet_in "$st" env FM_AFK_MODE=away "$LAUNCH" start-native); rc=$?
  if [ "$rc" -eq 0 ] || [ -e "$st/state/.afk" ] \
    || ! printf '%s' "$out" | grep -F 'the away daemon is not launched on this claude home' >/dev/null; then
    fail "an explicit away start must still refuse the away daemon in away wording (rc=$rc): $out"
  fi
  printf 'away\n' > "$st/state/.afk"
  out=$(quiet_in "$st" "$LAUNCH" start-native); rc=$?
  [ "$rc" -eq 0 ] && [ "$(head -n 1 "$st/state/.afk")" = quiet ] \
    || fail "a start with no FM_AFK_MODE must take quiet from the entry's record, over a stale flag (rc=$rc): $out"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  [ "$rc" -eq 1 ] && [ -z "$out" ] || fail "quiet-check while the quiet daemon runs must send a later /quiet to its refresh silently (rc=$rc): $out"
  out=$(quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter); rc=$?
  [ "$rc" -eq 0 ] && [ "$(quiet_in "$st" "$CONTRACT" field mode)" = quiet ] \
    || fail "a quiet refresh must keep the quiet daemon's record (rc=$rc): $out"
  pass "supervision host: an unready host's quiet entry records its mode, which carries the daemon start"
  quiet_in "$st" "$LAUNCH" stop >/dev/null || true
  rm -rf "$st"
}

# /afk then /quiet on an opted-in Claude home: the away record parks main, so
# quiet-check and a quiet enter refuse and name it, whatever state/.afk says,
# until the return archives it. Covered with the attended host ready, and over
# a quiet daemon that fell back because the dialog mirror was missing.
unit_supervision_host_quiet_after_afk() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet-away.XXXXXX")
  quiet_home "$st"
  refuses_under_away_record() {  # <case>
    cp "$st/state/.afk-contract" "$st/away-record"
    out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
    quiet_expect 2 'away record (state/.afk-contract) is live' "$1: quiet-check under a live away record must refuse and name it"
    out=$(quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet"); rc=$?
    quiet_expect 3 'away record (state/.afk-contract) is live' "$1: a quiet enter under a live away record must refuse and name it"
    cmp -s "$st/state/.afk-contract" "$st/away-record" || fail "$1: a refused quiet enter must leave the away record untouched"
  }

  out=$(quiet_in "$st" "$LAUNCH" enter --words "back after lunch"); rc=$?
  [ "$rc" -eq 0 ] && [ -f "$st/state/.afk-contract" ] && [ ! -e "$st/state/.afk" ] \
    || fail "/afk on an opted-in claude home must write the away record and no daemon flag (rc=$rc): $out"
  refuses_under_away_record "ready host"
  quiet_in "$st" "$LAUNCH" stop >/dev/null || fail "the return's stop must archive the away record"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  quiet_expect 0 'Quiet mode needs nothing on this home' "quiet-check after the return must say quiet mode needs nothing"
  pass "supervision host: /quiet under a live away record refuses and names it until the return"

  rm -f "$st/state/.host-mirror.jsonl"
  quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet" >/dev/null \
    && quiet_in "$st" "$LAUNCH" start-native >/dev/null && [ "$(head -n 1 "$st/state/.afk")" = quiet ] \
    || fail "a quiet entry without the dialog mirror must prepare the quiet daemon"
  out=$(quiet_in "$st" "$LAUNCH" enter --words "back after lunch"); rc=$?
  [ "$rc" -eq 0 ] && [ -z "$(quiet_in "$st" "$CONTRACT" field mode)" ] && [ "$(head -n 1 "$st/state/.afk")" = quiet ] \
    || fail "/afk over the quiet daemon must record away words and leave the quiet flag (rc=$rc): $out"
  refuses_under_away_record "over a quiet daemon"
  quiet_in "$st" "$LAUNCH" stop >/dev/null || fail "the return's stop must stop the quiet daemon and archive the record"
  [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-contract" ] || fail "the return must leave no flag or record"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  quiet_expect 1 'the dialog mirror is missing or could not be read' "quiet-check after the return must again send quiet mode to the daemon"
  pass "supervision host: /quiet under a live away record over a fallback quiet daemon refuses until the return"
  rm -rf "$st"
}

# A quiet start that fails after a quiet enter wrote its record, with no
# daemon running, archives that record and leaves no flag, so the present
# captain is not parked; an away start that fails keeps its record.
unit_supervision_host_quiet_failed_start() {
  local st out rc
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-quiet-failed.XXXXXX")
  quiet_home "$st"
  rm -f "$st/state/.host-mirror.jsonl"
  quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet" >/dev/null \
    || fail "a quiet entry without the dialog mirror must record quiet mode"
  out=$(quiet_in "$st" env FM_SUPERVISOR_TARGET=unused FM_SUPERVISOR_BACKEND=unsupported "$LAUNCH" start); rc=$?
  if [ "$rc" -eq 0 ] || [ -e "$st/state/.afk-contract" ] || [ -e "$st/state/.afk" ] \
    || [ -z "$(ls "$st/state/afk-contracts" 2>/dev/null)" ]; then
    fail "a failed quiet start must archive the quiet record and leave no flag (rc=$rc): $out"
  fi
  printf '%s\n' "$QUIET_MIRROR" > "$st/state/.host-mirror.jsonl"
  out=$(quiet_in "$st" "$LAUNCH" quiet-check); rc=$?
  quiet_expect 0 'Quiet mode needs nothing on this home' "once the mirror returns after a failed quiet start, the attended host must treat the captain as present"
  quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet" >/dev/null; rc=$?
  [ "$rc" -eq 3 ] && [ ! -e "$st/state/.afk-contract" ] || fail "a quiet enter after a failed quiet start must again write nothing (rc=$rc)"
  rm -f "$st/state/.host-mirror.jsonl"
  quiet_in "$st" env FM_AFK_MODE=quiet "$LAUNCH" enter --words "stay quiet" >/dev/null \
    || fail "a second quiet entry without the dialog mirror must record quiet mode"
  out=$(quiet_in "$st" env FM_SUPERVISOR_TARGET=unused "$LAUNCH" start-native); rc=$?
  [ "$rc" -eq 0 ] && [ "$(head -n 1 "$st/state/.afk")" = quiet ] \
    || fail "a successful quiet start must keep the quiet record and flag (rc=$rc): $out"
  quiet_in "$st" "$LAUNCH" stop >/dev/null || true
  pass "supervision host: a failed quiet start archives its quiet record so the present captain is not parked"

  : > "$st/config/supervision-host-off"
  quiet_in "$st" "$LAUNCH" enter --words "back after lunch" >/dev/null || fail "an away entry must record the away words"
  cp "$st/state/.afk-contract" "$st/away-record"
  out=$(quiet_in "$st" env FM_SUPERVISOR_TARGET=unused FM_SUPERVISOR_BACKEND=unsupported "$LAUNCH" start); rc=$?
  [ "$rc" -ne 0 ] && cmp -s "$st/state/.afk-contract" "$st/away-record" && [ ! -e "$st/state/.afk" ] \
    || fail "a failed away start must keep its away record (rc=$rc): $out"
  pass "supervision host: a failed away start keeps its away record"
  rm -rf "$st"
}

unit_native_entry_preserves_prepared_state() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-native-entry.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.afk"
  : > "$st/state/.subsuper-escalations"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_AFK_STATE_PREPARED=1 bash -c '
    . "$1"
    FM_AFK_DAEMON=/bin/true
    fm_afk_start_main
  ' _ "$START" >/dev/null 2>&1
  if [ -e "$st/state/.afk" ] && [ -e "$st/state/.subsuper-escalations" ]; then
    pass "native entry: launcher-prepared lifecycle state is not rewritten"
  else
    fail "native entry: launcher-prepared lifecycle state was mutated"
  fi
  rm -rf "$st"
}

unit_close_failure_preserves_record() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-close-fail.XXXXXX")
  mkdir -p "$st/state"
  printf 'tmux\texact-session\towned\n' > "$st/state/.afk-daemon-terminal"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_close_terminal() { return 1; }
    fm_afk_launch_terminal_absent() { return 1; }
    ! fm_afk_launch_reconcile
  ' _ "$LAUNCH"
  if [ -e "$st/state/.afk-daemon-terminal" ]; then
    pass "teardown failure: exact terminal record is preserved"
  else
    fail "teardown failure: exact terminal record was discarded"
  fi
  rm -rf "$st"
}

unit_record_publication_atomic() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-record-atomic.XXXXXX")
  mkdir -p "$st/state"
  printf 'tmux\told-session\towned\n' > "$st/state/.afk-daemon-terminal"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    mv() { return 1; }
    ! fm_afk_launch_record_write tmux new-session owned
  ' _ "$LAUNCH" \
    && [ "$(cat "$st/state/.afk-daemon-terminal")" = $'tmux\told-session\towned' ] \
    && ! find "$st/state" -name '.afk-daemon-terminal.pending.*' -print -quit | grep -q .; then
    pass "record publication: failed atomic rename preserves the complete prior record"
  else
    fail "record publication: failed write truncated or replaced the prior record"
  fi
  rm -rf "$st"
}

unit_malformed_record_fails_closed() {
  local st acted
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-record-malformed.XXXXXX")
  mkdir -p "$st/state"
  printf 'tmux\tonly-two-fields\n' > "$st/state/.afk-daemon-terminal"
  acted="$st/acted"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" ACTED="$acted" bash -c '
    . "$1"
    fm_afk_launch_close_terminal() { : > "$ACTED"; }
    ! fm_afk_launch_reconcile
  ' _ "$LAUNCH" \
    && [ ! -e "$acted" ] && [ -e "$st/state/.afk-daemon-terminal" ]; then
    pass "record read: malformed record fails closed without acting on a partial id"
  else
    fail "record read: malformed record was acted on or discarded"
  fi
  rm -rf "$st"
}

unit_stop_malformed_record_fails_closed() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop-malformed.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.afk"
  printf 'tmux\tonly-two-fields\n' > "$st/state/.afk-daemon-terminal"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    ! fm_afk_launch_stop
  ' _ "$LAUNCH" && [ -e "$st/state/.afk" ] && [ -e "$st/state/.afk-daemon-terminal" ]; then
    pass "stop: malformed terminal record preserves away state and fails closed"
  else
    fail "stop: malformed terminal record cleared protected lifecycle state"
  fi
  rm -rf "$st"
}

unit_tmux_planned_record_and_collision() {
  local st first second
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-tmux-plan.XXXXXX")
  mkdir -p "$st/state"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    tmux() {
      if [ "$1" = new-session ]; then
        [ -s "$FM_AFK_LAUNCH_RECORD" ] || return 9
        printf "%s" "$4" > "$FM_HOME/created-name"
        return 1
      fi
      [ "$1" != kill-session ] || : > "$FM_HOME/killed"
      return 1
    }
    ! fm_afk_launch_create_tmux captain:0 tmux
  ' _ "$LAUNCH" && [ ! -e "$st/state/.afk-daemon-terminal" ] && [ ! -e "$st/killed" ]; then
    pass "tmux launch: planned exact target is recorded before creation and removed on failure"
  else
    fail "tmux launch: creation began before exact target publication"
  fi
  first=$(cat "$st/created-name")
  rm -rf "$st"

  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-tmux-unique.XXXXXX")
  mkdir -p "$st/state"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    tmux() {
      [ "$1" != new-session ] || { printf "%s" "$4" > "$FM_HOME/created-name"; return 1; }
      [ "$1" != kill-session ] || : > "$FM_HOME/killed"
      return 1
    }
    ! fm_afk_launch_create_tmux captain:0 tmux
  ' _ "$LAUNCH" && [ ! -e "$st/killed" ]; then
    second=$(cat "$st/created-name")
    if [ "$first" != "$second" ]; then
      pass "tmux launch: unique names eliminate collision teardown"
    else
      fail "tmux launch: consecutive launches reused a session name"
    fi
  else
    fail "tmux launch: creation failure attempted session teardown"
  fi
  rm -rf "$st"
}

unit_stop_validates_before_signal() {
  local st sleeper_pid
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop-validate.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.afk"
  printf 'tmux\tonly-two-fields\n' > "$st/state/.afk-daemon-terminal"
  sleep 30 &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  sleeper_pid=$!
  mkdir -p "$st/state/.supervise-daemon.lock"
  printf '%s' "$sleeper_pid" > "$st/state/.supervise-daemon.lock/pid"
  # shellcheck source=/dev/null
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$sleeper_pid" > "$st/state/.supervise-daemon.lock/pid-identity" )
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" "$LAUNCH" stop >/dev/null 2>&1 || true
  if kill -0 "$sleeper_pid" 2>/dev/null && [ -e "$st/state/.afk" ]; then
    pass "stop validation: malformed record causes no daemon or state side effects"
  else
    fail "stop validation: malformed record signaled daemon or cleared state"
  fi
  kill "$sleeper_pid" 2>/dev/null || true
  wait "$sleeper_pid" 2>/dev/null || true
  rm -rf "$st"
}

unit_lock_requires_complete_metadata() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-lock-metadata.XXXXXX")
  mkdir -p "$st/state"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_pid_identity() { return 1; }
    ! fm_afk_launch_lock_acquire
  ' _ "$LAUNCH" && [ ! -e "$st/state/.afk-launch.lock" ]; then
    pass "launcher lock: incomplete metadata fails acquisition and releases lock"
  else
    fail "launcher lock: incomplete metadata was accepted"
  fi
  rm -rf "$st"
}

unit_stop_surfaces_afk_removal_failure() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop-remove.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.afk"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    rm() { local last=${!#}; [ "$last" != "$FM_AFK_LAUNCH_STATE/.afk" ]; }
    ! fm_afk_launch_stop
  ' _ "$LAUNCH"; then
    pass "stop state: away-flag removal failure is surfaced"
  else
    fail "stop state: away-flag removal failure reported success"
  fi
  rm -rf "$st"
}

unit_stop_confirms_daemon_exit() {
  local st daemon_pid
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-stop-live.XXXXXX")
  mkdir -p "$st/state/.supervise-daemon.lock"
  : > "$st/state/.afk"
  printf 'none\t-\tnative\n' > "$st/state/.afk-daemon-terminal"
  bash -c 'trap "" TERM; while :; do sleep 1; done' &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  daemon_pid=$!
  printf '%s' "$daemon_pid" > "$st/state/.supervise-daemon.lock/pid"
  # shellcheck source=/dev/null
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$daemon_pid" > "$st/state/.supervise-daemon.lock/pid-identity" )
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    seq() { printf "1\n"; }
    sleep() { :; }
    kill() {
      command kill "$@"
      if [ "$1" = -TERM ]; then
        rm -rf "$FM_AFK_LAUNCH_STATE/.supervise-daemon.lock"
      fi
    }
    ! fm_afk_launch_stop
  ' _ "$LAUNCH" && kill -0 "$daemon_pid" 2>/dev/null \
    && [ ! -e "$st/state/.supervise-daemon.lock" ] \
    && [ -e "$st/state/.afk" ] && [ -e "$st/state/.afk-daemon-terminal" ]; then
    pass "stop liveness: captured live daemon preserves lifecycle state after lock release"
  else
    fail "stop liveness: lock release was mistaken for captured daemon exit"
  fi
  kill -KILL "$daemon_pid" 2>/dev/null || true
  wait "$daemon_pid" 2>/dev/null || true
  rm -rf "$st"
}

unit_refresh_validates_record() {
  local st daemon_pid
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-refresh-record.XXXXXX")
  mkdir -p "$st/state/.supervise-daemon.lock"
  printf 'tmux\tonly-two-fields\n' > "$st/state/.afk-daemon-terminal"
  sleep 30 &
  # shellcheck disable=SC2031 # The background PID is captured immediately in this shell.
  daemon_pid=$!
  printf '%s' "$daemon_pid" > "$st/state/.supervise-daemon.lock/pid"
  # shellcheck source=/dev/null
  ( . "$ROOT/bin/fm-wake-lib.sh"; fm_pid_identity "$daemon_pid" > "$st/state/.supervise-daemon.lock/pid-identity" )
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" FM_SUPERVISOR_TARGET=unused \
    FM_SUPERVISOR_BACKEND=tmux bash -c '
      . "$1"
      ! fm_afk_launch_start && ! fm_afk_launch_start_native
    ' _ "$LAUNCH" && [ ! -e "$st/state/.afk" ]; then
    pass "refresh record: malformed terminal identity fails closed"
  else
    fail "refresh record: malformed terminal identity was accepted"
  fi
  kill "$daemon_pid" 2>/dev/null || true
  wait "$daemon_pid" 2>/dev/null || true
  rm -rf "$st"
}

unit_clear_failure_aborts_entry() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-clear-fail.XXXXXX")
  mkdir -p "$st/state"
  : > "$st/state/.subsuper-escalations"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_reconcile() { return 0; }
    fm_afk_clear_stale_artifacts() { return 1; }
    ! fm_afk_launch_start_native
  ' _ "$LAUNCH" && [ ! -e "$st/state/.afk" ] && [ -e "$st/state/.subsuper-escalations" ]; then
    pass "clear failure: native entry aborts and restores prior state"
  else
    fail "clear failure: native entry proceeded or lost prior state"
  fi
  rm -rf "$st"
}

unit_confirmed_absence_succeeds() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-confirmed-absent.XXXXXX")
  mkdir -p "$st/state"
  printf 'tmux\texact-session\towned\n' > "$st/state/.afk-daemon-terminal"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_close_terminal() { return 1; }
    fm_afk_launch_terminal_absent() { return 0; }
    fm_afk_launch_reconcile
  ' _ "$LAUNCH" && [ ! -e "$st/state/.afk-daemon-terminal" ]; then
    pass "confirmed absence: cleanup succeeds and removes the stale record"
  else
    fail "confirmed absence: close error incorrectly failed reconciliation"
  fi
  rm -rf "$st"
}

unit_incomplete_restore_retains_backup() {
  local st backup
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-restore-fail.XXXXXX")
  mkdir -p "$st/state"
  backup=$(mktemp -d "$st/state/.afk-launch-backup.XXXXXX")
  printf 'prior\n' > "$backup/.afk"
  if FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    cp() { return 1; }
    ! fm_afk_launch_restore_backup "$2" 1
  ' _ "$LAUNCH" "$backup" && [ -d "$backup" ] && [ -e "$backup/.afk" ]; then
    pass "rollback restore: incomplete restoration retains its recovery backup"
  else
    fail "rollback restore: incomplete restoration discarded its backup"
  fi
  rm -rf "$st"
}

unit_flag_write_failure_aborts() {
  local st
  st=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-flag-fail.XXXXXX")
  mkdir -p "$st/state"
  FM_HOME="$st" FM_STATE_OVERRIDE="$st/state" bash -c '
    . "$1"
    fm_afk_launch_flag_write() { return 1; }
    ! fm_afk_launch_start_native
  ' _ "$LAUNCH"
  if [ ! -e "$st/state/.afk" ] && [ ! -e "$st/state/.afk-daemon-terminal" ]; then
    pass "flag failure: lifecycle aborts without active state"
  else
    fail "flag failure: lifecycle reported active state"
  fi
  rm -rf "$st"
}

# ---------------------------------------------------------------------------
# E2E herdr: topology invariant.
# ---------------------------------------------------------------------------
e2e_herdr() {
  command -v herdr >/dev/null 2>&1 || { echo "skip: herdr not found (herdr e2e)"; return 0; }
  command -v jq >/dev/null 2>&1 || { echo "skip: jq not found (herdr e2e)"; return 0; }
  # shellcheck source=tests/herdr-test-safety.sh
  . "$ROOT/tests/herdr-test-safety.sh"
  # shellcheck source=/dev/null
  . "$ROOT/bin/fm-backend.sh"

  local SESSION home_tmp cap_ws cap_tab cap_pane target
  local before during after ws_before ws_during ws_after out dtgt dtab
  SESSION="fm-lab-afk-launch-e2e-$$"
  export HERDR_SESSION="$SESSION"
  home_tmp=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-e2e-home.XXXXXX")
  E2E_HERDR_CLEANUP() {
    # shellcheck disable=SC2031 # Cleanup reads the caller's resolved target; it does not reassign it.
    FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
      FM_SUPERVISOR_TARGET="$target" FM_SUPERVISOR_BACKEND=herdr "$LAUNCH" stop >/dev/null 2>&1 || true
    herdr_safe_stop_and_delete "$SESSION" >/dev/null 2>&1 || true
    rm -rf "$home_tmp" 2>/dev/null || true
  }
  fm_herdr_lab_prepare "$SESSION" || { fail "herdr e2e: could not prepare isolated lab session"; return 0; }
  fm_backend_source herdr || { E2E_HERDR_CLEANUP; fail "herdr e2e: fm_backend_source herdr failed"; return 0; }
  fm_backend_herdr_server_ensure "$SESSION" || { E2E_HERDR_CLEANUP; fail "herdr e2e: lab server did not start"; return 0; }

  out=$(fm_backend_herdr_cli "$SESSION" workspace create --cwd "$ROOT" --label captain --no-focus 2>/dev/null)
  cap_ws=$(printf '%s' "$out" | jq -r '.result.workspace.workspace_id // empty')
  cap_tab=$(printf '%s' "$out" | jq -r '.result.tab.tab_id // empty')
  cap_pane=$(printf '%s' "$out" | jq -r '.result.root_pane.pane_id // empty')
  if [ -z "$cap_ws" ] || [ -z "$cap_pane" ]; then E2E_HERDR_CLEANUP; fail "herdr e2e: could not create captain workspace"; return 0; fi
  target="$SESSION:$cap_pane"
  enter_posture "$home_tmp" || fail "herdr e2e: could not enter fixture posture"
  before=$(fm_backend_herdr_cli "$SESSION" pane list --workspace "$cap_ws" 2>/dev/null | jq --arg t "$cap_tab" '[.result.panes[]?|select(.tab_id==$t)]|length')
  ws_before=$(fm_backend_herdr_cli "$SESSION" workspace list 2>/dev/null | jq '[.result.workspaces[]?]|length')

  FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
    FM_SUPERVISOR_TARGET="$target" FM_SUPERVISOR_BACKEND=herdr FM_AFK_LAUNCH_ENTRY="$SLEEPER" \
    "$LAUNCH" start >/dev/null 2>&1

  during=$(fm_backend_herdr_cli "$SESSION" pane list --workspace "$cap_ws" 2>/dev/null | jq --arg t "$cap_tab" '[.result.panes[]?|select(.tab_id==$t)]|length')
  ws_during=$(fm_backend_herdr_cli "$SESSION" workspace list 2>/dev/null | jq '[.result.workspaces[]?]|length')
  dtgt=$(cut -f2 "$home_tmp/state/.afk-daemon-terminal" 2>/dev/null || true)
  dtab=$(fm_backend_herdr_cli "$SESSION" pane get "${dtgt#*:}" 2>/dev/null | jq -r '.result.pane.tab_id // empty')

  if [ "$before" = "$during" ]; then pass "herdr e2e: captain tab pane count unchanged after start (no split)"; else fail "herdr e2e: captain tab pane count changed ($before -> $during)"; fi
  if [ "$ws_during" -gt "$ws_before" ]; then pass "herdr e2e: daemon launched in a separate non-visible workspace"; else fail "herdr e2e: no separate daemon workspace created"; fi
  if [ -n "$dtab" ] && [ "$dtab" != "$cap_tab" ]; then pass "herdr e2e: daemon pane is NOT in the captain's tab"; else fail "herdr e2e: daemon pane shares the captain tab ($dtab)"; fi
  case "$dtgt" in "$SESSION":*) pass "herdr e2e: daemon terminal scoped to the lab session" ;; *) fail "herdr e2e: daemon terminal not in the lab session ($dtgt)" ;; esac

  FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
    FM_SUPERVISOR_TARGET="$target" FM_SUPERVISOR_BACKEND=herdr "$LAUNCH" stop >/dev/null 2>&1

  after=$(fm_backend_herdr_cli "$SESSION" pane list --workspace "$cap_ws" 2>/dev/null | jq --arg t "$cap_tab" '[.result.panes[]?|select(.tab_id==$t)]|length')
  ws_after=$(fm_backend_herdr_cli "$SESSION" workspace list 2>/dev/null | jq '[.result.workspaces[]?]|length')
  if [ "$after" = "$before" ]; then pass "herdr e2e: captain tab pane count restored after stop"; else fail "herdr e2e: captain tab pane count not restored ($before -> $after)"; fi
  if [ "$ws_after" = "$ws_before" ]; then pass "herdr e2e: daemon workspace removed by exact id on stop"; else fail "herdr e2e: daemon workspace leaked ($ws_before -> $ws_after)"; fi
  if [ ! -e "$home_tmp/state/.afk-daemon-terminal" ] && [ ! -e "$home_tmp/state/.afk" ]; then pass "herdr e2e: record + .afk cleared on stop"; else fail "herdr e2e: record or .afk not cleared"; fi

  E2E_HERDR_CLEANUP
}

# ---------------------------------------------------------------------------
# E2E tmux: topology invariant (captain window untouched; daemon in a separate
# detached session).
# ---------------------------------------------------------------------------
e2e_tmux() {
  command -v tmux >/dev/null 2>&1 || { echo "skip: tmux not found (tmux e2e)"; return 0; }
  local cap_session home_tmp cap_pane before during after rec
  cap_session="fm-afk-launch-cap-$$"
  home_tmp=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-tmux-home.XXXXXX")
  tmux new-session -d -s "$cap_session" 2>/dev/null || { fail "tmux e2e: could not create captain session"; rm -rf "$home_tmp"; return 0; }
  TRACK_TMUX_SESSIONS="$TRACK_TMUX_SESSIONS $cap_session"
  cap_pane=$(tmux display-message -p -t "$cap_session" '#{pane_id}')
  enter_posture "$home_tmp" || fail "tmux e2e: could not enter fixture posture"
  before=$(tmux list-panes -t "$cap_session" | wc -l | tr -d ' ')

  FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
    FM_SUPERVISOR_TARGET="$cap_pane" FM_SUPERVISOR_BACKEND=tmux FM_AFK_LAUNCH_ENTRY="$SLEEPER" \
    "$LAUNCH" start >/dev/null 2>&1

  during=$(tmux list-panes -t "$cap_session" | wc -l | tr -d ' ')
  rec=$(cut -f2 "$home_tmp/state/.afk-daemon-terminal" 2>/dev/null || true)
  TRACK_TMUX_SESSIONS="$TRACK_TMUX_SESSIONS $rec"
  if [ "$before" = "$during" ]; then pass "tmux e2e: captain window pane count unchanged after start (no split-window)"; else fail "tmux e2e: captain window pane count changed ($before -> $during)"; fi
  if [ -n "$rec" ] && tmux has-session -t "$rec" 2>/dev/null && [ "$rec" != "$cap_session" ]; then pass "tmux e2e: daemon launched in a separate detached session"; else fail "tmux e2e: no separate daemon session ($rec)"; fi

  FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
    FM_SUPERVISOR_TARGET="$cap_pane" FM_SUPERVISOR_BACKEND=tmux "$LAUNCH" stop >/dev/null 2>&1

  after=$(tmux list-panes -t "$cap_session" | wc -l | tr -d ' ')
  if [ "$after" = "$before" ]; then pass "tmux e2e: captain window pane count unchanged after stop"; else fail "tmux e2e: captain window changed ($before -> $after)"; fi
  if [ -n "$rec" ] && ! tmux has-session -t "$rec" 2>/dev/null; then pass "tmux e2e: daemon session killed by exact id on stop"; else fail "tmux e2e: daemon session leaked ($rec)"; fi
  if [ ! -e "$home_tmp/state/.afk-daemon-terminal" ] && [ ! -e "$home_tmp/state/.afk" ]; then pass "tmux e2e: record + .afk cleared on stop"; else fail "tmux e2e: record or .afk not cleared"; fi

  tmux kill-session -t "$cap_session" 2>/dev/null || true
  rm -rf "$home_tmp" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# E2E rex: topology invariant on this run's private Rex server. The shared
# safety helper gives it a temporary socket, state directory, and config.
# ---------------------------------------------------------------------------
e2e_rex() {
  local home_tmp out cap_sid cap_bid cap_target before during after rec_backend rec_target rec_sid label rc
  # shellcheck source=tests/rex-test-safety.sh
  . "$ROOT/tests/rex-test-safety.sh"
  rex_test_prepare || { rc=$?; [ "$rc" = 1 ] && { echo "skip: Rex CLI or jq unavailable (rex e2e)"; return 0; }; fail "rex e2e: private Rex server setup failed"; return 1; }
  rex_e2e() { (unset REX_SESSION REX_BLOCK; . "$ROOT/bin/fm-backend.sh"; fm_backend_source rex; "$@"); }
  rex_e2e_shape() {  # <session-id>: window and block ids, or empty when gone
    rex_e2e fm_backend_rex_session_view "$1" | jq -c '[.windows[] | {window_id, blocks: [.layers[].blocks[].block_id]}]'
  }
  rex_e2e_kill_test_session() {  # <session-id>: only an fm-test-* session
    local l
    l=$(rex_e2e fm_backend_rex_session_view "$1" | jq -r '.label // empty')
    case "$l" in fm-test-*) rex_e2e fm_backend_rex_cli kill "$1" >/dev/null 2>&1 || true ;; esac
  }
  home_tmp=$(mktemp -d "${TMPDIR:-/tmp}/fm-afk-rex-home.XXXXXX")
  label="fm-test-afk-daemon-$$"
  out=$(rex_test_new_session afk-cap) \
    || { fail "rex e2e: could not create the captain test session"; rm -rf "$home_tmp"; rex_test_cleanup; return 1; }
  read -r cap_sid cap_bid <<<"$out"
  cap_target="${cap_sid#session:}:${cap_bid#block:}"
  enter_posture "$home_tmp" || fail "rex e2e: could not enter fixture posture"
  before=$(rex_e2e_shape "$cap_sid")

  (unset REX_SESSION REX_BLOCK
    FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" FM_AFK_LAUNCH_LABEL="$label" \
      FM_SUPERVISOR_TARGET="$cap_target" FM_SUPERVISOR_BACKEND=rex FM_AFK_LAUNCH_ENTRY="$SLEEPER" \
      "$LAUNCH" start >/dev/null 2>&1)

  during=$(rex_e2e_shape "$cap_sid")
  IFS=$'\t' read -r rec_backend rec_target rec_sid <"$home_tmp/state/.afk-daemon-terminal" 2>/dev/null || true
  [ -z "$rec_sid" ] || printf '%s\n' "$rec_sid" >>"$REX_TEST_WORK/allowed"
  if [ "$before" = "$during" ]; then pass "rex e2e: captain session unchanged after start (no tab or split)"; else fail "rex e2e: captain session changed ($before -> $during)"; fi
  if [ "$rec_backend" = rex ] && [ -n "$rec_sid" ] && [ "$rec_sid" != "$cap_sid" ] \
    && [ "$(rex_e2e fm_backend_rex_session_view "$rec_sid" | jq -r .label)" = "$label" ] \
    && [ "${rec_target%%:*}" = "${rec_sid#session:}" ]; then
    pass "rex e2e: daemon launched in its own dedicated session, recorded by exact id"
  else
    fail "rex e2e: no separate recorded daemon session ($rec_backend $rec_target $rec_sid)"
  fi

  (unset REX_SESSION REX_BLOCK
    FM_HOME="$home_tmp" FM_STATE_OVERRIDE="$home_tmp/state" \
      FM_SUPERVISOR_TARGET="$cap_target" FM_SUPERVISOR_BACKEND=rex "$LAUNCH" stop >/dev/null 2>&1)

  after=$(rex_e2e_shape "$cap_sid")
  if [ "$after" = "$before" ]; then pass "rex e2e: captain session unchanged after stop"; else fail "rex e2e: captain session changed ($before -> $after)"; fi
  if [ -n "$rec_sid" ] && ! rex_e2e fm_backend_rex_session_view "$rec_sid" >/dev/null 2>&1; then
    pass "rex e2e: daemon session killed by exact id on stop"
  else
    fail "rex e2e: daemon session leaked ($rec_sid)"
  fi
  if [ ! -e "$home_tmp/state/.afk-daemon-terminal" ] && [ ! -e "$home_tmp/state/.afk" ]; then pass "rex e2e: record + .afk cleared on stop"; else fail "rex e2e: record or .afk not cleared"; fi

  [ -z "$rec_sid" ] || rex_e2e_kill_test_session "$rec_sid"
  rex_e2e_kill_test_session "$cap_sid"
  rex_test_assert_isolated
  rex_test_cleanup
  rm -rf "$home_tmp" 2>/dev/null || true
}

unit_clear_stale
unit_per_task_markers_session_scoped
unit_enter_records_the_posture_in_one_step_without_a_daemon
unit_retired_two_step_entry_is_refused
unit_pi_never_launches_the_daemon
unit_test_harness_seam_requires_the_marker
unit_pi_enter_stop_does_not_claim_a_daemon_terminal
unit_daemon_entry_requires_the_record
unit_failed_daemon_launch_preserves_the_record
unit_stop_archives_the_record_last
unit_relative_paths_are_absolute_before_daemon_launch
unit_fresh_vs_refresh
unit_mode_explicit_write
unit_mode_fresh_defaults_away
unit_mode_refresh_preserves_quiet
unit_mode_quiet_daemon_to_away
unit_mode_garbage_and_legacy_content_reads_away
unit_stop_ordering
unit_stop_rejects_reused_pid
unit_failed_start_rolls_back_state
unit_concurrent_start_serialized
unit_lock_initialization_grace
unit_signal_exits_with_lock_cleanup
unit_herdr_partial_create_recovery
unit_herdr_error_with_exact_ids_closes_exact
unit_herdr_run_failure_preserves_unconfirmed_record
unit_daemon_terminal_receives_the_primary_harness
unit_record_failure_closes_terminal
unit_readiness_failure_rolls_back_terminal
unit_readiness_failure_preserves_unconfirmed_record
unit_tmux_absence_distinguishes_probe_failure
unit_native_lifecycle
unit_supervision_host_claude_home_runs_no_away_daemon
unit_supervision_host_other_harnesses_run_no_away_daemon
unit_daemon_quiet_entry_holds_nothing_for_a_return
unit_supervision_host_quiet_statement
unit_supervision_host_quiet_fallback
unit_supervision_host_quiet_after_afk
unit_supervision_host_quiet_failed_start
unit_native_entry_preserves_prepared_state
unit_close_failure_preserves_record
unit_record_publication_atomic
unit_malformed_record_fails_closed
unit_stop_malformed_record_fails_closed
unit_tmux_planned_record_and_collision
unit_stop_validates_before_signal
unit_lock_requires_complete_metadata
unit_stop_surfaces_afk_removal_failure
unit_stop_confirms_daemon_exit
unit_refresh_validates_record
unit_clear_failure_aborts_entry
unit_confirmed_absence_succeeds
unit_incomplete_restore_retains_backup
unit_flag_write_failure_aborts
e2e_herdr
e2e_tmux
e2e_rex

[ "$FAILED" -eq 0 ] || exit 1
