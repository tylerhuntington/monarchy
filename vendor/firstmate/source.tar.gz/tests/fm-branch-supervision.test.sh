#!/usr/bin/env bash
# Tests for the Pi supervision branch's fleet-record layer
# (docs/pi-supervision-branch.md): the byte-stable branch prompt generator
# (bin/fm-branch-prompt.sh), the append-only outcome store
# (bin/fm-branch-outcome.sh), the per-task lease contract (bin/fm-lease.sh,
# bin/fm-lease-lib.sh), the lease and role-partition guards wired into the
# mutating entrypoints, and the proof that a home which never runs the branch
# is untouched by all of it.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

TMP_ROOT=$(fm_test_tmproot fm-branch-supervision)
fm_git_identity fmtest fmtest@example.invalid

# --- byte-stable branch prompt ------------------------------------------------

test_branch_prompt_is_byte_stable_and_above_cache_floor() {
  local home_a home_b out_a out_b out_c size
  home_a="$TMP_ROOT/prompt-home-a"
  home_b="$TMP_ROOT/prompt-home-b"
  mkdir -p "$home_a/state" "$home_b/state"
  # Give the two homes deliberately different fleet state and clock context:
  # a byte-stable prompt must not absorb any of it.
  printf 'signal: task-1 done\n' > "$home_a/state/task-1.status"
  printf 'window=x\nharness=pi\n' > "$home_a/state/task-1.meta"

  out_a=$(cd "$TMP_ROOT" && FM_HOME="$home_a" TZ=UTC "$ROOT/bin/fm-branch-prompt.sh") \
    || fail "branch prompt generator failed for home A"
  out_b=$(cd / && FM_HOME="$home_b" TZ=Australia/Eucla "$ROOT/bin/fm-branch-prompt.sh") \
    || fail "branch prompt generator failed for home B"
  sleep 1
  out_c=$(FM_HOME="$home_a" "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt generator failed on re-run"

  [ "$out_a" = "$out_b" ] || fail "branch prompt differs across homes/cwd/timezone: prefix stability broken"
  [ "$out_a" = "$out_c" ] || fail "branch prompt differs across runs at different times: prefix stability broken"

  # Below the provider's 1024-token caching minimum a branch prompt gets no
  # cache reuse at all (measured in the feasibility evidence), so hold a
  # comfortable byte floor.
  size=${#out_a}
  [ "$size" -ge 5000 ] || fail "branch prompt is only $size bytes - below the provider caching minimum"
  case "$out_a" in
    "You are the SUPERVISION BRANCH"*) ;;
    *) fail "branch prompt lost its role preamble" ;;
  esac
  case "$out_a" in
    *"stuck-crewmate-recovery"*) ;;
    *) fail "branch prompt lost the inlined recovery playbook" ;;
  esac
  case "$out_a" in
    *"Report verdict captain for the finished result of work the captain requested, even when that result is healthy."*"A start or still-working update on requested work that brings no new artifact, finding, or decision is verdict routine."*"Set silent true for a task-level routine outcome only when it says the worker is still busy, nothing new has happened since the last outcome, and no action was taken."*"Any routine outcome reporting an action, state change, or new result stays rendered; captain outcomes are never silent."*"Keep an unsolicited routine outcome as verdict routine"*"Keep an unchanged fleet review silent"*) ;;
    *) fail "branch prompt lost the requested-result, progress-routine, or routine-silence rules" ;;
  esac
  case "$out_a" in
    *"# PR identity: copy or abstain"*"copied verbatim from the task's \`done [at=<epoch>]: PR <url>\` status line or its \`pr=\` metadata field"*"Never assemble an owner, repository, host, or number"*"report the identifier you do have"*) ;;
    *) fail "branch prompt lost the copy-or-abstain PR identity rule" ;;
  esac
  # The 2026-09-22 away window: every landed exemption worker was left sitting
  # because the prompt granted landed-task cleanup without ever naming the
  # moment or the command, so the stale wake ended in the recovery playbook's
  # "nothing to recover".
  case "$out_a" in
    *"A worker whose pull request has landed is finished, not stuck"*"\`check: merge landed:\` wake names exactly that moment"*"\`bin/fm-teardown.sh <task>\` with no flags"*"never forced, worked around, or repaired by hand"*) ;;
    *) fail "branch prompt lost the landed-work cleanup rule" ;;
  esac
  case "$out_a" in
    *"A second mate's status log is a relay channel for its child work"*"retiring a second mate is MAIN's alone"*"Report a second mate's signal wake from the status lines that wake newly presents"*"A second mate's stale wake is a liveness event: report it even when it presents no new status lines."*) ;;
    *) fail "branch prompt lost the second-mate relay, signal-span, or stale-liveness rule" ;;
  esac
  pass "branch prompt is byte-stable across homes, cwd, timezone, and time, above the cache floor"
}

# A home adds its own rules through config/branch-prompt-include.md: absent or
# blank leaves the prompt byte-identical, present text lands verbatim as the
# last section, and an unusable path refuses with no prompt on stdout.
test_branch_prompt_home_include_is_appended_last() {
  local home config base out rc last_heading
  home="$TMP_ROOT/prompt-include-home"
  config="$home/config"
  mkdir -p "$config"
  base=$(FM_HOME="$TMP_ROOT/prompt-include-none" "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt failed without a home"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt failed without an include"
  [ "$out" = "$base" ] || fail "an absent include changed the branch prompt"
  printf ' \n\n' > "$config/branch-prompt-include.md"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt failed with a blank include"
  [ "$out" = "$base" ] || fail "a blank include changed the branch prompt"

  # shellcheck disable=SC2016 # The include is literal text and must never expand.
  printf '%s\n' 'Relaunch workers with `house-tool $(id)`.' > "$config/branch-prompt-include.md"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt failed with an include"
  case "$out" in
    "$base"*) ;;
    *) fail "the include did not leave the tracked prompt as an unchanged prefix" ;;
  esac
  # shellcheck disable=SC2016 # Literal include text.
  assert_contains "$out" 'Relaunch workers with `house-tool $(id)`.' "branch prompt did not carry the include verbatim"
  assert_contains "$out" "every other section of this prompt takes precedence" "include section lost its precedence line"
  last_heading=$(printf '%s\n' "$out" | grep '^# ' | tail -n 1)
  [ "$last_heading" = '# Home prompt additions' ] || fail "include was not the last section (got: $last_heading)"
  [ "$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh")" = "$out" ] || fail "branch prompt with an include is not byte-stable across runs"

  out=$(FM_HOME="$home" FM_CONFIG_OVERRIDE="$TMP_ROOT/prompt-include-empty-config" "$ROOT/bin/fm-branch-prompt.sh") \
    || fail "branch prompt failed under FM_CONFIG_OVERRIDE"
  [ "$out" = "$base" ] || fail "FM_CONFIG_OVERRIDE did not select the config directory"

  rm -f "$config/branch-prompt-include.md"
  mkdir "$config/branch-prompt-include.md"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh" 2>/dev/null); rc=$?
  expect_code 1 "$rc" "an unusable include path must stop the branch prompt"
  [ -z "$out" ] || fail "an unusable include still emitted a partial prompt"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-prompt.sh" 2>&1 >/dev/null)
  assert_contains "$out" "branch-prompt-include.md must be a readable regular file" "unusable include refusal did not name the file"
  pass "fm-branch-prompt.sh: the home prompt include lands last, verbatim, and refuses an unusable path"
}

test_branch_prompt_routes_completed_scouts_through_guarded_cleanup() {
  local prompt skill
  prompt=$(bash "$ROOT/bin/fm-branch-prompt.sh") || fail "branch prompt generator failed"

  # The emitted system prompt is the contract, not the generator's source or
  # proof that a model will obey it. No live agent or endpoint is involved.
  case "$prompt" in
    *"For a completed scout, follow the scout-completion and captain-hold-lifecycle policies included below in both postures."*"After their completion gate passes, retain the report, claim the task's lease, and run \`bin/fm-teardown.sh <task>\` with no flags."*"Report the findings and cleanup result in that event's outcome; a refusal is reported with its exact reason and never forced, worked around, or repaired by hand."*) ;;
    *) fail "branch prompt omits the completed-scout cleanup sequence or refusal reporting" ;;
  esac
  assert_contains "$prompt" \
    "Reporting a scout as finished and idle is not a substitute for that cleanup." \
    "branch prompt permits stopping after an idle assessment of a completed scout"
  assert_contains "$prompt" \
    "Missing or incomplete reports, an unreviewed decision inventory or unrecorded captain calls, WIP ships, deliberate external waits, and idle or exited agents are not proof of task completion." \
    "branch prompt lost the incomplete-work and agent-lifetime boundaries"
  assert_contains "$prompt" \
    "Ordinary teardown of a confirmed-landed ship or a completed scout, steering, lifecycle control, PR checks, and backlog status moves are yours, under the task's lease." \
    "branch role limits still exclude completed-scout cleanup"

  # This checks delivery of the per-task result contract, not model adherence.
  assert_contains "$prompt" \
    "Run each task's cleanup in a separate tool call and use that call's exit status and output for its outcome." \
    "branch prompt omits per-task cleanup result attribution"
  assert_contains "$prompt" \
    "An allowance diagnostic is not a refusal; report a refusal only when that task's cleanup actually refuses, quoting its reason." \
    "branch prompt does not distinguish cleanup permission from refusal"

  # Verbatim policy inclusion is an owned output contract. These owners must
  # reach hosts that disable automatic skill loading, without a policy copy.
  for skill in scout-completion captain-hold-lifecycle; do
    assert_contains "$prompt" "$(cat "$ROOT/.agents/skills/$skill/SKILL.md")" \
      "branch prompt does not include the complete $skill policy"
  done
  pass "emitted branch prompt routes completed scouts through existing policies and leased cleanup, preserving unfinished work"
}

# --- append-only outcome store ------------------------------------------------

test_outcome_store_is_append_only_with_cursor_reads() {
  local home store snapshot seq1 seq2 unread replay out status
  home="$TMP_ROOT/store-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"

  seq1=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'worker healthy, "quoted" text kept' --wake 'signal: working') \
    || fail "first append failed"
  [ "$seq1" = 1 ] || fail "first outcome seq was $seq1, not 1"
  seq2=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'PR https://example.com/pr/2 checks green') \
    || fail "second append failed"
  [ "$seq2" = 2 ] || fail "second outcome seq was $seq2, not 2"

  # The store is the owned durable contract: every line stays valid JSON.
  python3 - "$store" <<'PY' || fail "outcome store holds invalid JSON"
import json, sys
rows = [json.loads(line) for line in open(sys.argv[1])]
assert [row["seq"] for row in rows] == [1, 2], rows
assert rows[0]["verdict"] == "routine" and rows[1]["verdict"] == "captain", rows
assert rows[0]["summary"] == 'worker healthy, "quoted" text kept', rows[0]
assert rows[0]["silent"] is False and rows[1]["silent"] is False, rows
PY

  # mark-read moves only the cursor sidecar; the log bytes never change.
  snapshot=$(cat "$store")
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 1 || fail "mark-read failed"
  unread=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread) || fail "unread failed"
  case "$unread" in
    '{"seq":2,'*) ;;
    *) fail "unread did not return exactly the records above the cursor: $unread" ;;
  esac
  [ "$(cat "$store")" = "$snapshot" ] || fail "mark-read rewrote the append-only store"

  # startup-replay must stop before an unread captain row. Only Pi's durable
  # visible entry may acknowledge it, so the cursor cannot skip past it.
  replay=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" startup-replay) || fail "startup-replay failed"
  [ -z "$replay" ] || fail "startup-replay printed a captain row before Pi persisted its visible entry"
  assert_contains "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread)" \
    "https://example.com/pr/2" "startup-replay advanced past an unrendered captain row"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = 1 ] \
    || fail "startup-replay moved the cursor across the captain row"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 2 \
    || fail "synthetic Pi acknowledgement failed"

  # Later appends land strictly after the earlier bytes (append-only merge).
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-3 --verdict routine --summary 'later outcome' >/dev/null || fail "third append failed"
  case "$(cat "$store")" in
    "$snapshot"*) ;;
    *) fail "a later append disturbed earlier store bytes" ;;
  esac

  printf '{"seq":4,"epoch":' >> "$store"
  snapshot=$(cat "$store")
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-5 --verdict captain --summary 'must remain unrecorded' 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append accepted a malformed outcome-store tail"
  assert_contains "$out" "malformed or non-sequential" "torn-tail refusal lost its diagnostic"
  [ "$(cat "$store")" = "$snapshot" ] || fail "failed append changed the torn outcome store"
  pass "outcome store is append-only and refuses sequence reuse after a torn tail"
}

test_outcome_append_keeps_a_bounded_display_tail() {
  local home store tail cursor
  home="$TMP_ROOT/tail-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  tail="$home/state/.branch-outcomes-tail.jsonl"
  jq -nc 'range(1; 206) | {seq: ., epoch: 100, task: "task-\(.)", wake: "", verdict: "routine", summary: "row \(.)", silent: false}' \
    > "$store"
  printf '205\n' > "$home/state/.branch-outcomes-cursor"
  cursor=$(cat "$home/state/.branch-outcomes-cursor")
  [ ! -e "$tail" ] || fail "a display tail existed before any append"

  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-206 --verdict captain --summary $'PR "ready"\nwith a second line' >/dev/null \
    || fail "append failed on a store with history"
  [ "$(wc -l < "$tail" | tr -d ' ')" = 200 ] || fail "the display tail is not bounded to the newest 200 rows"
  [ "$(cat "$tail")" = "$(tail -n 200 "$store")" ] || fail "the display tail is not the store's newest rows verbatim"
  [ "$(head -n 1 "$tail" | jq -r .seq)" = 7 ] || fail "the display tail does not start at the 200th newest row"
  [ "$(tail -n 1 "$tail" | jq -r .summary)" = $'PR "ready"\nwith a second line' ] \
    || fail "the display tail lost the new row's exact summary"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = "$cursor" ] || fail "refreshing the display tail moved the read cursor"
  pass "outcome append refreshes a bounded, verbatim display tail of the newest rows without moving the cursor"
}

test_outcome_tail_keeps_whole_newest_rows_within_its_byte_budget() {
  local home store tail first before
  home="$TMP_ROOT/tail-bytes-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  tail="$home/state/.branch-outcomes-tail.jsonl"
  jq -nc 'range(1; 6) | {seq: ., epoch: 100, task: "task-\(.)", wake: "", verdict: "routine", summary: ("x" * 307200), silent: false}' \
    > "$store"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-6 --verdict captain --summary 'small newest' >/dev/null || fail "append failed on a store of large rows"
  [ "$(wc -c < "$tail" | tr -d ' ')" -le 1048576 ] || fail "the display tail exceeded its 1 MiB budget"
  first=$(head -n 1 "$tail" | jq -r .seq) || fail "the display tail's first row is not whole JSON"
  [ "$(cat "$tail")" = "$(tail -n "$((7 - first))" "$store")" ] || fail "the display tail is not a verbatim suffix of the store"
  before=$(sed -n "$((first - 1))p" "$store" | wc -c | tr -d ' ')
  [ $(( $(wc -c < "$tail" | tr -d ' ') + before )) -gt 1048576 ] || fail "the display tail dropped a row that fit its budget"

  jq -nc '{seq: 7, epoch: 100, task: "task-7", wake: "", verdict: "routine", summary: ("y" * 1100000), silent: false}' >> "$store"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-8 --verdict routine --summary 'after the oversized row' >/dev/null || fail "append failed after an oversized row"
  [ "$(jq -r .seq "$tail")" = 8 ] || fail "a row larger than the budget did not leave the display tail to the rows after it"
  pass "the display tail keeps only whole newest rows within its 1 MiB budget, never shortening one"
}

test_outcome_seed_tail_creates_only_an_absent_display_tail() {
  local home store tail out
  home="$TMP_ROOT/tail-seed-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  tail="$home/state/.branch-outcomes-tail.jsonl"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail || fail "seed-tail failed on an empty home"
  [ ! -e "$tail" ] || fail "seed-tail created a display tail without a store"

  jq -nc 'range(1; 206) | {seq: ., epoch: 100, task: "task-\(.)", wake: "", verdict: (if . == 204 then "captain" else "routine" end), summary: "row \(.)", silent: false}' \
    > "$store"
  printf '205\n' > "$home/state/.branch-outcomes-cursor"
  printf '203\n' > "$home/state/.branch-outcomes-processed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" present >/dev/null || fail "present failed on a store that predates the tail"
  [ ! -e "$tail" ] || fail "present seeded the display tail; seed-tail is its one seeding owner"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail) || fail "seed-tail failed on a store that predates the tail"
  [ -z "$out" ] || fail "seed-tail printed output: $out"
  [ "$(cat "$tail")" = "$(tail -n 200 "$store")" ] || fail "seed-tail did not write the store's newest rows"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = 205 ] || fail "seeding the display tail moved the read cursor"
  [ "$(cat "$home/state/.branch-outcomes-processed")" = 203 ] || fail "seeding the display tail moved the processed marker"

  printf 'kept\n' > "$tail"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail || fail "seed-tail failed with a display tail"
  [ "$(cat "$tail")" = kept ] || fail "seed-tail rewrote an existing display tail"

  printf 'not json\n' >> "$store"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail \
    || fail "seed-tail parsed the store although a display tail already existed"
  [ "$(cat "$tail")" = kept ] || fail "seed-tail rewrote an existing display tail beside a malformed store"
  rm -f "$tail"
  if FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail 2>/dev/null; then
    fail "seed-tail accepted a malformed store"
  fi
  [ ! -e "$tail" ] || fail "seed-tail copied a malformed store"
  pass "outcome seed-tail writes an absent display tail from a valid store's newest rows without moving a marker, and leaves an existing one to append"
}

test_outcome_seed_tail_only_reads_bounded_suffix() {
  local home store tail
  home="$TMP_ROOT/tail-seed-bounded-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  tail="$home/state/.branch-outcomes-tail.jsonl"
  # The malformed old row lies well outside the 1 MiB window. Seeding must
  # neither inspect it nor copy it, while still validating the recent rows.
  python3 - "$store" <<'PY'
import json, sys
with open(sys.argv[1], 'w') as f:
    f.write('invalid old row ' + 'z' * 1100000 + '\n')
    for seq in range(2, 252):
        f.write(json.dumps(dict(seq=seq, epoch=100, task='task-1', wake='',
                                verdict='routine', summary='x' * 6000)) + '\n')
PY
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail \
    || fail "seed-tail inspected old malformed history outside the bounded window"
  python3 - "$store" "$tail" <<'PY' || fail "seed-tail did not publish the exact byte- and row-bounded suffix"
import sys
rows = open(sys.argv[1], 'rb').readlines()[-200:]
kept = []
for row in reversed(rows):
    if sum(map(len, kept)) + len(row) > 1048576:
        break
    kept.insert(0, row)
assert open(sys.argv[2], 'rb').read() == b''.join(kept)
PY
  rm -f "$tail"
  printf '{"seq":252,"epoch":100,"task":"task-1","wake":"","verdict":"routine","summary":"ok"}\n' >> "$store"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" seed-tail \
    || fail "seed-tail failed on a new valid row past malformed old history"
  [ "$(tail -n 1 "$tail" | jq -r .seq)" = 252 ] || fail "seed-tail missed the latest row"
  pass "seed-tail validates and publishes only a bounded newest window, not old malformed history"
}

test_outcome_startup_replay_preserves_silence() {
  local home replay out status store
  home="$TMP_ROOT/store-silent-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-a --verdict captain --summary 'blocked' --silent true 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append accepted a silent captain outcome"
  assert_contains "$out" "silent outcomes must have the routine verdict" "silent captain refusal lost its diagnostic"
  [ ! -e "$store" ] || fail "refused silent captain outcome changed the durable store"

  printf 'working: still building\n' > "$home/state/task-a.status"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-a --verdict routine --summary 'worker still busy, nothing new, no action taken' --silent true >/dev/null \
    || fail "silent task-scoped routine append failed"
  [ -s "$home/state/.task-a.branch-outcome-index" ] \
    || fail "silent task outcome was omitted from the status-outcome backstop index"
  assert_contains "$(cat "$home/state/.task-a.branch-outcome-index")" \
    "$(printf 'fm-branch-outcome-index-v1\t1\t')" "status-outcome backstop index lost the silent task outcome"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task fleet --verdict routine --summary 'fleet reviewed, nothing changed' --silent true >/dev/null \
    || fail "silent heartbeat append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'worker recovered automatically' >/dev/null \
    || fail "visible outcome append failed"

  replay=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" startup-replay) || fail "mixed startup replay failed"
  assert_not_contains "$replay" "fleet reviewed, nothing changed" "startup replay printed a silent heartbeat outcome"
  assert_not_contains "$replay" "worker still busy, nothing new, no action taken" "startup replay printed a silent task outcome"
  assert_contains "$replay" "worker recovered automatically" "startup replay lost a visible routine outcome"
  [ -z "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread)" ] \
    || fail "startup replay did not mark the silent and visible rows read"

  printf '%s\n' '{"seq":4,"epoch":1,"task":"task-legacy","wake":"","verdict":"routine","summary":"legacy visible outcome"}' \
    >> "$home/state/branch-outcomes.jsonl"
  replay=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" startup-replay) || fail "legacy startup replay failed"
  assert_contains "$replay" "legacy visible outcome" "startup replay hid a legacy row with no silent field"
  [ -z "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread)" ] \
    || fail "startup replay did not mark the legacy row read"

  printf '%s\n' '{"seq":5,"epoch":1,"task":"task-bad","wake":"","verdict":"captain","summary":"poisoned","silent":true}' >> "$store"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread accepted a stored silent captain outcome"
  assert_contains "$out" "malformed or non-sequential" "stored silent captain refusal lost its diagnostic"
  pass "routine task and fleet no-change outcomes stay stored and silent captain outcomes are refused"
}

test_outcome_startup_replay_stops_at_captain_barrier() {
  local home replay unread
  home="$TMP_ROOT/store-captain-barrier-home"
  mkdir -p "$home/state"

  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'leading routine' >/dev/null || fail "leading append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'captain must render in Pi' >/dev/null || fail "captain append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-3 --verdict routine --summary 'routine behind captain' >/dev/null || fail "trailing append failed"

  replay=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" startup-replay) || fail "barrier replay failed"
  assert_contains "$replay" "leading routine" "startup replay lost the leading routine row"
  assert_not_contains "$replay" "captain must render in Pi" "startup replay rendered the captain row"
  assert_not_contains "$replay" "routine behind captain" "startup replay crossed the captain barrier"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = 1 ] || fail "cursor crossed the captain barrier"
  unread=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread) || fail "barrier unread failed"
  assert_contains "$unread" '"seq":2' "captain row did not remain unread"
  assert_contains "$unread" '"seq":3' "row behind captain did not remain unread"
  pass "startup replay cannot advance the cursor across an unrendered captain outcome"
}

test_outcome_cursor_corruption_fails_closed() {
  local home store snapshot out status
  home="$TMP_ROOT/store-corrupt-cursor-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"

  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict captain --summary 'captain outcome must remain unread' >/dev/null \
    || fail "captain outcome append failed"
  snapshot=$(cat "$store")
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 01 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-read accepted a noncanonical sequence"
  [ ! -e "$home/state/.branch-outcomes-cursor" ] || fail "noncanonical mark-read created a malformed cursor"

  printf '1x2\n' > "$home/state/.branch-outcomes-cursor"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread accepted a malformed cursor and skipped an outcome"
  assert_contains "$out" "outcome cursor is malformed" "malformed cursor refusal lost its diagnostic"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = 1x2 ] || fail "failed unread rewrote the malformed cursor"
  [ "$(cat "$store")" = "$snapshot" ] || fail "failed unread changed the append-only outcome store"

  printf '999999999999999999999999999999999\n' > "$home/state/.branch-outcomes-cursor"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread accepted an out-of-range cursor"
  assert_contains "$out" "outcome cursor is out of range" "out-of-range cursor refusal lost its diagnostic"

  printf '2\n' > "$home/state/.branch-outcomes-cursor"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread accepted a cursor beyond the outcome-store tail"
  assert_contains "$out" "cursor is ahead of the store" "ahead-of-store refusal lost its diagnostic"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 1 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-read accepted an existing cursor beyond the store"
  assert_contains "$out" "cursor is ahead of the store" "mark-read ahead-cursor refusal lost its diagnostic"
  [ "$(cat "$home/state/.branch-outcomes-cursor")" = 2 ] || fail "refused mark-read changed the ahead cursor"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'must not remain hidden behind the cursor' 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append accepted a cursor beyond the outcome-store tail"
  assert_contains "$out" "cursor is invalid or ahead of the store" "append cursor refusal lost its diagnostic"
  [ "$(cat "$store")" = "$snapshot" ] || fail "failed append changed the store behind an invalid cursor"
  pass "malformed and ahead-of-store cursor state fail closed before any outcome can be skipped"
}

test_cursor_advancement_refuses_ahead_processed_marker() {
  local home cursor marker out status
  home="$TMP_ROOT/store-ahead-processed-home"
  mkdir -p "$home/state"
  cursor="$home/state/.branch-outcomes-cursor"
  marker="$home/state/.branch-outcomes-processed"

  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'already read' >/dev/null || fail "first routine append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict routine --summary 'replayable second' >/dev/null || fail "second routine append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-3 --verdict routine --summary 'replayable third' >/dev/null || fail "third routine append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 1 || fail "fixture mark-read failed"
  printf '3\n' > "$marker"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 3 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-read legitimized an ahead processed marker"
  assert_contains "$out" "processed marker is ahead of the read cursor" "mark-read ahead-marker refusal lost its diagnostic"
  [ "$(cat "$cursor")" = 1 ] || fail "refused mark-read advanced the cursor"
  [ "$(cat "$marker")" = 3 ] || fail "refused mark-read changed the processed marker"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" startup-replay 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "startup replay legitimized an ahead processed marker"
  assert_contains "$out" "processed marker is ahead of the read cursor" "startup replay ahead-marker refusal lost its diagnostic"
  [ "$(cat "$cursor")" = 1 ] || fail "refused startup replay advanced the cursor"
  [ "$(cat "$marker")" = 3 ] || fail "refused startup replay changed the processed marker"
  pass "cursor advancement refuses to legitimize an ahead processed marker"
}

test_outcome_sequence_conflicts_fail_closed() {
  local home store snapshot out status
  home="$TMP_ROOT/store-sequence-conflict-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  printf '%s\n' \
    '{"seq":1,"epoch":1,"task":"task-1","wake":"","verdict":"routine","summary":"first","silent":false}' \
    '{"seq":1,"epoch":2,"task":"task-conflict","wake":"","verdict":"captain","summary":"conflict","silent":false}' \
    '{"seq":3,"epoch":3,"task":"task-3","wake":"","verdict":"routine","summary":"third","silent":false}' \
    > "$store"
  snapshot=$(cat "$store")

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread skipped over a conflicting middle sequence"
  assert_contains "$out" "malformed or non-sequential" "sequence-conflict read refusal lost its diagnostic"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-4 --verdict routine --summary 'must remain unrecorded' 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append continued after a conflicting middle sequence"
  assert_contains "$out" "malformed or non-sequential" "sequence-conflict append refusal lost its diagnostic"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" list --recent 2 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "list exposed rows from a conflicting outcome store"
  assert_contains "$out" "malformed or non-sequential" "sequence-conflict list refusal lost its diagnostic"
  [ "$(cat "$store")" = "$snapshot" ] || fail "sequence-conflict refusal changed the durable store"
  pass "middle sequence conflicts fail closed for every store read and append"
}

test_outcome_lookup_returns_exact_sequences_and_refuses_missing_rows() {
  local home out status selected
  home="$TMP_ROOT/store-exact-lookup-home"
  mkdir -p "$home/state"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary first >/dev/null || fail "lookup fixture append 1 failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict routine --summary second --silent true >/dev/null || fail "lookup fixture append 2 failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-3 --verdict captain --summary third >/dev/null || fail "lookup fixture append 3 failed"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" lookup --seqs 3,1) \
    || fail "lookup refused existing sequences 3 and 1"
  selected=$(printf '%s\n' "$out" | jq -sr '[.[].seq] | join(",")')
  [ "$selected" = "3,1" ] || fail "lookup changed requested sequence order: $selected"
  assert_contains "$out" '"task":"task-1"' "lookup omitted the first requested row"
  assert_contains "$out" '"task":"task-3"' "lookup omitted the second requested row"

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" lookup --seqs 1,4 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "lookup accepted a missing sequence"
  assert_contains "$out" "requested outcome sequences are missing" "missing-row lookup lost its diagnostic"
  pass "outcome lookup returns exact sequence rows and distinguishes missing receipts"
}

test_outcome_non_jsonl_layout_fails_closed() {
  local home store snapshot out status
  home="$TMP_ROOT/store-physical-layout-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  printf '%s\n' \
    '{' \
    '  "seq": 1, "epoch": 1, "task": "task-1", "wake": "",' \
    '  "verdict": "routine", "summary": "pretty printed", "silent": false' \
    '}' > "$store"
  snapshot=$(cat "$store")

  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" list 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "list accepted a multi-line outcome record"
  assert_contains "$out" "malformed or non-sequential" "multi-line record refusal lost its diagnostic"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict routine --summary 'must remain unrecorded' 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append extended a store containing a multi-line record"
  [ "$(cat "$store")" = "$snapshot" ] || fail "multi-line layout refusal changed the durable store"

  printf '%s\n' \
    '{"seq":1,"epoch":1,"task":"task-1","wake":"","verdict":"routine","summary":"first","silent":false}' \
    '' \
    '{"seq":2,"epoch":2,"task":"task-2","wake":"","verdict":"captain","summary":"second","silent":false}' \
    > "$store"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unread 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unread accepted a blank physical record"
  assert_contains "$out" "malformed or non-sequential" "blank-record refusal lost its diagnostic"

  printf '%s' '{"seq":1,"epoch":1,"task":"task-1","wake":"","verdict":"routine","summary":"unterminated","silent":false}' > "$store"
  snapshot=$(cat "$store")
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'must remain unrecorded' 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "append accepted an unterminated outcome store"
  assert_contains "$out" "malformed or non-sequential" "unterminated-store refusal lost its diagnostic"
  [ "$(cat "$store")" = "$snapshot" ] || fail "failed append changed the unterminated store"
  pass "outcome stores require terminated single-line JSON records"
}

# A supervision-host drain presents off Pi: every unread row and every
# unprocessed captain row, moving nothing, so the drain marks them read only
# once it has shown them; a routine row is presented once and a captain row
# until it is acknowledged.
test_outcome_present_reads_without_advancing() {
  local home out
  home="$TMP_ROOT/store-present-home"
  mkdir -p "$home/state"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'routine first' >/dev/null || fail "routine append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'captain second' >/dev/null || fail "captain append failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" present) || fail "present failed"
  [ "$(printf '%s\n' "$out" | jq -r '"\(.seq):\(.unread)"' | tr '\n' ' ')" = "1:true 2:true " ] \
    || fail "present did not print both unread rows: $out"
  assert_absent "$home/state/.branch-outcomes-cursor" "present must not move the read cursor"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 2 || fail "the presented rows could not be marked read"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" present) || fail "second present failed"
  [ "$(printf '%s\n' "$out" | jq -r '"\(.seq):\(.unread)"' | tr '\n' ' ')" = "2:false " ] \
    || fail "a second present must repeat only the unprocessed captain row: $out"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-processed --through 2 || fail "the presented captain row could not be acknowledged"
  [ -z "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" present)" ] || fail "an acknowledged store still presented rows"
  pass "outcome store: present shows each routine row once and each captain row until it is acknowledged"
}

# Both presenters name how long ago each captain row was recorded, in the one
# wording the store owns: minutes under an hour, hours under two days, then
# days, with a clock that moved backwards reading as just recorded. It is
# computed at read time and never written into the store, and routine rows
# carry no age.
test_outcome_rows_carry_their_recorded_age() {
  local home store now snapshot out
  home="$TMP_ROOT/store-age-home"
  mkdir -p "$home/state"
  store="$home/state/branch-outcomes.jsonl"
  now=$(date +%s)
  local epoch seq=0
  for epoch in $((now + 600)) $((now - 125)) $((now - 90 * 60)) $((now - 47 * 3600)) $((now - 49 * 3600)) $((now - 6 * 86400 - 60)); do
    seq=$((seq + 1))
    printf '{"seq":%s,"epoch":%s,"task":"task-%s","wake":"","verdict":"captain","summary":"row %s","silent":false}\n' \
      "$seq" "$epoch" "$seq" "$seq" >> "$store"
  done
  printf '{"seq":7,"epoch":%s,"task":"task-7","wake":"","verdict":"routine","summary":"row 7","silent":false}\n' \
    "$((now - 86400))" >> "$store"
  snapshot=$(cat "$store")
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" present) || fail "present failed"
  [ "$(printf '%s\n' "$out" | jq -r '.recordedAgo // "none"' | tr '\n' ' ')" = "0m 2m 1h 47h 2d 6d none " ] \
    || fail "present did not name each captain row's recorded age, and only theirs: $out"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 7 || fail "mark-read failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed) || fail "unprocessed failed"
  [ "$(printf '%s\n' "$out" | jq -r '"\(.seq):\(.recordedAgo)"' | tr '\n' ' ')" = "1:0m 2:2m 3:1h 4:47h 5:2d 6:6d " ] \
    || fail "unprocessed did not name each row's recorded age: $out"
  [ "$(cat "$store")" = "$snapshot" ] || fail "reading the age changed the store"
  pass "outcome store: present and unprocessed name each captain row's recorded age without writing it"
}

test_outcome_processed_marker_is_sequence_bound() {
  local home marker out status
  home="$TMP_ROOT/store-processed-home"
  mkdir -p "$home/state"
  marker="$home/state/.branch-outcomes-processed"

  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-1 --verdict routine --summary 'routine first' >/dev/null || fail "routine append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-2 --verdict captain --summary 'captain second' >/dev/null || fail "captain append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-3 --verdict captain --summary 'captain third' >/dev/null || fail "second captain append failed"

  # Nothing is unprocessed until it has been read (its visible entry exists).
  [ -z "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed)" ] \
    || fail "an unread captain row was reported as unprocessed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 2 || fail "mark-read failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed) || fail "unprocessed failed"
  case "$out" in
    '{"seq":2,'*) ;;
    *) fail "unprocessed did not return exactly the read captain rows: $out" ;;
  esac
  assert_not_contains "$out" '"seq":1' "a routine row entered the processing path"

  # The marker advances only to a read, currently unprocessed captain row.
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-processed --through 3 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-processed advanced past the read cursor"
  assert_contains "$out" "beyond the read cursor" "past-cursor refusal lost its diagnostic"
  [ ! -e "$marker" ] || fail "a refused acknowledgement created the processed marker"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-processed --through 1 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-processed accepted a routine sequence"
  assert_contains "$out" "not an unprocessed captain outcome" "routine-sequence refusal lost its diagnostic"
  [ ! -e "$marker" ] || fail "a routine-sequence acknowledgement created the processed marker"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-processed --through 2 || fail "mark-processed failed"
  [ "$(cat "$marker")" = 2 ] || fail "processed marker was not written"
  [ -z "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed)" ] \
    || fail "an acknowledged row stayed unprocessed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-processed --through 1 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "mark-processed accepted an already-processed sequence"
  assert_contains "$out" "already processed" "already-processed refusal lost its diagnostic"
  [ "$(cat "$marker")" = 2 ] || fail "refused backwards acknowledgement moved the processed marker"

  # Reading the next captain row reopens exactly that row for processing.
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 3 || fail "second mark-read failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed) || fail "second unprocessed failed"
  case "$out" in
    '{"seq":3,'*) ;;
    *) fail "the newly read captain row was not the only unprocessed row: $out" ;;
  esac

  # processed-init leaves a present marker alone and fails closed on a
  # malformed one instead of skipping an outcome.
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" processed-init || fail "processed-init failed on a present marker"
  [ "$(cat "$marker")" = 2 ] || fail "processed-init rewrote a present marker"
  printf '2x\n' > "$marker"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unprocessed accepted a malformed processed marker"
  assert_contains "$out" "processed marker is malformed" "malformed marker refusal lost its diagnostic"
  printf '5\n' > "$marker"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unprocessed accepted a marker ahead of the read cursor"
  assert_contains "$out" "ahead of the read cursor" "ahead-of-cursor refusal lost its diagnostic"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" processed-init 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "processed-init accepted a marker ahead of the read cursor"
  assert_contains "$out" "ahead of the read cursor" "processed-init ahead-marker refusal lost its diagnostic"
  [ "$(cat "$marker")" = 5 ] || fail "refused processed-init rewrote the ahead marker"
  printf '999999999999999999999999999999999\n' > "$marker"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "unprocessed accepted an out-of-range processed marker"
  assert_contains "$out" "processed marker is out of range" "out-of-range marker refusal lost its diagnostic"
  [ "$(cat "$marker")" = 999999999999999999999999999999999 ] \
    || fail "out-of-range marker refusal changed the marker"

  # A home with delivered history and no marker cannot tell a read row from
  # an acknowledged one, so processed-init never adopts the read cursor: the
  # absent marker keeps reading as zero, the safe direction.
  home="$TMP_ROOT/store-processed-migration-home"
  mkdir -p "$home/state"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" append \
    --task task-old --verdict captain --summary 'delivered before the marker existed' >/dev/null || fail "migration append failed"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" mark-read --through 1 || fail "migration mark-read failed"
  assert_contains "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed)" '"seq":1' \
    "an absent marker hid a delivered captain row instead of reading as zero"
  FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" processed-init || fail "migration processed-init failed"
  [ ! -e "$home/state/.branch-outcomes-processed" ] || fail "processed-init created the marker from the read cursor"
  assert_contains "$(FM_HOME="$home" "$ROOT/bin/fm-branch-outcome.sh" unprocessed)" '"seq":1' \
    "processed-init adopted a delivered but unacknowledged captain row as processed"
  pass "the processed marker is sequence-bound, never ahead of the read cursor, never backwards, and never adopts delivered history"
}

# --- lease contract -----------------------------------------------------------

test_lease_exclusivity_release_stale_and_sweep() {
  local home out status
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/lease-home"
  mkdir -p "$home/state"
  printf '%s\n' "$$" > "$home/state/.lock"

  # Claim, exclusivity, same-actor refresh.
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-1 --actor branch \
    || fail "branch claim failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-1) || fail "check missed a held lease"
  case "$out" in
    "branch $$ "*" live") ;;
    *) fail "check misreported the lease: $out" ;;
  esac
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=main FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "cross-actor claim exited $status, not the lease refusal 6"
  assert_contains "$out" "leased to the branch supervision actor" "refusal did not name the holder"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-1 \
    || fail "same-actor refresh was refused"

  # Release by the calling holder; release of an unheld lease stays a silent no-op.
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release task-1 --actor branch || fail "release failed"
  FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-1 >/dev/null && fail "released lease still reported"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release task-1 --actor branch || fail "idempotent release failed"

  # A lease held by a dead process is stale: claimable by the other actor and
  # removed by the sweep, while a live lease survives the sweep.
  printf 'branch\t999999\t123\n' > "$home/state/.lease-task-dead"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=main FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-dead \
    || fail "stale lease blocked a live claim"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-dead)
  case "$out" in "main $$ "*) ;; *) fail "stale lease was not taken over: $out" ;; esac
  printf 'branch\t999999\t123\n' > "$home/state/.lease-task-dead2"
  FM_HOME="$home" "$ROOT/bin/fm-lease.sh" sweep || fail "sweep failed"
  [ ! -e "$home/state/.lease-task-dead2" ] || fail "sweep left a provably stale lease"
  [ -e "$home/state/.lease-task-dead" ] || fail "sweep removed a live lease"

  # The reserved backlog resource claims like any task.
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim backlog --actor branch \
    || fail "backlog lease claim failed"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=main FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim backlog 2>&1)
  [ $? -eq 6 ] || fail "backlog lease did not enforce exclusivity"
  pass "lease exclusivity, same-actor refresh, release, staleness, and sweep hold"
}

# --- guards in the mutating entrypoints ---------------------------------------

test_mutating_scripts_refuse_the_other_actors_lease() {
  local home root out status
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/guard-home"
  root="$TMP_ROOT/guard-root"
  mkdir -p "$home/state" "$root"
  printf '%s\n' "$$" > "$home/state/.lock"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  ln -s "$ROOT/bin" "$root/bin"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-held --actor branch \
    || fail "fixture lease claim failed"

  # fm-control: refused while the branch holds the lease; the ordinary no-task
  # error (a different failure) proves pass-through once the lease is gone.
  out=$(FM_HOME="$home" "$ROOT/bin/fm-control.sh" task-held interrupt 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "leased fm-control exited $status, not 6: $out"
  assert_contains "$out" "leased to the branch supervision actor" "fm-control refusal lost the holder"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-control.sh" task-unheld interrupt 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "unleased fm-control still hit the lease refusal"
  assert_contains "$out" "no task 'task-unheld'" "unleased fm-control lost its ordinary error"

  # fm-teardown: same refusal shape before any teardown work.
  out=$(FM_HOME="$home" "$ROOT/bin/fm-teardown.sh" task-held 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "leased fm-teardown exited $status, not 6: $out"
  assert_contains "$out" "teardown (fm-teardown) refused" "fm-teardown refusal lost its action label"

  # The same lease refuses the BRANCH actor when MAIN holds it - the guard is
  # symmetric, not a branch-only fence.
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release task-held --actor branch
  FM_HOME="$home" FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-held --actor main \
    || fail "main fixture claim failed"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-control.sh" task-held interrupt 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch actor bypassed main's lease: $status: $out"
  assert_contains "$out" "leased to the main supervision actor" "symmetric refusal lost the holder"
  pass "fm-control and fm-teardown refuse the other actor's live lease and pass through otherwise"
}

test_main_owned_actions_refuse_the_branch_actor() {
  local home root out status
  home="$TMP_ROOT/partition-home"
  root="$TMP_ROOT/partition-root"
  mkdir -p "$home/state" "$root"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  ln -s "$ROOT/bin" "$root/bin"

  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch fm-pr-merge exited $status, not 6: $out"
  assert_contains "$out" "the supervision branch never performs this action" "pr-merge refusal lost the partition wording"

  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-merge-local.sh" task-x 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch fm-merge-local exited $status, not 6: $out"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch fm-spawn exited $status, not 6: $out"
  assert_contains "$out" "new-task spawn (fm-spawn) refused" "spawn refusal lost its action label"

  # The same calls as MAIN fail on their ORDINARY validation instead - the
  # partition guard never fires for the main actor.
  out=$(FM_HOME="$home" "$ROOT/bin/fm-merge-local.sh" task-x 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "main fm-merge-local hit the partition refusal"
  assert_contains "$out" "no meta for task task-x" "main fm-merge-local lost its ordinary error"
  pass "PR merge, local landing, and new-task spawn refuse the branch actor and spare main"
}

test_home_without_branch_is_untouched() {
  local home out status
  home="$TMP_ROOT/untouched-home"
  mkdir -p "$home/state"

  # No lease files, no actor variable: the guard layer must be invisible - the
  # scripts fail (or succeed) exactly on their pre-existing logic, and nothing
  # branch-related appears in state/.
  out=$(FM_HOME="$home" "$ROOT/bin/fm-control.sh" task-any interrupt 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "no-branch home hit a lease refusal in fm-control"
  assert_contains "$out" "no task 'task-any'" "no-branch fm-control lost its ordinary error"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-pr-merge.sh" 2>&1)
  status=$?
  [ "$status" -eq 2 ] || fail "no-branch fm-pr-merge usage error changed: $status: $out"
  [ -z "$(find "$home/state" -name '.lease-*' -o -name 'branch-outcomes*' -o -name '.branch-*' 2>/dev/null)" ] \
    || fail "guard layer created branch state in a home that never ran the branch"

  # An unmarked caller with no lease file for the task takes no lock at all on
  # a home that does not run the supervision host (a Codex primary without
  # config/supervision-host), so the guard leaves a home that never ran a
  # branch byte-for-byte unchanged.
  # The positional parameter belongs to the nested shell.
  # shellcheck disable=SC2016
  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR FM_TEST_HARNESS=codex STATE="$home/state" bash -c '
    . "$1"
    fm_lease_guard task-none "probe"
    if [ -e "$STATE/.fm-lease-command.lock" ]; then echo lock-taken; else echo no-lock; fi
  ' _ "$ROOT/bin/fm-lease-lib.sh" 2>&1)
  [ "$out" = no-lock ] || fail "an unmarked guard with no lease file engaged the lease-command lock: $out"

  # A stale Pi marker and a leftover lease cannot bind a no-lock Claude home;
  # the guard removes the leftover and passes silently.
  printf 'harness=claude\n' > "$home/state/fake.meta"
  printf '%s\n' "$PPID" > "$home/state/.pi-branch-extension-loaded"
  printf 'branch\t%s\t123\n' "$PPID" > "$home/state/.lease-task-reused"
  out=$(STATE="$home/state" bash -c '. "$1"; fm_lease_guard task-reused "probe"; fm_lease_forbid_branch "probe"; echo silent-pass' _ "$ROOT/bin/fm-lease-lib.sh" 2>&1)
  [ "$out" = "silent-pass" ] || fail "guard helpers honored a leftover Pi lease in a no-lock Claude home: $out"
  [ ! -e "$home/state/.lease-task-reused" ] || fail "guard kept a leftover Pi lease without a session lock"

  # A leftover lease whose pid is alive but is not the current lock holder - a
  # session that exited while its pid lives on - is stale for a Claude main.
  printf '%s\n' "$$" > "$home/state/.lock"
  printf 'branch\t%s\t123\n' "$PPID" > "$home/state/.lease-task-reused"
  # The positional parameter belongs to the nested shell.
  # shellcheck disable=SC2016
  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 STATE="$home/state" bash -c '. "$1"; fm_lease_guard task-reused "probe"; echo silent-pass' _ "$ROOT/bin/fm-lease-lib.sh" 2>&1)
  [ "$out" = "silent-pass" ] || fail "guard helpers honored a lease whose pid no longer holds the lock: $out"
  [ ! -e "$home/state/.lease-task-reused" ] || fail "Claude context kept a lease whose pid is not the current lock holder"
  pass "a home without a live branch lease takes no lock and clears leftover leases in any calling context"
}

# --- the partition across two processes, off Pi -------------------------------

# A branch that runs as its own process beside an unmarked main (no Pi marker,
# no actor variable - how every non-Pi primary's own shell looks) must bind that
# main exactly as it binds a Pi main: liveness is the lease record alone.
test_unmarked_main_honors_a_live_branch_lease() {
  local home fakebin out status lease_before
  home="$TMP_ROOT/unmarked-main-home"
  fakebin="$TMP_ROOT/unmarked-main-bin"
  mkdir -p "$home/state" "$fakebin"
  printf '%s\n' "$$" > "$home/state/.lock"
  fm_write_meta "$home/state/task-held.meta" "window=fm-task-held" "backend=tmux" "harness=claude"
  # A delivery that got past the guard would reach tmux; record it instead.
  printf '#!/usr/bin/env bash\nprintf "%%s\\n" "$*" >> "%s"\nexit 1\n' "$home/tmux-calls" > "$fakebin/tmux"
  chmod +x "$fakebin/tmux"

  env -u PI_CODING_AGENT FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-held --actor branch || fail "the branch process could not claim its lease"
  lease_before=$(cat "$home/state/.lease-task-held")

  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" \
    "$ROOT/bin/fm-lease.sh" check task-held) || fail "an unmarked main could not see the branch lease"
  case "$out" in
    "branch $$ "*" live") ;;
    *) fail "an unmarked main read the live branch lease as: $out" ;;
  esac

  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-held 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an unmarked main claim over the live branch lease exited $status, not 6: $out"
  env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" \
    "$ROOT/bin/fm-lease.sh" sweep || fail "sweep from an unmarked main failed"
  [ "$(cat "$home/state/.lease-task-held")" = "$lease_before" ] \
    || fail "an unmarked main overwrote or swept the live branch lease"

  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" PATH="$fakebin:$PATH" \
    "$ROOT/bin/fm-send.sh" fm-task-held "steer while leased" 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an unmarked main steer through the live branch lease exited $status, not 6: $out"
  assert_contains "$out" "steer (fm-send) refused" "the fm-send refusal lost its action label"
  [ ! -e "$home/tmux-calls" ] || fail "the refused steer still reached the endpoint: $(cat "$home/tmux-calls")"
  [ -z "$(find "$home/state" -path '*.inbox*' -name '*.msg' 2>/dev/null)" ] \
    || fail "the refused steer still wrote an inbox record"

  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" PATH="$fakebin:$PATH" \
    "$ROOT/bin/fm-control.sh" task-held interrupt 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an unmarked main fm-control exited $status, not 6: $out"
  assert_contains "$out" "leased to the branch supervision actor" "the fm-control refusal lost the holder"
  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" PATH="$fakebin:$PATH" \
    "$ROOT/bin/fm-teardown.sh" task-held 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an unmarked main fm-teardown exited $status, not 6: $out"
  [ -e "$home/state/task-held.meta" ] || fail "the refused teardown still removed the task record"

  # Once the branch releases, the same unmarked main proceeds.
  env -u PI_CODING_AGENT FM_HOME="$home" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-lease.sh" release task-held --actor branch || fail "branch release failed"
  env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-held || fail "an unmarked main could not claim after the branch released"

  # A new session owning the lock makes the old session's lease stale for the
  # unmarked main too, and its guard clears it.
  env -u PI_CODING_AGENT FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-old --actor branch || fail "branch claim for the old session failed"
  printf '%s\n' "$PPID" > "$home/state/.lock"
  out=$(env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" \
    "$ROOT/bin/fm-lease.sh" check task-old) || fail "check missed the old session's lease"
  case "$out" in
    *" stale") ;;
    *) fail "a lease from a session that no longer holds the lock read as: $out" ;;
  esac
  pass "an unmarked main honors a live branch lease across processes and ignores a previous session's"
}

# A lease file engages the guard's claim serialization for an unmarked caller
# too, so the branch cannot claim between that caller's check and its mutation.
test_unmarked_guard_with_a_lease_file_holds_exclusivity_through_mutation() {
  local home operation_pid claim_pid claim_status
  home="$TMP_ROOT/unmarked-guard-mutation-home"
  mkdir -p "$home/state"
  printf '%s\n' "$$" > "$home/state/.lock"
  printf 'branch\t999999\t123\n' > "$home/state/.lease-task-race"

  # The positional parameter belongs to the nested shell.
  # shellcheck disable=SC2016
  # The mutation stand-in waits for release under a bound, so a failed
  # assertion below cannot leave it holding the suite open.
  env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 STATE="$home/state" \
    FM_TEST_READY="$home/operation-ready" FM_TEST_RELEASE="$home/operation-release" bash -c '
      . "$1"
      fm_lease_guard task-race "probe"
      trap "fm_lease_guard_release" EXIT
      : > "$FM_TEST_READY"
      i=0
      while [ ! -e "$FM_TEST_RELEASE" ] && [ "$i" -lt 1500 ]; do sleep 0.01; i=$((i + 1)); done
    ' _ "$ROOT/bin/fm-lease-lib.sh" >/dev/null 2>&1 &
  operation_pid=$!
  while [ ! -e "$home/operation-ready" ]; do sleep 0.01; done
  [ ! -e "$home/state/.lease-task-race" ] || fail "the unmarked guard kept the dead session's lease"

  env -u PI_CODING_AGENT FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-race --actor branch >/dev/null 2>&1 &
  claim_pid=$!
  sleep 0.2
  kill -0 "$claim_pid" 2>/dev/null \
    || fail "the branch claimed while the unmarked guarded mutation was still running"
  [ ! -e "$home/state/.lease-task-race" ] \
    || fail "the concurrent claim published a lease before the unmarked guarded mutation ended"

  : > "$home/operation-release"
  wait "$operation_pid" || fail "unmarked guarded mutation fixture failed"
  wait "$claim_pid"; claim_status=$?
  [ "$claim_status" -eq 0 ] || fail "claim did not proceed after the unmarked guarded mutation ended: $claim_status"
  pass "a lease file makes an unmarked guard exclude a concurrent claim for the complete mutation"
}

# A home that runs the supervision host has a branch actor that can claim a
# task no one has leased yet, so its unmarked main must exclude that first
# claim for the whole guarded mutation, while a home that does not run it
# keeps taking no lock at all. A Claude home runs it by default and an off
# file opts out; another primary needs the file (bin/fm-supervision-engine-lib.sh
# owns the gate, and FM_TEST_HARNESS pins the primary it judges).
test_host_home_unmarked_guard_excludes_the_first_claim() {
  local home operation_pid claim_pid claim_status out harness line
  home="$TMP_ROOT/host-first-claim-home"
  mkdir -p "$home/state" "$home/config"
  printf '%s\n' "$$" > "$home/state/.lock"

  # Where the home does not run the host the unmarked guard stays lock-free
  # for an unleased task. The positional parameter belongs to the nested shell.
  probe_lock() {  # <harness>
    # shellcheck disable=SC2016
    env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_TEST_HARNESS="$1" FM_HOME="$home" STATE="$home/state" bash -c '
      . "$1"
      fm_lease_guard task-first "probe"
      if [ -e "$STATE/.fm-lease-command.lock" ]; then echo lock-taken; else echo no-lock; fi
      fm_lease_guard_release
    ' _ "$ROOT/bin/fm-lease-lib.sh" 2>&1
  }
  for line in - off; do
    rm -f "$home/config/supervision-host" "$home/config/supervision-host-off"
    [ "$line" = - ] || : > "$home/config/supervision-host-off"
    for harness in claude codex; do
      [ "$line:$harness" != -:claude ] || continue
      out=$(probe_lock "$harness")
      [ "$out" = no-lock ] || fail "a $harness home whose config/supervision-host is ${line/-/absent} engaged the lease-command lock: $out"
    done
  done
  rm -f "$home/config/supervision-host" "$home/config/supervision-host-off"
  out=$(probe_lock claude)
  [ "$out" = lock-taken ] || fail "a Claude home without config/supervision-host runs the host, so its unmarked guard must take the lease-command lock: $out"

  : > "$home/config/supervision-host"
  # The positional parameter belongs to the nested shell.
  # shellcheck disable=SC2016
  env -u PI_CODING_AGENT -u FM_SUPERVISION_ACTOR CLAUDECODE=1 FM_HOME="$home" STATE="$home/state" \
    FM_TEST_READY="$home/operation-ready" FM_TEST_RELEASE="$home/operation-release" bash -c '
      . "$1"
      fm_lease_guard task-first "probe"
      trap "fm_lease_guard_release" EXIT
      : > "$FM_TEST_READY"
      i=0
      while [ ! -e "$FM_TEST_RELEASE" ] && [ "$i" -lt 1500 ]; do sleep 0.01; i=$((i + 1)); done
    ' _ "$ROOT/bin/fm-lease-lib.sh" >/dev/null 2>&1 &
  operation_pid=$!
  while [ ! -e "$home/operation-ready" ]; do sleep 0.01; done
  [ ! -e "$home/state/.lease-task-first" ] || fail "the guard created a lease for an unleased task"

  env -u PI_CODING_AGENT FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-first --actor branch >/dev/null 2>&1 &
  claim_pid=$!
  sleep 0.2
  kill -0 "$claim_pid" 2>/dev/null \
    || fail "the host branch took the first claim while main's guarded mutation was still running"
  [ ! -e "$home/state/.lease-task-first" ] \
    || fail "the first claim published a lease before main's guarded mutation ended"

  : > "$home/operation-release"
  wait "$operation_pid" || fail "host-home guarded mutation fixture failed"
  wait "$claim_pid"; claim_status=$?
  [ "$claim_status" -eq 0 ] || fail "the first claim did not proceed after main's guarded mutation ended: $claim_status"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-first) || fail "the first claim left no lease"
  case "$out" in
    "branch $$ "*" live") ;;
    *) fail "the first claim recorded: $out" ;;
  esac
  pass "a host home's unmarked main excludes the host's first claim for its whole mutation, and other homes take no lock"
}

# --- session-bound staleness and the loud accidental-override guard ---------

test_lease_liveness_binds_to_the_session_lock() {
  local home out
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/lock-bound-home"
  mkdir -p "$home/state"

  # A lease recorded by a pid that is alive but is NOT the current session-lock
  # holder is stale: a Pi session exited and its pid was recycled, or a non-Pi
  # harness now owns this home. Either way the leftover lease must not bind.
  printf '%s\n' "$$" > "$home/state/.lock.other"
  printf 'branch\t%s\t123\n' "$PPID" > "$home/state/.lease-task-reused"
  printf '%s\n' "$$" > "$home/state/.lock"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-reused) || fail "check missed the leftover lease"
  case "$out" in
    *" stale") ;;
    *) fail "an alive non-lock-holder pid read as live: $out" ;;
  esac
  FM_HOME="$home" "$ROOT/bin/fm-lease.sh" sweep || fail "sweep failed"
  [ ! -e "$home/state/.lease-task-reused" ] || fail "sweep kept a lease whose pid is not the lock holder"

  # The same pid IS live while the lock names it.
  FM_HOME="$home" FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-current --actor main \
    || fail "claim under the current lock holder failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-current)
  case "$out" in
    "main $$ "*" live") ;;
    *) fail "the current lock holder's lease did not read live: $out" ;;
  esac

  printf '%sjunk\n' "$$" > "$home/state/.lock"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-current) || fail "check missed the lease under a malformed lock"
  case "$out" in
    *" stale") ;;
    *) fail "a malformed lock proved lease liveness: $out" ;;
  esac
  FM_HOME="$home" "$ROOT/bin/fm-lease.sh" sweep || fail "sweep under malformed lock failed"
  [ ! -e "$home/state/.lease-task-current" ] || fail "sweep kept a lease proven only by a malformed lock"
  pass "lease liveness requires an exact valid session-lock pid"
}

test_claim_with_a_holder_pinned_before_a_reanchor_records_the_lock_holder() {
  local home out status
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/pinned-reanchor-home"
  mkdir -p "$home/state"

  # The branch turn pinned $PPID, then a same-session re-anchor moved line 1 to
  # $$ while $PPID stayed alive: a new claim and a refresh record line 1.
  printf '%s\n' "$$" > "$home/state/.lock"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$PPID "$ROOT/bin/fm-lease.sh" claim task-1 --actor branch \
    || fail "branch claim with the pinned pre-re-anchor holder failed"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$PPID "$ROOT/bin/fm-lease.sh" claim task-1 --actor branch \
    || fail "branch refresh with the pinned pre-re-anchor holder failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-1)
  case "$out" in
    "branch $$ "*" live") ;;
    *) fail "a claim pinned before the re-anchor did not record the live lock holder: $out" ;;
  esac
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=main "$ROOT/bin/fm-lease.sh" claim task-1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "main claimed the branch's task after the re-anchor: $status: $out"

  # A dead pinned holder means another session took the lock: the claim keeps
  # the dead pid, so the lease stays stale.
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=999999 "$ROOT/bin/fm-lease.sh" claim task-2 --actor branch \
    || fail "branch claim with a dead pinned holder failed"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-2)
  case "$out" in
    "branch 999999 "*" stale") ;;
    *) fail "a dead pinned holder was replaced by the lock holder: $out" ;;
  esac
  pass "a claim pinned before a re-anchor records the live lock holder; a dead pin stays stale"
}

test_concurrent_stale_lease_claims_have_one_winner() {
  local home fakebin real_mv branch_pid main_pid branch_status main_status
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/concurrent-lease-home"
  fakebin="$TMP_ROOT/concurrent-lease-bin"
  mkdir -p "$home/state" "$fakebin"
  printf '%s\n' "$$" > "$home/state/.lock"
  printf 'branch\t999999\t123\n' > "$home/state/.lease-task-race"
  real_mv=$(command -v mv)
  cat > "$fakebin/mv" <<'SH'
#!/usr/bin/env bash
last=${!#}
if [ "$last" = "$FM_TEST_LEASE_PATH" ] && mkdir "$FM_TEST_GATE.once" 2>/dev/null; then
  : > "$FM_TEST_GATE.ready"
  while [ ! -e "$FM_TEST_GATE.release" ]; do sleep 0.01; done
fi
exec "$FM_TEST_REAL_MV" "$@"
SH
  chmod +x "$fakebin/mv"

  PATH="$fakebin:$PATH" FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    FM_TEST_REAL_MV="$real_mv" FM_TEST_LEASE_PATH="$home/state/.lease-task-race" FM_TEST_GATE="$home/state/gate" \
    "$ROOT/bin/fm-lease.sh" claim task-race --actor branch >/dev/null 2>&1 &
  branch_pid=$!
  while [ ! -e "$home/state/gate.ready" ]; do sleep 0.01; done
  PATH="$fakebin:$PATH" FM_HOME="$home" FM_SUPERVISION_ACTOR=main FM_LEASE_HOLDER_PID=$$ \
    FM_TEST_REAL_MV="$real_mv" FM_TEST_LEASE_PATH="$home/state/.lease-task-race" FM_TEST_GATE="$home/state/gate" \
    "$ROOT/bin/fm-lease.sh" claim task-race --actor main >/dev/null 2>&1 &
  main_pid=$!
  sleep 0.1
  : > "$home/state/gate.release"
  wait "$branch_pid"; branch_status=$?
  wait "$main_pid"; main_status=$?
  [ "$branch_status" -eq 0 ] || fail "first serialized lease claim failed with $branch_status"
  [ "$main_status" -eq 6 ] || fail "concurrent lease claim also succeeded or returned $main_status"
  pass "concurrent stale-lease claims serialize so exactly one actor succeeds"
}

test_guard_stale_clear_cannot_delete_a_new_claim() {
  local home fakebin real_rm guard_pid claim_pid guard_status claim_status out
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/guard-claim-race-home"
  fakebin="$TMP_ROOT/guard-claim-race-bin"
  mkdir -p "$home/state" "$fakebin"
  printf '%s\n' "$$" > "$home/state/.lock"
  printf 'main\t999999\t123\n' > "$home/state/.lease-task-race"
  real_rm=$(command -v rm)
  cat > "$fakebin/rm" <<'SH'
#!/usr/bin/env bash
last=${!#}
if [ "$last" = "$FM_TEST_STALE_PATH" ] && mkdir "$FM_TEST_GATE.once" 2>/dev/null; then
  : > "$FM_TEST_GATE.ready"
  while [ ! -e "$FM_TEST_GATE.release" ]; do sleep 0.01; done
fi
exec "$FM_TEST_REAL_RM" "$@"
SH
  chmod +x "$fakebin/rm"

  PATH="$fakebin:$PATH" STATE="$home/state" FM_TEST_REAL_RM="$real_rm" \
    FM_TEST_STALE_PATH="$home/state/.lease-task-race" FM_TEST_GATE="$home/state/gate" \
    bash -c '. "$1"; fm_lease_guard task-race "probe"' _ "$ROOT/bin/fm-lease-lib.sh" &
  guard_pid=$!
  while [ ! -e "$home/state/gate.ready" ]; do sleep 0.01; done
  PATH="$fakebin:$PATH" FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    FM_TEST_REAL_RM="$real_rm" FM_TEST_STALE_PATH="$home/state/.lease-task-race" FM_TEST_GATE="$home/state/gate" \
    "$ROOT/bin/fm-lease.sh" claim task-race --actor branch >/dev/null 2>&1 &
  claim_pid=$!
  sleep 0.1
  : > "$home/state/gate.release"
  wait "$guard_pid"; guard_status=$?
  wait "$claim_pid"; claim_status=$?
  [ "$guard_status" -eq 0 ] || fail "guard stale cleanup failed with $guard_status"
  [ "$claim_status" -eq 0 ] || fail "serialized claim failed with $claim_status"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-lease.sh" check task-race) || fail "guard deleted the newer lease claim"
  case "$out" in
    "branch $$ "*" live") ;;
    *) fail "newer claim was not preserved as live: $out" ;;
  esac
  pass "guard stale cleanup cannot race with or delete a newer lease claim"
}

test_guard_holds_exclusivity_through_mutation() {
  local home operation_pid claim_pid claim_status
  home="$TMP_ROOT/guard-mutation-home"
  mkdir -p "$home/state"
  printf '%s\n' "$$" > "$home/state/.lock"

  PI_CODING_AGENT=true STATE="$home/state" FM_TEST_READY="$home/operation-ready" \
    FM_TEST_RELEASE="$home/operation-release" bash -c '
      . "$1"
      fm_lease_guard task-race "probe"
      trap "fm_lease_guard_release" EXIT
      : > "$FM_TEST_READY"
      while [ ! -e "$FM_TEST_RELEASE" ]; do sleep 0.01; done
    ' _ "$ROOT/bin/fm-lease-lib.sh" &
  operation_pid=$!
  while [ ! -e "$home/operation-ready" ]; do sleep 0.01; done

  PI_CODING_AGENT=true FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-race --actor branch >/dev/null 2>&1 &
  claim_pid=$!
  sleep 0.2
  kill -0 "$claim_pid" 2>/dev/null \
    || fail "the other actor claimed while the guarded mutation was still running"
  [ ! -e "$home/state/.lease-task-race" ] \
    || fail "the concurrent claim published a lease before the guarded mutation ended"

  : > "$home/operation-release"
  wait "$operation_pid" || fail "guarded mutation fixture failed"
  wait "$claim_pid"; claim_status=$?
  [ "$claim_status" -eq 0 ] || fail "claim did not proceed after guarded mutation ended: $claim_status"
  pass "lease guard excludes a concurrent actor for the complete mutation"
}

test_claim_refuses_the_other_actors_name_loudly() {
  local home out status
  home="$TMP_ROOT/claim-guard-home"
  mkdir -p "$home/state"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ \
    "$ROOT/bin/fm-lease.sh" claim task-z --actor main 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "cross-actor claim exited $status, not 6: $out"
  assert_contains "$out" "cannot claim a lease as main" "accidental-override refusal lost its wording"
  [ ! -e "$home/state/.lease-task-z" ] || fail "refused claim still created a lease"
  pass "a claim naming the other actor fails loudly instead of silently impersonating it"
}

test_release_actor_drops_only_that_actors_leases() {
  local home out status
  local -x PI_CODING_AGENT=true
  home="$TMP_ROOT/release-actor-home"
  mkdir -p "$home/state"
  printf '%s\n' "$$" > "$home/state/.lock"
  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-a --actor branch \
    || fail "branch claim failed"
  FM_HOME="$home" FM_LEASE_HOLDER_PID=$$ "$ROOT/bin/fm-lease.sh" claim task-b --actor main \
    || fail "main claim failed"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release task-b --actor main 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch release of main lease exited $status, not 6: $out"
  assert_contains "$out" "cannot release a lease as main" "cross-actor release refusal lost its diagnostic"
  [ -e "$home/state/.lease-task-b" ] || fail "refused release removed main's lease"

  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release-actor --actor main 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch release-actor of main leases exited $status, not 6: $out"
  assert_contains "$out" "cannot release leases as main" "cross-actor bulk release refusal lost its diagnostic"
  [ -e "$home/state/.lease-task-b" ] || fail "refused bulk release removed main's lease"

  FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-lease.sh" release-actor --actor branch || fail "release-actor failed"
  [ ! -e "$home/state/.lease-task-a" ] || fail "release-actor kept the branch lease"
  [ -e "$home/state/.lease-task-b" ] || fail "release-actor dropped main's lease"
  pass "release commands authorize the caller and bulk release drops only that actor's leases"
}

# --- role-partition refinements ----------------------------------------------

test_branch_cannot_force_teardown_or_directly_relaunch() {
  local home root out status
  home="$TMP_ROOT/partition2-home"
  root="$TMP_ROOT/partition2-root"
  mkdir -p "$home/state" "$root"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  ln -s "$ROOT/bin" "$root/bin"

  # Forced teardown discards work; the branch never discards anything.
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-teardown.sh" task-x --force 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch forced teardown exited $status, not 6: $out"
  assert_contains "$out" "cannot discard work" "forced-teardown refusal lost its wording"
  # An ORDINARY branch teardown is not blocked by this guard (it fails later
  # on its ordinary no-task validation instead).
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-teardown.sh" task-x 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "ordinary branch teardown hit the forced-discard refusal: $out"

  # A branch relaunch is legal only through fm-control's owned transaction,
  # never by direct fm-spawn invocation.
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-x --relaunch 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "direct branch relaunch exited $status, not 6: $out"
  assert_contains "$out" "must relaunch through fm-control" "relaunch refusal lost its wording"
  pass "the branch cannot force a teardown or bypass fm-control for a relaunch"
}

# --- away posture: main parked, standing authority relocated -----------------

# The relocation is exactly bin/fm-lease-lib.sh's role-partition paragraph:
# the branch passes the main-only partition for the PR merge and a fresh spawn
# ONLY while a confirmed, live away-posture record exists; local-only landing
# is never relocated; the record's spend cap binds a fresh ordinary spawn for
# either actor; and an unconfirmed, archived, or invalid record is absence,
# restoring the attended refusal byte for byte.
test_away_record_relocates_main_owned_actions_to_the_branch() {
  local home root out status refusal
  home="$TMP_ROOT/away-home"
  root="$TMP_ROOT/away-root"
  mkdir -p "$home/state" "$root"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  ln -s "$ROOT/bin" "$root/bin"
  refusal="error: PR merge (fm-pr-merge) refused - the supervision branch never performs this action; report the outcome and leave it to main (role partition: docs/pi-supervision-branch.md)"

  # Attended: the refusal wording every caller already pins.
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "attended branch fm-pr-merge exited $status, not 6: $out"
  assert_contains "$out" "$refusal" "attended refusal lost its wording"

  # /afk is the go: the one entry call writes the record that relocates.
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 2 >/dev/null || fail "away entry failed"

  # Under the record the partition passes and the merge script reaches its
  # OWN gate (no task record here), never the partition refusal.
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "branch fm-pr-merge still hit the partition under the record: $out"
  assert_contains "$out" "main is parked" "the relocation did not announce itself"
  assert_contains "$out" "task metadata is unavailable" "the merge did not reach its own gate under the record"

  # Local-only landing is never relocated: it has no record-side gate.
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-merge-local.sh" task-x 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "branch fm-merge-local was relocated under the record (exit $status): $out"
  assert_contains "$out" "local-only landing (fm-merge-local) refused" "merge-local refusal lost its wording under the record"

  # A fresh spawn passes the partition and meets the spend cap: one ordinary
  # task record against a cap of 2, then a second ordinary record refuses.
  # An arbitrary id is not already-queued work, so the branch is refused at
  # that gate rather than proceeding to ordinary validation.
  fm_write_meta "$home/state/task-a.meta" "window=fm-task-a" "kind=ship"
  fm_write_meta "$home/state/mate-1.meta" "window=remote:mate-1" "kind=secondmate"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -ne 6 ] || fail "branch fm-spawn still hit the partition under the record: $out"
  assert_contains "$out" "main is parked" "the spawn relocation did not announce itself"
  assert_contains "$out" "queued unblocked work" "an arbitrary branch spawn was not held to queued work"
  assert_not_contains "$out" "caps concurrent workers" "one ordinary task under a cap of 2 was refused"
  fm_write_meta "$home/state/task-b.meta" "window=fm-task-b" "kind=ship"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 1 ] || fail "spend-cap refusal exited $status, not 1: $out"
  assert_contains "$out" "caps concurrent workers at 2 and 2 ordinary task(s) are live" "spend-cap refusal lost its count"
  # The cap binds main too: the posture, not the actor, is what caps spend.
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 1 ] || fail "main spawn past the cap exited $status, not 1: $out"
  assert_contains "$out" "caps concurrent workers" "main was not held to the spend cap"

  rm -f "$root/bin"
  mkdir -p "$root/bin"
  for f in "$ROOT/bin"/*; do
    ln -s "$f" "$root/bin/${f##*/}"
  done
  rm -f "$root/bin/fm-afk-contract.sh"
  cat > "$root/bin/fm-afk-contract.sh" <<WRAPPER
#!/usr/bin/env bash
set -eu
REAL="$ROOT/bin/fm-afk-contract.sh"
COUNT="$home/contract-call-count"
n=0
[ -f "\$COUNT" ] && n=\$(cat "\$COUNT")
n=\$((n + 1))
printf '%s\n' "\$n" > "\$COUNT"
if [ "\$n" -eq 2 ]; then
  "\$REAL" archive >/dev/null
fi
exec "\$REAL" "\$@"
WRAPPER
  chmod +x "$root/bin/fm-afk-contract.sh"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" "$root/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1) || true
  assert_not_contains "$out" "caps concurrent workers" "a field-read after archive refused a main spawn via the spend cap"
  assert_not_contains "$out" "no readable spend cap" "a field-read after archive killed the spawn instead of restoring attended behavior"
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 2 >/dev/null || fail "away re-entry failed"

  # Archive is absence: the attended refusal returns, byte for byte.
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" archive >/dev/null || fail "away archive failed"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an archived record still relocated the merge (exit $status): $out"
  assert_contains "$out" "$refusal" "the attended refusal changed after archive"
  assert_not_contains "$out" "main is parked" "an archived record still announced a relocation"
  out=$(FM_HOME="$home" "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  assert_not_contains "$out" "caps concurrent workers" "the spend cap outlived the record"
  # A record that no longer validates is absence too.
  printf 'version: 99\n' > "$home/state/.afk-contract"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an invalid record relocated the merge (exit $status): $out"
  assert_contains "$out" "$refusal" "the attended refusal changed under an invalid record"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  assert_not_contains "$out" "caps concurrent workers" "an invalid record refused a main spawn via the spend cap"
  assert_not_contains "$out" "no readable spend cap" "an invalid record refused a main spawn for an unreadable cap"
  # Quiet mode's record is a present captain (bin/fm-afk-contract.sh AWAY OR
  # QUIET), so it relocates nothing: main keeps its standing authority.
  rm -f "$home/state/.afk-contract"
  FM_HOME="$home" FM_AFK_MODE=quiet "$ROOT/bin/fm-afk-contract.sh" enter --words 'keep routine wakes off my main' >/dev/null \
    || fail "quiet entry failed"
  out=$(FM_HOME="$home" FM_SUPERVISION_ACTOR=branch "$ROOT/bin/fm-pr-merge.sh" task-x https://github.com/o/r/pull/1 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "quiet mode's record relocated the merge to the branch (exit $status): $out"
  assert_contains "$out" "$refusal" "the attended refusal changed under quiet mode's record"
  assert_not_contains "$out" "main is parked" "quiet mode's record announced a relocation"
  pass "the away-posture record relocates the PR merge and a spawn under the spend cap to the branch, never local landing, and only while confirmed, valid, and away"
}

test_away_branch_spawn_requires_queued_dispatchable_work() {
  local home root out status
  home="$TMP_ROOT/away-queued-home"
  root="$TMP_ROOT/away-queued-root"
  mkdir -p "$home/state" "$home/data" "$home/config" "$root"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  ln -s "$ROOT/bin" "$root/bin"
  fm_test_tasks_toml "$home/.tasks.toml"
  printf 'manual\n' > "$home/config/backlog-backend"
  cat > "$home/data/backlog.md" <<'EOF'
## In flight
- [ ] task-inflight - orphaned in-flight work

## Queued
- [ ] task-queued - already queued work

## Done
EOF
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 2 >/dev/null || fail "away entry failed"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-arbitrary --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 1 ] || fail "an arbitrary branch spawn exited $status, not 1: $out"
  assert_contains "$out" "queued unblocked work" "an arbitrary id was dispatched under the record"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-queued --mode no-mistakes --yolo off 2>&1)
  status=$?
  assert_not_contains "$out" "queued unblocked work" "a queued item was refused as if it were arbitrary: $out"
  [ "$status" -ne 6 ] || fail "a queued branch spawn hit the partition: $out"
  assert_contains "$out" "main is parked" "the queued spawn lost its relocation note"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" task-inflight --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 1 ] || fail "an in-flight branch spawn exited $status, not 1: $out"
  assert_contains "$out" "queued unblocked work" "an in-flight row was dispatched by the away branch"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$ROOT/bin/fm-spawn.sh" mate-new --secondmate 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "a branch secondmate spawn exited $status, not 6: $out"
  assert_contains "$out" "the supervision branch never performs this action" "a branch secondmate spawn was not refused at the partition"

  rm -f "$root/bin"
  mkdir -p "$root/bin"
  for f in "$ROOT/bin"/*; do
    ln -s "$f" "$root/bin/${f##*/}"
  done
  rm -f "$root/bin/fm-afk-contract.sh"
  cat > "$root/bin/fm-afk-contract.sh" <<WRAPPER
#!/usr/bin/env bash
set -eu
REAL="$ROOT/bin/fm-afk-contract.sh"
COUNT="$home/contract-validate-count"
if [ "\${1:-}" = validate ]; then
  n=0
  [ -f "\$COUNT" ] && n=\$(cat "\$COUNT")
  n=\$((n + 1))
  printf '%s\n' "\$n" > "\$COUNT"
  if [ "\$n" -eq 2 ]; then
    "\$REAL" archive >/dev/null
  fi
fi
exec "\$REAL" "\$@"
WRAPPER
  chmod +x "$root/bin/fm-afk-contract.sh"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" FM_SUPERVISION_ACTOR=branch \
    "$root/bin/fm-spawn.sh" task-queued --mode no-mistakes --yolo off 2>&1)
  status=$?
  [ "$status" -eq 6 ] || fail "an archived-after-early-guard spawn exited $status, not 6: $out"
  assert_contains "$out" "the supervision branch never performs this action" \
    "archiving between the early guard and the gate did not restore the attended refusal"

  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" \
    "$ROOT/bin/fm-spawn.sh" task-arbitrary --mode no-mistakes --yolo off 2>&1)
  assert_not_contains "$out" "queued unblocked work" "main's attended spawn was held to the branch queued-work gate"
  pass "relocated branch spawn admits only already-queued dispatchable work, including on a manual-backend home"
}

# A quiet-mode record is a present captain: its spend cap never queues the
# captain's own dispatch for a return, while an away record's cap still binds.
test_quiet_record_never_caps_a_present_captains_spawn() {
  local home root out
  home="$TMP_ROOT/quiet-spend-home"
  root="$TMP_ROOT/quiet-spend-root"
  mkdir -p "$home/state" "$root/bin"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  FM_AFK_MODE=quiet FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 1 >/dev/null || fail "quiet entry failed"
  fm_write_meta "$home/state/task-a.meta" "window=fm-task-a" "kind=ship"
  fm_write_meta "$home/state/task-b.meta" "window=fm-task-b" "kind=ship"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  assert_not_contains "$out" "caps concurrent workers" "a quiet record capped a present captain's spawn"
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 1 >/dev/null 2>&1 || fail "away entry over quiet failed"
  out=$(FM_HOME="$home" FM_ROOT_OVERRIDE="$root" "$ROOT/bin/fm-spawn.sh" task-new --mode no-mistakes --yolo off 2>&1)
  assert_contains "$out" "caps concurrent workers at 1 and 2 ordinary task(s) are live" "the away record's cap no longer binds"
  pass "a quiet-mode record never caps a present captain's spawn, while the away record's cap still binds"
}

test_away_spend_cap_is_rechecked_under_the_task_set_lock() {
  local home root out i
  home="$TMP_ROOT/away-cap-lock-home"
  root="$TMP_ROOT/away-cap-lock-root"
  mkdir -p "$home/state" "$home/data" "$home/config" "$root/bin"
  git init -q -b main "$root"
  git -C "$root" commit -q --allow-empty -m init
  for f in "$ROOT/bin"/*; do
    ln -s "$f" "$root/bin/${f##*/}"
  done
  rm -f "$root/bin/fm-afk-contract.sh"
  cat > "$root/bin/fm-afk-contract.sh" <<WRAPPER
#!/usr/bin/env bash
set -eu
REAL="$ROOT/bin/fm-afk-contract.sh"
COUNT="$home/contract-field-count"
if [ "\${1:-}" = field ]; then
  n=0
  [ -f "\$COUNT" ] && n=\$(cat "\$COUNT")
  n=\$((n + 1))
  printf '%s\n' "\$n" > "\$COUNT"
  if [ "\$n" -eq 1 ]; then
    : > "$home/early-cap-passed"
    i=0
    while [ ! -f "$home/competitor-published" ]; do
      i=\$((i + 1))
      [ "\$i" -lt 200 ] || exit 1
      sleep 0.05
    done
  fi
fi
exec "\$REAL" "\$@"
WRAPPER
  chmod +x "$root/bin/fm-afk-contract.sh"
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter --spend 1 >/dev/null || fail "away entry failed"

  FM_HOME="$home" FM_ROOT_OVERRIDE="$root" \
    "$root/bin/fm-spawn.sh" task-q1 --mode no-mistakes --yolo off \
    > "$home/q1.out" 2>&1 &
  i=0
  while [ ! -f "$home/early-cap-passed" ]; do
    i=$((i + 1))
    [ "$i" -lt 200 ] || fail "spawn never reached the early spend-cap check: $(cat "$home/q1.out" 2>/dev/null || true)"
    sleep 0.05
  done
  fm_write_meta "$home/state/task-live.meta" "window=fm-task-live" "kind=ship"
  : > "$home/competitor-published"
  wait || true
  out=$(cat "$home/q1.out" 2>/dev/null || true)
  assert_contains "$out" "caps concurrent workers at 1 and 1 ordinary task(s) are live" \
    "the paused spawn did not recheck the cap after the competitor published: $out"
  [ ! -f "$home/state/task-q1.meta" ] || fail "the stale-count spawn published after a competitor landed"
  pass "the away spend cap is rechecked under the task-set lock so concurrent spawns cannot both publish"
}

test_branch_prompt_is_byte_stable_and_above_cache_floor
test_branch_prompt_home_include_is_appended_last
test_branch_prompt_routes_completed_scouts_through_guarded_cleanup
test_outcome_store_is_append_only_with_cursor_reads
test_outcome_append_keeps_a_bounded_display_tail
test_outcome_tail_keeps_whole_newest_rows_within_its_byte_budget
test_outcome_seed_tail_creates_only_an_absent_display_tail
test_outcome_seed_tail_only_reads_bounded_suffix
test_outcome_startup_replay_preserves_silence
test_outcome_startup_replay_stops_at_captain_barrier
test_outcome_cursor_corruption_fails_closed
test_cursor_advancement_refuses_ahead_processed_marker
test_outcome_sequence_conflicts_fail_closed
test_outcome_lookup_returns_exact_sequences_and_refuses_missing_rows
test_outcome_non_jsonl_layout_fails_closed
test_outcome_processed_marker_is_sequence_bound
test_outcome_present_reads_without_advancing
test_outcome_rows_carry_their_recorded_age
test_lease_exclusivity_release_stale_and_sweep
test_mutating_scripts_refuse_the_other_actors_lease
test_main_owned_actions_refuse_the_branch_actor
test_home_without_branch_is_untouched
test_unmarked_main_honors_a_live_branch_lease
test_unmarked_guard_with_a_lease_file_holds_exclusivity_through_mutation
test_host_home_unmarked_guard_excludes_the_first_claim
test_lease_liveness_binds_to_the_session_lock
test_claim_with_a_holder_pinned_before_a_reanchor_records_the_lock_holder
test_concurrent_stale_lease_claims_have_one_winner
test_guard_stale_clear_cannot_delete_a_new_claim
test_guard_holds_exclusivity_through_mutation
test_claim_refuses_the_other_actors_name_loudly
test_release_actor_drops_only_that_actors_leases
test_branch_cannot_force_teardown_or_directly_relaunch
test_away_record_relocates_main_owned_actions_to_the_branch
test_away_branch_spawn_requires_queued_dispatchable_work
test_away_spend_cap_is_rechecked_under_the_task_set_lock
test_quiet_record_never_caps_a_present_captains_spawn
