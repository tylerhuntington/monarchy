#!/usr/bin/env bash
# Tests for the tracked Pi primary watcher extension and Pi secondmate wiring.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

TMP_ROOT=$(fm_test_tmproot fm-pi-watch-extension)
EXT="$ROOT/.pi/extensions/fm-primary-pi-watch.ts"
# Node 24 warns when these test-only dynamic imports load tracked ESM plugins
# from a clean checkout with no tracked .opencode/package.json. The warning is
# unrelated to plugin output, which the assertions intentionally require empty.
export NODE_NO_WARNINGS=1

# Every case drives a plugin through node, and the plugin starts arm stubs that
# can leave background pollers behind when a case fails or is interrupted. Those
# pollers reparent to init, so removing TMP_ROOT alone never stops them: a
# poller waiting for a file under the removed root then spins forever. Each node
# run therefore gets its own process group, led by a perl wrapper whose argv
# names TMP_ROOT, and teardown signals every recorded group that still has a
# member naming TMP_ROOT before the root is removed. That membership test keeps
# a group number the kernel reused for an unrelated process out of reach.
# Every blocking stub loop also ends once its own script ("$0") is gone, so a
# poller that escapes the reap (a runner killed with SIGKILL) stops within one
# sleep of the root's later removal by fm_test_reap_orphans.
PI_PROCESS_GROUPS="$TMP_ROOT/.pi-process-groups"

node() {
  local leader
  perl -e '
    setpgrp(0, 0) or exit 125;
    shift;
    my $pid = fork() // exit 125;
    if (!$pid) { exec { $ARGV[0] } @ARGV or exit 127; }
    waitpid($pid, 0);
    exit(($? & 127) ? 128 + ($? & 127) : $? >> 8);
  ' "$TMP_ROOT/" node "$@" <&0 &
  leader=$!
  printf '%s\n' "$leader" >> "$PI_PROCESS_GROUPS"
  wait "$leader"
}

pi_owned_group_live() {  # <pgid>
  ps -eo pgid=,args= 2>/dev/null \
    | awk -v group="$1" -v root="$TMP_ROOT/" '$1 == group && index($0, root) { found = 1 } END { exit !found }'
}

pi_reap_process_groups() {
  local signal pgid i live
  [ -f "$PI_PROCESS_GROUPS" ] || return 0
  for signal in TERM KILL; do
    while IFS= read -r pgid; do
      case "$pgid" in ''|*[!0-9]*) continue ;; esac
      pi_owned_group_live "$pgid" && kill -s "$signal" -- "-$pgid" 2>/dev/null
    done < "$PI_PROCESS_GROUPS"
    i=0
    while [ "$i" -lt 20 ]; do
      live=0
      while IFS= read -r pgid; do
        case "$pgid" in ''|*[!0-9]*) continue ;; esac
        pi_owned_group_live "$pgid" && live=1 && break
      done < "$PI_PROCESS_GROUPS"
      [ "$live" -eq 1 ] || return 0
      sleep 0.1
      i=$((i + 1))
    done
  done
}

pi_teardown() {
  pi_reap_process_groups
  fm_test_cleanup
}

trap pi_teardown EXIT
trap 'pi_teardown; exit 130' INT
trap 'pi_teardown; exit 143' TERM
trap 'pi_teardown; exit 129' HUP
trap 'pi_teardown; exit 131' QUIT

# One owner for the readiness budget every unready-successor test below spends
# on purpose. Both plugins start a successor arm through a login shell and
# SIGTERM it when it stays silent past this budget, so the budget has to outlast
# a cold login-shell start. A successor killed before its first statement never
# appends its arm row and never installs the TERM trap these tests observe, so
# too small a budget reports a lost successor instead of the bounded recovery
# under test. A stock login shell already costs about 200ms on an idle
# workstation, and a loaded CI runner is slower, so keep an order of magnitude
# over that rather than a value that only holds locally. The wait loops in those
# tests are sized against this number.
ARM_READY_TIMEOUT_MS=2000

install_pi_watch_extension_fixture() {
  local repo=$1
  mkdir -p \
    "$repo/.pi/extensions/lib" \
    "$repo/node_modules/@earendil-works/pi-coding-agent" \
    "$repo/node_modules/@earendil-works/pi-tui" \
    "$repo/node_modules/typebox"
  cp "$EXT" "$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cp "$ROOT/.pi/extensions/lib/fm-branch-dispatch.ts" "$repo/.pi/extensions/lib/fm-branch-dispatch.ts"
  cp "$ROOT/.pi/extensions/lib/fm-native-contract.ts" "$repo/.pi/extensions/lib/fm-native-contract.ts"
  cp "$ROOT/.pi/extensions/lib/fm-async-exec.ts" "$repo/.pi/extensions/lib/fm-async-exec.ts"
  cp "$ROOT/.pi/extensions/lib/fm-calm-visibility.ts" "$repo/.pi/extensions/lib/fm-calm-visibility.ts"
  cp "$ROOT/.pi/extensions/lib/fm-operational-input.ts" "$repo/.pi/extensions/lib/fm-operational-input.ts"
  mkdir -p "$repo/bin"
  cp "$ROOT/bin/fm-operational-input.sh" "$repo/bin/fm-operational-input.sh"
  chmod +x "$repo/bin/fm-operational-input.sh"
  cat > "$repo/node_modules/@earendil-works/pi-coding-agent/package.json" <<'JSON'
{"name":"@earendil-works/pi-coding-agent","type":"module","exports":"./index.js"}
JSON
  cat > "$repo/node_modules/@earendil-works/pi-coding-agent/index.js" <<'JS'
export function getMarkdownTheme() { return {}; }
export class UserMessageComponent {
  render() { return []; }
  invalidate() {}
}
JS
  cat > "$repo/node_modules/@earendil-works/pi-tui/package.json" <<'JSON'
{"name":"@earendil-works/pi-tui","type":"module","exports":"./index.js"}
JSON
  cat > "$repo/node_modules/@earendil-works/pi-tui/index.js" <<'JS'
export class Box {
  addChild() {}
  clear() {}
  setBgFn() {}
}
export class Container {}
export class Text {}
JS
  cat > "$repo/node_modules/typebox/package.json" <<'JSON'
{"name":"typebox","type":"module","exports":"./index.js"}
JSON
  cat > "$repo/node_modules/typebox/index.js" <<'JS'
export const Type = {
  Object(properties) {
    return { type: "object", properties, additionalProperties: false };
  },
};
JS
}

test_pi_extension_reports_external_healthy_watcher() {
  local repo home plugin out status
  repo="$TMP_ROOT/pi-external-healthy-root"
  home="$TMP_ROOT/pi-external-healthy-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let handler = null;
let notification = "";
let prompt = "";
const pi = {
  on() {},
  registerCommand(name, options) {
    if (name === "fm-watch-arm-pi") handler = options.handler;
  },
  registerTool() {},
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
if (!handler) {
  console.error("Pi watch command was not registered");
  process.exit(1);
}
const result = await handler("", {
  ui: {
    notify(message) {
      notification = message;
    },
  },
});
if (result !== undefined) {
  console.error(`Pi command returned a value: ${String(result)}`);
  process.exit(1);
}
if (!notification.includes("started Pi extension arm child")) {
  console.error(notification);
  process.exit(1);
}
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.startsWith("\u2063FIRSTMATE_OP: v1 watcher: ")) {
  console.error(`untyped operational follow-up: ${prompt}`);
  process.exit(1);
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE")) {
  console.error(`missing follow-up prompt: ${prompt}`);
  process.exit(1);
}
if (!prompt.includes("external healthy watcher")) {
  console.error(prompt);
  process.exit(1);
}
if (!prompt.includes("watcher: healthy pid=1")) {
  console.error(prompt);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "Pi extension must surface an external healthy watcher as an owned-wake failure"
  [ -z "$out" ] || fail "Pi external-healthy test printed output: $out"
  pass "Pi extension reports external healthy watcher output"
}

test_pi_tool_returns_agent_tool_result() {
  local repo home plugin out status
  repo="$TMP_ROOT/pi-tool-result-root"
  home="$TMP_ROOT/pi-tool-result-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
exit 0
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
if (!tool) throw new Error("Pi watch tool was not registered");
if (tool.label !== "Arm firstmate watcher") throw new Error(`unexpected label: ${tool.label}`);
if (tool.parameters?.type !== "object") throw new Error("tool parameters are not a TypeBox object schema");
const metadata = [tool.description, tool.promptSnippet, ...(tool.promptGuidelines ?? [])].join("\n");
if (metadata.includes("Always use this tool")) throw new Error(`broad tool-selection metadata remained visible: ${metadata}`);
if (!tool.description.includes("first required Pi watcher cycle")) throw new Error(`tool description omitted the first-cycle condition: ${tool.description}`);
if (!tool.promptSnippet.includes("ordinary re-arming is automatic")) throw new Error(`tool snippet omitted automatic continuation: ${tool.promptSnippet}`);
if (!tool.promptGuidelines.some((guideline) => guideline.includes("ordinary signal, stale, check, or heartbeat handling"))) {
  throw new Error(`tool guidelines omitted ordinary-notification prevention: ${tool.promptGuidelines}`);
}
const result = await tool.execute("tool-call-1", {}, undefined, undefined, {});
if (!Array.isArray(result.content) || result.content[0]?.type !== "text") {
  throw new Error(`invalid tool content: ${JSON.stringify(result)}`);
}
if (!result.content[0].text.includes("started Pi extension arm child")) {
  throw new Error(`unexpected tool text: ${result.content[0].text}`);
}
if (!result.content[0].text.includes("future ordinary re-arms are automatic")) {
  throw new Error(`initial tool result omitted automatic continuation guidance: ${result.content[0].text}`);
}
if (!result.content[0].text.includes("only after a later notification says the cycle is missing, failed, or unhealthy")) {
  throw new Error(`initial tool result omitted the repair-only condition: ${result.content[0].text}`);
}
if (result.details?.ok !== true || result.details?.message !== result.content[0].text) {
  throw new Error(`invalid tool details: ${JSON.stringify(result.details)}`);
}
EOF
)
  status=$?
  expect_code 0 "$status" "Pi custom tool must expose first-cycle or repair-only metadata and return Pi's AgentToolResult shape"
  [ -z "$out" ] || fail "Pi tool-result test printed output: $out"
  pass "Pi custom tool exposes repair-only metadata and returns automatic-continuation guidance"
}

test_pi_redundant_tool_call_is_owned_noop() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-redundant-tool-root"
  home="$TMP_ROOT/pi-redundant-tool-home"
  log="$TMP_ROOT/pi-redundant-tool.log"
  stop="$TMP_ROOT/pi-redundant-tool.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
const initial = await tool.execute("tool-call-first", {}, undefined, undefined, {});
if (!initial.content[0]?.text.includes("started Pi extension arm child")) {
  throw new Error(`initial call did not start the arm child: ${initial.content[0]?.text}`);
}
const redundant = await tool.execute("tool-call-redundant", {}, undefined, undefined, {});
if (!redundant.content[0]?.text.includes("Pi extension already owns an arm child; no manual re-arm needed")) {
  throw new Error(`redundant call omitted ownership-based no-op guidance: ${redundant.content[0]?.text}`);
}
if (/^watcher: healthy\b/.test(redundant.content[0]?.text)) {
  throw new Error(`redundant call overclaimed independent health: ${redundant.content[0]?.text}`);
}
if (!redundant.content[0]?.text.includes("only after a later notification says the cycle is missing, failed, or unhealthy")) {
  throw new Error(`redundant call omitted the repair-only condition: ${redundant.content[0]?.text}`);
}
for (let i = 0; i < 100 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (!existsSync(process.env.FM_ARM_LOG)) throw new Error("initial arm child did not start");
await new Promise((resolve) => setTimeout(resolve, 100));
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (rows.length !== 1) throw new Error(`redundant call spawned ${rows.length} arm children`);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
EOF
)
  status=$?
  expect_code 0 "$status" "Pi redundant tool call must remain an ownership-based no-op with repair-only guidance"
  [ -z "$out" ] || fail "Pi redundant-call test printed output: $out"
  pass "Pi redundant tool call returns ownership guidance and spawns no second child"
}

test_pi_scheduled_retry_call_is_owned_noop() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-scheduled-retry-root"
  home="$TMP_ROOT/pi-scheduled-retry-home"
  log="$TMP_ROOT/pi-scheduled-retry.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
exit 0
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_WATCH_REARM_RETRY_BASE_MS=10000 FM_WATCH_REARM_RETRY_MAX_MS=10000 node --input-type=module 2>&1 <<'EOF'
import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-first", {}, undefined, undefined, {});
let redundant = null;
for (let i = 0; i < 100; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
  redundant = await tool.execute("tool-call-during-retry", {}, undefined, undefined, {});
  if (redundant.content[0]?.text.includes("scheduled continuity retry")) break;
}
if (!redundant?.content[0]?.text.includes("Pi extension already owns a scheduled continuity retry; no manual re-arm needed")) {
  throw new Error(`scheduled retry did not return ownership-based no-op guidance: ${redundant?.content[0]?.text}`);
}
if (/^watcher: healthy\b/.test(redundant.content[0]?.text)) {
  throw new Error(`scheduled retry call overclaimed independent health: ${redundant.content[0]?.text}`);
}
if (!redundant.content[0]?.text.includes("only after a later notification says the cycle is missing, failed, or unhealthy")) {
  throw new Error(`scheduled retry call omitted the repair-only condition: ${redundant.content[0]?.text}`);
}
await new Promise((resolve) => setTimeout(resolve, 100));
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (rows.length !== 1) throw new Error(`scheduled retry call spawned ${rows.length} arm children`);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi scheduled-retry call must not duplicate the extension-owned retry"
  [ -z "$out" ] || fail "Pi scheduled-retry test printed output: $out"
  pass "Pi scheduled retry remains extension-owned after another tool call"
}

test_pi_actionable_close_starts_single_successor_before_delivery() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-continuous-rearm-root"
  home="$TMP_ROOT/pi-continuous-rearm-home"
  log="$TMP_ROOT/pi-continuous-rearm.log"
  stop="$TMP_ROOT/pi-continuous-rearm.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let deliveryStarted = false;
let rowsAtDelivery = 0;
let releaseDelivery = () => {};
const deliveryBlocked = new Promise((resolve) => {
  releaseDelivery = resolve;
});
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {
    rowsAtDelivery = existsSync(process.env.FM_ARM_LOG)
      ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").filter((row) => row.startsWith("arm=")).length
      : 0;
    deliveryStarted = true;
    await deliveryBlocked;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-continuity", {}, undefined, undefined, {});
for (let i = 0; i < 250; i += 1) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  if (rows.length >= 2 && deliveryStarted) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
const armRows = rows.filter((row) => row.startsWith("arm="));
if (armRows.length !== 2) throw new Error(`expected one successor arm, got ${armRows.length}: ${rows.join(" | ")}`);
if (!deliveryStarted) throw new Error("wake delivery did not begin");
if (rowsAtDelivery !== 2) throw new Error(`wake delivery began before successor establishment (${rowsAtDelivery} arm rows)`);
if (!/predecessor=[0-9]+/.test(armRows[1])) throw new Error(`successor did not receive predecessor identity: ${armRows[1]}`);
if (!rows.some((row) => row.startsWith("confirmed generation=fixture-generation"))) {
  throw new Error(`handling delivery was not confirmed before the follow-up: ${rows.join(" | ")}`);
}
await new Promise((resolve) => setTimeout(resolve, 100));
const stableRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (stableRows.filter((row) => row.startsWith("arm=")).length !== 2) {
  throw new Error(`blocked follow-up started extra arm work: ${stableRows.join(" | ")}`);
}
if (stableRows.filter((row) => row.startsWith("confirmed ")).length !== 1) {
  throw new Error(`successful prompt delivery was not confirmed exactly once: ${stableRows.join(" | ")}`);
}
releaseDelivery();
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "Pi actionable close must start one successor before wake delivery settles"
  [ -z "$out" ] || fail "Pi continuous-rearm test printed output: $out"
  pass "Pi actionable close starts one successor before wake delivery settles"
}

# The arm child can publish its complete actionable line before its process
# closes while the watcher finishes durable cleanup. The still-open predecessor
# must never be mistaken for the successor merely because its readiness promise
# already settled.
test_pi_actionable_output_waits_for_predecessor_close() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-actionable-before-close-root"
  home="$TMP_ROOT/pi-actionable-before-close-home"
  log="$TMP_ROOT/pi-actionable-before-close.log"
  stop="$TMP_ROOT/pi-actionable-before-close.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'handling-confirmed\n' >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=before-close-%s\n' "$$" "$count"
if [ "$count" -eq 1 ]; then
  printf 'actionable-emitted\n' >> "$FM_ARM_LOG"
  printf 'signal: actionable output before predecessor close\n'
  sleep 0.5
  printf 'predecessor-closed\n' >> "$FM_ARM_LOG"
  exit 0
fi
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const failNow = (message) => {
  console.error(message);
  process.exit(1);
};
let tool = null;
const prompts = [];
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompts.push(message);
    writeFileSync(process.env.FM_ARM_LOG, "delivery\n", { flag: "a" });
  },
  events: { on() {}, emit() {} },
};

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("initial-arm", {}, undefined, undefined, {});
await new Promise((resolve) => setTimeout(resolve, 1200));
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
const armIndexes = rows.map((row, index) => row.startsWith("arm=") ? index : -1).filter((index) => index >= 0);
const closeIndex = rows.indexOf("predecessor-closed");
const deliveryIndex = rows.indexOf("delivery");
if (armIndexes.length !== 2) failNow(`expected a successor after the predecessor close: ${rows.join(" | ")}`);
if (closeIndex < 0 || deliveryIndex < 0) failNow(`missing close or delivery evidence: ${rows.join(" | ")}`);
if (armIndexes[1] < closeIndex) failNow(`successor started before predecessor close: ${rows.join(" | ")}`);
if (deliveryIndex < armIndexes[1]) failNow(`wake was delivered before successor startup: ${rows.join(" | ")}`);
if (prompts.length !== 1 || !prompts[0].includes("signal: actionable output before predecessor close")) {
  failNow(`wrong actionable wake: ${prompts.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "Pi actionable output must wait for predecessor close before successor restoration"
  [ -z "$out" ] || fail "Pi actionable-before-close test printed output: $out"
  pass "Pi actionable output waits for predecessor close before successor restoration"
}

# A successor can print readiness after its arm process has already exited when
# a descendant retains the stdout pipe and emits the line. Readiness alone must
# not let the original wake reach Pi while no arm child is alive: restoration
# has to start a live successor inside its existing retry bound first.
test_pi_dead_ready_successor_is_retried_before_delivery() {
  local repo home plugin log stop release holder out status
  repo="$TMP_ROOT/pi-dead-ready-successor-root"
  home="$TMP_ROOT/pi-dead-ready-successor-home"
  log="$TMP_ROOT/pi-dead-ready-successor.log"
  stop="$TMP_ROOT/pi-dead-ready-successor.stop"
  release="$TMP_ROOT/pi-dead-ready-successor.release"
  holder="$TMP_ROOT/pi-dead-ready-successor-holder.sh"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$holder" <<'SH'
#!/usr/bin/env bash
parent=$1
release=$2
while kill -0 "$parent" 2>/dev/null; do sleep 0.01; done
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=dead-ready\n' "$parent"
while [ ! -e "$release" ]; do sleep 0.02; done
SH
  chmod +x "$holder"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: wake before dead-ready successor\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  ("${FM_HOLDER:?}" "$$" "${FM_RELEASE_FILE:?}" >&1 2>/dev/null &)
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=live-successor\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_RELEASE_FILE="$release" FM_HOLDER="$holder" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
let armsAtDelivery = 0;
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").split("\n").filter((row) => row.startsWith("arm="))
  : [];
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    armsAtDelivery = armRows().length;
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("initial-dead-ready-arm", {}, undefined, undefined, {});
for (let i = 0; i < 500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
let failure = "";
if (!prompt.includes("signal: wake before dead-ready successor")) {
  failure = `original wake was not delivered: ${prompt}`;
} else if (armsAtDelivery < 3) {
  failure = `wake reached Pi with no live successor; arms at delivery=${armsAtDelivery}: ${armRows().join(" | ")}`;
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
await new Promise((resolve) => setTimeout(resolve, 100));
if (failure) throw new Error(failure);
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi restoration must retry a dead-but-ready successor before delivering the wake: $out"
  [ -z "$out" ] || fail "Pi dead-ready successor test printed output: $out"
  pass "Pi restoration retries a dead-but-ready successor before delivering the wake"
}

# A verified successor can die just after restoration accepts it while a
# descendant still holds its stdio pipes, so Node never reports close. The
# arm's exit alone must still route into the bounded retry instead of leaving
# the home unwatched until the descendant lets go.
test_pi_successor_exit_with_held_pipe_schedules_retry() {
  local repo home plugin log stop release delivered out status
  repo="$TMP_ROOT/pi-held-pipe-successor-root"
  home="$TMP_ROOT/pi-held-pipe-successor-home"
  log="$TMP_ROOT/pi-held-pipe-successor.log"
  stop="$TMP_ROOT/pi-held-pipe-successor.stop"
  release="$TMP_ROOT/pi-held-pipe-successor.release"
  delivered="$TMP_ROOT/pi-held-pipe-successor.delivered"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: wake before held-pipe successor\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  printf 'watcher: started pid=%s (beacon fresh) recovery-generation=held-pipe\n' "$$"
  (while [ ! -e "${FM_RELEASE_FILE:?}" ]; do sleep 0.02; done &)
  while [ ! -e "${FM_DELIVERED_FILE:?}" ]; do sleep 0.02; done
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=retry-successor\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_RELEASE_FILE="$release" FM_DELIVERED_FILE="$delivered" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").split("\n").filter((row) => row.startsWith("arm="))
  : [];
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
    writeFileSync(process.env.FM_DELIVERED_FILE, "delivered\n");
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("initial-held-pipe-arm", {}, undefined, undefined, {});
for (let i = 0; i < 500 && armRows().length < 3; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
let failure = "";
if (!prompt.includes("signal: wake before held-pipe successor")) {
  failure = `original wake was not delivered: ${prompt}`;
} else if (armRows().length < 3) {
  failure = `successor exit with a held pipe left no retry: ${armRows().join(" | ")}`;
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
await new Promise((resolve) => setTimeout(resolve, 100));
if (failure) throw new Error(failure);
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi successor exit with a held pipe must schedule the bounded retry: $out"
  [ -z "$out" ] || fail "Pi held-pipe successor test printed output: $out"
  pass "Pi successor exit with a held pipe schedules the bounded retry"
}

# Node can report the arm process exit before its stdout pipe drains. Delay the
# arm's own final output behind a descendant-held FIFO so the actionable line
# reaches the extension after exit; it must still become the wake, not a retry.
test_pi_actionable_line_draining_after_exit_stays_actionable() {
  local repo home plugin log fifo stop out status
  repo="$TMP_ROOT/pi-actionable-after-exit-root"
  home="$TMP_ROOT/pi-actionable-after-exit-home"
  log="$TMP_ROOT/pi-actionable-after-exit.log"
  fifo="$TMP_ROOT/pi-actionable-after-exit.fifo"
  stop="$TMP_ROOT/pi-actionable-after-exit.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  mkfifo "${FM_DELAY_FIFO:?}"
  exec 3>&1
  (
    exec 4<"$FM_DELAY_FIFO"
    sleep 0.1
    cat <&4 >&3
  ) &
  exec 3>&-
  exec >"$FM_DELAY_FIFO"
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: actionable output drained after exit\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=drained-actionable\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_DELAY_FIFO="$fifo" FM_STOP_FILE="$stop" FM_WATCH_REARM_RETRY_BASE_MS=2000 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").split("\n").filter((row) => row.startsWith("arm="))
  : [];
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("initial-delayed-drain-arm", {}, undefined, undefined, {});
for (let i = 0; i < 100 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
let failure = "";
if (!prompt.includes("signal: actionable output drained after exit")) {
  failure = `late actionable line was lost: ${prompt || "no wake delivered"}`;
} else if (armRows().length !== 2) {
  failure = `late actionable line started the wrong number of successors: ${armRows().join(" | ")}`;
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
await new Promise((resolve) => setTimeout(resolve, 100));
if (failure) throw new Error(failure);
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi actionable output draining after exit must stay actionable: $out"
  [ -z "$out" ] || fail "Pi actionable-after-exit test printed output: $out"
  pass "Pi actionable output draining after exit stays actionable"
}

test_pi_branch_offer_owns_actionable_wake() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-branch-offer-root"
  home="$TMP_ROOT/pi-branch-offer-home"
  log="$TMP_ROOT/pi-branch-offer.log"
  stop="$TMP_ROOT/pi-branch-offer.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: branch-offer synthetic wake\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

// Two independent runs against the SAME dispatcher build: with an accepting
// branch listener the wake must be owned by the branch (no main follow-up);
// with a bus but no acceptor the dispatcher must fall back to main. The
// divergence between the two runs is asserted, so the case cannot go vacuous.
async function runScenario(withAcceptor) {
  writeFileSync(process.env.FM_ARM_LOG, "");
  const offers = [];
  let mainPrompt = "";
  let tool = null;
  const handlers = new Map();
  const bus = {
    on(channel, handler) {
      handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
      return () => {};
    },
    emit(channel, data) {
      for (const handler of handlers.get(channel) ?? []) handler(data);
    },
  };
  if (withAcceptor) {
    bus.on("fm-branch-supervision:dispatch", (offer) => {
      offers.push({ message: offer.message, projects: offer.projects });
      offer.accept();
    });
  }
  const pi = {
    on() {},
    events: bus,
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async (message) => {
      mainPrompt = message;
    },
  };
  const mod = await import(`${pathToFileURL(process.env.PLUGIN).href}?scenario=${withAcceptor}`);
  mod.default(pi);
  await tool.execute("tool-call-branch-offer", {}, undefined, undefined, {});
  for (let i = 0; i < 250; i += 1) {
    const settled = withAcceptor ? offers.length > 0 : mainPrompt !== "";
    if (settled) break;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
  return { offers, mainPrompt, rows };
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/branch-offer.meta`, "project=/projects/approved\nwindow=fm-branch-offer\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\tbranch-offer.status\tsignal: branch-offer synthetic wake\n");
const accepted = await runScenario(true);
if (accepted.offers.length !== 1) throw new Error(`expected one branch offer, got ${accepted.offers.length}`);
if (!accepted.offers[0].message.includes("signal: branch-offer synthetic wake")) {
  throw new Error(`offer missed the wake reason: ${accepted.offers[0].message}`);
}
if (JSON.stringify(accepted.offers[0].projects) !== JSON.stringify(["/projects/approved"])) {
  throw new Error(`offer did not carry the queued task project: ${JSON.stringify(accepted.offers[0].projects)}`);
}
if (accepted.mainPrompt !== "") throw new Error(`accepted offer still reached main: ${accepted.mainPrompt}`);
if (!accepted.rows.some((row) => row.startsWith("confirmed generation=fixture-generation"))) {
  throw new Error(`handling delivery was not confirmed before the branch handoff: ${accepted.rows.join(" | ")}`);
}
const declined = await runScenario(false);
if (declined.offers.length !== 0) throw new Error("no-acceptor scenario recorded an offer");
if (!declined.mainPrompt.includes("FIRSTMATE WATCHER WAKE")) {
  throw new Error(`unaccepted offer did not fall back to main: ${declined.mainPrompt}`);
}
if (!declined.mainPrompt.includes("signal: branch-offer synthetic wake")) {
  throw new Error(`fallback wake lost the reason line: ${declined.mainPrompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "Pi dispatcher must hand an accepted wake to the branch and fall back to main otherwise"
  [ -z "$out" ] || fail "Pi branch-offer test printed output: $out"
  pass "Pi dispatcher branch offer owns accepted wakes and falls back to main"
}

test_pi_branch_offer_flags_heartbeat() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-branch-heartbeat-root"
  home="$TMP_ROOT/pi-branch-heartbeat-home"
  log="$TMP_ROOT/pi-branch-heartbeat.log"
  stop="$TMP_ROOT/pi-branch-heartbeat.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'heartbeat\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  # A bare heartbeat is the real wake emitted after the cheap bash scan flags
  # a fleet pass as possibly captain-relevant. It has no task-scoped queue row,
  # so branch eligibility must remain independent of project resolution.
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, projects: offer.projects, heartbeat: offer.heartbeat, eligible: offer.eligible });
  offer.accept();
});
let tool = null;
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\theartbeat\theartbeat\theartbeat\n");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-branch-heartbeat", {}, undefined, undefined, {});
for (let i = 0; i < 250 && offers.length === 0; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1) throw new Error(`expected one branch offer, got ${offers.length}`);
if (offers[0].message !== "heartbeat") {
  throw new Error(`offer changed the bare heartbeat wake reason: ${offers[0].message}`);
}
if (offers[0].heartbeat !== true || offers[0].eligible !== true) throw new Error(`heartbeat offer was not eligible: ${JSON.stringify(offers[0])}`);
if (JSON.stringify(offers[0].projects) !== JSON.stringify([])) {
  throw new Error(`heartbeat offer unexpectedly carried scoped projects: ${JSON.stringify(offers[0].projects)}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "Pi dispatcher must flag a heartbeat offer independent of task scoping"
  [ -z "$out" ] || fail "Pi branch-heartbeat test printed output: $out"
  pass "Pi dispatcher flags a fleet-wide heartbeat offer as branch-eligible"
}

test_pi_heartbeat_is_not_ridden_into_main_by_a_co_present_check() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-heartbeat-mixed-queue-root"
  home="$TMP_ROOT/pi-heartbeat-mixed-queue-home"
  log="$TMP_ROOT/pi-heartbeat-mixed-queue.log"
  stop="$TMP_ROOT/pi-heartbeat-mixed-queue.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'heartbeat\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, heartbeat: offer.heartbeat, eligible: offer.eligible });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\theartbeat\theartbeat\theartbeat\n2\t2\tcheck\tx-inbox\tcheck: pending x mention\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-heartbeat-mixed-queue", {}, undefined, undefined, {});
// The offer is what this asserts on, so wait for it and then give any
// erroneous main delivery a real chance to land before calling it absent.
for (let i = 0; i < 250 && offers.length === 0; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
for (let i = 0; i < 25 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].heartbeat !== true || offers[0].eligible !== true) {
  throw new Error(`a co-present check row made the heartbeat offer ineligible: ${JSON.stringify(offers)}`);
}
if (prompt) {
  throw new Error(`a co-present check row rode the heartbeat into main: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "a heartbeat must not ride a co-present check row into main: $out"
  [ -z "$out" ] || fail "Pi mixed heartbeat-queue test printed output: $out"
  pass "a co-present check row neither vetoes nor rides a heartbeat into main"
}

# Every check the main session alone can act on stays on main, even when an
# unrelated task-local row in the same queue is perfectly branch-eligible. The
# no-op checks the branch never sees are suppressed at their source instead
# (bin/fm-procevent-lavish.sh "silent"), so what remains under a `check:`
# trigger is exactly the main-only set, and each named class is driven here
# through the real dispatcher.
test_pi_main_only_check_classes_stay_on_main() {
  local repo home plugin log stop out status reason label
  repo="$TMP_ROOT/pi-main-only-check-root"
  home="$TMP_ROOT/pi-main-only-check-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$home/projects/approved"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  printf 'project=%s/projects/approved\nwindow=fm-window\n' "$home" > "$home/state/task-a.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf '%s\n' "${FM_TEST_REASON:?}"
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  while IFS='|' read -r label reason; do
    [ -n "$label" ] || continue
    log="$TMP_ROOT/pi-main-only-check-$label.log"
    stop="$TMP_ROOT/pi-main-only-check-$label.stop"
    out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" \
      FM_TEST_REASON="$reason" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, eligible: offer.eligible });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
// A task-local row the branch would happily take sits in the same queue, so
// only the check-kind TRIGGER itself can be what keeps this wake on main.
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\tsignal\ttask-a.status\tsignal: task-a.status\n2\t2\tcheck\tmain-only\t" + process.env.FM_TEST_REASON + "\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-main-only-check", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].eligible !== false) {
  throw new Error(`a main-only check was offered to the branch: ${JSON.stringify(offers)}`);
}
if (!prompt.includes(`FIRSTMATE WATCHER WAKE: ${process.env.FM_TEST_REASON}`)) {
  throw new Error(`a main-only check did not reach main: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
    )
    status=$?
    expect_code 0 "$status" "the $label check class must stay on main: $out"
    [ -z "$out" ] || fail "Pi main-only check test ($label) printed output: $out"
  done <<'CLASSES'
relay-mention|check: x-mention 1234567890
credential-failure|check: gh auth check failed; re-authenticate before dispatch
merge-confirmation|check: task-a.check.sh: PR merged
real-board-answer|check: procevent lavish lavish-abcdef0123456789 1
CLASSES
  pass "every main-only check class still reaches main, never the supervision branch"
}

# A surfaced captain-held signal uses the existing decision-owned payload, so a
# co-present routine row cannot take the signal close away from main.
test_pi_captain_held_signal_stays_on_main() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-captain-held-whitespace-root"
  home="$TMP_ROOT/pi-captain-held-whitespace-home"
  log="$TMP_ROOT/pi-captain-held-whitespace.log"
  stop="$TMP_ROOT/pi-captain-held-whitespace.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$home/projects/approved"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  printf 'project=%s/projects/approved\nwindow=fm-window\n' "$home" > "$home/state/task-a.meta"
  printf 'captain-held [key=route]: awaiting the captain\n \t \n' > "$home/state/task-a.status"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: task-a.status\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" \
    node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, eligible: offer.eligible });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\tsignal\ttask-a.status\tneeds-decision: task-a.status\n" +
    "1\t2\tsignal\ttask-a.status\tsignal: routine follow-up\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-captain-held-signal", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].eligible !== false) {
  throw new Error(`a captain-held signal trigger was offered to the branch: ${JSON.stringify(offers)}`);
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE: signal: task-a.status")) {
  throw new Error(`a captain-held signal trigger did not reach main: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "a captain-held signal trigger must stay on main: $out"
  [ -z "$out" ] || fail "Pi captain-held signal test printed output: $out"
  pass "a captain-held signal trigger reaches main with routine rows present"
}

# An unread second-mate pending-reply escalation keeps a later stale reminder
# under the same task's window alias on main until the decision row is read.
test_pi_unread_pending_reply_forces_later_stale_alias_to_main() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-mixed-signal-root"
  home="$TMP_ROOT/pi-mixed-signal-home"
  log="$TMP_ROOT/pi-mixed-signal.log"
  stop="$TMP_ROOT/pi-mixed-signal.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$home/projects/approved"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  printf 'project=%s/projects/approved\nwindow=fm-a\n' "$home" > "$home/state/task-a.meta"
  printf 'blocked [key=pending-reply-0123456789abcdef]: pending-reply-missed: task=task-a pending-reply-id=0123456789abcdef request=finish report\n' \
    > "$home/state/task-a.status"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'stale: fm-a (routine reminder)\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" \
    node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, eligible: offer.eligible, projects: [...offer.projects] });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\tsignal\ttask-a.status\tneeds-decision: task-a.status\n" +
    "2\t2\tstale\tfm-a\tstale: fm-a (routine reminder)\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-later-stale-alias", {}, undefined, undefined, {});
for (let i = 0; i < 250 && offers.length === 0; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].eligible !== false) {
  throw new Error(`a later stale alias bypassed its unread decision: ${JSON.stringify(offers)}`);
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE: stale: fm-a")) {
  throw new Error(`a later stale alias with an unread decision did not wake main: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "an unread pending-reply escalation must keep a later stale alias on main: $out"
  [ -z "$out" ] || fail "Pi unread pending-reply alias test printed output: $out"
  pass "an unread pending-reply escalation keeps later stale aliases on main"
}

# The captain's accepted rule names ONE coalesced trigger batch, not only a
# single status file with two rows: when a watcher poll bundles a routine
# signal for one task and a needs-decision signal for a DIFFERENT task into
# one "signal: <files>" close, the whole batch - both files - must reach main
# together, never split so the routine file goes to the branch while only the
# decision file goes to main. A `some`-vs-`every` regression on the file-list
# cross-reference would pass the same-key test above (both entries share one
# key) but must fail here, where the two files are genuinely distinct.
test_pi_distinct_files_mixed_batch_routes_whole_batch_to_main() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-distinct-mixed-batch-root"
  home="$TMP_ROOT/pi-distinct-mixed-batch-home"
  log="$TMP_ROOT/pi-distinct-mixed-batch.log"
  stop="$TMP_ROOT/pi-distinct-mixed-batch.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$home/projects/approved"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  printf 'project=%s/projects/approved\nwindow=fm-a\n' "$home" > "$home/state/task-a.meta"
  printf 'project=%s/projects/approved\nwindow=fm-b\n' "$home" > "$home/state/task-b.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: task-a.status task-b.status\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" \
    node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, eligible: offer.eligible, projects: [...offer.projects] });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\tsignal\ttask-a.status\tneeds-decision: task-a.status\n" +
    "2\t2\tsignal\ttask-b.status\tsignal: task-b.status\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-distinct-mixed-batch", {}, undefined, undefined, {});
for (let i = 0; i < 250 && offers.length === 0; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].eligible !== false) {
  throw new Error(`a distinct-file mixed batch was split, offering the routine file to the branch: ${JSON.stringify(offers)}`);
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE: signal: task-a.status task-b.status")) {
  throw new Error(`the distinct-file mixed batch did not reach main as one whole close: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "a distinct-file mixed batch must route wholly to main, not split: $out"
  [ -z "$out" ] || fail "Pi distinct-file mixed-batch test printed output: $out"
  pass "a mixed batch of two distinct files - one routine, one needs-decision - routes wholly to main"
}

# Independent heartbeat handling: a needs-decision row sitting elsewhere in the
# unread queue is excluded and non-vetoing exactly like a check-kind row, so it
# must neither block nor ride along with a co-present, otherwise-eligible
# heartbeat scan (docs/pi-supervision-branch.md "Heartbeat routing").
test_pi_heartbeat_is_not_ridden_into_main_by_a_co_present_needs_decision() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-heartbeat-needs-decision-root"
  home="$TMP_ROOT/pi-heartbeat-needs-decision-home"
  log="$TMP_ROOT/pi-heartbeat-needs-decision.log"
  stop="$TMP_ROOT/pi-heartbeat-needs-decision.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'heartbeat\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, heartbeat: offer.heartbeat, eligible: offer.eligible });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  "1\t1\theartbeat\theartbeat\theartbeat\n2\t2\tsignal\tdecision-task.status\tneeds-decision: decision-task.status\n",
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-heartbeat-needs-decision", {}, undefined, undefined, {});
for (let i = 0; i < 250 && offers.length === 0; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
for (let i = 0; i < 25 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 1 || offers[0].heartbeat !== true || offers[0].eligible !== true) {
  throw new Error(`a co-present needs-decision row made the heartbeat offer ineligible: ${JSON.stringify(offers)}`);
}
if (prompt) {
  throw new Error(`a co-present needs-decision row rode the heartbeat into main: ${prompt}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "a heartbeat must not ride a co-present needs-decision row into main: $out"
  [ -z "$out" ] || fail "Pi heartbeat/needs-decision test printed output: $out"
  pass "a co-present needs-decision row neither vetoes nor rides a heartbeat into main"
}

test_pi_heartbeat_restoration_failure_stays_on_main() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-heartbeat-restoration-failure-root"
  home="$TMP_ROOT/pi-heartbeat-restoration-failure-home"
  log="$TMP_ROOT/pi-heartbeat-restoration-failure.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'heartbeat\n'
  exit 0
fi
printf 'synthetic successor startup failure\n' >&2
exit 1
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, heartbeat: offer.heartbeat });
  offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-heartbeat-restoration-failure", {}, undefined, undefined, {});
for (let i = 0; i < 500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (offers.length !== 0) {
  throw new Error(`heartbeat restoration failure was offered to the branch: ${JSON.stringify(offers)}`);
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE: heartbeat\n\nwatcher: FAILED")) {
  throw new Error(`main wake lost the bare heartbeat reason: ${prompt}`);
}
if (!prompt.includes("watcher: FAILED - Pi extension could not restore watcher continuity after 2 retries")) {
  throw new Error(`main wake lost the restoration failure: ${prompt}`);
}
EOF
  )
  status=$?
  expect_code 0 "$status" "heartbeat restoration failure must bypass an accepting branch: $out"
  [ -z "$out" ] || fail "Pi heartbeat restoration-failure test printed output: $out"
  pass "heartbeat restoration failure stays on main"
}

test_pi_watcher_failure_never_offered_to_branch() {
  local repo home plugin out status
  repo="$TMP_ROOT/pi-watcher-failure-root"
  home="$TMP_ROOT/pi-watcher-failure-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  # Only "actionable" closes (signal/stale/check/heartbeat) ever reach
  # offerWakeToBranch; only main can repair the watcher cycle
  # (docs/pi-supervision-branch.md), and default-on eligibility must not
  # change that. A live, always-accepting bus listener proves the negative:
  # even with an acceptor present, a watcher-failure close is never offered.
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let handler = null;
const handlers = new Map();
const bus = {
  on(channel, h) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), h]);
    return () => {};
  },
  emit(channel, data) {
    for (const h of handlers.get(channel) ?? []) h(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, heartbeat: offer.heartbeat });
  offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand(name, options) {
    if (name === "fm-watch-arm-pi") handler = options.handler;
  },
  registerTool() {},
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await handler("", { ui: { notify() {} } });
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("external healthy watcher")) {
  throw new Error(`watcher failure did not reach main: ${prompt}`);
}
if (offers.length !== 0) {
  throw new Error(`watcher failure was offered to the branch: ${JSON.stringify(offers)}`);
}
EOF
  )
  status=$?
  expect_code 0 "$status" "watcher-failure repair must never be offered to the branch: $out"
  [ -z "$out" ] || fail "Pi watcher-failure test printed output: $out"
  pass "watcher-failure repair stays with main even with a live, accepting branch listener"
}

# Under the away-posture record the dispatcher offers every actionable row to
# the branch - a check-kind trigger and a needs-decision signal included, the
# two classes attended routing forces to main - while the two broken-queue
# vetoes (an unresolvable task-local row, a structurally invalid row) and every
# watcher-failure alarm still reach main exactly as attended
# (docs/pi-supervision-branch.md "Postures").
test_pi_away_record_collapses_eligibility_and_keeps_vetoes_on_main() {
  local repo home plugin log stop out status label expect reason queue
  repo="$TMP_ROOT/pi-away-root"
  home="$TMP_ROOT/pi-away-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$home/projects/approved"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  printf 'project=%s/projects/approved\nwindow=fm-window\n' "$home" > "$home/state/task-a.meta"
  FM_HOME="$home" "$ROOT/bin/fm-afk-contract.sh" enter >/dev/null || fail "away entry failed"
  [ -f "$home/state/.afk-contract" ] || fail "the away-posture record was not written"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then exit 0; fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf '%s\n' "${FM_TEST_REASON:?}"
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  while IFS='|' read -r label expect reason queue; do
    [ -n "$label" ] || continue
    log="$TMP_ROOT/pi-away-$label.log"
    stop="$TMP_ROOT/pi-away-$label.stop"
    out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" \
      FM_TEST_REASON="$reason" FM_TEST_QUEUE="$queue" FM_TEST_EXPECT="$expect" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let tool = null;
const handlers = new Map();
const bus = {
  on(channel, handler) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
    return () => {};
  },
  emit(channel, data) {
    for (const handler of handlers.get(channel) ?? []) handler(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message, eligible: offer.eligible });
  if (offer.eligible) offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(
  `${process.env.FM_HOME}/state/.wake-queue`,
  process.env.FM_TEST_QUEUE.replace(/\\t/g, "\t").replace(/\\n/g, "\n"),
);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-away", {}, undefined, undefined, {});
for (let i = 0; i < 250 && offers.length === 0 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
// Give a wrongly-routed main follow-up time to show up before asserting its absence.
for (let i = 0; i < 25 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (process.env.FM_TEST_EXPECT === "branch") {
  if (offers.length !== 1 || offers[0].eligible !== true) {
    throw new Error(`under the away-posture record this wake was not offered to the branch: ${JSON.stringify(offers)}`);
  }
  if (prompt) throw new Error(`a branch-eligible wake still woke the parked main: ${prompt}`);
} else {
  if (offers.length !== 1 || offers[0].eligible !== false) {
    throw new Error(`a broken-queue wake was offered to the branch under the record: ${JSON.stringify(offers)}`);
  }
  if (!prompt.includes(`FIRSTMATE WATCHER WAKE: ${process.env.FM_TEST_REASON}`)) {
    throw new Error(`a wake the branch cannot take did not fall back to main: ${prompt}`);
  }
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
    )
    status=$?
    expect_code 0 "$status" "away routing for the $label case must bind: $out"
    [ -z "$out" ] || fail "Pi away routing test ($label) printed output: $out"
  done <<'CASES'
check-trigger|branch|check: task-a.check.sh: PR merged|1\t1\tsignal\ttask-a.status\tsignal: task-a.status\n2\t2\tcheck\tmain-only\tcheck: task-a.check.sh: PR merged\n
check-only|branch|check: x-mention 1234567890|1\t1\tcheck\tmain-only\tcheck: x-mention 1234567890\n
needs-decision|branch|signal: task-a.status|1\t1\tsignal\ttask-a.status\tneeds-decision: [key=scope] skip or re-implement\n
unresolvable|main|signal: task-zz.status|1\t1\tsignal\ttask-zz.status\tsignal: task-zz.status\n
corrupt|main|signal: task-a.status|not a queue row\n
CASES

  # Only main can repair supervision itself: a watcher-failure alarm still
  # reaches main with the record present and a live, accepting branch listener.
  repo="$TMP_ROOT/pi-away-alarm-root"
  mkdir -p "$repo/bin"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const offers = [];
let prompt = "";
let handler = null;
const handlers = new Map();
const bus = {
  on(channel, h) {
    handlers.set(channel, [...(handlers.get(channel) ?? []), h]);
    return () => {};
  },
  emit(channel, data) {
    for (const h of handlers.get(channel) ?? []) h(data);
  },
};
bus.on("fm-branch-supervision:dispatch", (offer) => {
  offers.push({ message: offer.message });
  offer.accept();
});
const pi = {
  on() {},
  events: bus,
  registerCommand(name, options) {
    if (name === "fm-watch-arm-pi") handler = options.handler;
  },
  registerTool() {},
  sendUserMessage: async (message) => {
    prompt = message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await handler("", { ui: { notify() {} } });
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("external healthy watcher")) {
  throw new Error(`a watcher failure under the away-posture record did not reach main: ${prompt}`);
}
if (offers.length !== 0) {
  throw new Error(`a watcher failure was offered to the branch under the record: ${JSON.stringify(offers)}`);
}
EOF
  )
  status=$?
  expect_code 0 "$status" "a watcher-failure alarm must still reach main under the record: $out"
  [ -z "$out" ] || fail "Pi away alarm test printed output: $out"
  pass "under the away-posture record every actionable row is offered to the branch while broken-queue wakes and watcher-failure alarms still reach main"
}

test_pi_handling_delivery_failure_is_typed_once() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-handling-fail-root"
  home="$TMP_ROOT/pi-handling-fail-home"
  log="$TMP_ROOT/pi-handling-fail.log"
  stop="$TMP_ROOT/pi-handling-fail.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'refused generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 1
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-handling-fail", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt.includes("handling delivery confirmation was rejected"); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE")) throw new Error(`missing follow-up: ${prompt}`);
if (!prompt.includes("handling delivery confirmation was rejected")) {
  throw new Error(`failed handshake was swallowed: ${prompt}`);
}
if ((prompt.match(/FIRSTMATE WATCHER WAKE/g) || []).length !== 1) {
  throw new Error(`failed handshake was not a single typed message: ${prompt}`);
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.filter((row) => row.startsWith("refused ")).length < 1) {
  throw new Error(`handling-delivered was never attempted: ${rows.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must surface a refused handling handshake as one typed failure"
  [ -z "$out" ] || fail "Pi handling-delivery failure test printed output: $out"
  pass "Pi refused handling handshake is classified and not swallowed"
}

test_pi_confirm_failure_retires_arm_with_distinct_watcher_pid() {
  local repo home plugin log stop retired out status
  repo="$TMP_ROOT/pi-confirm-distinct-root"
  home="$TMP_ROOT/pi-confirm-distinct-home"
  log="$TMP_ROOT/pi-confirm-distinct.log"
  stop="$TMP_ROOT/pi-confirm-distinct.stop"
  retired="$TMP_ROOT/pi-confirm-distinct.retired"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'refused generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 1
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
sleep 0.02 & dead=$!; wait "$dead" 2>/dev/null || true
if [ "$dead" = "$$" ]; then dead=1; fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-distinct\n' "$dead"
trap 'printf "retired\n" > "${FM_RETIRED_FILE:?}"; exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_RETIRED_FILE="$retired" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-confirm-distinct", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt.includes("handling delivery confirmation was rejected"); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("handling delivery confirmation was rejected")) {
  throw new Error(`failed handshake was swallowed: ${prompt}`);
}
let retired = false;
for (let i = 0; i < 250 && !retired; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
  retired = existsSync(process.env.FM_RETIRED_FILE);
}
if (!retired) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  throw new Error(`broken arm survived a failed confirmation with a distinct watcher pid: ${rows.join(" | ")}`);
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
const armRows = rows.filter((row) => row.startsWith("arm="));
if (armRows.length !== 2) throw new Error(`expected one successor arm, got ${armRows.length}: ${rows.join(" | ")}`);
const watcherPid = rows.find((row) => row.startsWith("refused "))?.split("watcher=")[1];
const armPid = armRows[1].split(" ")[0].slice("arm=".length);
if (!watcherPid || watcherPid === armPid) {
  throw new Error(`fixture did not use distinct arm and watcher pids: ${rows.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must retire the failed arm when the watcher pid differs from the arm pid: $out"
  [ -z "$out" ] || fail "Pi confirm-distinct test printed output: $out"
  pass "Pi confirm failure retires the named arm with distinct watcher pid"
}

# A failed confirmation retires only the arm its own recovery token names.
# Here the restored successor has already exited (its stdout still held open,
# so its close never fires) and a manual repair has started a newer arm before
# the successor reports ready; the confirmation then fails with the
# successor's dead watcher pid, and the newer healthy arm must survive.
test_pi_confirm_failure_spares_a_newer_arm() {
  local repo home plugin log stop go retired out status
  repo="$TMP_ROOT/pi-confirm-newer-root"
  home="$TMP_ROOT/pi-confirm-newer-home"
  log="$TMP_ROOT/pi-confirm-newer.log"
  stop="$TMP_ROOT/pi-confirm-newer.stop"
  go="$TMP_ROOT/pi-confirm-newer.go"
  retired="$TMP_ROOT/pi-confirm-newer.retired"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'refused generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 1
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  sleep 0 & dead=$!; wait "$dead" 2>/dev/null || true
  (
    while [ ! -e "${FM_GO_FILE:?}" ] && [ -e "$0" ]; do sleep 0.02; done
    printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-stale\n' "$dead"
    while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.05; done
  ) &
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-newer\n' "$$"
trap 'printf "retired\n" > "${FM_RETIRED_FILE:?}"; exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_GO_FILE="$go" FM_RETIRED_FILE="$retired" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").filter((row) => row.startsWith("arm="))
  : [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-confirm-newer-first", {}, undefined, undefined, {});
for (let i = 0; i < 250 && armRows().length < 2; i += 1) await sleep(20);
if (armRows().length < 2) throw new Error("restoration never started a successor");
const successorPid = Number(armRows()[1].slice("arm=".length));
let dead = false;
for (let i = 0; i < 250 && !dead; i += 1) {
  try {
    process.kill(successorPid, 0);
    await sleep(20);
  } catch {
    dead = true;
  }
}
if (!dead) throw new Error(`successor pid ${successorPid} never exited`);
const repair = await tool.execute("tool-call-confirm-newer-repair", {}, undefined, undefined, {});
if (!repair.content[0].text.includes("started Pi extension arm child")) {
  throw new Error(`repair did not start a newer arm: ${repair.content[0].text}`);
}
for (let i = 0; i < 250 && armRows().length < 3; i += 1) await sleep(20);
if (armRows().length !== 3) throw new Error(`expected a newer third arm: ${armRows().join(" | ")}`);
const newerPid = Number(armRows()[2].slice("arm=".length));
writeFileSync(process.env.FM_GO_FILE, "go\n");
for (let i = 0; i < 250 && !prompt.includes("handling delivery confirmation was rejected"); i += 1) await sleep(20);
if (!prompt.includes("handling delivery confirmation was rejected")) {
  throw new Error(`the stale successor's confirmation never failed: ${prompt}`);
}
await sleep(200);
if (existsSync(process.env.FM_RETIRED_FILE)) {
  throw new Error("a failed confirmation for a stale successor retired the newer healthy arm");
}
process.kill(newerPid, 0);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must not retire a newer arm when a stale successor's confirmation fails: $out"
  [ -z "$out" ] || fail "Pi confirm-newer test printed output: $out"
  pass "Pi confirm failure for a stale successor spares the newer arm"
}

# A marker that advanced mid-restore supersedes the in-flight delivery: the
# shell reports a generation mismatch (status 3), so the wake must be
# delivered with no rejection appendix, nothing may be retired, and the
# attempt plus the confirm result must land in the bounded extension log.
# The log assertions run opted in (FM_WATCH_EXTENSION_LOG_KEEP_LINES=50
# below); the default-off contract lives in
# test_pi_extension_log_stays_off_unless_opted_in.
test_pi_superseded_delivery_has_no_rejection_appendix() {
  local repo home plugin log stop out status extension_log
  repo="$TMP_ROOT/pi-handling-superseded-root"
  home="$TMP_ROOT/pi-handling-superseded-home"
  log="$TMP_ROOT/pi-handling-superseded.log"
  stop="$TMP_ROOT/pi-handling-superseded.stop"
  extension_log="$home/state/.watch-extension.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'superseded generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 3
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_WATCH_EXTENSION_LOG_KEEP_LINES=50 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-handling-superseded", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt.includes("FIRSTMATE WATCHER WAKE"); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE")) throw new Error(`missing follow-up: ${prompt}`);
if (prompt.includes("handling delivery confirmation was rejected")) {
  throw new Error(`a superseded delivery carried a rejection appendix: ${prompt}`);
}
if ((prompt.match(/FIRSTMATE WATCHER WAKE/g) || []).length !== 1) {
  throw new Error(`a superseded delivery was not a single plain message: ${prompt}`);
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.filter((row) => row.startsWith("superseded ")).length < 1) {
  throw new Error(`handling-delivered was never attempted: ${rows.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must deliver a superseded wake with no rejection appendix: $out"
  [ -z "$out" ] || fail "Pi superseded-delivery test printed output: $out"
  [ -f "$extension_log" ] || fail "Pi extension recorded no bounded restore/confirm log"
  grep -qF "restore attempt=" "$extension_log" \
    || fail "extension log has no restore attempt: $(cat "$extension_log")"
  grep -qF "result=superseded" "$extension_log" \
    || fail "extension log has no superseded confirm result: $(cat "$extension_log")"
  pass "Pi superseded handling delivery carries no rejection appendix and is logged"
}

# A superseded confirmation is not a failure, so the wake routes exactly like
# a confirmed delivery: an accepting supervision branch owns it and main gets
# no follow-up. The same fixture with the confirmation succeeding is the
# control, so the case cannot go vacuous.
test_pi_superseded_delivery_is_offered_to_branch() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-superseded-branch-root"
  home="$TMP_ROOT/pi-superseded-branch-home"
  log="$TMP_ROOT/pi-superseded-branch.log"
  stop="$TMP_ROOT/pi-superseded-branch.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirm generation=%s watcher=%s status=%s\n' "$2" "$4" "${FM_CONFIRM_STATUS:?}" >> "${FM_ARM_LOG:?}"
  exit "$FM_CONFIRM_STATUS"
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: superseded synthetic wake\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

async function runScenario(confirmStatus) {
  process.env.FM_CONFIRM_STATUS = String(confirmStatus);
  writeFileSync(process.env.FM_ARM_LOG, "");
  const offers = [];
  let mainPrompt = "";
  let tool = null;
  const handlers = new Map();
  const bus = {
    on(channel, handler) {
      handlers.set(channel, [...(handlers.get(channel) ?? []), handler]);
      return () => {};
    },
    emit(channel, data) {
      for (const handler of handlers.get(channel) ?? []) handler(data);
    },
  };
  bus.on("fm-branch-supervision:dispatch", (offer) => {
    offers.push(offer.message);
    offer.accept();
  });
  const pi = {
    on() {},
    events: bus,
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async (message) => {
      mainPrompt += message;
    },
  };
  const mod = await import(`${pathToFileURL(process.env.PLUGIN).href}?confirm=${confirmStatus}`);
  mod.default(pi);
  await tool.execute(`tool-call-superseded-branch-${confirmStatus}`, {}, undefined, undefined, {});
  for (let i = 0; i < 250 && offers.length === 0 && mainPrompt === ""; i += 1) {
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
  return { offers, mainPrompt, rows };
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/superseded-branch.meta`, "project=/projects/approved\nwindow=fm-superseded-branch\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\tsuperseded-branch.status\tsignal: superseded synthetic wake\n");
for (const confirmStatus of [0, 3]) {
  const result = await runScenario(confirmStatus);
  if (!result.rows.some((row) => row.startsWith("confirm ") && row.endsWith(`status=${confirmStatus}`))) {
    throw new Error(`confirm status ${confirmStatus} was never exercised: ${result.rows.join(" | ")}`);
  }
  if (result.offers.length !== 1) {
    throw new Error(`confirm status ${confirmStatus}: expected one branch offer, got ${result.offers.length}; main got: ${result.mainPrompt}`);
  }
  if (!result.offers[0].includes("signal: superseded synthetic wake")) {
    throw new Error(`confirm status ${confirmStatus}: offer missed the wake reason: ${result.offers[0]}`);
  }
  if (result.offers[0].includes("handling delivery confirmation was rejected")) {
    throw new Error(`confirm status ${confirmStatus}: offer carried a rejection appendix: ${result.offers[0]}`);
  }
  if (result.mainPrompt !== "") {
    throw new Error(`confirm status ${confirmStatus}: accepted offer still reached main: ${result.mainPrompt}`);
  }
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must offer a superseded wake to the branch exactly like a confirmed one: $out"
  [ -z "$out" ] || fail "Pi superseded branch-offer test printed output: $out"
  pass "Pi superseded handling delivery is offered to the branch like a confirmed one"
}

# The extension diagnostic log is opt-in and default-off: the same
# mid-restore supersession that logs when opted in must create no
# state/.watch-extension.log file with the knob unset, zero, or
# non-numeric, while the wake is still delivered with no rejection
# appendix. Each knob value runs in a fresh home because the extension
# reads the knob once at module load.
test_pi_extension_log_stays_off_unless_opted_in() {
  local repo driver mode home log stop extension_log knob_value out status
  repo="$TMP_ROOT/pi-extension-log-off-root"
  driver="$TMP_ROOT/pi-extension-log-off-driver.mjs"
  mkdir -p "$repo/bin"
  install_pi_watch_extension_fixture "$repo"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'superseded generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 3
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  cat > "$driver" <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-handling-superseded", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt.includes("FIRSTMATE WATCHER WAKE"); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!prompt.includes("FIRSTMATE WATCHER WAKE")) throw new Error(`missing follow-up: ${prompt}`);
if (prompt.includes("handling delivery confirmation was rejected")) {
  throw new Error(`a superseded delivery carried a rejection appendix: ${prompt}`);
}
if ((prompt.match(/FIRSTMATE WATCHER WAKE/g) || []).length !== 1) {
  throw new Error(`a superseded delivery was not a single plain message: ${prompt}`);
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.filter((row) => row.startsWith("superseded ")).length < 1) {
  throw new Error(`handling-delivered was never attempted: ${rows.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  for mode in unset zero bogus; do
    home="$TMP_ROOT/pi-extension-log-off-home-$mode"
    log="$TMP_ROOT/pi-extension-log-off-$mode.log"
    stop="$TMP_ROOT/pi-extension-log-off-$mode.stop"
    extension_log="$home/state/.watch-extension.log"
    mkdir -p "$home/state" "$home/config"
    if [ "$mode" = unset ]; then
      out=$(PLUGIN="$repo/.pi/extensions/fm-primary-pi-watch.ts" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node "$driver" 2>&1)
    else
      if [ "$mode" = zero ]; then knob_value=0; else knob_value="not-a-number"; fi
      out=$(PLUGIN="$repo/.pi/extensions/fm-primary-pi-watch.ts" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_WATCH_EXTENSION_LOG_KEEP_LINES="$knob_value" node "$driver" 2>&1)
    fi
    status=$?
    expect_code 0 "$status" "Pi superseded delivery must still succeed with the log $mode: $out"
    [ -z "$out" ] || fail "Pi log-off ($mode) run printed output: $out"
    [ ! -e "$extension_log" ] || fail "Pi extension wrote its diagnostic log with the knob $mode: $(cat "$extension_log")"
  done
  pass "Pi extension diagnostic log stays off unless opted in"
}

# A repair call must not no-op on an arm child whose process is already dead
# while its close event is still pending (stdio pipe held): the first arm
# below exits at once but leaves a pipe holder behind, so the extension still
# holds the handle with no close fired. The repair must not fail over the dead
# arm, and a second arm follows without another call.
test_pi_repair_starts_fresh_arm_over_dead_child() {
  local repo home plugin log stop holder out status
  repo="$TMP_ROOT/pi-stale-child-root"
  home="$TMP_ROOT/pi-stale-child-home"
  log="$TMP_ROOT/pi-stale-child.log"
  stop="$TMP_ROOT/pi-stale-child.stop"
  holder="$TMP_ROOT/pi-stale-child-holder.sh"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$holder" <<'SH'
#!/usr/bin/env bash
while [ ! -e "${1:?}" ] && [ -e "$0" ]; do sleep 0.05; done
SH
  chmod +x "$holder"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
  ("${FM_HOLDER:?}" "${FM_STOP_FILE:?}" >&1 2>/dev/null &)
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_HOLDER="$holder" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
const first = await tool.execute("tool-call-first-arm", {}, undefined, undefined, {});
if (!first.content[0].text.includes("started Pi extension arm child")) {
  throw new Error(`first arm did not start: ${first.content[0].text}`);
}
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
let armPid = "";
for (let i = 0; i < 250 && !armPid; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
  const row = armRows().find((line) => line.startsWith("arm="));
  if (row) armPid = row.split(" ")[0].slice("arm=".length);
}
if (!armPid) throw new Error("first arm never logged its pid");
let dead = false;
for (let i = 0; i < 250 && !dead; i += 1) {
  try {
    process.kill(Number(armPid), 0);
  } catch {
    dead = true;
  }
  if (!dead) await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!dead) throw new Error(`first arm pid ${armPid} never exited`);
const second = await tool.execute("tool-call-repair", {}, undefined, undefined, {});
const text = second.content[0].text;
if (text.includes("FAILED")) {
  throw new Error(`repair failed over a dead child: ${text}`);
}
let rearmed = false;
for (let i = 0; i < 250 && !rearmed; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
  rearmed = armRows().filter((line) => line.startsWith("arm=")).length >= 2;
}
if (!rearmed) {
  throw new Error(`repair started no second arm: ${armRows().join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi repair must start a fresh arm over a dead child handle: $out"
  [ -z "$out" ] || fail "Pi stale-child repair test printed output: $out"
  pass "Pi repair starts a fresh arm instead of no-opping on a dead child"
}

# A scheduled continuity retry must not stall behind a dead-but-unclosed arm
# child. The first arm exits with its stdout held open, the next arm (from the
# exit's retry or a manual repair) does the same, and then the first arm's
# close finally fires: continuity must still reach a fresh live arm.
test_pi_scheduled_retry_starts_fresh_arm_over_dead_child() {
  local repo home plugin log stop release out status
  repo="$TMP_ROOT/pi-retry-dead-root"
  home="$TMP_ROOT/pi-retry-dead-home"
  log="$TMP_ROOT/pi-retry-dead.log"
  stop="$TMP_ROOT/pi-retry-dead.stop"
  release="$TMP_ROOT/pi-retry-dead.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
if [ "$count" -eq 1 ]; then
  (while [ ! -e "${FM_RELEASE_FILE:?}" ] && [ -e "$0" ]; do sleep 0.02; done) &
  exit 0
fi
if [ "$count" -eq 2 ]; then
  (while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.05; done) &
  exit 0
fi
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_RELEASE_FILE="$release" FM_WATCH_REARM_RETRY_BASE_MS=20 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").filter((row) => row.startsWith("arm="))
  : [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function waitForArms(count) {
  for (let i = 0; i < 250 && armRows().length < count; i += 1) await sleep(20);
  if (armRows().length < count) throw new Error(`expected ${count} arms: ${armRows().join(" | ")}`);
  return Number(armRows()[count - 1].slice("arm=".length));
}
async function waitForExit(pid) {
  for (let i = 0; i < 250; i += 1) {
    try {
      process.kill(pid, 0);
    } catch {
      return;
    }
    await sleep(20);
  }
  throw new Error(`arm pid ${pid} never exited`);
}
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-retry-dead-first", {}, undefined, undefined, {});
await waitForExit(await waitForArms(1));
const repair = await tool.execute("tool-call-retry-dead-repair", {}, undefined, undefined, {});
if (repair.content[0].text.includes("FAILED")) {
  throw new Error(`repair failed over the dead first arm: ${repair.content[0].text}`);
}
await waitForExit(await waitForArms(2));
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
for (let i = 0; i < 250 && armRows().length < 3; i += 1) await sleep(20);
if (armRows().length !== 3) {
  throw new Error(`the first arm's close scheduled no retry over the dead second arm: ${armRows().join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi scheduled retry must start a fresh arm over a dead child handle: $out"
  [ -z "$out" ] || fail "Pi scheduled-retry dead-child test printed output: $out"
  pass "Pi scheduled retry starts a fresh arm instead of stalling on a dead child"
}

# A verified successor that closes while its wake is still being delivered
# defers its retry to the end of that delivery. If a manual repair meanwhile
# left a dead-but-unclosed arm in the slot, the deferred retry must still
# start a fresh arm.
test_pi_deferred_close_starts_fresh_arm_over_dead_child() {
  local repo home plugin log stop release out status
  repo="$TMP_ROOT/pi-deferred-dead-root"
  home="$TMP_ROOT/pi-deferred-dead-home"
  log="$TMP_ROOT/pi-deferred-dead.log"
  stop="$TMP_ROOT/pi-deferred-dead.stop"
  release="$TMP_ROOT/pi-deferred-dead.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic actionable close\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
  while [ ! -e "${FM_RELEASE_FILE:?}" ] && [ -e "$0" ]; do sleep 0.02; done
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
if [ "$count" -eq 3 ]; then
  (while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.05; done) &
  exit 0
fi
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_RELEASE_FILE="$release" FM_WATCH_REARM_RETRY_BASE_MS=20 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let deliveryStarted = false;
let finishDelivery = () => {};
const deliveryHeld = new Promise((resolve) => {
  finishDelivery = resolve;
});
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {
    deliveryStarted = true;
    await deliveryHeld;
  },
};
const armRows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").filter((row) => row.startsWith("arm="))
  : [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function waitForArms(count) {
  for (let i = 0; i < 250 && armRows().length < count; i += 1) await sleep(20);
  if (armRows().length < count) throw new Error(`expected ${count} arms: ${armRows().join(" | ")}`);
  return Number(armRows()[count - 1].slice("arm=".length));
}
async function waitForExit(pid) {
  for (let i = 0; i < 250; i += 1) {
    try {
      process.kill(pid, 0);
    } catch {
      return;
    }
    await sleep(20);
  }
  throw new Error(`arm pid ${pid} never exited`);
}
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-deferred-dead-first", {}, undefined, undefined, {});
const successorPid = await waitForArms(2);
for (let i = 0; i < 250 && !deliveryStarted; i += 1) await sleep(20);
if (!deliveryStarted) throw new Error("the restored wake was never delivered");
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
await waitForExit(successorPid);
await sleep(100);
const repair = await tool.execute("tool-call-deferred-dead-repair", {}, undefined, undefined, {});
if (!repair.content[0].text.includes("started Pi extension arm child")) {
  throw new Error(`repair did not start an arm after the successor closed: ${repair.content[0].text}`);
}
await waitForExit(await waitForArms(3));
finishDelivery();
for (let i = 0; i < 250 && armRows().length < 4; i += 1) await sleep(20);
if (armRows().length !== 4) {
  throw new Error(`the deferred close started no retry over the dead repair arm: ${armRows().join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi deferred close must start a fresh arm over a dead child handle: $out"
  [ -z "$out" ] || fail "Pi deferred-close dead-child test printed output: $out"
  pass "Pi deferred close starts a fresh arm instead of stalling on a dead child"
}

test_pi_hung_successor_falls_back_to_typed_wake() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-hung-successor-root"
  home="$TMP_ROOT/pi-hung-successor-home"
  log="$TMP_ROOT/pi-hung-successor.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic wake\n'
  exit 0
fi
trap 'exit 0' TERM INT
while [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_PI_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
let rowsAtPrompt = 0;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
    rowsAtPrompt = existsSync(process.env.FM_ARM_LOG)
      ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").length
      : 0;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-hung-successor", {}, undefined, undefined, {});
// Three unready successors each cost the full readiness budget, so wait well
// past their sum. The wait ends as soon as the wake lands.
for (let i = 0; i < 1500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 4) throw new Error(`expected one successor plus two retries, got ${rows.length}: ${rows.join(" | ")}`);
if (rowsAtPrompt !== 4) throw new Error(`wake arrived before restoration exhausted (${rowsAtPrompt} arm rows)`);
if (!prompt.includes("signal: synthetic wake")) throw new Error(`original wake was lost: ${prompt}`);
if (!prompt.includes("could not restore watcher continuity after 2 retries")) throw new Error(`missing typed restoration failure: ${prompt}`);
await new Promise((resolve) => setTimeout(resolve, 100));
const stableRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (stableRows.length !== 4) throw new Error(`single-flight recovery launched ${stableRows.length} arms`);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must deliver the actionable wake after bounded hung-successor recovery"
  [ -z "$out" ] || fail "Pi hung-successor test printed output: $out"
  pass "Pi hung successor falls back to one typed actionable wake"
}

test_pi_unretired_successor_falls_back_without_retry() {
  local repo home plugin log release out status
  repo="$TMP_ROOT/pi-unretired-successor-root"
  home="$TMP_ROOT/pi-unretired-successor-home"
  log="$TMP_ROOT/pi-unretired-successor.log"
  release="$TMP_ROOT/pi-unretired-successor.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ -f "$FM_ARM_LOG" ]; then
  count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
else
  count=0
fi
if [ "$count" -eq 0 ]; then
  printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic wake\n'
  exit 0
fi
trap '' TERM INT
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.1; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_RELEASE_FILE="$release" FM_PI_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=20 FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
let rowsAtPrompt = 0;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
    rowsAtPrompt = existsSync(process.env.FM_ARM_LOG)
      ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").length
      : 0;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-unretired-successor", {}, undefined, undefined, {});
for (let i = 0; i < 500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 2) throw new Error(`unretired arm overlapped a retry: ${rows.join(" | ")}`);
if (rowsAtPrompt !== 2) throw new Error(`wake arrived after an overlapping retry (${rowsAtPrompt} arm rows)`);
if (!prompt.includes("signal: synthetic wake")) throw new Error(`original wake was lost: ${prompt}`);
if (!prompt.includes("unready successor arm did not exit within 20ms")) throw new Error(`missing unretired-arm failure: ${prompt}`);
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
await new Promise((resolve) => setTimeout(resolve, 80));
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must fall back without overlapping an unretired successor"
  [ -z "$out" ] || fail "Pi unretired-successor test printed output: $out"
  pass "Pi unretired successor falls back without an overlapping retry"
}

test_pi_late_unretired_close_resumes_supervision() {
  local kind repo home plugin log ready retired release stop out status
  for kind in actionable non-actionable; do
    repo="$TMP_ROOT/pi-late-$kind-root"
    home="$TMP_ROOT/pi-late-$kind-home"
    log="$TMP_ROOT/pi-late-$kind.log"
    ready="$TMP_ROOT/pi-late-$kind.ready"
    retired="$TMP_ROOT/pi-late-$kind.retired"
    release="$TMP_ROOT/pi-late-$kind.release"
    stop="$TMP_ROOT/pi-late-$kind.stop"
    mkdir -p "$repo/bin" "$home/state" "$home/config"
    install_pi_watch_extension_fixture "$repo"
    plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
    cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: original wake\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  trap 'printf "retired\\n" > "${FM_UNRETIRED_RETIRE_FILE:?}"' TERM INT
  printf 'ready\n' > "${FM_UNRETIRED_READY_FILE:?}"
  while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
  [ "$FM_LATE_KIND" = actionable ] && printf 'signal: late wake\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
    chmod +x "$repo/bin/fm-watch-arm.sh"
    out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_UNRETIRED_READY_FILE="$ready" FM_UNRETIRED_RETIRE_FILE="$retired" FM_RELEASE_FILE="$release" FM_STOP_FILE="$stop" FM_LATE_KIND="$kind" FM_PI_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=20 FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const prompts = [];
const handlers = new Map();
const pi = {
  on(event, handler) {
    handlers.set(event, handler);
  },
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  // Nothing here consumes the follow-up: continuity must not depend on it.
  sendUserMessage: async (message) => {
    prompts.push(message);
  },
};
const rows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
async function waitFor(predicate, message) {
  for (let i = 0; i < 500; i += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(message);
}
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-late-close", {}, undefined, undefined, {});
await waitFor(
  () => existsSync(process.env.FM_UNRETIRED_READY_FILE),
  "unretired successor did not enter its retirement wait",
);
await waitFor(() => prompts.length >= 1, "original fallback was not delivered");
await waitFor(
  () => existsSync(process.env.FM_UNRETIRED_RETIRE_FILE),
  "unretired successor was not asked to retire before fallback",
);
if (rows().length !== 2) throw new Error(`unretired arm overlapped before fallback: ${rows().join(" | ")}`);
if (!prompts[0]?.includes("original wake")) throw new Error(`missing original fallback: ${prompts.join(" | ")}`);
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
for (let i = 0; i < 500; i += 1) {
  if (rows().length >= 3 && (process.env.FM_LATE_KIND !== "actionable" || prompts.some((message) => message.includes("late wake")))) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (rows().length !== 3) throw new Error(`late close did not restore one successor: ${rows().join(" | ")}`);
if (process.env.FM_LATE_KIND === "actionable") {
  if (prompts.length !== 2 || !prompts[1].includes("late wake")) throw new Error(`late actionable close was not delivered: ${prompts.join(" | ")}`);
} else if (prompts.length !== 1) {
  throw new Error(`late non-actionable close sent an extra wake: ${prompts.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
await new Promise((resolve) => setTimeout(resolve, 80));
EOF
)
    status=$?
    expect_code 0 "$status" "Pi late $kind close must remain supervised after fallback"
    [ -z "$out" ] || fail "Pi late-$kind test printed output: $out"
  done
  pass "Pi late unretired closes resume classified supervision"
}

test_pi_empty_close_retries_instead_of_disappearing() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-empty-close-root"
  home="$TMP_ROOT/pi-empty-close-home"
  log="$TMP_ROOT/pi-empty-close.log"
  stop="$TMP_ROOT/pi-empty-close.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then exit 0; fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompts = 0;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {
    prompts += 1;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-empty", {}, undefined, undefined, {});
for (let i = 0; i < 250; i += 1) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  if (rows.length >= 2) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (rows.length !== 2) throw new Error(`clean empty close was ignored: ${rows.join(" | ")}`);
if (prompts !== 0) throw new Error(`restored transient close surfaced ${prompts} failure prompts`);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
  )
  status=$?
  expect_code 0 "$status" "Pi clean empty close must trigger a bounded continuity retry"
  [ -z "$out" ] || fail "Pi empty-close retry test printed output: $out"
  pass "Pi clean empty close triggers a bounded continuity retry"
}

test_pi_established_empty_close_honors_retry_limit() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-established-empty-close-root"
  home="$TMP_ROOT/pi-established-empty-close-home"
  log="$TMP_ROOT/pi-established-empty-close.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
exit 0
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-established-empty", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 3) throw new Error(`retry limit launched ${rows.length} arm cycles: ${rows.join(" | ")}`);
if (!prompt.includes("after 2 retries")) throw new Error(`retry exhaustion was not surfaced: ${prompt}`);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi established clean closes must honor the continuity retry limit"
  [ -z "$out" ] || fail "Pi established-empty-close retry test printed output: $out"
  pass "Pi established clean closes stop at the configured retry limit"
}

test_pi_actionable_close_rechecks_session_lock() {
  local repo home plugin log release out status
  repo="$TMP_ROOT/pi-close-lock-root"
  home="$TMP_ROOT/pi-close-lock-home"
  log="$TMP_ROOT/pi-close-lock.log"
  release="$TMP_ROOT/pi-close-lock.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
printf 'signal: lock handoff\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_RELEASE_FILE="$release" node --input-type=module 2>&1 <<'EOF'
import { spawn } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
let prompt = "";
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompt += message;
  },
};
const lock = `${process.env.FM_HOME}/state/.lock`;
writeFileSync(lock, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-lock-close", {}, undefined, undefined, {});
const other = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
try {
  writeFileSync(lock, `${other.pid}\n`);
  writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
  for (let i = 0; i < 250 && !prompt.includes("no longer owns the lock"); i += 1) {
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
  if (rows.length !== 1) throw new Error(`successor launched after lock loss: ${rows.join(" | ")}`);
  if (!prompt.includes("no longer owns the lock")) throw new Error(`missing lock-loss failure: ${prompt}`);
} finally {
  other.kill("SIGTERM");
}
EOF
  )
  status=$?
  [ "$status" -eq 0 ] || fail "Pi close handler must verify session-lock ownership before successor launch: $out"
  [ -z "$out" ] || fail "Pi close lock test printed output: $out"
  pass "Pi close handler verifies session-lock ownership before successor launch"
}

test_pi_arm_distinguishes_session_lock_ownership() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-lock-ownership-root"
  home="$TMP_ROOT/pi-lock-ownership-home"
  log="$TMP_ROOT/pi-lock-ownership.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" node --input-type=module 2>&1 <<'EOF'
import { existsSync, unlinkSync, writeFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
if (!tool) throw new Error("Pi watch tool was not registered");

const lock = `${process.env.FM_HOME}/state/.lock`;
const callArm = () => tool.execute("tool-call-lock", {}, undefined, undefined, {});
const assertMissingLock = (result, label) => {
  if (result.details?.ok !== false) throw new Error(`${label} unexpectedly armed: ${JSON.stringify(result.details)}`);
  if (!result.details.message.includes("no live session holds the lock")) {
    throw new Error(`${label} missing no-live-session guidance: ${result.details.message}`);
  }
  if (!result.details.message.includes("bin/fm-session-start.sh") || !result.details.message.includes("re-arm")) {
    throw new Error(`${label} missing reclaim and re-arm guidance: ${result.details.message}`);
  }
  if (result.details.message.includes("held by another firstmate session")) {
    throw new Error(`${label} was misreported as a live other holder: ${result.details.message}`);
  }
};

if (existsSync(lock)) unlinkSync(lock);
assertMissingLock(await callArm(), "absent lock");
writeFileSync(lock, "999999\n");
assertMissingLock(await callArm(), "dead lock holder");
for (const value of ["unknown\n", "1\n", "2\n3\n"]) {
  writeFileSync(lock, value);
  const unknown = await callArm();
  if (unknown.details?.ok !== false || !unknown.details.message.includes("read-only")) {
    throw new Error(`unknown ownership unexpectedly armed: ${JSON.stringify(unknown.details)}`);
  }
}

const other = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
try {
  writeFileSync(lock, `${other.pid}\n`);
  const liveOther = await callArm();
  if (liveOther.details?.ok !== false) throw new Error(`live other holder unexpectedly armed: ${JSON.stringify(liveOther.details)}`);
  if (liveOther.details.message !== "watcher: read-only - session lock is held by another firstmate session") {
    throw new Error(`unexpected live-other response: ${liveOther.details.message}`);
  }
} finally {
  other.kill("SIGTERM");
}

if (existsSync(process.env.FM_ARM_LOG)) throw new Error("watcher arm ran without lock ownership");
writeFileSync(lock, `${process.pid}\n`);
const owned = await callArm();
if (owned.details?.ok !== true || !owned.details.message.includes("started Pi extension arm child")) {
  throw new Error(`owned lock did not arm: ${JSON.stringify(owned.details)}`);
}
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) throw new Error("owned lock did not run the watcher arm");
EOF
)
  status=$?
  expect_code 0 "$status" "Pi watcher arm must distinguish owned, live-other, and missing or dead session locks"
  [ -z "$out" ] || fail "Pi lock-ownership arm test printed output: $out"
  pass "Pi watcher arm distinguishes all session lock ownership states"
}

# On Windows the session lock may hold a tagged win:<pid> (bin/fm-session-lock-lib.sh),
# and native Node sees that Windows pid directly, so the arm reads a tagged holder
# by its digits. A malformed tag, and any tag off Windows, stays no identity. The
# platform is set per call so every host exercises both sides.
test_pi_arm_reads_a_windows_tagged_session_lock() {
  local repo home plugin log out status
  repo="$TMP_ROOT/pi-tagged-lock-root"
  home="$TMP_ROOT/pi-tagged-lock-home"
  log="$TMP_ROOT/pi-tagged-lock.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" node --input-type=module 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { spawn, spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";

let tool = null;
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
if (!tool) throw new Error("Pi watch tool was not registered");

const lock = `${process.env.FM_HOME}/state/.lock`;
const platform = Object.getOwnPropertyDescriptor(process, "platform");
async function armOn(name, value) {
  writeFileSync(lock, `${value}\n`);
  Object.defineProperty(process, "platform", { ...platform, value: name });
  try {
    return await tool.execute("tool-call-tagged-lock", {}, undefined, undefined, {});
  } finally {
    Object.defineProperty(process, "platform", platform);
  }
}
const otherHolder = "watcher: read-only - session lock is held by another firstmate session";
const expectRefused = (result, label, message) => {
  if (result.details?.ok !== false) throw new Error(`${label} unexpectedly armed: ${JSON.stringify(result.details)}`);
  if (!result.details.message.includes(message)) throw new Error(`${label} gave the wrong refusal: ${result.details.message}`);
};

const dead = spawnSync(process.execPath, ["-e", "0"], { stdio: "ignore" }).pid;
expectRefused(await armOn("win32", `win:${dead}`), "a dead tagged holder", "no live session holds the lock");
const other = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
try {
  expectRefused(await armOn("win32", `win:${other.pid}`), "a live other tagged holder", otherHolder);
} finally {
  other.kill("SIGTERM");
}
for (const value of ["win:", `win:${process.pid}x`, `WIN:${process.pid}`, "win:1"]) {
  expectRefused(await armOn("win32", value), `the malformed tagged lock ${value}`, otherHolder);
}
expectRefused(await armOn("linux", `win:${process.pid}`), "a tagged lock off Windows", otherHolder);
if (existsSync(process.env.FM_ARM_LOG)) throw new Error("watcher arm ran without owning the tagged lock");

const owned = await armOn("win32", `win:${process.pid}`);
if (owned.details?.ok !== true || !owned.details.message.includes("started Pi extension arm child")) {
  throw new Error(`an owned tagged lock did not arm: ${JSON.stringify(owned.details)}`);
}
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) throw new Error("an owned tagged lock did not run the watcher arm");
EOF
)
  status=$?
  expect_code 0 "$status" "Pi watcher arm must read a Windows-tagged session lock only on Windows"
  [ -z "$out" ] || fail "Pi tagged-lock arm test printed output: $out"
  pass "Pi watcher arm reads a Windows-tagged session lock only on Windows"
}

# A Pi command started from inside the live session, such as the `pi --help`
# capability probe, auto-loads this extension too and passes the ancestor walk
# in lockOwnership. Its pid dies at once, so the marker must stay on the live
# session above it, generation line included, while a dead or foreign marker pid
# is still replaced.
test_pi_extension_keeps_marker_of_live_ancestor_session() {
  local repo home plugin marker_case out status
  repo="$TMP_ROOT/pi-marker-guard-root"
  home="$TMP_ROOT/pi-marker-guard-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  for marker_case in nested dead foreign fresh; do
    rm -f "$home/state/.pi-watch-extension-loaded"
    out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" MARKER_CASE="$marker_case" node --input-type=module 2>&1 <<'EOF'
import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const marker = `${process.env.FM_HOME}/state/.pi-watch-extension-loaded`;
const version = `sha256:${createHash("sha256").update(readFileSync(process.env.PLUGIN)).digest("hex")}`;
// The lock names the parent of this process: a live strict ancestor, exactly where
// the real session sits above a nested `pi --help`.
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.ppid}\n`);

const pi = {
  on() {},
  registerCommand() {},
  registerTool() {},
  sendUserMessage: async () => {},
};
async function load() {
  const mod = await import(pathToFileURL(process.env.PLUGIN).href);
  mod.default(pi);
}
function expectBoundToThisProcess(label) {
  const lines = readFileSync(marker, "utf8").split("\n");
  if (
    lines.length !== 4 || lines[3] !== "" ||
    lines[0] !== version ||
    lines[1] !== String(process.pid) ||
    !/^generation=[1-9][0-9]* phase=active$/.test(lines[2])
  ) {
    throw new Error(`${label}: marker was not bound to this process: ${JSON.stringify(lines.join("\n"))}`);
  }
}
function pidAlive(pid) {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

switch (process.env.MARKER_CASE) {
  case "nested": {
    const before = `${version}\n${process.ppid}\ngeneration=7 phase=active\n`;
    writeFileSync(marker, before);
    await load();
    const after = readFileSync(marker, "utf8");
    if (after !== before) throw new Error(`nested load replaced the marker of the live session: ${JSON.stringify(after)}`);
    break;
  }
  case "dead": {
    const dead = spawnSync(process.execPath, ["-e", "0"], { stdio: "ignore" }).pid;
    if (!dead || pidAlive(dead)) throw new Error(`could not produce a dead pid (got ${dead})`);
    writeFileSync(marker, `${version}\n${dead}\ngeneration=7 phase=active\n`);
    await load();
    expectBoundToThisProcess("marker on a dead pid");
    break;
  }
  case "foreign": {
    const foreign = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
    try {
      writeFileSync(marker, `${version}\n${foreign.pid}\ngeneration=7 phase=active\n`);
      await load();
      expectBoundToThisProcess("marker on a live non-ancestor pid");
    } finally {
      foreign.kill("SIGTERM");
    }
    break;
  }
  case "fresh": {
    if (existsSync(marker)) throw new Error("fresh case started with a marker present");
    await load();
    expectBoundToThisProcess("fresh load");
    break;
  }
  default:
    throw new Error(`unknown marker case: ${process.env.MARKER_CASE}`);
}
EOF
)
    status=$?
    [ "$status" = 0 ] || fail "Pi watch marker guard failed for the '$marker_case' case (exit $status): $out"
    [ -z "$out" ] || fail "Pi watch marker guard '$marker_case' case printed output: $out"
  done
  pass "Pi watch extension: a nested load keeps the live session's watch marker"
}

test_pi_session_transition_generation_owner() {
  local repo home plugin child_pid_file child_marker_file marker_root arm_log fail_once out status
  repo="$TMP_ROOT/pi-session-transition-root"
  home="$TMP_ROOT/pi-session-transition-home"
  child_pid_file="$TMP_ROOT/pi-session-transition-child.pid"
  child_marker_file="$TMP_ROOT/pi-session-transition-child.marker"
  marker_root="$TMP_ROOT/pi-session-transition-markers"
  arm_log="$TMP_ROOT/pi-session-transition-arm.log"
  fail_once="$TMP_ROOT/pi-session-transition-fail-once"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$marker_root"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
# Model the real --restart arm taking over from the still-live replacement
# predecessor only after this successor process has been committed.
previous=$(cat "${FM_CHILD_PID_FILE:?}" 2>/dev/null || true)
if [ -n "$previous" ] && kill -0 "$previous" 2>/dev/null; then
  kill -TERM "$previous" 2>/dev/null || true
fi
if [ -f "${FM_FAIL_ONCE:?}" ]; then
  rm -f "$FM_FAIL_ONCE"
  printf 'failed-replacement-attempt\n' >> "${FM_ARM_LOG:?}"
  printf 'watcher: FAILED - simulated replacement launch failure\n' >&2
  exit 7
fi
# The marker identifies this exact process lifetime after its PID is recycled.
marker=$(mktemp "${FM_MARKER_ROOT:?}/arm.XXXXXX") || exit 1
cleanup() { rm -f "$marker"; }
trap cleanup EXIT
trap 'exit 0' TERM INT
printf 'watcher: started pid=%s\n' "$$"
printf '%s\n' "$$" > "${FM_CHILD_PID_FILE:?}"
printf '%s\n' "$marker" > "${FM_CHILD_MARKER_FILE:?}"
printf 'arm pid=%s marker=%s\n' "$$" "$marker" >> "${FM_ARM_LOG:?}"
while [ -e "$0" ]; do sleep 0.2; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_CHILD_PID_FILE="$child_pid_file" FM_CHILD_MARKER_FILE="$child_marker_file" FM_MARKER_ROOT="$marker_root" FM_ARM_LOG="$arm_log" FM_FAIL_ONCE="$fail_once" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

function makePi() {
  const handlers = new Map();
  let tool = null;
  const pi = {
    on(event, handler) {
      handlers.set(event, handler);
    },
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async () => {},
    events: { on() {} },
  };
  return { pi, handlers, getTool: () => tool };
}

function pidAlive(pid) {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

async function waitFor(pred, label, attempts = 250) {
  for (let i = 0; i < attempts; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  throw new Error(`timeout waiting for ${label}`);
}

function currentArm() {
  try {
    return {
      pid: readFileSync(process.env.FM_CHILD_PID_FILE, "utf8").trim(),
      marker: readFileSync(process.env.FM_CHILD_MARKER_FILE, "utf8").trim(),
    };
  } catch {
    return { pid: "", marker: "" };
  }
}

function extensionOwner() {
  const path = `${process.env.FM_HOME}/state/.pi-watch-extension-loaded`;
  try {
    return readFileSync(path, "utf8").trim().split("\n")[2] ?? "";
  } catch {
    return "";
  }
}

function liveArmPids() {
  if (!existsSync(process.env.FM_ARM_LOG)) return [];
  return readFileSync(process.env.FM_ARM_LOG, "utf8")
    .trim()
    .split(/\n/)
    .filter(Boolean)
    .map((line) => {
      const match = /pid=(\d+) marker=(\S+)/.exec(line);
      return match ? { pid: match[1], marker: match[2] } : { pid: "", marker: "" };
    })
    .filter((arm) => arm.pid && arm.marker && existsSync(arm.marker) && pidAlive(arm.pid))
    .map((arm) => arm.pid);
}

const mod = await import(pathToFileURL(process.env.PLUGIN).href);

const startup = makePi();
mod.default(startup.pi);
if (!/^generation=[1-9][0-9]* phase=active$/.test(extensionOwner())) {
  throw new Error(`extension bind did not publish its pre-lock active generation: ${extensionOwner()}`);
}
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await startup.handlers.get("session_start")?.({ type: "session_start", reason: "startup" }, {});
await waitFor(() => {
  const arm = currentArm();
  return arm.pid && arm.marker && existsSync(arm.marker) && pidAlive(arm.pid);
}, "startup child");
const { pid: startupChild, marker: startupMarker } = currentArm();
if (!pidAlive(startupChild)) throw new Error("startup child was not alive");
if (!/^generation=[1-9][0-9]* phase=active$/.test(extensionOwner())) {
  throw new Error(`startup did not publish an active generation owner: ${extensionOwner()}`);
}
const staleTool = startup.getTool();

async function replaceSession(previous, reason) {
  const previousArm = currentArm();
  const previousOwner = extensionOwner();
  const previousGeneration = /^generation=([1-9][0-9]*) phase=active$/.exec(previousOwner)?.[1];
  if (!previousGeneration) throw new Error(`${reason} predecessor had no active generation owner: ${previousOwner}`);
  await previous.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason }, {});
  if (!previousArm.marker || !existsSync(previousArm.marker) || !pidAlive(previousArm.pid)) {
    throw new Error(`${reason} shutdown retired the old generation before a successor owned recovery`);
  }
  if (extensionOwner() !== `generation=${previousGeneration} phase=handoff`) {
    throw new Error(`${reason} shutdown did not publish its generation handoff: ${extensionOwner()}`);
  }
  const next = makePi();
  mod.default(next.pi);
  await next.handlers.get("session_start")?.({
    type: "session_start",
    reason,
    previousSessionFile: `/tmp/previous-${reason}.jsonl`,
  }, {});
  await waitFor(() => {
    const arm = currentArm();
    return arm.pid && arm.marker && arm.marker !== previousArm.marker && existsSync(arm.marker) && pidAlive(arm.pid) && liveArmPids().includes(arm.pid);
  }, `${reason} replacement child and arm record`);
  await waitFor(() => !existsSync(previousArm.marker), `${reason} previous child exit after successor claim`);
  const nextOwner = extensionOwner();
  const nextGeneration = /^generation=([1-9][0-9]*) phase=active$/.exec(nextOwner)?.[1];
  if (!nextGeneration || nextGeneration === previousGeneration) {
    throw new Error(`${reason} successor did not claim a distinct active generation: ${nextOwner}`);
  }
  const live = liveArmPids();
  if (live.length !== 1) {
    throw new Error(`${reason} expected exactly one live arm child, got ${live.join(",") || "(none)"}`);
  }
  const redundant = await next.getTool().execute(`redundant-${reason}`, {}, undefined, undefined, {});
  if (!redundant.details?.ok || !String(redundant.details.message).includes("unchanged")) {
    throw new Error(`${reason} replacement lost automatic arm ownership: ${JSON.stringify(redundant.details)}`);
  }
  return next;
}

let current = await replaceSession(startup, "new");
current = await replaceSession(current, "resume");
current = await replaceSession(current, "fork");
current = await replaceSession(current, "reload");

// A replacement that kills the predecessor but fails before watcher readiness
// remains generation-owned and reaches its bounded automatic retry.
writeFileSync(process.env.FM_FAIL_ONCE, "fail once\n");
current = await replaceSession(current, "resume");
if (!readFileSync(process.env.FM_ARM_LOG, "utf8").includes("failed-replacement-attempt")) {
  throw new Error("replacement launch failure did not exercise automatic retry");
}

// Same bound instance: ordinary shutdown then session_start without a fresh factory.
const sameInstanceArm = currentArm();
const sameInstanceGeneration = /^generation=([1-9][0-9]*) phase=active$/.exec(extensionOwner())?.[1];
await current.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
if (!sameInstanceArm.marker || !existsSync(sameInstanceArm.marker) || !pidAlive(sameInstanceArm.pid)) {
  throw new Error("same-instance shutdown retired the old generation before its replacement started");
}
if (!sameInstanceGeneration || extensionOwner() !== `generation=${sameInstanceGeneration} phase=handoff`) {
  throw new Error(`same-instance shutdown did not publish its handoff generation: ${extensionOwner()}`);
}
await current.handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
await waitFor(() => {
    const arm = currentArm();
    return arm.pid && arm.marker && arm.marker !== sameInstanceArm.marker && existsSync(arm.marker) && pidAlive(arm.pid) && liveArmPids().includes(arm.pid);
}, "same-instance replacement child and arm record");
await waitFor(() => !existsSync(sameInstanceArm.marker), "same-instance previous child exit");
const sameInstanceOwner = extensionOwner();
const sameInstanceSuccessor = /^generation=([1-9][0-9]*) phase=active$/.exec(sameInstanceOwner)?.[1];
if (!sameInstanceSuccessor || sameInstanceSuccessor === sameInstanceGeneration) {
  throw new Error(`same-instance successor did not claim a distinct active generation: ${sameInstanceOwner}`);
}
const sameInstanceResult = await current.getTool().execute("same-instance-redundant", {}, undefined, undefined, {});
if (!sameInstanceResult.details?.ok || !String(sameInstanceResult.details.message).includes("unchanged")) {
  throw new Error(`same-instance replacement lost automatic arm ownership: ${JSON.stringify(sameInstanceResult.details)}`);
}
if (liveArmPids().length !== 1) {
  throw new Error(`same-instance expected one live arm child, got ${liveArmPids().join(",")}`);
}

// Stale prior-generation callback must not stop, rearm, or clear the active generation.
const activeChild = currentArm().pid;
const stale = await staleTool.execute("stale-prior-generation", {}, undefined, undefined, {});
if (stale.details?.ok !== false || !String(stale.details.message).includes("shutting down")) {
  throw new Error(`stale prior generation did not refuse: ${JSON.stringify(stale.details)}`);
}
if (!pidAlive(activeChild)) throw new Error("active generation child died after stale callback");
if (existsSync(startupMarker)) throw new Error("startup generation child was resurrected");
// Model the old generation PID being recycled for the active child.
// Its retired lifetime marker must keep the historical row from counting live.
writeFileSync(process.env.FM_ARM_LOG, `arm pid=${activeChild} marker=${startupMarker}\n`, { flag: "a" });
if (liveArmPids().length !== 1 || liveArmPids()[0] !== activeChild) {
  throw new Error(`stale callback mutated live arm set: ${liveArmPids().join(",")}`);
}
const redundant = await current.getTool().execute("redundant", {}, undefined, undefined, {});
if (!redundant.details?.ok || !String(redundant.details.message).includes("unchanged")) {
  throw new Error(`active generation lost single-flight ownership: ${JSON.stringify(redundant.details)}`);
}

// Repeated transitions keep exactly one live cycle and never revive the refusal.
for (const reason of ["resume", "fork", "new", "resume"]) {
  current = await replaceSession(current, reason);
}

// Real terminal shutdown still blocks late rearming.
const finalArm = currentArm();
await current.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "quit" }, {});
await waitFor(() => !existsSync(finalArm.marker), "terminal shutdown child exit");
if (extensionOwner()) throw new Error(`terminal shutdown left an extension owner: ${extensionOwner()}`);
const quitArm = await current.getTool().execute("after-quit", {}, undefined, undefined, {});
if (quitArm.details?.ok !== false || quitArm.details.message !== "watcher: not armed - Pi session is shutting down") {
  throw new Error(`terminal quit must keep the shutting-down refusal: ${JSON.stringify(quitArm.details)}`);
}
if (liveArmPids().length !== 0) {
  throw new Error(`terminal quit left live arm children: ${liveArmPids().join(",")}`);
}
EOF
)
  status=$?
  [ "$status" -eq 0 ] || fail "Pi session transitions must auto-arm through their generation owner (exit $status): $out"
  [ -z "$out" ] || fail "Pi session-transition generation owner test printed output: $out"
  pass "Pi session transitions auto-arm through a generation owner across /new /resume /fork/reload, stale callbacks, and quit"
}

test_pi_session_replacement_carries_inflight_actionable_close() {
  local repo home plugin log marker_root trigger stop out status
  repo="$TMP_ROOT/pi-session-replacement-handoff-root"
  home="$TMP_ROOT/pi-session-replacement-handoff-home"
  log="$TMP_ROOT/pi-session-replacement-handoff.log"
  marker_root="$TMP_ROOT/pi-session-replacement-handoff-markers"
  trigger="$TMP_ROOT/pi-session-replacement-handoff.trigger"
  stop="$TMP_ROOT/pi-session-replacement-handoff.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config" "$marker_root"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
marker=$(mktemp "${FM_MARKER_ROOT:?}/arm.XXXXXX") || exit 1
cleanup() { rm -f "$marker"; }
trap cleanup EXIT
trap 'exit 0' TERM INT
printf 'arm pid=%s marker=%s\n' "$$" "$marker" >> "${FM_ARM_LOG:?}"
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=replacement-fixture\n' "$$"
# Model --restart taking over the retained predecessor after successor commit.
previous=$(sed -n '1p' "$FM_ARM_LOG.pid" 2>/dev/null || true)
previous_marker=$(sed -n '2p' "$FM_ARM_LOG.pid" 2>/dev/null || true)
printf '%s\n%s\n' "$$" "$marker" > "$FM_ARM_LOG.pid"
if [ -n "$previous" ] && [ -f "$previous_marker" ]; then
  kill -TERM "$previous" 2>/dev/null || true
fi
while :; do
  if [ -e "$FM_TRIGGER_FILE" ]; then
    outcome=$(cat "$FM_TRIGGER_FILE")
    rm -f "$FM_TRIGGER_FILE"
    printf 'signal: '
    sleep 0.02
    printf '%s\n' "$outcome"
    exit 0
  fi
  [ ! -e "$FM_STOP_FILE" ] || exit 0
  sleep 0.02
done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_MARKER_ROOT="$marker_root" FM_TRIGGER_FILE="$trigger" FM_STOP_FILE="$stop" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let releaseOldDelivery = () => {};
const oldDeliveryRelease = new Promise((resolve) => {
  releaseOldDelivery = resolve;
});
let oldDeliveryStarted = false;

function makePi(blockDelivery = false) {
  const handlers = new Map();
  const eventHandlers = new Map();
  let tool = null;
  const prompts = [];
  const pi = {
    on(event, handler) {
      handlers.set(event, handler);
    },
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async (message) => {
      prompts.push(message);
    },
    events: {
      on(event, handler) {
        eventHandlers.set(event, [...(eventHandlers.get(event) ?? []), handler]);
      },
      emit(event, data) {
        if (blockDelivery && event === "fm-branch-supervision:dispatch") {
          oldDeliveryStarted = true;
          data.accept(oldDeliveryRelease);
        }
        for (const handler of eventHandlers.get(event) ?? []) handler(data);
      },
    },
  };
  return { pi, handlers, getTool: () => tool, prompts };
}

function pidAlive(pid) {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

function armRows() {
  if (!existsSync(process.env.FM_ARM_LOG)) return [];
  return readFileSync(process.env.FM_ARM_LOG, "utf8")
    .trim()
    .split(/\n/)
    .filter((row) => row.startsWith("arm "))
    .map((row) => {
      const match = /pid=(\d+) marker=(\S+)/.exec(row);
      return match ? { pid: match[1], marker: match[2] } : { pid: "", marker: "" };
    });
}

function liveArms() {
  return armRows().filter((arm) => arm.pid && arm.marker && existsSync(arm.marker) && pidAlive(arm.pid));
}

async function waitFor(pred, label, attempts = 500) {
  for (let i = 0; i < attempts; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/replacement-race.meta`, "project=/projects/replacement-race\nwindow=fm-replacement-race\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\treplacement-race.status\tsignal: replacement-race actionable outcome\n");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const previous = makePi(true);
mod.default(previous.pi);
const initial = await previous.getTool().execute("initial-arm", {}, undefined, undefined, {});
if (!initial.details?.ok || !String(initial.details.message).includes("started Pi extension arm child")) {
  throw new Error(`initial arm failed: ${JSON.stringify(initial.details)}`);
}
await waitFor(() => liveArms().length === 1, "initial live arm");

writeFileSync(process.env.FM_TRIGGER_FILE, "replacement-race actionable outcome\n");
await waitFor(() => oldDeliveryStarted, "old-session accepted branch delivery");
if (previous.prompts.length !== 0) {
  throw new Error(`accepted old-session branch wake reached main: ${previous.prompts.join(" | ")}`);
}
await waitFor(() => liveArms().length === 1 && armRows().length >= 2, "old-session successor");
writeFileSync(process.env.FM_TRIGGER_FILE, "replacement-successor actionable outcome\n");
await waitFor(() => liveArms().length === 1 && armRows().length === 3, "mid-delivery successor restored before replacement");
const handoffArm = liveArms()[0];

await previous.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
if (!existsSync(handoffArm.marker) || !pidAlive(handoffArm.pid)) {
  throw new Error("replacement shutdown retired the restored predecessor before the new owner committed");
}

const replacement = makePi(false);
const replacementMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=durable-handoff`);
replacementMod.default(replacement.pi);
const replacementStart = replacement.handlers.get("session_start")?.({
  type: "session_start",
  reason: "new",
  previousSessionFile: "/tmp/previous.jsonl",
}, {});
await new Promise((resolve) => setTimeout(resolve, 50));
await waitFor(() => liveArms().length === 1 && armRows().length === 4 && !existsSync(handoffArm.marker), "replacement arm before old delivery settlement");
if (replacement.prompts.some((message) => message.includes("signal: replacement-race actionable outcome"))) {
  throw new Error(`replacement raced the accepted old-session delivery: ${replacement.prompts.join(" | ")}`);
}
writeFileSync(
  `${process.env.FM_HOME}/state/extensions/pi-primary-watch/session-replacement-actionable.json`,
  "{malformed handoff\n",
);
releaseOldDelivery();
await replacementStart;
await waitFor(
  () => replacement.prompts.some((message) => message.includes("signal: replacement-successor actionable outcome")),
  "replacement-session successor actionable delivery",
);
if (replacement.prompts.some((message) => message.includes("signal: replacement-race actionable outcome"))) {
  throw new Error(`settled old-session branch delivery was replayed: ${replacement.prompts.join(" | ")}`);
}
if (replacement.prompts.filter((message) => message.includes("signal: replacement-successor actionable outcome")).length !== 1) {
  throw new Error(`replacement session did not receive exactly one carried successor outcome: ${replacement.prompts.join(" | ")}`);
}
if (!replacement.prompts.some((message) => message.includes("could not clear a delivered replacement-session actionable wake"))) {
  throw new Error(`handoff cleanup failure was not surfaced: ${replacement.prompts.join(" | ")}`);
}
await new Promise((resolve) => setTimeout(resolve, 700));
if (replacement.prompts.filter((message) => message.includes("could not clear a delivered replacement-session actionable wake")).length !== 1) {
  throw new Error(`persistent handoff cleanup failure repeated alerts: ${replacement.prompts.join(" | ")}`);
}
await waitFor(() => liveArms().length === 1 && armRows().length >= 3, "replacement live arm");
const redundant = await replacement.getTool().execute("replacement-redundant", {}, undefined, undefined, {});
if (!redundant.details?.ok || !String(redundant.details.message).includes("unchanged")) {
  throw new Error(`replacement did not retain automatic arm ownership: ${JSON.stringify(redundant.details)}`);
}

await new Promise((resolve) => setTimeout(resolve, 100));
if (liveArms().length !== 1) {
  throw new Error(`old delivery completion disturbed replacement ownership: ${JSON.stringify(liveArms())}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi session replacement must auto-arm and carry an in-flight actionable close: $out"
  [ -z "$out" ] || fail "Pi session-replacement handoff test printed output: $out"
  pass "Pi session replacement auto-arms and carries its in-flight actionable close"
}

test_pi_streaming_followup_is_replayed_after_replacement() {
  local repo home plugin trigger out status
  repo="$TMP_ROOT/pi-streaming-followup-replacement-root"
  home="$TMP_ROOT/pi-streaming-followup-replacement-home"
  trigger="$TMP_ROOT/pi-streaming-followup-replacement.trigger"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
trap 'exit 0' TERM INT
printf 'watcher: started pid=%s\n' "$$"
while :; do
  if [ -e "$FM_TRIGGER_FILE" ]; then
    rm -f "$FM_TRIGGER_FILE"
    printf 'signal: streaming queued actionable outcome\n'
    exit 0
  fi
  sleep 0.02
done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_TRIGGER_FILE="$trigger" node --input-type=module 2>&1 <<'EOF'
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

function makePi() {
  const handlers = new Map();
  const prompts = [];
  let tool = null;
  const pi = {
    on(event, handler) {
      handlers.set(event, handler);
    },
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async (message) => {
      prompts.push(message);
    },
    events: { on() {}, emit() {} },
  };
  return { pi, handlers, prompts, getTool: () => tool };
}

async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const originalMod = await import(pathToFileURL(process.env.PLUGIN).href);
const original = makePi();
originalMod.default(original.pi);
await original.handlers.get("session_start")?.({ type: "session_start", reason: "startup" }, {});
original.handlers.get("agent_start")?.({}, {});
writeFileSync(process.env.FM_TRIGGER_FILE, "trigger\n");
await waitFor(
  () => original.prompts.some((message) => message.includes("signal: streaming queued actionable outcome")),
  "old-session queued follow-up",
);
await original.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});

const replacementMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=streaming-followup`);
const replacement = makePi();
replacementMod.default(replacement.pi);
await replacement.handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
await waitFor(
  () => replacement.prompts.some((message) => message.includes("signal: streaming queued actionable outcome")),
  "replacement-session replay",
);
if (replacement.prompts.filter((message) => message.includes("signal: streaming queued actionable outcome")).length !== 1) {
  throw new Error(`replacement did not replay the unconsumed follow-up exactly once: ${replacement.prompts.join(" | ")}`);
}
replacement.handlers.get("before_agent_start")?.({
  messageType: "custom",
  message: { role: "custom", customType: "fixture", content: replacement.prompts[0], display: true },
}, {});
await replacement.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});

const finalMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=idle-followup`);
const finalSession = makePi();
finalMod.default(finalSession.pi);
const { unlinkSync } = await import("node:fs");
unlinkSync(`${process.env.FM_HOME}/state/.lock`);
await finalSession.handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
if (finalSession.prompts.length !== 0) throw new Error("lockless replacement adopted its handoff early");
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const reclaimed = await finalSession.getTool().execute("reclaimed-arm", {}, undefined, undefined, {});
if (!reclaimed.details?.ok) throw new Error(`reclaimed arm failed: ${JSON.stringify(reclaimed.details)}`);
await waitFor(
  () => finalSession.prompts.some((message) => message.includes("signal: streaming queued actionable outcome")),
  "second replacement replay before idle consumption",
);
if (finalSession.prompts.filter((message) => message.includes("signal: streaming queued actionable outcome")).length !== 1) {
  throw new Error(`second replacement did not replay the idle queued follow-up exactly once: ${finalSession.prompts.join(" | ")}`);
}
finalSession.handlers.get("before_agent_start")?.({ messageType: "user", prompt: finalSession.prompts[0] }, {});
await new Promise((resolve) => setTimeout(resolve, 20));
await finalSession.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
const consumedMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=consumed-user`);
const consumed = makePi();
consumedMod.default(consumed.pi);
await consumed.handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
if (consumed.prompts.length !== 0) throw new Error("a consumed user wake replayed after replacement");
await consumed.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "exit" }, {});
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi replacement must replay a streaming follow-up before consumption"
  [ -z "$out" ] || fail "Pi streaming follow-up replacement test printed output: $out"
  pass "Pi replacement replays a streaming follow-up before consumption"
}

# The 2026-09-02 incident: a wake delivered while main was mid-turn never raised
# before_agent_start, the extension waited for it, and every later actionable
# close was dropped. Continuity must settle on Pi accepting the follow-up, while
# consumption still decides what a replacement replays.
test_pi_streaming_time_delivery_keeps_the_successor_chain() {
  local repo home plugin log trigger out status
  repo="$TMP_ROOT/pi-streaming-chain-root"
  home="$TMP_ROOT/pi-streaming-chain-home"
  log="$TMP_ROOT/pi-streaming-chain.log"
  trigger="$TMP_ROOT/pi-streaming-chain.trigger"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed=%s\n' "$2" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=chain-%s\n' "$$" "$count"
trap 'exit 0' TERM INT
while [ ! -e "$FM_TRIGGER_FILE.$count" ] && [ -e "$0" ]; do sleep 0.02; done
printf 'signal: streaming chain wake %s\n' "$count"
exit 0
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_TRIGGER_FILE="$trigger" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const handlers = new Map();
const prompts = [];
let streaming = false;
let beforeAgentStarts = 0;
const pi = {
  on(event, handler) {
    handlers.set(event, handler);
  },
  registerCommand() {},
  registerTool() {},
  // The real Pi prompt path: a follow-up sent while the agent is streaming is
  // queued for the running run and raises no before_agent_start; only a send
  // to an idle agent starts a run and raises it with the exact text.
  sendUserMessage: async (message) => {
    prompts.push(message);
    if (streaming) return;
    beforeAgentStarts += 1;
    handlers.get("before_agent_start")?.({ messageType: "user", prompt: message }, {});
  },
  events: { on() {}, emit() {} },
};
// The running run reaching a queued follow-up: Pi emits the user message.
const consumeQueued = (message) =>
  handlers.get("message_start")?.({ message: { role: "user", content: [{ type: "text", text: message }] } }, {});
const arms = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").split("\n").filter((row) => row.startsWith("arm=")).length
  : 0;
async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}
const wakes = (text) => prompts.filter((message) => message.includes(text)).length;

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await handlers.get("session_start")?.({ type: "session_start", reason: "startup" }, {});
await waitFor(() => arms() === 1, "first arm");
streaming = true;
writeFileSync(`${process.env.FM_TRIGGER_FILE}.1`, "close\n");
await waitFor(() => prompts.length === 1, "first wake delivered while main streams");
if (wakes("signal: streaming chain wake 1") !== 1) throw new Error(`wrong first wake: ${prompts.join(" | ")}`);
await waitFor(() => arms() === 2, "successor after the streaming-time delivery");
writeFileSync(`${process.env.FM_TRIGGER_FILE}.2`, "close\n");
await waitFor(() => prompts.length === 2, "second wake delivered while main still streams");
if (wakes("signal: streaming chain wake 2") !== 1) throw new Error(`wrong second wake: ${prompts.join(" | ")}`);
await waitFor(() => arms() === 3, "successor after the second streaming-time delivery");
if (beforeAgentStarts !== 0) throw new Error(`streaming follow-ups raised before_agent_start ${beforeAgentStarts} times`);

// Pi 1.2 emits an idle custom-message trigger without prompt. Its content
// matching a queued user wake must not mark that wake consumed.
await handlers.get("before_agent_start")?.({
  type: "before_agent_start",
  messageType: "custom",
  message: {
    role: "custom", customType: "fixture", content: prompts[1],
    display: false, timestamp: Date.now(),
  },
  systemPrompt: "fixture", systemPromptOptions: {},
}, {});
// The run reaches the first queued follow-up; the second is still queued when
// the captain replaces the session, so only the second rides the handoff.
consumeQueued(prompts[0]);
await handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
const handoffPath = `${process.env.FM_HOME}/state/extensions/pi-primary-watch/session-replacement-actionable.json`;
const handoff = JSON.parse(readFileSync(handoffPath, "utf8"));
if (handoff.pending.length !== 1 || handoff.pending[0].delivered || !handoff.pending[0].message.includes("signal: streaming chain wake 2")) {
  throw new Error(`replacement handoff did not carry exactly the unconsumed wake: ${JSON.stringify(handoff)}`);
}
streaming = false;
const replacementMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=streaming-chain`);
replacementMod.default(pi);
await handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
await waitFor(() => prompts.length === 3, "replacement replay of the unconsumed wake");
if (wakes("signal: streaming chain wake 2") !== 2 || wakes("signal: streaming chain wake 1") !== 1) {
  throw new Error(`replacement replayed the wrong wakes: ${prompts.join(" | ")}`);
}
if (beforeAgentStarts !== 1) throw new Error(`idle replay raised before_agent_start ${beforeAgentStarts} times`);
await waitFor(() => arms() === 4, "replacement arm");
await waitFor(() => !existsSync(handoffPath), "consumed replay clears its handoff record");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi streaming-time wake delivery must keep the successor chain and replay only unconsumed wakes"
  [ -z "$out" ] || fail "Pi streaming-time delivery chain test printed output: $out"
  pass "Pi streaming-time wake delivery keeps the successor chain and replays only unconsumed wakes"
}

# A verified successor can die while the wake it was started for is still
# being delivered (a branch turn can take minutes). Its failure close arrives
# while the pipeline is busy, so the ordinary retry path must be deferred to
# the end of that delivery rather than skipped, or the live generation is left
# with no watcher and no retry.
# Issue 7032 restores per-close succession while keeping branch settlement
# serialized. Real arm processes expose the ordering; Pi callbacks are mocked.
test_pi_actionable_closes_restore_while_branch_delivery_is_held() {
  local repo home plugin log trigger out status mode
  mode=${1:-serial}
  repo="$TMP_ROOT/pi-held-branch-$mode-root"
  home="$TMP_ROOT/pi-held-branch-$mode-home"
  log="$TMP_ROOT/pi-held-branch-$mode.log"
  trigger="$TMP_ROOT/pi-held-branch-$mode.close"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
live="$FM_CLOSE_PREFIX.live.$$"
touch "$live"
trap 'rm -f "$live"' EXIT
trap 'exit 0' TERM INT
previous=$(sed -n '1p' "$FM_ARM_LOG.pid" 2>/dev/null || true)
previous_marker=$(sed -n '2p' "$FM_ARM_LOG.pid" 2>/dev/null || true)
printf '%s\n%s\n' "$$" "$live" > "$FM_ARM_LOG.pid"
if [ -n "$previous" ] && [ -f "$previous_marker" ]; then kill -TERM "$previous" 2>/dev/null || true; fi
if [ "$FM_HELD_CLOSE_CASE" = replacement ] && [ "$count" -eq 3 ]; then
  printf 'waiting=3\n' >> "$FM_ARM_LOG"
  while :; do sleep 0.02; done
fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
printf 'ready=%s\n' "$count" >> "$FM_ARM_LOG"
while [ "$count" -ne 1 ] && [ ! -e "$FM_CLOSE_PREFIX.$count" ]; do sleep 0.02; done
printf 'signal: held branch close %s\n' "$count"
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_CLOSE_PREFIX="$trigger" FM_HELD_CLOSE_CASE="$mode" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const handlers = new Map();
const offers = [];
const releases = [];
let tool;
let activeDeliveries = 0;
let maxDeliveries = 0;
let firstSettled = false;
const rows = () => existsSync(process.env.FM_ARM_LOG) ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n") : [];
const arms = () => rows().filter((row) => row.startsWith("arm="));
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(predicate, label) {
  for (let i = 0; i < 500; i += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}; arms=${arms().length} offers=${offers.length}`);
}
const pi = {
  on(event, handler) { handlers.set(event, handler); },
  registerCommand() {},
  registerTool(candidate) { if (candidate.name === "fm_watch_arm_pi") tool = candidate; },
  sendUserMessage: async () => { throw new Error("eligible branch wake unexpectedly fell back to main"); },
  events: {
    on() {},
    emit(event, offer) {
      if (event !== "fm-branch-supervision:dispatch") return;
      offers.push(offer.message);
      activeDeliveries += 1;
      maxDeliveries = Math.max(maxDeliveries, activeDeliveries);
      const index = offers.length;
      const held = new Promise((resolve) => releases.push(resolve));
      offer.accept(held.then(() => {
        activeDeliveries -= 1;
        if (index === 1) firstSettled = true;
      }));
    },
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/held.meta`, "project=/projects/held\nwindow=fm-held\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\theld.status\tsignal: held branch close 1\n");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
const mode = process.env.FM_HELD_CLOSE_CASE;
const expectedOffers = mode === "quit" ? 1 : mode === "replacement" ? 2 : 3;
try {
  await tool.execute("held-initial", {}, undefined, undefined, {});
  await waitFor(() => offers.length === 1 && rows().includes("ready=2"), "delivery A behind ready B");
  writeFileSync(`${process.env.FM_CLOSE_PREFIX}.2`, "close\n");
  if (mode === "replacement") {
    await waitFor(() => rows().includes("waiting=3"), "restoration held on C readiness");
    const predecessor = Number(arms()[2].slice(4));
    await handlers.get("session_shutdown")({ type: "session_shutdown", reason: "new" }, {});
    if (!alive(predecessor)) throw new Error("replacement retired the predecessor before successor commit");
    await handlers.get("session_start")({ type: "session_start", reason: "new" }, {});
    await waitFor(() => !alive(predecessor), "replacement committed before retained C retirement");
  } else {
    await waitFor(() => rows().includes("ready=3"), "ready C while A remains held");
    writeFileSync(`${process.env.FM_CLOSE_PREFIX}.3`, "close\n");
  }
  await waitFor(() => rows().includes("ready=4"), "further successor while A remains held");
  if (firstSettled || offers.length !== 1 || maxDeliveries !== 1) {
    throw new Error(`delivery escaped its hold/serialization: ${JSON.stringify({ firstSettled, offers, maxDeliveries })}`);
  }
  const redundant = await tool.execute("held-manual", {}, undefined, undefined, {});
  if (!redundant.details.ok || !redundant.details.message.includes("unchanged") || arms().length !== 4) {
    throw new Error("manual arm duplicated the held-delivery successor");
  }
  if (mode === "quit") await handlers.get("session_shutdown")({ type: "session_shutdown", reason: "quit" }, {});
  for (let index = 0; index < expectedOffers; index += 1) {
    await waitFor(() => offers.length === index + 1, `serialized delivery ${index + 1}`);
    if (offers[index] !== `signal: held branch close ${index + 1}`) throw new Error(`lost/reordered close: ${offers}`);
    releases[index]();
  }
  await waitFor(() => activeDeliveries === 0, "all admitted deliveries settled");
  await new Promise((resolve) => setTimeout(resolve, 100));
  if (offers.length !== expectedOffers || maxDeliveries !== 1 || arms().length !== 4) throw new Error("duplicate delivery or arm after settlement");
} finally {
  await handlers.get("session_shutdown")({ type: "session_shutdown", reason: "quit" }, {});
  for (const release of releases) release();
  await waitFor(() => arms().every((row) => !alive(Number(row.slice(4)))), "all owned arm PIDs stopped");
}
const afterQuit = await tool.execute("held-after-quit", {}, undefined, undefined, {});
if (afterQuit.details.ok || arms().length !== 4 || offers.length !== expectedOffers) throw new Error("terminal callbacks rearmed or replayed");
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must restore every actionable close while branch delivery remains held: $out"
  [ -z "$out" ] || fail "Pi held-branch test printed output: $out"
  pass "Pi restores successors during held branch delivery with serialized settlement ($mode)"
}

# A close whose delivery waits behind an earlier held delivery must not be
# confirmed against a successor that a later close already replaced. The
# handoff is confirmed inside the continuity operation, while that successor is
# still the live arm, and the delivery reads the cached outcome. Without that,
# the queued close is confirmed against a dead watcher pid and the healthy
# newer successor is reported to main as a restoration failure.
test_pi_repeated_close_under_a_held_delivery_keeps_its_confirmed_handoff() {
  local repo home plugin log trigger out status
  repo="$TMP_ROOT/pi-repeated-close-root"
  home="$TMP_ROOT/pi-repeated-close-home"
  log="$TMP_ROOT/pi-repeated-close.log"
  trigger="$TMP_ROOT/pi-repeated-close.close"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  gen=${2:-} pid=${4:-}
  # The real script checks the named watcher pid before the episode
  # generation, so a successor that a later close already replaced is
  # rejected rather than reported as superseded. A confirmation of a token
  # whose generation no longer matches the current one is superseded.
  if ! kill -0 "$pid" 2>/dev/null; then
    printf 'rejected-dead generation=%s watcher=%s\n' "$gen" "$pid" >> "${FM_ARM_LOG:?}"
    exit 1
  fi
  current=$(cat "${FM_ARM_LOG}.gen" 2>/dev/null || true)
  if [ -n "$current" ] && [ "$current" != "$gen" ]; then
    printf 'superseded generation=%s watcher=%s current=%s\n' "$gen" "$pid" "$current" >> "${FM_ARM_LOG:?}"
    exit 3
  fi
  printf 'confirmed generation=%s watcher=%s\n' "$gen" "$pid" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
live="$FM_CLOSE_PREFIX.live.$$"
touch "$live"
trap 'rm -f "$live"' EXIT
trap 'exit 0' TERM INT
# Each arm carries its own recovery generation and records it as the current
# one, so a confirmation of a token from an earlier arm is a generation
# mismatch rather than an accidental match.
printf 'gen-%s\n' "$count" > "${FM_ARM_LOG}.gen"
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=gen-%s\n' "$$" "$count"
printf 'ready=%s\n' "$count" >> "$FM_ARM_LOG"
while [ "$count" -ne 1 ] && [ ! -e "$FM_CLOSE_PREFIX.$count" ]; do sleep 0.02; done
printf 'signal: repeated close %s\n' "$count"
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_CLOSE_PREFIX="$trigger" FM_WATCH_EXTENSION_LOG_KEEP_LINES=200 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const handlers = new Map();
const offers = [];
const releases = [];
const prompts = [];
let tool;
let activeDeliveries = 0;
let maxDeliveries = 0;
const rows = () => existsSync(process.env.FM_ARM_LOG) ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n") : [];
const arms = () => rows().filter((row) => row.startsWith("arm="));
const confirmations = () => rows().filter((row) => row.startsWith("confirmed generation="));
const rejections = () => rows().filter((row) => row.startsWith("rejected-dead"));
const supersessions = () => rows().filter((row) => row.startsWith("superseded generation="));
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(predicate, label) {
  for (let i = 0; i < 1000; i += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}; rows=${rows().join(" | ")}; extlog=${existsSync(`${process.env.FM_HOME}/state/.watch-extension.log`) ? readFileSync(`${process.env.FM_HOME}/state/.watch-extension.log`, "utf8").replace(/\n/g, " | ") : "none"}`);
}
const pi = {
  on(event, handler) { handlers.set(event, handler); },
  registerCommand() {},
  registerTool(candidate) { if (candidate.name === "fm_watch_arm_pi") tool = candidate; },
  sendUserMessage: async (message) => { prompts.push(message); },
  events: {
    on() {},
    emit(event, offer) {
      if (event !== "fm-branch-supervision:dispatch") return;
      offers.push(offer.message);
      activeDeliveries += 1;
      maxDeliveries = Math.max(maxDeliveries, activeDeliveries);
      const index = offers.length;
      const held = new Promise((resolve) => releases.push(resolve));
      offer.accept(held.then(() => { activeDeliveries -= 1; }));
    },
  },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/held.meta`, "project=/projects/held\nwindow=fm-held\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\theld.status\tsignal: repeated close 1\n");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
try {
  await tool.execute("repeated-initial", {}, undefined, undefined, {});
  await waitFor(() => offers.length === 1 && confirmations().length === 1, "first handoff confirmed");
  // The successor closes while the first delivery is still held, and so does
  // its own successor: each queued close replaces the arm the previous one
  // confirmed.
  writeFileSync(`${process.env.FM_CLOSE_PREFIX}.2`, "close\n");
  await waitFor(() => arms().length === 3 && confirmations().length === 2, "second handoff confirmed");
  writeFileSync(`${process.env.FM_CLOSE_PREFIX}.3`, "close\n");
  await waitFor(() => arms().length === 4 && confirmations().length === 3, "third handoff confirmed");
  // Let the held first delivery settle: the queued closes deliver in order,
  // and each of them releases the next one.
  for (let index = 0; index < 3; index += 1) {
    await waitFor(() => offers.length === index + 1, `serialized delivery ${index + 1}`);
    releases[index]();
  }
  await waitFor(() => offers.length === 3, "every queued close delivered");
  await new Promise((resolve) => setTimeout(resolve, 150));
  if (prompts.length !== 0) {
    throw new Error(`a queued close reached main instead of the branch: ${prompts.join(" | ")}`);
  }
  if (maxDeliveries !== 1) throw new Error(`delivery escaped its serialization: ${maxDeliveries}`);
  if (rejections().length !== 0) {
    throw new Error(`a live handoff was rejected: ${rows().join(" | ")}`);
  }
  if (supersessions().length !== 0) {
    throw new Error(`a live handoff was reported as superseded: ${rows().join(" | ")}`);
  }
  const generations = confirmations().map((row) => row.split(" ")[1]);
  if (generations.join(",") !== "generation=gen-2,generation=gen-3,generation=gen-4") {
    throw new Error(`each close was confirmed against its own successor: ${generations.join(" | ")}`);
  }
  const order = offers.map((message) => message.trim());
  const expected = ["signal: repeated close 1", "signal: repeated close 2", "signal: repeated close 3"];
  if (order.join("|") !== expected.join("|")) {
    throw new Error(`queued closes lost or changed their order: ${order.join(" | ")}`);
  }
} finally {
  await handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "quit" }, {});
  for (const release of releases) release();
  await waitFor(() => arms().every((row) => !alive(Number(row.slice(4)))), "all owned arm PIDs stopped");
}
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must confirm a queued close's handoff while its own successor is still live: $out"
  [ -z "$out" ] || fail "Pi repeated-close test printed output: $out"
  pass "Pi confirms a queued close's handoff inside the continuity operation"
}

# The former after-delivery expectation conflicts with the approved restore
# contract: a verified failure keeps its bounded retry during held delivery.
test_pi_successor_failure_during_delivery_is_retried_after_delivery() {
  local repo home plugin log stop out status
  repo="$TMP_ROOT/pi-successor-dies-mid-delivery-root"
  home="$TMP_ROOT/pi-successor-dies-mid-delivery-home"
  log="$TMP_ROOT/pi-successor-dies-mid-delivery.log"
  stop="$TMP_ROOT/pi-successor-dies-mid-delivery.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
if [ "$count" -eq 1 ]; then
  printf 'signal: wake before the successor dies\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  sleep 0.1
  printf 'watcher: FAILED - successor lost its beacon\n'
  exit 3
fi
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let releaseBranch = () => {};
const branchSettlement = new Promise((resolve) => {
  releaseBranch = resolve;
});
let branchAccepted = false;
let tool = null;
const prompts = [];
const pi = {
  on() {},
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    prompts.push(message);
  },
  events: {
    on() {},
    emit(event, data) {
      if (event !== "fm-branch-supervision:dispatch") return;
      branchAccepted = true;
      data.accept(branchSettlement);
    },
  },
};
const arms = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").split("\n").filter((row) => row.startsWith("arm=")).length
  : 0;
async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
writeFileSync(`${process.env.FM_HOME}/state/mid-delivery.meta`, "project=/projects/mid-delivery\nwindow=fm-mid-delivery\n");
writeFileSync(`${process.env.FM_HOME}/state/.wake-queue`, "1\t1\tsignal\tmid-delivery.status\tsignal: wake before the successor dies\n");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("initial-arm", {}, undefined, undefined, {});
await waitFor(() => branchAccepted, "branch accepted the wake behind a verified successor");
if (arms() !== 2) throw new Error(`expected the verified successor before delivery, got ${arms()} arms`);
// The successor dies while the branch still holds the delivery.
await new Promise((resolve) => setTimeout(resolve, 300));
if (arms() !== 2) throw new Error(`a retry launched while the delivery was still in flight: ${arms()} arms`);
releaseBranch();
await waitFor(() => arms() === 3, "a retry watcher after the delivery settled");
await new Promise((resolve) => setTimeout(resolve, 150));
if (arms() !== 3) throw new Error(`the deferred retry was not single-flight: ${arms()} arms`);
if (prompts.length !== 0) throw new Error(`a bounded retry surfaced a failure prompt: ${prompts.join(" | ")}`);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi must retry a verified successor that failed during wake delivery"
  [ -z "$out" ] || fail "Pi successor-dies-mid-delivery test printed output: $out"
  pass "Pi retries a verified successor that failed during wake delivery once that delivery settles"
}

test_pi_late_retiring_actionable_reaches_replacement() {
  local repo home plugin count out status
  repo="$TMP_ROOT/pi-late-retiring-actionable-root"
  home="$TMP_ROOT/pi-late-retiring-actionable-home"
  count="$TMP_ROOT/pi-late-retiring-actionable.count"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
count=0
[ ! -f "$FM_ARM_COUNT" ] || count=$(cat "$FM_ARM_COUNT")
count=$((count + 1))
printf '%s\n' "$count" > "$FM_ARM_COUNT"
previous=$(cat "$FM_ARM_COUNT.pid" 2>/dev/null || true)
printf '%s\n' "$$" > "$FM_ARM_COUNT.pid"
[ -z "$previous" ] || kill -TERM "$previous" 2>/dev/null || true
late_close() {
  sleep 0.15
  printf 'signal: late retiring actionable outcome\n'
  exit 0
}
trap late_close TERM INT
printf 'watcher: started pid=%s\n' "$$"
while [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_COUNT="$count" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=20 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

function makePi() {
  const handlers = new Map();
  let tool = null;
  const prompts = [];
  const pi = {
    on(event, handler) {
      handlers.set(event, handler);
    },
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async (message) => {
      prompts.push(message);
    },
    events: { on() {}, emit() {} },
  };
  return { pi, handlers, getTool: () => tool, prompts };
}

async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const originalMod = await import(pathToFileURL(process.env.PLUGIN).href);
const original = makePi();
originalMod.default(original.pi);
const armed = await original.getTool().execute("initial-arm", {}, undefined, undefined, {});
if (!armed.details?.ok) throw new Error(`initial arm failed: ${JSON.stringify(armed.details)}`);
await waitFor(() => existsSync(process.env.FM_ARM_COUNT) && readFileSync(process.env.FM_ARM_COUNT, "utf8").trim() === "1", "original arm");
await original.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
writeFileSync(`${process.env.FM_HOME}/state/extensions`, "block late handoff publication\n");
const foreignState = `${process.env.FM_HOME}/foreign-state`;
const { mkdirSync } = await import("node:fs");
mkdirSync(foreignState, { recursive: true });
writeFileSync(`${foreignState}/.lock`, `${process.pid}\n`);
process.env.FM_STATE_OVERRIDE = foreignState;
const foreignMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=foreign-state`);
const foreign = makePi();
foreignMod.default(foreign.pi);
await foreign.handlers.get("session_start")?.({ type: "session_start", reason: "resume" }, {});
await new Promise((resolve) => setTimeout(resolve, 250));
if (foreign.prompts.some((message) => message.includes("signal: late retiring actionable outcome"))) {
  throw new Error(`late old-state outcome crossed into foreign state: ${foreign.prompts.join(" | ")}`);
}
await foreign.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "quit" }, {});
delete process.env.FM_STATE_OVERRIDE;

const replacementMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=late-retiring-close`);
const replacement = makePi();
replacementMod.default(replacement.pi);
await replacement.handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
await waitFor(
  () => replacement.prompts.some((message) => message.includes("signal: late retiring actionable outcome")),
  "late actionable delivery to replacement",
);
const latePrompts = replacement.prompts.filter((message) => message.includes("signal: late retiring actionable outcome"));
if (latePrompts.length !== 1) {
  throw new Error(`replacement did not receive exactly one late outcome: ${replacement.prompts.join(" | ")}`);
}
if (!latePrompts[0].includes("watcher: FAILED - Pi extension could not persist a late replacement-session actionable wake")) {
  throw new Error(`late handoff publication failure was not surfaced: ${latePrompts[0]}`);
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi replacement must receive an actionable close after retirement timeout"
  [ -z "$out" ] || fail "Pi late retiring actionable test printed output: $out"
  pass "Pi replacement receives actionable closes after retirement timeout"
}

test_pi_replacement_tokens_are_process_unique() {
  local repo home plugin count out status
  repo="$TMP_ROOT/pi-replacement-token-uniqueness-root"
  home="$TMP_ROOT/pi-replacement-token-uniqueness-home"
  count="$TMP_ROOT/pi-replacement-token-uniqueness.count"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
count=0
[ ! -f "$FM_ARM_COUNT" ] || count=$(cat "$FM_ARM_COUNT")
count=$((count + 1))
printf '%s\n' "$count" > "$FM_ARM_COUNT"
previous=$(cat "$FM_ARM_COUNT.pid" 2>/dev/null || true)
printf '%s\n' "$$" > "$FM_ARM_COUNT.pid"
[ -z "$previous" ] || kill -TERM "$previous" 2>/dev/null || true
late_close() {
  sleep 0.08
  printf 'signal: module-%s late actionable outcome\n' "$count"
  exit 0
}
trap late_close TERM INT
printf 'watcher: started pid=%s\n' "$$"
while [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_COUNT="$count" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=10 node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

Date.now = () => 1700000000000;

function makePi() {
  const handlers = new Map();
  let tool = null;
  const pi = {
    on(event, handler) {
      handlers.set(event, handler);
    },
    registerCommand() {},
    registerTool(candidate) {
      if (candidate.name === "fm_watch_arm_pi") tool = candidate;
    },
    sendUserMessage: async () => {},
    events: { on() {}, emit() {} },
  };
  return { pi, handlers, getTool: () => tool };
}

async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
for (let moduleIndex = 1; moduleIndex <= 2; moduleIndex += 1) {
  const mod = await import(`${pathToFileURL(process.env.PLUGIN).href}?token-module=${moduleIndex}`);
  const instance = makePi();
  mod.default(instance.pi);
  const armed = await instance.getTool().execute(`arm-${moduleIndex}`, {}, undefined, undefined, {});
  if (!armed.details?.ok) throw new Error(`module ${moduleIndex} arm failed: ${JSON.stringify(armed.details)}`);
  await waitFor(
    () => existsSync(process.env.FM_ARM_COUNT) && Number(readFileSync(process.env.FM_ARM_COUNT, "utf8").trim()) >= moduleIndex,
    `module ${moduleIndex} arm`,
  );
  await instance.handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
}
// Replacement shutdown deliberately retains the established module-2 arm until
// a successor commits. Start that successor so both retiring modules publish
// their late actionable closes under distinct process-wide tokens.
const collectorMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?token-module=collector`);
const collector = makePi();
collectorMod.default(collector.pi);
const collectorArm = await collector.getTool().execute("arm-collector", {}, undefined, undefined, {});
if (!collectorArm.details?.ok) throw new Error(`collector arm failed: ${JSON.stringify(collectorArm.details)}`);
await waitFor(
  () => existsSync(process.env.FM_ARM_COUNT) && Number(readFileSync(process.env.FM_ARM_COUNT, "utf8").trim()) >= 3,
  "collector arm",
);
const handoffPath = `${process.env.FM_HOME}/state/extensions/pi-primary-watch/session-replacement-actionable.json`;
await waitFor(() => existsSync(handoffPath), "replacement handoff");
await waitFor(() => JSON.parse(readFileSync(handoffPath, "utf8")).pending.length === 2, "two distinct handoff outcomes");
const handoff = JSON.parse(readFileSync(handoffPath, "utf8"));
if (new Set(handoff.pending.map((item) => item.token)).size !== 2) {
  throw new Error(`fresh modules reused a replacement token: ${JSON.stringify(handoff)}`);
}
for (const moduleIndex of [1, 2]) {
  if (!handoff.pending.some((item) => item.message.includes(`signal: module-${moduleIndex} late actionable outcome`))) {
    throw new Error(`module ${moduleIndex} outcome was dropped: ${JSON.stringify(handoff)}`);
  }
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi replacement handoff tokens must stay unique across fresh modules"
  [ -z "$out" ] || fail "Pi replacement token uniqueness test printed output: $out"
  pass "Pi replacement handoff tokens stay unique across fresh modules"
}

test_pi_replacement_persistence_failure_keeps_predecessor_until_successor() {
  local repo home plugin count marker out status
  repo="$TMP_ROOT/pi-replacement-persistence-failure-root"
  home="$TMP_ROOT/pi-replacement-persistence-failure-home"
  count="$TMP_ROOT/pi-replacement-persistence-failure.count"
  marker="$TMP_ROOT/pi-replacement-persistence-failure.marker"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
count=0
[ ! -f "$FM_ARM_COUNT" ] || count=$(cat "$FM_ARM_COUNT")
count=$((count + 1))
printf '%s\n' "$count" > "$FM_ARM_COUNT"
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s\n' "$$"
  printf 'signal: persistence failure actionable outcome\n'
  exit 0
fi
previous=$(cat "$FM_CHILD_MARKER" 2>/dev/null || true)
if [ -n "$previous" ] && kill -0 "$previous" 2>/dev/null; then
  kill -TERM "$previous" 2>/dev/null || true
  while kill -0 "$previous" 2>/dev/null; do sleep 0.01; done
fi
cleanup() { rm -f "$FM_CHILD_MARKER"; }
trap cleanup EXIT
trap 'exit 0' TERM INT
printf '%s\n' "$$" > "$FM_CHILD_MARKER"
printf 'watcher: started pid=%s\n' "$$"
while [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_ARM_COUNT="$count" FM_CHILD_MARKER="$marker" node --input-type=module 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const handlers = new Map();
let tool = null;
let deliveryStarted = false;
const prompts = [];
const pi = {
  on(event, handler) {
    handlers.set(event, handler);
  },
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async (message) => {
    deliveryStarted = true;
    prompts.push(message);
  },
  events: { on() {}, emit() {} },
};

async function waitFor(pred, label) {
  for (let i = 0; i < 500; i += 1) {
    if (pred()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timeout waiting for ${label}`);
}

writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
const armed = await tool.execute("initial-arm", {}, undefined, undefined, {});
if (!armed.details?.ok) throw new Error(`initial arm failed: ${JSON.stringify(armed.details)}`);
await waitFor(() => deliveryStarted && existsSync(process.env.FM_CHILD_MARKER), "blocked delivery and successor child");
writeFileSync(`${process.env.FM_HOME}/state/extensions`, "block handoff directory\n");
await handlers.get("session_shutdown")?.({ type: "session_shutdown", reason: "new" }, {});
if (!existsSync(process.env.FM_CHILD_MARKER)) {
  throw new Error("replacement shutdown retired the established predecessor after handoff persistence failed");
}
const { unlinkSync } = await import("node:fs");
unlinkSync(`${process.env.FM_HOME}/state/extensions`);
const replacementMod = await import(`${pathToFileURL(process.env.PLUGIN).href}?replacement=persistence-failure`);
replacementMod.default(pi);
await handlers.get("session_start")?.({ type: "session_start", reason: "new" }, {});
await waitFor(() => prompts.length >= 2, "in-process handoff after persistence failure");
if (!prompts[1].includes("signal: persistence failure actionable outcome")) {
  throw new Error(`replacement lost the in-process actionable outcome: ${prompts.join(" | ")}`);
}
if (!prompts[1].includes("could not persist a replacement-session actionable wake")) {
  throw new Error(`replacement did not surface the persistence failure: ${prompts[1]}`);
}
handlers.get("before_agent_start")?.({ messageType: "user", prompt: prompts[1] }, {});
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi replacement persistence failure must keep its predecessor until a successor commits"
  [ -z "$out" ] || fail "Pi replacement persistence-failure continuity test printed output: $out"
  pass "Pi replacement persistence failure keeps its predecessor until a successor commits"
}

test_pi_process_exit_cleanup_listener_lifecycle() {
  local repo home plugin out status
  repo="$TMP_ROOT/pi-exit-listener-root"
  home="$TMP_ROOT/pi-exit-listener-home"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  : > "$repo/bin/fm-watch-arm.sh"
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" node --input-type=module 2>&1 <<'EOF'
import { pathToFileURL } from "node:url";

const handlers = new Map();
const pi = {
  on(event, handler) {
    handlers.set(event, handler);
  },
  registerCommand() {},
  registerTool() {},
  sendUserMessage: async () => {},
};
const before = process.listenerCount("exit");
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
if (process.listenerCount("exit") !== before + 1) {
  throw new Error("Pi extension did not install exactly one process-exit fallback");
}
await handlers.get("session_shutdown")?.({ type: "session_shutdown" }, {});
if (process.listenerCount("exit") !== before + 1) {
  throw new Error("session_shutdown removed the process-lifetime exit fallback");
}
await handlers.get("session_start")?.({ type: "session_start" }, {});
if (process.listenerCount("exit") !== before + 1) {
  throw new Error("replacement activation duplicated the process-exit fallback");
}
EOF
)
  status=$?
  expect_code 0 "$status" "Pi cleanup fallback listener must remain singular across session replacement"
  [ -z "$out" ] || fail "Pi listener-lifecycle test printed output: $out"
  pass "Pi process-exit cleanup listener remains singular across session replacement"
}

# A case that fails before writing its stop file leaves its arm stub's poller
# behind, reparented away from the case. The stub here is the unguarded shape of
# the pollers that once outlived this suite: only the process-group reap that
# teardown runs can stop it, and once reaped nothing from its root survives.
test_pi_failed_case_poller_is_reaped_as_a_group() {
  local repo stop pid_file out status poller i
  repo="$TMP_ROOT/pi-failed-case-root"
  stop="$TMP_ROOT/pi-failed-case.stop"
  pid_file="$TMP_ROOT/pi-failed-case.poller"
  mkdir -p "$repo/bin"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
(while [ ! -e "$FM_STOP_FILE" ]; do sleep 0.05; done) &
printf '%s\n' "$!" > "$FM_POLLER_PID_FILE"
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(FM_ARM="$repo/bin/fm-watch-arm.sh" FM_STOP_FILE="$stop" FM_POLLER_PID_FILE="$pid_file" node --input-type=module 2>&1 <<'EOF'
import { spawnSync } from "node:child_process";
spawnSync("bash", [process.env.FM_ARM], { stdio: "ignore" });
throw new Error("injected case failure before the stop file");
EOF
)
  status=$?
  [ "$status" -ne 0 ] || fail "the injected case failure did not fail: $out"
  poller=$(cat "$pid_file" 2>/dev/null || true)
  if [ -z "$poller" ] || ! kill -0 "$poller" 2>/dev/null; then
    fail "the failed case left no live poller, so the reap below would prove nothing"
  fi
  pi_reap_process_groups
  i=0
  while [ "$i" -lt 20 ] && kill -0 "$poller" 2>/dev/null; do
    sleep 0.1
    i=$((i + 1))
  done
  if kill -0 "$poller" 2>/dev/null; then
    kill -KILL "$poller" 2>/dev/null || true
    fail "the process-group reap left the failed case's poller pid $poller running"
  fi
  out=$(ps -eo ppid=,args= 2>/dev/null | awk -v root="$repo/" '$1 == 1 && index($0, root)')
  [ -z "$out" ] || fail "orphans from the failed case survived the reap: $out"
  pass "Pi teardown reaps a failed case's orphaned poller as a process group"
}

# Run last: after the teardown reap, nothing this suite started may be left
# running under init from its temporary root.
test_pi_suite_leaves_no_orphaned_processes() {
  local out
  pi_reap_process_groups
  out=$(ps -eo ppid=,args= 2>/dev/null | awk -v root="$TMP_ROOT/" '$1 == 1 && index($0, root)')
  [ -z "$out" ] || fail "processes from this suite's temporary root outlived the teardown reap: $out"
  pass "Pi suite leaves no orphaned process from its temporary root"
}

test_pi_process_exit_cleanup_stops_arm_child() {
  local repo home plugin cleanup_log pid_file out status pid i
  repo="$TMP_ROOT/pi-process-exit-root"
  home="$TMP_ROOT/pi-process-exit-home"
  cleanup_log="$TMP_ROOT/pi-process-exit-cleaned"
  pid_file="$TMP_ROOT/pi-process-exit-child.pid"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  install_pi_watch_extension_fixture "$repo"
  plugin="$repo/.pi/extensions/fm-primary-pi-watch.ts"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
trap 'printf "%s\n" "$$" >> "$FM_CLEANUP_LOG"; exit 0' TERM
printf '%s\n' "$$" > "$FM_CHILD_PID_FILE"
while [ -e "$0" ]; do sleep 1; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" FM_HOME="$home" FM_ROOT_OVERRIDE="$repo" FM_CLEANUP_LOG="$cleanup_log" FM_CHILD_PID_FILE="$pid_file" node --input-type=module 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

let tool = null;
const handlers = new Map();
const pi = {
  on(event, handler) {
    handlers.set(event, handler);
  },
  registerCommand() {},
  registerTool(candidate) {
    if (candidate.name === "fm_watch_arm_pi") tool = candidate;
  },
  sendUserMessage: async () => {},
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default(pi);
await tool.execute("tool-call-exit", {}, undefined, undefined, {});
for (let i = 0; i < 250 && !existsSync(process.env.FM_CHILD_PID_FILE); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_CHILD_PID_FILE)) throw new Error("arm child did not start");
const firstChild = readFileSync(process.env.FM_CHILD_PID_FILE, "utf8").trim();
await handlers.get("session_shutdown")?.({ type: "session_shutdown" }, {});
await handlers.get("session_start")?.({ type: "session_start" }, {});
await tool.execute("tool-call-replacement", {}, undefined, undefined, {});
for (let i = 0; i < 250; i += 1) {
  const currentChild = readFileSync(process.env.FM_CHILD_PID_FILE, "utf8").trim();
  if (currentChild !== firstChild) break;
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (readFileSync(process.env.FM_CHILD_PID_FILE, "utf8").trim() === firstChild) {
  throw new Error("replacement arm child did not start");
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "Pi process exit must run the watcher cleanup fallback"
  [ -z "$out" ] || fail "Pi process-exit cleanup test printed output: $out"
  pid=$(cat "$pid_file")
  i=0
  while [ "$i" -lt 250 ] && ! grep -qx "$pid" "$cleanup_log" 2>/dev/null; do
    sleep 0.02
    i=$((i + 1))
  done
  grep -qx "$pid" "$cleanup_log" 2>/dev/null || fail "Pi process-exit fallback did not deliver TERM to the replacement arm child"
  if kill -0 "$pid" 2>/dev/null; then
    kill -TERM "$pid" 2>/dev/null || true
    fail "Pi arm child $pid survived process-exit cleanup"
  fi
  pass "Pi process-exit cleanup stops the attached arm child"
}

test_opencode_plugin_package_boundary_is_explicit_esm() {
  local fixture plugin out status
  fixture="$TMP_ROOT/opencode-esm-boundary/.opencode"
  plugin="$fixture/plugins/fm-primary-watch-arm.js"
  mkdir -p "$fixture/plugins/lib"
  printf '%s\n' '{"dependencies":{}}' > "$fixture/package.json"
  cp "$ROOT/.opencode/plugins/package.json" "$fixture/plugins/package.json"
  cp "$ROOT/.opencode/plugins/fm-primary-watch-arm.js" "$plugin"
  cp "$ROOT/.opencode/plugins/lib/fm-operational-input.js" "$fixture/plugins/lib/fm-operational-input.js"
  cp "$ROOT/.opencode/plugins/lib/fm-opencode2.js" "$fixture/plugins/lib/fm-opencode2.js"
  out=$(PLUGIN="$plugin" node --input-type=module 2>&1 <<'EOF'
import { pathToFileURL } from "node:url";
await import(pathToFileURL(process.env.PLUGIN).href);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode plugin must import beneath an explicit ESM package boundary"
  [ -z "$out" ] || fail "OpenCode ESM boundary import printed output: $out"
  pass "OpenCode plugins have an explicit ESM boundary even under a typeless parent package"
}

test_opencode_primary_watch_plugin_uses_effective_state_home() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-effective-state-root"
  home="$TMP_ROOT/opencode-effective-state-home"
  log="$TMP_ROOT/opencode-effective-state.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'home=%s root=%s\n' "${FM_HOME:-}" "${FM_ROOT_OVERRIDE:-}" >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" node 2>&1 <<'EOF'
import { existsSync, readFileSync, realpathSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const client = { session: { promptAsync: async () => {} } };
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm did not run");
  process.exit(1);
}
const text = readFileSync(process.env.FM_ARM_LOG, "utf8");
const expectedRoot = realpathSync(process.env.WORKTREE);
if (!text.includes(`home=${process.env.FM_HOME}`) || !text.includes(`root=${expectedRoot}`)) {
  console.error(text);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode watch plugin must use FM_HOME state outside the repo root"
  [ -z "$out" ] || fail "OpenCode effective-state test printed output: $out"
  pass "OpenCode watcher plugin uses the effective FM_HOME state"
}

test_opencode2_watch_plugin_arms_on_interrupted_turn_but_not_shutdown() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode2-terminal-root"
  home="$TMP_ROOT/opencode2-terminal-home"
  log="$TMP_ROOT/opencode2-terminal.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'armed\n' >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  # The OpenCode 2.0.x plugin context carries the project only as
  # ctx.location.project.directory, so this fixture deliberately omits every
  # other directory field.
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" node 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const queue = [];
let wake = null;
const push = (event) => { queue.push(event); if (wake) { wake(); wake = null; } };
async function* stream() {
  for (;;) {
    while (queue.length) yield queue.shift();
    await new Promise((resolve) => { wake = resolve; });
  }
}
const ctx = {
  location: { project: { directory: process.env.WORKTREE } },
  event: { subscribe: () => stream() },
  session: { prompt: async () => {} },
};
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default.setup(ctx);
push({ type: "session.execution.interrupted", data: { sessionID: "ses-shutdown", reason: "shutdown" } });
await sleep(1000);
if (existsSync(process.env.FM_ARM_LOG)) {
  console.error("a shutdown terminal event armed the watcher");
  process.exit(1);
}
push({ type: "session.execution.interrupted", data: { sessionID: "ses-root" } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) await sleep(20);
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("an interrupted turn did not arm the watcher");
  process.exit(1);
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode 2 watch plugin must arm on an interrupted turn and ignore shutdown: $out"
  [ -z "$out" ] || fail "OpenCode 2 terminal-event test printed output: $out"
  pass "OpenCode 2 watch plugin arms on an interrupted turn from the project location and ignores shutdown"
}

test_opencode2_sessionstart_nudge_prompts_with_flat_session_shape() {
  local plugin repo home out status
  plugin="$ROOT/.opencode/plugins/fm-primary-sessionstart-nudge.js"
  repo="$TMP_ROOT/opencode2-nudge-root"
  home="$TMP_ROOT/opencode2-nudge-home"
  mkdir -p "$repo/bin" "$home/state"
  git init -q "$repo"
  cat > "$repo/bin/fm-sessionstart-nudge.sh" <<'SH'
#!/usr/bin/env bash
printf 'NUDGE_TEXT\n'
SH
  chmod +x "$repo/bin/fm-sessionstart-nudge.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" node 2>&1 <<'EOF'
import { pathToFileURL } from "node:url";

const calls = [];
async function* stream() {
  yield { type: "session.created", data: { sessionID: "ses-1" } };
  await new Promise(() => {});
}
const ctx = {
  location: { project: { directory: process.env.WORKTREE } },
  event: { subscribe: () => stream() },
  session: { prompt: async (arg) => { calls.push(arg); } },
};
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default.setup(ctx);
for (let i = 0; i < 250 && calls.length === 0; i += 1) await new Promise((r) => setTimeout(r, 20));
const first = calls[0];
if (!first || first.sessionID !== "ses-1" || first.text !== "NUDGE_TEXT") {
  console.error(JSON.stringify(calls));
  process.exit(1);
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode 2 session-start nudge must prompt with { sessionID, text }: $out"
  pass "OpenCode 2 session-start nudge resolves the project location and prompts with the flat session shape"
}

test_opencode2_seatbelts_block_only_the_shell_tool() {
  local repo out status plugin owner
  repo="$TMP_ROOT/opencode2-seatbelt-root"
  mkdir -p "$repo/bin"
  git init -q "$repo"
  for owner in fm-cd-pretool-check.sh fm-arm-pretool-check.sh; do
    cat > "$repo/bin/$owner" <<'SH'
#!/usr/bin/env bash
[ "${1:-}" = --command ] || exit 0
case "${2:-}" in
  *DENY_ME*) printf 'seatbelt denied\n' >&2; exit 2 ;;
esac
exit 0
SH
    chmod +x "$repo/bin/$owner"
  done
  for plugin in fm-primary-cd-check.js fm-primary-pretool-check.js; do
    out=$(PLUGIN="$ROOT/.opencode/plugins/$plugin" WORKTREE="$repo" node 2>&1 <<'EOF'
import { pathToFileURL } from "node:url";

let hook = null;
const ctx = {
  location: { project: { directory: process.env.WORKTREE } },
  tool: { hook: (name, fn) => { if (name === "execute.before") hook = fn; } },
};
const mod = await import(pathToFileURL(process.env.PLUGIN).href);
mod.default.setup(ctx);
const call = (tool, command) => hook({ tool, sessionID: "ses-1", id: "call-1", input: { command } });
let blocked = false;
try {
  await call("shell", "echo DENY_ME");
} catch (error) {
  blocked = String(error.message).includes("seatbelt denied");
}
if (!blocked) {
  console.error("the shell tool was not blocked");
  process.exit(1);
}
await call("shell", "echo allowed");
await call("mcp_runner", "echo DENY_ME");
await call("read", "echo DENY_ME");
process.exit(0);
EOF
)
    status=$?
    expect_code 0 "$status" "OpenCode 2 $plugin must block the shell tool and never a non-shell tool carrying a command: $out"
  done
  pass "OpenCode 2 seatbelts block only the shell tool, never a non-shell or MCP tool carrying a command"
}

test_opencode2_prompt_session_never_resends_after_a_failed_attempt() {
  local out status
  out=$(LIB="$ROOT/.opencode/plugins/lib/fm-opencode2.js" node 2>&1 <<'EOF'
import { pathToFileURL } from "node:url";

const { promptSession } = await import(pathToFileURL(process.env.LIB).href);
const calls = [];
const ctx = { session: { prompt: async (arg) => { calls.push(["prompt", arg]); throw new Error("timeout after delivery"); } } };
const client = { session: { promptAsync: async (arg) => { calls.push(["promptAsync", arg]); } } };
let threw = false;
try {
  await promptSession(ctx, client, "ses-1", "wake");
} catch {
  threw = true;
}
if (!threw || calls.length !== 1 || calls[0][1].sessionID !== "ses-1" || calls[0][1].text !== "wake") {
  console.error(JSON.stringify(calls));
  process.exit(1);
}
calls.length = 0;
await promptSession(null, client, "ses-2", "wake");
if (calls.length !== 1 || calls[0][1].path.id !== "ses-2" || calls[0][1].body.parts[0].text !== "wake") {
  console.error(JSON.stringify(calls));
  process.exit(1);
}
process.exit(0);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode promptSession must send once and never retry another shape: $out"
  pass "OpenCode promptSession sends one prompt shape and never resends after a failed attempt"
}

test_opencode_primary_watch_plugin_sources_effective_config() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-effective-config-root"
  home="$TMP_ROOT/opencode-effective-config-home"
  log="$TMP_ROOT/opencode-effective-config.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  printf 'export FM_POLL=7\n' > "$home/config/x-mode.env"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'poll=%s\n' "${FM_POLL:-missing}" >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const client = { session: { promptAsync: async () => {} } };
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm did not run");
  process.exit(1);
}
const text = readFileSync(process.env.FM_ARM_LOG, "utf8");
if (!text.includes("poll=7")) {
  console.error(text);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode watch plugin must source FM_HOME config outside the repo root"
  [ -z "$out" ] || fail "OpenCode effective-config test printed output: $out"
  pass "OpenCode watcher plugin sources the effective config"
}

test_opencode_primary_watch_plugin_requires_session_lock() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-lock-root"
  home="$TMP_ROOT/opencode-lock-home"
  log="$TMP_ROOT/opencode-lock.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" node 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const client = { session: { promptAsync: async () => {} } };
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
const event = { event: { type: "session.idle", properties: { sessionID: "session-test" } } };
writeFileSync(`${process.env.FM_HOME}/state/.lock`, "999999\n");
await hooks.event(event);
// The hook starts its attempt without awaiting it, and the plugin answers a
// second attempt from the one already in flight. Join that attempt through the
// coordinator rather than waiting a fixed span: refusing an unowned lock walks
// git and ps probes that can outlast any such span, and the owned-lock event
// below would then be answered from the refusal instead of arming.
const refusal = await globalThis.__firstmateOpenCodeWatchArm.ensureArmed("session-test", client);
if (refusal !== "read-only") {
  console.error(`expected a read-only refusal without the session lock, got ${refusal}`);
  process.exit(1);
}
if (existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm ran without owning the session lock");
  process.exit(1);
}
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event(event);
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm did not run after the session lock matched");
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode watch plugin must arm only when this session owns the fleet lock"
  [ -z "$out" ] || fail "OpenCode session-lock test printed output: $out"
  pass "OpenCode watcher plugin requires session lock ownership"
}

test_opencode_watch_arm_coordinator_respects_primary_scope() {
  local plugin base repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  base="$TMP_ROOT/opencode-coordinator-base"
  repo="$TMP_ROOT/opencode-coordinator-wt"
  home="$TMP_ROOT/opencode-coordinator-home"
  log="$TMP_ROOT/opencode-coordinator.log"
  fm_git_worktree "$base" "$repo" fm/opencode-coordinator
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  : > "$repo/AGENTS.md"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" node 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const client = { session: { promptAsync: async () => {} } };
await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
const status = await globalThis.__firstmateOpenCodeWatchArm.ensureArmed("session-test", client);
await new Promise((resolve) => setTimeout(resolve, 120));
if (status !== "not-primary") {
  console.error(`expected not-primary, got ${status}`);
  process.exit(1);
}
if (existsSync(process.env.FM_ARM_LOG)) {
  console.error("coordinator armed from a linked worktree");
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode watch coordinator must keep primary scope checks in the shared arm path"
  [ -z "$out" ] || fail "OpenCode coordinator-scope test printed output: $out"
  pass "OpenCode watcher coordinator respects primary scope"
}

test_opencode_primary_watch_plugin_rearms_after_wake() {
  local plugin repo home log stop out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-rearm-root"
  home="$TMP_ROOT/opencode-rearm-home"
  log="$TMP_ROOT/opencode-rearm.log"
  stop="$TMP_ROOT/opencode-rearm.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'arm=%s predecessor=%s\n' "$$" "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^arm=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic wake\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompts = 0;
let rowsAtPrompt = 0;
let releasePrompt = () => {};
const promptBlocked = new Promise((resolve) => {
  releasePrompt = resolve;
});
const client = {
  session: {
    promptAsync: async () => {
      rowsAtPrompt = existsSync(process.env.FM_ARM_LOG)
        ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").filter((row) => row.startsWith("arm=")).length
        : 0;
      prompts += 1;
      await promptBlocked;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
const event = { event: { type: "session.idle", properties: { sessionID: "session-test" } } };
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event(event);
for (let i = 0; i < 250; i += 1) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  if (rows.length >= 2 && prompts >= 1) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
const armRows = rows.filter((row) => row.startsWith("arm="));
if (armRows.length !== 2) throw new Error(`expected one successor arm, got ${armRows.length}: ${rows.join(" | ")}`);
if (prompts !== 1) throw new Error(`expected one blocked wake prompt, got ${prompts}`);
if (rowsAtPrompt !== 2) throw new Error(`wake prompt began before successor establishment (${rowsAtPrompt} arm rows)`);
if (!/predecessor=[0-9]+/.test(armRows[1])) throw new Error(`successor did not receive predecessor identity: ${armRows[1]}`);
if (!rows.some((row) => row.startsWith("confirmed generation=fixture-generation"))) {
  throw new Error(`handling delivery was not confirmed before the follow-up: ${rows.join(" | ")}`);
}
await new Promise((resolve) => setTimeout(resolve, 100));
const stableRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (stableRows.filter((row) => row.startsWith("arm=")).length !== 2) {
  throw new Error(`blocked follow-up started extra arm work: ${stableRows.join(" | ")}`);
}
if (stableRows.filter((row) => row.startsWith("confirmed ")).length !== 1) {
  throw new Error(`successful prompt delivery was not confirmed exactly once: ${stableRows.join(" | ")}`);
}
releasePrompt();
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
EOF
  )
  status=$?
  [ "$status" -eq 0 ] || fail "OpenCode watch plugin must start one successor before wake prompt delivery settles: $out"
  [ -z "$out" ] || fail "OpenCode rearm test printed output: $out"
  pass "OpenCode watcher plugin starts one successor before wake prompt delivery settles"
}

# An opted-in home spawns the supervision host in the arm's place; its
# streamed status line drives readiness and the handling handoff, and a
# handed-back wake is delivered with every host line and the away note.
test_opencode_primary_watch_plugin_runs_the_supervision_host() {  # [away|quiet]
  local kind=${1:-away} plugin repo home log stop out status f
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-host-root-$kind"
  home="$TMP_ROOT/opencode-host-home-$kind"
  log="$TMP_ROOT/opencode-host-$kind.log"
  stop="$TMP_ROOT/opencode-host-$kind.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  if [ "$kind" = quiet ]; then
    # Quiet mode's record is a present captain (bin/fm-afk-contract.sh AWAY OR
    # QUIET): the plugin asks the record owner, so the same handback carries no
    # away note.
    for f in fm-afk-contract.sh fm-classify-lib.sh fm-timeout-lib.sh; do cp "$ROOT/bin/$f" "$repo/bin/$f"; done
    FM_HOME="$home" FM_AFK_MODE=quiet "$ROOT/bin/fm-afk-contract.sh" enter --words 'keep routine wakes off my main' >/dev/null 2>&1 \
      || fail "fixture: could not record quiet mode"
  else
    : > "$home/state/.afk-contract"
  fi
  : > "$home/config/supervision-host"
  cp "$ROOT/bin/fm-supervision-engine-lib.sh" "$repo/bin/"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --handling-delivered ]; then
  printf 'confirmed generation=%s watcher=%s\n' "$2" "$4" >> "${FM_ARM_LOG:?}"
  exit 0
fi
printf 'plain-arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
exit 1
SH
  cat > "$repo/bin/fm-supervision-host.sh" <<'SH'
#!/usr/bin/env bash
printf 'host=%s args=%s primary=%s predecessor=%s\n' "$$" "$*" "${FM_SUPERVISION_HOST_PRIMARY:-}" \
  "${FM_WATCH_PREDECESSOR_ARM_PID:-none}" >> "${FM_ARM_LOG:?}"
count=$(grep -c '^host=' "$FM_ARM_LOG")
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  sleep 0.3
  printf 'signal: synthetic wake\nsupervision-host: the away session could not take this wake: fixture; this wake is yours\nsupervision-host: outcome 1 for demo [captain]: fixture\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh) recovery-generation=fixture-generation\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh" "$repo/bin/fm-supervision-host.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" RECORD_KIND="$kind" node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const prompts = [];
const client = { session: { promptAsync: async (request) => { prompts.push(request.body.parts[0].text); } } };
const hooks = await mod.FmPrimaryWatchArm({ client, directory: process.env.WORKTREE, worktree: process.env.WORKTREE });
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 400 && prompts.length < 1; i += 1) await new Promise((resolve) => setTimeout(resolve, 10));
const rows = existsSync(process.env.FM_ARM_LOG) ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n") : [];
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
if (rows.some((row) => row.startsWith("plain-arm="))) throw new Error(`an opted-in home ran the plain arm: ${rows.join(" | ")}`);
const hosts = rows.filter((row) => row.startsWith("host="));
if (hosts.length !== 2) throw new Error(`expected the host and one successor host, got: ${rows.join(" | ")}`);
if (!hosts.every((row) => / args=park --restart primary=opencode /.test(row))) throw new Error(`the host must run as 'park --restart' with the opencode pin: ${hosts.join(" | ")}`);
if (!/predecessor=[0-9]+$/.test(hosts[1])) throw new Error(`the successor host did not receive the closed host as its predecessor: ${hosts[1]}`);
if (!rows.some((row) => row === "confirmed generation=fixture-generation watcher=" + hosts[1].replace(/^host=([0-9]+).*/, "$1"))) {
  throw new Error(`the handling handoff was not confirmed against the successor host's cycle: ${rows.join(" | ")}`);
}
if (prompts.length !== 1) throw new Error(`expected one wake prompt, got ${prompts.length}`);
for (const needle of [
  "signal: synthetic wake",
  "supervision-host: the away session could not take this wake: fixture; this wake is yours",
  "supervision-host: outcome 1 for demo [captain]: fixture",
]) {
  if (!prompts[0].includes(needle)) throw new Error(`the wake prompt lacks '${needle}': ${prompts[0]}`);
}
const awayNote = prompts[0].includes("not from the captain: it is not a return");
if (process.env.RECORD_KIND === "quiet" ? awayNote : !awayNote) {
  throw new Error(`the away note must appear exactly under an away record (${process.env.RECORD_KIND}): ${prompts[0]}`);
}
EOF
  )
  status=$?
  [ "$status" -eq 0 ] || fail "OpenCode watch plugin must run the supervision host on an opted-in home ($kind record): $out"
  [ -z "$out" ] || fail "OpenCode host test printed output: $out"
  pass "OpenCode watcher plugin runs the supervision host on an opted-in home and relays every host line ($kind record)"
}

test_opencode_pre_ready_actionable_close_preserves_its_successor() {
  local plugin repo home log release retired stop out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-pre-ready-actionable-root"
  home="$TMP_ROOT/opencode-pre-ready-actionable-home"
  log="$TMP_ROOT/opencode-pre-ready-actionable.log"
  release="$TMP_ROOT/opencode-pre-ready-actionable.release"
  retired="$TMP_ROOT/opencode-pre-ready-actionable.retired"
  stop="$TMP_ROOT/opencode-pre-ready-actionable.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: original wake\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  printf 'signal: pre-ready successor wake\n'
  trap 'printf "retired\\n" > "${FM_PRE_READY_RETIRED_FILE:?}"; exit 0' TERM INT
  while [ ! -e "$FM_PRE_READY_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_PRE_READY_RELEASE_FILE="$release" FM_PRE_READY_RETIRED_FILE="$retired" FM_STOP_FILE="$stop" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const prompts = [];
const client = {
  session: {
    promptAsync: async (request) => {
      prompts.push(request.body.parts[0].text);
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 500; i += 1) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  if (rows.length >= 2 && prompts.some((message) => message.includes("original wake"))) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (rows.length !== 2) throw new Error(`pre-ready successor was replaced before its close: ${rows.join(" | ")}`);
if (!prompts.some((message) => message.includes("original wake"))) throw new Error(`original actionable wake was not delivered: ${prompts.join(" | ")}`);
await new Promise((resolve) => setTimeout(resolve, 150));
if (existsSync(process.env.FM_PRE_READY_RETIRED_FILE)) throw new Error("pre-ready actionable successor was retired before its close");
writeFileSync(process.env.FM_PRE_READY_RELEASE_FILE, "release\n");
for (let i = 0; i < 500; i += 1) {
  const successorRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
  if (successorRows.length >= 3 && prompts.some((message) => message.includes("pre-ready successor wake"))) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const stableRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (stableRows.length !== 3) throw new Error(`pre-ready close did not create exactly one successor: ${stableRows.join(" | ")}`);
if (!prompts.some((message) => message.includes("pre-ready successor wake"))) throw new Error(`pre-ready actionable wake was not delivered: ${prompts.join(" | ")}`);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode must retire the pre-ready arm, not its actionable successor"
  [ -z "$out" ] || fail "OpenCode pre-ready actionable test printed output: $out"
  pass "OpenCode pre-ready actionable close preserves its successor"
}

test_opencode_hung_successor_falls_back_to_typed_wake() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-hung-successor-root"
  home="$TMP_ROOT/opencode-hung-successor-home"
  log="$TMP_ROOT/opencode-hung-successor.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic wake\n'
  exit 0
fi
trap 'exit 0' TERM INT
while [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_OPENCODE_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompt = "";
let rowsAtPrompt = 0;
const client = {
  session: {
    promptAsync: async (request) => {
      prompt += request.body.parts[0].text;
      rowsAtPrompt = existsSync(process.env.FM_ARM_LOG)
        ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").length
        : 0;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
// Three unready successors each cost the full readiness budget, so wait well
// past their sum. The wait ends as soon as the wake lands.
for (let i = 0; i < 1500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 4) throw new Error(`expected one successor plus two retries, got ${rows.length}: ${rows.join(" | ")}`);
if (rowsAtPrompt !== 4) throw new Error(`wake arrived before restoration exhausted (${rowsAtPrompt} arm rows)`);
if (!prompt.includes("signal: synthetic wake")) throw new Error(`original wake was lost: ${prompt}`);
if (!prompt.includes("could not restore watcher continuity after 2 retries")) throw new Error(`missing typed restoration failure: ${prompt}`);
await new Promise((resolve) => setTimeout(resolve, 100));
const stableRows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (stableRows.length !== 4) throw new Error(`single-flight recovery launched ${stableRows.length} arms`);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode must deliver the actionable wake after bounded hung-successor recovery"
  [ -z "$out" ] || fail "OpenCode hung-successor test printed output: $out"
  pass "OpenCode hung successor falls back to one typed actionable wake"
}

test_opencode_unretired_successor_falls_back_without_retry() {
  local plugin repo home log release out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-unretired-successor-root"
  home="$TMP_ROOT/opencode-unretired-successor-home"
  log="$TMP_ROOT/opencode-unretired-successor.log"
  release="$TMP_ROOT/opencode-unretired-successor.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
if [ -f "$FM_ARM_LOG" ]; then
  count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
else
  count=0
fi
if [ "$count" -eq 0 ]; then
  printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: synthetic wake\n'
  exit 0
fi
trap '' TERM INT
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.1; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_RELEASE_FILE="$release" FM_OPENCODE_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=20 FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompt = "";
let rowsAtPrompt = 0;
const client = {
  session: {
    promptAsync: async (request) => {
      prompt += request.body.parts[0].text;
      rowsAtPrompt = existsSync(process.env.FM_ARM_LOG)
        ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n").length
        : 0;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 500 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 2) throw new Error(`unretired arm overlapped a retry: ${rows.join(" | ")}`);
if (rowsAtPrompt !== 2) throw new Error(`wake arrived after an overlapping retry (${rowsAtPrompt} arm rows)`);
if (!prompt.includes("signal: synthetic wake")) throw new Error(`original wake was lost: ${prompt}`);
if (!prompt.includes("unready successor arm did not exit within 20ms")) throw new Error(`missing unretired-arm failure: ${prompt}`);
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
await new Promise((resolve) => setTimeout(resolve, 80));
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode must fall back without overlapping an unretired successor"
  [ -z "$out" ] || fail "OpenCode unretired-successor test printed output: $out"
  pass "OpenCode unretired successor falls back without an overlapping retry"
}

test_opencode_late_unretired_close_resumes_supervision() {
  local kind plugin repo home log ready retired release stop out status
  for kind in actionable non-actionable; do
    plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
    repo="$TMP_ROOT/opencode-late-$kind-root"
    home="$TMP_ROOT/opencode-late-$kind-home"
    log="$TMP_ROOT/opencode-late-$kind.log"
    ready="$TMP_ROOT/opencode-late-$kind.ready"
    retired="$TMP_ROOT/opencode-late-$kind.retired"
    release="$TMP_ROOT/opencode-late-$kind.release"
    stop="$TMP_ROOT/opencode-late-$kind.stop"
    mkdir -p "$repo/bin" "$home/state" "$home/config"
    git init -q "$repo"
    : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
    : > "$home/state/task.meta"
    cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then
  printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
  printf 'signal: original wake\n'
  exit 0
fi
if [ "$count" -eq 2 ]; then
  trap 'printf "retired\\n" > "${FM_UNRETIRED_RETIRE_FILE:?}"' TERM INT
  printf 'ready\n' > "${FM_UNRETIRED_READY_FILE:?}"
  while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
  [ "$FM_LATE_KIND" = actionable ] && printf 'signal: late wake\n'
  exit 0
fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
    chmod +x "$repo/bin/fm-watch-arm.sh"
    out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_UNRETIRED_READY_FILE="$ready" FM_UNRETIRED_RETIRE_FILE="$retired" FM_RELEASE_FILE="$release" FM_STOP_FILE="$stop" FM_LATE_KIND="$kind" FM_OPENCODE_ARM_READY_TIMEOUT_MS="$ARM_READY_TIMEOUT_MS" FM_WATCH_ARM_RETIRE_TIMEOUT_MS=20 FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
const prompts = [];
const client = {
  session: {
    promptAsync: async (request) => {
      prompts.push(request.body.parts[0].text);
    },
  },
};
const rows = () => existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
async function waitFor(predicate, message) {
  for (let i = 0; i < 500; i += 1) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(message);
}
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
await waitFor(
  () => existsSync(process.env.FM_UNRETIRED_READY_FILE),
  "unretired successor did not enter its retirement wait",
);
await waitFor(() => prompts.length >= 1, "original fallback was not delivered");
await waitFor(
  () => existsSync(process.env.FM_UNRETIRED_RETIRE_FILE),
  "unretired successor was not asked to retire before fallback",
);
if (rows().length !== 2) throw new Error(`unretired arm overlapped before fallback: ${rows().join(" | ")}`);
if (!prompts[0]?.includes("original wake")) throw new Error(`missing original fallback: ${prompts.join(" | ")}`);
writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
for (let i = 0; i < 500; i += 1) {
  if (rows().length >= 3 && (process.env.FM_LATE_KIND !== "actionable" || prompts.some((message) => message.includes("late wake")))) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
if (rows().length !== 3) throw new Error(`late close did not restore one successor: ${rows().join(" | ")}`);
if (process.env.FM_LATE_KIND === "actionable") {
  if (prompts.length !== 2 || !prompts[1].includes("late wake")) throw new Error(`late actionable close was not delivered: ${prompts.join(" | ")}`);
} else if (prompts.length !== 1) {
  throw new Error(`late non-actionable close sent an extra wake: ${prompts.join(" | ")}`);
}
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
await new Promise((resolve) => setTimeout(resolve, 80));
EOF
)
    status=$?
    expect_code 0 "$status" "OpenCode late $kind close must remain supervised after fallback"
    [ -z "$out" ] || fail "OpenCode late-$kind test printed output: $out"
  done
  pass "OpenCode late unretired closes resume classified supervision"
}

test_opencode_empty_close_retries_instead_of_disappearing() {
  local plugin repo home log stop out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-empty-close-root"
  home="$TMP_ROOT/opencode-empty-close-home"
  log="$TMP_ROOT/opencode-empty-close.log"
  stop="$TMP_ROOT/opencode-empty-close.stop"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
count=$(wc -l < "$FM_ARM_LOG" | tr -d '[:space:]')
if [ "$count" -eq 1 ]; then exit 0; fi
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
trap 'exit 0' TERM INT
while [ ! -e "$FM_STOP_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_STOP_FILE="$stop" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompts = 0;
const client = {
  session: {
    promptAsync: async () => {
      prompts += 1;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250; i += 1) {
  const rows = existsSync(process.env.FM_ARM_LOG)
    ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
    : [];
  if (rows.length >= 2) break;
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
if (rows.length !== 2) throw new Error(`clean empty close was ignored: ${rows.join(" | ")}`);
if (prompts !== 0) throw new Error(`restored transient close surfaced ${prompts} failure prompts`);
writeFileSync(process.env.FM_STOP_FILE, "stop\n");
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode clean empty close must trigger a bounded continuity retry"
  [ -z "$out" ] || fail "OpenCode empty-close retry test printed output: $out"
  pass "OpenCode clean empty close triggers a bounded continuity retry"
}

test_opencode_established_empty_close_honors_retry_limit() {
  local plugin repo home log out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-established-empty-close-root"
  home="$TMP_ROOT/opencode-established-empty-close-home"
  log="$TMP_ROOT/opencode-established-empty-close.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
printf 'watcher: started pid=%s (beacon fresh)\n' "$$"
exit 0
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_WATCH_REARM_RETRY_BASE_MS=5 FM_WATCH_REARM_RETRY_MAX_MS=10 FM_WATCH_REARM_RETRY_LIMIT=2 node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompt = "";
const client = {
  session: {
    promptAsync: async (request) => {
      prompt += request.body.parts[0].text;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !prompt; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const rows = existsSync(process.env.FM_ARM_LOG)
  ? readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n")
  : [];
if (rows.length !== 3) throw new Error(`retry limit launched ${rows.length} arm cycles: ${rows.join(" | ")}`);
if (!prompt.includes("after 2 retries")) throw new Error(`retry exhaustion was not surfaced: ${prompt}`);
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode established clean closes must honor the continuity retry limit"
  [ -z "$out" ] || fail "OpenCode established-empty-close retry test printed output: $out"
  pass "OpenCode established clean closes stop at the configured retry limit"
}

test_opencode_actionable_close_rechecks_session_lock() {
  local plugin repo home log release out status
  plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  repo="$TMP_ROOT/opencode-close-lock-root"
  home="$TMP_ROOT/opencode-close-lock-home"
  log="$TMP_ROOT/opencode-close-lock.log"
  release="$TMP_ROOT/opencode-close-lock.release"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm=%s\n' "$$" >> "${FM_ARM_LOG:?}"
while [ ! -e "$FM_RELEASE_FILE" ] && [ -e "$0" ]; do sleep 0.02; done
printf 'signal: lock handoff\n'
SH
  chmod +x "$repo/bin/fm-watch-arm.sh"
  out=$(PLUGIN="$plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_RELEASE_FILE="$release" node 2>&1 <<'EOF'
import { spawn } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const mod = await import(pathToFileURL(process.env.PLUGIN).href);
let prompt = "";
const client = {
  session: {
    promptAsync: async (request) => {
      prompt += request.body.parts[0].text;
    },
  },
};
const hooks = await mod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
const lock = `${process.env.FM_HOME}/state/.lock`;
writeFileSync(lock, `${process.pid}\n`);
const eventPromise = hooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 10));
}
const other = spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
try {
  writeFileSync(lock, `${other.pid}\n`);
  writeFileSync(process.env.FM_RELEASE_FILE, "release\n");
  await eventPromise;
  for (let i = 0; i < 250 && !prompt.includes("no longer owns the lock"); i += 1) {
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  const rows = readFileSync(process.env.FM_ARM_LOG, "utf8").trim().split("\n");
  if (rows.length !== 1) throw new Error(`successor launched after lock loss: ${rows.join(" | ")}`);
  if (!prompt.includes("no longer owns the lock")) throw new Error(`missing lock-loss failure: ${prompt}`);
} finally {
  other.kill("SIGTERM");
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode close handler must verify session-lock ownership before successor launch"
  [ -z "$out" ] || fail "OpenCode close lock test printed output: $out"
  pass "OpenCode close handler verifies session-lock ownership before successor launch"
}

test_opencode_watch_arm_coordinates_with_turnend_guard() {
  local arm_plugin guard_plugin repo home log guard_log out status
  arm_plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  guard_plugin="$ROOT/.opencode/plugins/fm-primary-turnend-guard.js"
  repo="$TMP_ROOT/opencode-coordinate-root"
  home="$TMP_ROOT/opencode-coordinate-home"
  log="$TMP_ROOT/opencode-coordinate-arm.log"
  guard_log="$TMP_ROOT/opencode-coordinate-guard.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'arm\n' >> "${FM_ARM_LOG:?}"
printf 'watcher: started pid=1 (beacon fresh)\n'
SH
  cat > "$repo/bin/fm-turnend-guard.sh" <<'SH'
#!/usr/bin/env bash
printf 'guard\n' >> "${FM_GUARD_LOG:?}"
printf 'guard should not run\n' >&2
exit 2
SH
  chmod +x "$repo/bin/fm-watch-arm.sh" "$repo/bin/fm-turnend-guard.sh"
  out=$(ARM_PLUGIN="$arm_plugin" GUARD_PLUGIN="$guard_plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_GUARD_LOG="$guard_log" node 2>&1 <<'EOF'
import { existsSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const armMod = await import(pathToFileURL(process.env.ARM_PLUGIN).href);
const guardMod = await import(pathToFileURL(process.env.GUARD_PLUGIN).href);
let promptBody = "";
const client = {
  session: {
    promptAsync: async (request) => {
      promptBody = request.body.parts[0].text;
    },
  },
};
await armMod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
const guardHooks = await guardMod.FmPrimaryTurnendGuard({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await guardHooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_ARM_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm did not run");
  process.exit(1);
}
if (existsSync(process.env.FM_GUARD_LOG)) {
  console.error("turn-end guard ran before the watch arm could establish supervision");
  process.exit(1);
}
if (promptBody) {
  console.error(`unexpected prompt: ${promptBody}`);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode turn-end guard must let the auto-arm plugin establish supervision first"
  [ -z "$out" ] || fail "OpenCode coordination test printed output: $out"
  pass "OpenCode watcher plugin coordinates with the turn-end guard"
}

test_opencode_healthy_arm_output_does_not_suppress_guard() {
  local arm_plugin guard_plugin repo home log guard_log out status
  arm_plugin="$ROOT/.opencode/plugins/fm-primary-watch-arm.js"
  guard_plugin="$ROOT/.opencode/plugins/fm-primary-turnend-guard.js"
  repo="$TMP_ROOT/opencode-external-healthy-root"
  home="$TMP_ROOT/opencode-external-healthy-home"
  log="$TMP_ROOT/opencode-external-healthy-arm.log"
  guard_log="$TMP_ROOT/opencode-external-healthy-guard.log"
  mkdir -p "$repo/bin" "$home/state" "$home/config"
  git init -q "$repo"
  : > "$repo/AGENTS.md"
  cp "$ROOT/bin/fm-supervision-lib.sh" "$repo/bin/fm-supervision-lib.sh"
  : > "$home/state/task.meta"
  cat > "$repo/bin/fm-watch-arm.sh" <<'SH'
#!/usr/bin/env bash
printf 'args=%s\n' "$*" >> "${FM_ARM_LOG:?}"
printf 'watcher: healthy pid=1 (beacon 0s)\n'
SH
  cat > "$repo/bin/fm-turnend-guard.sh" <<'SH'
#!/usr/bin/env bash
printf 'guard\n' >> "${FM_GUARD_LOG:?}"
printf 'guard ran after external healthy watcher\n' >&2
exit 2
SH
  chmod +x "$repo/bin/fm-watch-arm.sh" "$repo/bin/fm-turnend-guard.sh"
  out=$(ARM_PLUGIN="$arm_plugin" GUARD_PLUGIN="$guard_plugin" WORKTREE="$repo" FM_HOME="$home" FM_ARM_LOG="$log" FM_GUARD_LOG="$guard_log" node 2>&1 <<'EOF'
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const armMod = await import(pathToFileURL(process.env.ARM_PLUGIN).href);
const guardMod = await import(pathToFileURL(process.env.GUARD_PLUGIN).href);
let promptBody = "";
const client = {
  session: {
    promptAsync: async (request) => {
      promptBody = request.body.parts[0].text;
    },
  },
};
await armMod.FmPrimaryWatchArm({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
const guardHooks = await guardMod.FmPrimaryTurnendGuard({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
writeFileSync(`${process.env.FM_HOME}/state/.lock`, `${process.pid}\n`);
await guardHooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
for (let i = 0; i < 250 && !existsSync(process.env.FM_GUARD_LOG); i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 20));
}
if (!existsSync(process.env.FM_ARM_LOG)) {
  console.error("watch arm did not run");
  process.exit(1);
}
if (!readFileSync(process.env.FM_ARM_LOG, "utf8").includes("args=--restart")) {
  console.error("watch arm was not asked to restart into an owned child");
  process.exit(1);
}
if (!existsSync(process.env.FM_GUARD_LOG)) {
  console.error("turn-end guard was suppressed by an external healthy watcher");
  process.exit(1);
}
if (!promptBody.includes("TURN WOULD END BLIND")) {
  console.error(`missing blind-turn prompt: ${promptBody}`);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode watch plugin must not treat external healthy output as an owned arm"
  [ -z "$out" ] || fail "OpenCode external-healthy test printed output: $out"
  pass "OpenCode healthy arm output does not suppress the turn-end guard"
}

# Both OpenCode plugin writes to a child's stdin can fail with EPIPE, because
# the child is free to exit without reading. An unhandled stdin error is a
# thrown 'error' event that takes the whole host process down with it. Here the
# guard's own blind-turn text is larger than a pipe buffer, so the write to an
# encoder that exits without reading cannot complete: the guard must report the
# encoder's refusal by staying silent, not by killing the session.
test_opencode_turnend_guard_survives_an_encoder_that_never_reads_stdin() {
  local guard_plugin repo guard_log out status
  guard_plugin="$ROOT/.opencode/plugins/fm-primary-turnend-guard.js"
  repo="$TMP_ROOT/opencode-guard-encoder-root"
  guard_log="$TMP_ROOT/opencode-guard-encoder-guard.log"
  mkdir -p "$repo/bin"
  cat > "$repo/bin/fm-turnend-guard.sh" <<'SH'
#!/usr/bin/env bash
printf 'guard\n' >> "${FM_GUARD_LOG:?}"
printf 'watcher: FAILED - %s\n' "$(head -c 200000 /dev/zero | tr '\0' 'x')" >&2
exit 2
SH
  cat > "$repo/bin/fm-operational-input.sh" <<'SH'
#!/usr/bin/env bash
printf 'operational-input: refused\n' >&2
exit 1
SH
  chmod +x "$repo/bin/fm-turnend-guard.sh" "$repo/bin/fm-operational-input.sh"
  out=$(GUARD_PLUGIN="$guard_plugin" WORKTREE="$repo" FM_GUARD_LOG="$guard_log" node 2>&1 <<'EOF'
import { existsSync } from "node:fs";
import { pathToFileURL } from "node:url";

const guardMod = await import(pathToFileURL(process.env.GUARD_PLUGIN).href);
let prompts = 0;
const client = { session: { promptAsync: async () => { prompts += 1; } } };
const guardHooks = await guardMod.FmPrimaryTurnendGuard({
  client,
  directory: process.env.WORKTREE,
  worktree: process.env.WORKTREE,
});
await guardHooks.event({ event: { type: "session.idle", properties: { sessionID: "session-test" } } });
if (!existsSync(process.env.FM_GUARD_LOG)) {
  console.error("turn-end guard did not run");
  process.exit(1);
}
if (prompts !== 0) {
  console.error(`guard prompted ${prompts} times despite an encoder that refused the input`);
  process.exit(1);
}
EOF
)
  status=$?
  expect_code 0 "$status" "OpenCode turn-end guard must survive an encoder that never reads its stdin ($out)"
  [ -z "$out" ] || fail "OpenCode guard encoder test printed output: $out"
  pass "OpenCode turn-end guard survives an encoder that never reads stdin"
}

test_pi_extension_reports_external_healthy_watcher
test_pi_tool_returns_agent_tool_result
test_pi_redundant_tool_call_is_owned_noop
test_pi_scheduled_retry_call_is_owned_noop
test_pi_actionable_close_starts_single_successor_before_delivery
test_pi_actionable_output_waits_for_predecessor_close
test_pi_dead_ready_successor_is_retried_before_delivery
test_pi_successor_exit_with_held_pipe_schedules_retry
test_pi_actionable_line_draining_after_exit_stays_actionable
test_pi_branch_offer_owns_actionable_wake
test_pi_branch_offer_flags_heartbeat
test_pi_heartbeat_is_not_ridden_into_main_by_a_co_present_check
test_pi_main_only_check_classes_stay_on_main
test_pi_captain_held_signal_stays_on_main
test_pi_unread_pending_reply_forces_later_stale_alias_to_main
test_pi_distinct_files_mixed_batch_routes_whole_batch_to_main
test_pi_heartbeat_is_not_ridden_into_main_by_a_co_present_needs_decision
test_pi_heartbeat_restoration_failure_stays_on_main
test_pi_watcher_failure_never_offered_to_branch
test_pi_away_record_collapses_eligibility_and_keeps_vetoes_on_main
test_pi_handling_delivery_failure_is_typed_once
test_pi_confirm_failure_retires_arm_with_distinct_watcher_pid
test_pi_confirm_failure_spares_a_newer_arm
test_pi_superseded_delivery_has_no_rejection_appendix
test_pi_superseded_delivery_is_offered_to_branch
test_pi_extension_log_stays_off_unless_opted_in
test_pi_repair_starts_fresh_arm_over_dead_child
test_pi_scheduled_retry_starts_fresh_arm_over_dead_child
test_pi_deferred_close_starts_fresh_arm_over_dead_child
test_pi_failed_case_poller_is_reaped_as_a_group
test_pi_hung_successor_falls_back_to_typed_wake
test_pi_unretired_successor_falls_back_without_retry
test_pi_late_unretired_close_resumes_supervision
test_pi_empty_close_retries_instead_of_disappearing
test_pi_established_empty_close_honors_retry_limit
test_pi_actionable_close_rechecks_session_lock
test_pi_arm_distinguishes_session_lock_ownership
test_pi_arm_reads_a_windows_tagged_session_lock
test_pi_extension_keeps_marker_of_live_ancestor_session
test_pi_session_transition_generation_owner
test_pi_session_replacement_carries_inflight_actionable_close
test_pi_streaming_followup_is_replayed_after_replacement
test_pi_streaming_time_delivery_keeps_the_successor_chain
test_pi_actionable_closes_restore_while_branch_delivery_is_held
test_pi_actionable_closes_restore_while_branch_delivery_is_held replacement
test_pi_actionable_closes_restore_while_branch_delivery_is_held quit
test_pi_repeated_close_under_a_held_delivery_keeps_its_confirmed_handoff
test_pi_successor_failure_during_delivery_is_retried_after_delivery
test_pi_late_retiring_actionable_reaches_replacement
test_pi_replacement_tokens_are_process_unique
test_pi_replacement_persistence_failure_keeps_predecessor_until_successor
test_pi_process_exit_cleanup_listener_lifecycle
test_pi_process_exit_cleanup_stops_arm_child
test_opencode_plugin_package_boundary_is_explicit_esm
test_opencode_primary_watch_plugin_uses_effective_state_home
test_opencode2_watch_plugin_arms_on_interrupted_turn_but_not_shutdown
test_opencode2_sessionstart_nudge_prompts_with_flat_session_shape
test_opencode2_seatbelts_block_only_the_shell_tool
test_opencode2_prompt_session_never_resends_after_a_failed_attempt
test_opencode_primary_watch_plugin_sources_effective_config
test_opencode_primary_watch_plugin_requires_session_lock
test_opencode_watch_arm_coordinator_respects_primary_scope
test_opencode_primary_watch_plugin_rearms_after_wake
test_opencode_primary_watch_plugin_runs_the_supervision_host
test_opencode_primary_watch_plugin_runs_the_supervision_host quiet
test_opencode_pre_ready_actionable_close_preserves_its_successor
test_opencode_hung_successor_falls_back_to_typed_wake
test_opencode_unretired_successor_falls_back_without_retry
test_opencode_late_unretired_close_resumes_supervision
test_opencode_empty_close_retries_instead_of_disappearing
test_opencode_established_empty_close_honors_retry_limit
test_opencode_actionable_close_rechecks_session_lock
test_opencode_watch_arm_coordinates_with_turnend_guard
test_opencode_healthy_arm_output_does_not_suppress_guard
test_opencode_turnend_guard_survives_an_encoder_that_never_reads_stdin
test_pi_suite_leaves_no_orphaned_processes
