#!/usr/bin/env bash
# tests/fm-tmux-agent-liveness.test.sh - portable regression for the tmux
# agent-liveness classifier (bin/backends/tmux.sh).
#
# It runs REAL processes in a REAL tmux server on a private socket (`-L`), and
# needs no harness and no credentials, so it runs everywhere CI runs tmux. The
# live per-harness counterpart is tests/fm-harness-liveness-drift-live-e2e.test.sh.
#
# The defect it exists for: a harness that rewrites its own process title made
# `#{pane_current_command}` report a version string, the classifier could not
# attribute the pane, and supervision lost the agent. The version-string case
# below carries the proof that the verdict never depends on a single name
# surface: it drives the two sources apart on purpose and asserts that
# divergence, so it cannot go quietly vacuous. tmux and `ps -o comm=` read
# different name surfaces, and which one a given construction blinds differs
# between macOS and Linux, so every case asserts only the platform-independent
# property that the verdict itself is correct.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

fail() { printf 'not ok - %s\n' "$1" >&2; cleanup_all; exit 1; }
pass() { printf 'ok - %s\n' "$1"; }

command -v tmux >/dev/null 2>&1 || { echo "skip: tmux not found"; exit 0; }

REAL_TMUX=$(command -v tmux)
SOCKET="fm-liveness-$$"
LAB=$(mktemp -d "${TMPDIR:-/tmp}/fm-liveness.XXXXXX")
SESSION=liveness

cleanup_all() {
  "$REAL_TMUX" -L "$SOCKET" kill-server >/dev/null 2>&1 || true
  [ -n "${LAB:-}" ] && rm -rf "$LAB"
  fm_test_cleanup
}
trap cleanup_all EXIT

# A `tmux` shim on PATH so bin/backends/tmux.sh's bare `tmux` calls reach the
# private socket and never touch the host's real sessions.
mkdir -p "$LAB/shim" "$LAB/bin" "$LAB/bin/claude" "$LAB/bin/decoy" "$LAB/wt"
cat > "$LAB/shim/tmux" <<SH
#!/usr/bin/env bash
exec "$REAL_TMUX" -L "$SOCKET" "\$@"
SH
chmod +x "$LAB/shim/tmux"
PATH="$LAB/shim:$PATH"
export PATH

# Stand-in "harness" binaries: each is a symlink named after the harness whose
# target is fm_agent_standin's long-running native process (tests/lib.sh owns
# why it is never a copy and never a host `sleep` that dispatches on its name).
# The symlink name is what the kernel records as the executable identity, which
# is exactly the signal under test.
STANDIN_BIN=$(fm_agent_standin "$LAB/standin") || {
  echo "skip: no long-running stand-in binary survives a rename (multicall coreutils, no C compiler)"
  exit 0
}
CC_BIN=$(command -v cc 2>/dev/null || command -v gcc 2>/dev/null || true)
ln -s "$STANDIN_BIN" "$LAB/bin/claude-link"
ln -s "$STANDIN_BIN" "$LAB/bin/pi"
ln -s "$STANDIN_BIN" "$LAB/bin/notaharness"
# omp (Oh My Pi) is a single binary whose live process name is the bare word
# `omp`; the two decoys are the substrings an unanchored glob would misread.
ln -s "$STANDIN_BIN" "$LAB/bin/omp"
ln -s "$STANDIN_BIN" "$LAB/bin/ompd"
ln -s "$STANDIN_BIN" "$LAB/bin/comp"
# Command Code sets its process title to the bare word `command-code`; the decoy
# merely contains it.
ln -s "$STANDIN_BIN" "$LAB/bin/command-code"
ln -s "$STANDIN_BIN" "$LAB/bin/command-code-helper"
# Hermes's own launcher is argv[0] `hermes`; the decoy merely contains it.
ln -s "$STANDIN_BIN" "$LAB/bin/hermes"
ln -s "$STANDIN_BIN" "$LAB/bin/hermes-helper"
# muse's installed binary is muse-bin-<version>: the launcher execs it, so the
# version is the LIVE process name and it changes on every auto-update. Unlike
# Claude Code's version-named binary there is no `muse` path component to fall
# back on (~/.local/bin/muse-bin-<version>), so the executable name is the ONLY
# signal, and `muse` alone is a common English fragment that must not widen into
# a substring match. The last two names are the decoys that would be misread.
ln -s "$STANDIN_BIN" "$LAB/bin/muse-bin-0.1.0-R708.1"
ln -s "$STANDIN_BIN" "$LAB/bin/musescore"
ln -s "$STANDIN_BIN" "$LAB/bin/amuse"
ln -s "$STANDIN_BIN" "$LAB/bin/muse-binary"
ln -s "$STANDIN_BIN" "$LAB/bin/muse-bind"

# A launcher whose own process identity is a bare shell, running the harness as
# a child in the same foreground process group - the shape the real Pi Launcher
# path takes, and the one where trusting a single name source can produce a
# false `dead`.
cat > "$LAB/bin/agent-launcher" <<SH
#!/bin/sh
"$LAB/bin/pi" 900 &
wait
SH
chmod +x "$LAB/bin/agent-launcher"

# shellcheck source=/dev/null
. "$ROOT/bin/fm-backend.sh"
fm_backend_source tmux || fail "fm_backend_source tmux failed"

# The idle window names its shell explicitly rather than letting tmux fall back
# to `default-shell`, which is whoever runs the suite. An operator's login shell
# runs that operator's configuration, and a prompt or update hook that spawns a
# helper puts a non-shell process in this pane's FOREGROUND process group - the
# one surface the classifier reads - so the idle case below saw `ambiguous`
# instead of `dead` on exactly the runs where such a helper overlapped it. A
# bare `/bin/sh`, the same shell the background case already execs, is idle
# because nothing configured it, which is what that case means to assert.
"$REAL_TMUX" -L "$SOCKET" new-session -d -s "$SESSION" -n idle -c "$LAB/wt" -- /bin/sh \
  || fail "could not start the private tmux server"

# Run the pane's process DIRECTLY as the window command rather than typing into
# a shell, so no case depends on interactive shell readiness.
new_window() {  # <name> <cmd...>
  local name=$1
  shift
  "$REAL_TMUX" -L "$SOCKET" new-window -d -t "$SESSION:" -n "$name" -c "$LAB/wt" -- "$@" \
    || fail "could not create window $name"
}

wait_for_state() {  # <target> <expected> [tries]
  local target=$1 expected=$2 tries=${3:-100} got i=0
  while [ "$i" -lt "$tries" ]; do
    got=$(fm_backend_agent_state tmux "$target")
    [ "$got" = "$expected" ] && return 0
    sleep 0.1
    i=$((i + 1))
  done
  printf 'last verdict for %s was %s (expected %s); title=%s comms=[%s]\n' \
    "$target" "${got:-<none>}" "$expected" \
    "$(fm_backend_tmux_current_command "$target")" \
    "$(fm_backend_tmux_foreground_comms "$target" | tr '\n' ' ')" >&2
  return 1
}

# Does the tmux current-command source, on its own, name a verified harness?
title_classifies_agent() {  # <target>
  local name
  name=$(fm_backend_tmux_current_command "$1" 2>/dev/null)
  [ "$(fm_agent_process_classify_name "$name")" = agent ]
}

# Does the foreground-process-group identity, including argv[0], name one?
comms_classify_agent() {  # <target>
  local name
  while IFS= read -r name; do
    [ -n "$name" ] || continue
    [ "$(fm_agent_process_classify_name "$name")" = agent ] && return 0
  done <<EOF
$(fm_backend_tmux_foreground_comms "$1")
EOF
  while IFS= read -r name; do
    [ -n "$name" ] || continue
    [ "$(fm_agent_process_classify_name '' "$name")" = agent ] && return 0
  done <<EOF
$(fm_backend_tmux_foreground_argv0s "$1")
EOF
  return 1
}

# The core anti-brittleness assertion: the two name sources must genuinely
# DISAGREE for this case, so a verdict of alive proves the surviving source
# carried it. Without this the divergence cases could silently go vacuous.
assert_sources_disagree() {  # <target> <label>
  local t=0 c=0
  title_classifies_agent "$1" && t=1
  comms_classify_agent "$1" && c=1
  [ $((t + c)) -eq 1 ] || fail \
    "$2: the two name sources were expected to disagree, but title=$t comms=$c (title='$(fm_backend_tmux_current_command "$1")' comms='$(fm_backend_tmux_foreground_comms "$1" | tr '\n' ' ')')"
}

# --- a harness-named foreground process -------------------------------------
# Invoking the symlink by its harness name proves the ordinary positive path
# with a real process. macOS exposes different names for the symlink through
# tmux and ps, while Linux can expose the symlink name through both, so the
# version-string case below owns the cross-platform divergence assertion.

new_window agent "$LAB/bin/claude-link" 900
wait_for_state "$SESSION:agent" alive \
  || fail "a running harness-named foreground process must classify alive"
pass "tmux liveness: a harness-named foreground process classifies alive"

# --- muse's version-suffixed binary name ------------------------------------
# A muse crewmate pane misclassified here reads as a dead endpoint, so a healthy
# worker would be torn down or relaunched. The decoys below are what keep the
# fix from being a substring match that claims unrelated programs.

new_window muse "$LAB/bin/muse-bin-0.1.0-R708.1" 900
wait_for_state "$SESSION:muse" alive \
  || fail "muse's version-suffixed binary name must classify alive"
pass "tmux liveness: muse's version-suffixed muse-bin-<version> classifies alive"

for decoy in musescore amuse muse-binary muse-bind; do
  new_window "decoy-$decoy" "$LAB/bin/$decoy" 900
  wait_for_state "$SESSION:decoy-$decoy" ambiguous \
    || fail "'$decoy' merely contains 'muse' and must not classify as a live agent pane"
done
pass "tmux liveness: unrelated muse-containing command names stay ambiguous"

# --- omp's bare binary name -------------------------------------------------
# omp (Oh My Pi) runs as a single binary whose live process name is exactly
# `omp`, with no path component to fall back on, so the anchored name is the
# only signal and the two decoys prove it never widens into a substring match.

new_window omp "$LAB/bin/omp" 900
wait_for_state "$SESSION:omp" alive \
  || fail "omp's bare binary name must classify alive"
pass "tmux liveness: omp's bare binary name classifies alive"

for decoy in ompd comp; do
  new_window "decoy-$decoy" "$LAB/bin/$decoy" 900
  wait_for_state "$SESSION:decoy-$decoy" ambiguous \
    || fail "'$decoy' merely contains 'omp' and must not classify as a live agent pane"
done
pass "tmux liveness: unrelated omp-containing command names stay ambiguous"

new_window command-code "$LAB/bin/command-code" 900
wait_for_state "$SESSION:command-code" alive \
  || fail "Command Code's anchored process name must classify alive"
new_window decoy-command-code-helper "$LAB/bin/command-code-helper" 900
wait_for_state "$SESSION:decoy-command-code-helper" ambiguous \
  || fail "'command-code-helper' merely contains Command Code's name and must not classify as a live agent pane"
pass "tmux liveness: Command Code's anchored process name classifies alive; a containing name stays ambiguous"

# --- a version name blinds one source ---------------------------------------
# Giving a genuine harness-named executable the version-string argv[0] that
# Claude Code 2.1.220 reports drives the two sources apart on both supported
# platforms and proves the surviving source carries the verdict. This needs a
# real executable file rather than a symlink, because macOS takes the title
# from the resolved target's name, so it is skipped where no C compiler exists.

if [ -n "$CC_BIN" ] &&
  printf '%s\n' '#include <unistd.h>' 'int main(void){for(;;)sleep(60);return 0;}' > "$LAB/spin.c" &&
  "$CC_BIN" -o "$LAB/bin/claude/2.1.220" "$LAB/spin.c" 2>/dev/null &&
  "$CC_BIN" -o "$LAB/bin/decoy/2.1.220" "$LAB/spin.c" 2>/dev/null; then
  new_window titled "$LAB/bin/claude/2.1.220"
  wait_for_state "$SESSION:titled" alive \
    || fail "a version-named executable under a harness install path must classify alive"
  assert_sources_disagree "$SESSION:titled" "version-string process name"
  pass "tmux liveness: a version-named executable under a harness install path classifies alive"

  new_window path-decoy "$LAB/bin/decoy/2.1.220"
  wait_for_state "$SESSION:path-decoy" ambiguous \
    || fail "a version-named executable without a whole harness path component must stay ambiguous"
  pass "tmux liveness: a version-named executable under a decoy path stays ambiguous"
else
  echo "skip: no C compiler, so the version-string process-name case cannot build its executable"
fi

# --- neither source names a harness: no invented agent ----------------------

new_window unknown bash -c "exec -a 2.1.220 '$LAB/bin/notaharness' 900"
wait_for_state "$SESSION:unknown" ambiguous \
  || fail "a foreground process no name source attributes must stay ambiguous"
pass "tmux liveness: a process neither name source attributes stays ambiguous rather than inventing an agent"

# --- Hermes's Python bootstrap and same-group Node TUI child -----------------
# Neither process name identifies the harness on the reported git install.
# The first script argument, not a prompt or the Python -c payload, owns it.
PYTHON_BIN=$(command -v python3 2>/dev/null || true)
NODE_BIN=$(command -v node 2>/dev/null || true)
if [ -n "$PYTHON_BIN" ] && [ -n "$NODE_BIN" ]; then
  mkdir -p "$LAB/.hermes/hermes-agent/ui-tui/dist" "$LAB/unrelated"
  printf 'setInterval(() => {}, 1000);\n' > "$LAB/.hermes/hermes-agent/ui-tui/dist/entry.js"
  cp "$LAB/.hermes/hermes-agent/ui-tui/dist/entry.js" "$LAB/unrelated/entry.js"
  bootstrap='import os, subprocess, sys; child = subprocess.Popen([sys.argv[1], "--expose-gc", sys.argv[2]]); open(sys.argv[3], "w").write(str(child.pid)); child.wait()'
  for shape in native unrelated; do
    script="$LAB/.hermes/hermes-agent/ui-tui/dist/entry.js"
    [ "$shape" = native ] || script="$LAB/unrelated/entry.js"
    target="$SESSION:hermes-$shape"
    new_window "hermes-$shape" env -u NODE_OPTIONS -u NODE_PATH "$PYTHON_BIN" -I -c "$bootstrap" "$NODE_BIN" "$script" "$LAB/$shape.pid"
    child_pid=
    for _ in $(seq 1 100); do
      [ -s "$LAB/$shape.pid" ] && child_pid=$(cat "$LAB/$shape.pid") && break
      sleep 0.1
    done
    [ -n "$child_pid" ] || fail "Hermes $shape bootstrap did not start its Node child"
    pane_pid=$("$REAL_TMUX" -L "$SOCKET" display-message -p -t "$target" '#{pane_pid}')
    parent_pgid=$(ps -p "$pane_pid" -o pgid= | tr -d ' ')
    child_pgid=$(ps -p "$child_pid" -o pgid= | tr -d ' ')
    [ -n "$parent_pgid" ] && [ "$parent_pgid" = "$child_pgid" ] \
      || fail "Hermes $shape parent and child must share their process group"
    foreground_pids=$(fm_backend_tmux_foreground_pids "$target")
    printf '%s\n' "$foreground_pids" | grep -Fxq "$pane_pid" \
      || fail "Hermes $shape Python bootstrap must be foreground"
    printf '%s\n' "$foreground_pids" | grep -Fxq "$child_pid" \
      || fail "Hermes $shape Node child must be foreground"
    if title_classifies_agent "$target" || comms_classify_agent "$target"; then
      fail "Hermes $shape case must not rely on a harness-named process"
    fi
    if [ "$shape" = native ]; then
      wait_for_state "$target" alive || fail "Hermes bootstrap and Node TUI must classify alive"
      (
        fm_backend_tmux_foreground_pids() { :; }
        [ -z "$(fm_backend_tmux_foreground_pids "$target")" ] || exit 1
        [ "$(fm_backend_agent_state tmux "$target")" = alive ]
      ) || fail "Hermes TUI must remain alive with only the ps argument path"
      if [ -r "/proc/$child_pid/cmdline" ]; then
        (
          fm_backend_tmux_foreground_args() { :; }
          [ -z "$(fm_backend_tmux_foreground_args "$target")" ] || exit 1
          [ "$(fm_backend_agent_state tmux "$target")" = alive ]
        ) || fail "Hermes TUI must remain alive with only the kernel argv path"
      fi
      pass "tmux liveness: Python -I -c bootstrap with same-group Node --expose-gc Hermes TUI classifies alive without harness names"
    else
      wait_for_state "$target" ambiguous || fail "unrelated Node script must stay ambiguous"
      pass "tmux liveness: the same bootstrap with an unrelated Node script stays ambiguous"
    fi
  done
else
  echo "skip: Hermes bootstrap/Node regression needs python3 and node"
fi

# --- a launcher whose own identity reads as a bare shell --------------------
# The single-source classifier would read this pane as an idle shell and call
# it dead - the one verdict that can start a duplicate agent on a live worktree.

new_window launcher "$LAB/bin/agent-launcher"
wait_for_state "$SESSION:launcher" alive \
  || fail "a launcher running a harness child must classify alive, never dead"
comms_classify_agent "$SESSION:launcher" \
  || fail "the launcher's harness child must be visible in the foreground process group"
pass "tmux liveness: a launcher whose own identity reads as a bare shell classifies alive from its harness child"

# --- an idle shell is still confidently dead --------------------------------

wait_for_state "$SESSION:idle" dead \
  || fail "an idle shell pane must classify dead"
pass "tmux liveness: an idle shell pane classifies dead"

# --- a harness-named BACKGROUND process must not fake an agent --------------
# Scoping to the foreground process group is what prevents this false alive; a
# descendant walk of the pane would report this pane as running an agent.
# `set -m` gives the background job its own process group, which is what an
# interactive shell does for a job an exited agent left behind.

new_window background bash -c "set -m; '$LAB/bin/claude-link' 900 & printf '%s\n' \"\$!\" > '$LAB/bg.pid'; exec /bin/sh"
bg_pid=
for _ in $(seq 1 100); do
  [ -s "$LAB/bg.pid" ] && bg_pid=$(cat "$LAB/bg.pid") && break
  sleep 0.1
done
[ -n "$bg_pid" ] || fail "the background harness-named process never started"
kill -0 "$bg_pid" 2>/dev/null \
  || fail "the background harness-named process is not running, so this case would prove nothing"
wait_for_state "$SESSION:background" dead \
  || fail "a pane whose only harness-named process is backgrounded must classify dead"
kill -0 "$bg_pid" 2>/dev/null \
  || fail "the background harness-named process died during the check, so this case proves nothing"
pass "tmux liveness: a harness-named background process in an idle pane still classifies dead"

# --- an absent window never inherits tmux's active-window fallback ----------
# tmux answers a display-message for an absent target from the CLIENT's active
# window instead of failing, so both raw name reads can describe a completely
# different pane. The classifier's window-membership check is what contains
# that, and this case proves the composed verdict does not inherit it.

fm_backend_tmux_foreground_comms "$SESSION:no-such-window" >/dev/null \
  || fail "the foreground-comms read must stay best-effort for an absent window"
[ "$(fm_backend_agent_state tmux "$SESSION:no-such-window")" = missing ] \
  || fail "an absent window in a readable session must classify missing, not whatever the fallback pane runs"
pass "tmux liveness: an absent window classifies missing rather than inheriting tmux's active-window fallback"

# --- Cursor's composer: the terminal cursor is NOT a composer locator --------
# Cursor Agent CLI parks its terminal cursor below its footer with cursor_flag 0,
# so tmux's #{cursor_y} answers `unknown` for every Cursor pane state and the
# away-mode escalation guard could never prove the composer empty. The composite
# reader reclassifies a proven-Cursor pane the way every cursorless backend
# already does. These cases drive the two signals apart on purpose: the SAME
# screen must read differently depending only on whether the pane's foreground
# process is genuinely Cursor, and the cursor-anchored source must be asserted
# blind so the case cannot go quietly vacuous.

# shellcheck source=bin/fm-tmux-lib.sh
. "$ROOT/bin/fm-tmux-lib.sh"

ln -s "$STANDIN_BIN" "$LAB/bin/cursor-agent"
ln -s "$STANDIN_BIN" "$LAB/bin/notcursor"

# Cursor's real screen shape: a BARE composer row carrying its U+2192 glyph, two
# footer rows below it, and the terminal cursor left on a blank row past the
# footer - exactly where cursor-agent 2026.08.11-e8db854 parks it. An IDLE
# composer draws its placeholder de-emphasised (SGR 2), which is what separates
# it from real typed text once the capture preserves styling; a plain-bright row
# is genuine input. Both forms are reproduced here rather than assumed.
cursor_screen() {  # <composer-text> <ghost 0|1>
  local text=$1 ghost=$2 open='' close=''
  if [ "$ghost" = 1 ]; then
    open=$(printf '\033[2m')
    close=$(printf '\033[0m')
  fi
  printf '\n  \xe2\x86\x92 %s%s%s\n\n  Cursor Grok 4.5 High                    Run Everything\n  %s \xc2\xb7 main\n\n' \
    "$open" "$text" "$close" "$LAB/wt"
}

open_composer_pane() {  # <window> <binary> <composer-text> <ghost 0|1>
  local window=$1 binary=$2 text=$3 ghost=$4
  new_window "$window" bash -c "$(declare -f cursor_screen); LAB='$LAB'; cursor_screen '$text' '$ghost'; exec '$binary' 900"
  local i=0
  while [ "$i" -lt 100 ]; do
    case "$("$REAL_TMUX" -L "$SOCKET" capture-pane -p -t "$SESSION:$window" 2>/dev/null)" in
      *"$text"*) return 0 ;;
    esac
    sleep 0.1
    i=$((i + 1))
  done
  fail "pane $window never rendered its composer"
}

cursor_anchored_verdict() {  # <target>
  local cy pane
  cy=$(fm_tmux_composer_cursor_row "$1")
  pane=$(fm_tmux_composer_capture "$1")
  fm_composer_classify_screen "$(fm_tmux_composer_caps)" "$pane" "$cy"
}

open_composer_pane cursor-idle "$LAB/bin/cursor-agent" 'Plan, search, build anything' 1
fm_tmux_pane_is_cursor "$SESSION:cursor-idle" \
  || fail "a pane whose foreground process is cursor-agent must be identified as Cursor"
[ "$(cursor_anchored_verdict "$SESSION:cursor-idle")" = unknown ] \
  || fail "the cursor-anchored source must be blind here, or this case proves nothing about the fallback"
[ "$(fm_tmux_composer_state "$SESSION:cursor-idle")" = empty ] \
  || fail "an idle Cursor composer must read empty; without it every away-mode escalation defers forever"
pass "cursor composer: an idle Cursor pane reads empty even though the cursor row is blind"

# cursor-agent 2026.10.19 draws the glyph and the placeholder as one dim run,
# with half-block rules around the row and no reverse-video cell. The older
# screen above keeps the glyph outside the dim run, so it cannot see this.
cursor_screen_dimrun() {  # <composer-text> <idle|typed>
  local text=$1 mode=$2 e
  e=$(printf '\033')
  printf '\n %s[38;2;42;44;57m▄▄▄▄▄▄▄▄%s[39m\n' "$e" "$e"
  if [ "$mode" = idle ]; then
    printf ' %s[48;2;42;44;57m %s[2m→ %s%s[0m%s[48;2;42;44;57m        %s[49m\n' \
      "$e" "$e" "$text" "$e" "$e" "$e"
  else
    printf ' %s[48;2;42;44;57m %s[2m→ %s[0m%s[38;2;224;222;244m%s%s[0m\n' \
      "$e" "$e" "$e" "$e" "$text" "$e"
  fi
  printf ' %s[38;2;42;44;57m▀▀▀▀▀▀▀▀%s[39m\n  Cursor Grok 4.5                    Run Everything\n\n' \
    "$e" "$e"
}
open_dimrun_pane() {  # <window> <binary> <composer-text> <idle|typed>
  local window=$1 binary=$2 text=$3 mode=$4
  new_window "$window" bash -c "$(declare -f cursor_screen_dimrun); cursor_screen_dimrun '$text' '$mode'; exec '$binary' 900"
  local i=0
  while [ "$i" -lt 100 ]; do
    case "$("$REAL_TMUX" -L "$SOCKET" capture-pane -p -t "$SESSION:$window" 2>/dev/null)" in
      *"$text"*) return 0 ;;
    esac
    sleep 0.1
    i=$((i + 1))
  done
  fail "pane $window never rendered its composer"
}
open_dimrun_pane cursor-dim-idle "$LAB/bin/cursor-agent" 'Add a follow-up' idle
fm_tmux_pane_is_cursor "$SESSION:cursor-dim-idle" \
  || fail "the fully dim pane's foreground process must still be Cursor"
[ "$(cursor_anchored_verdict "$SESSION:cursor-dim-idle")" = unknown ] \
  || fail "the fully dim pane's cursor-anchored source must stay blind"
[ "$(fm_tmux_composer_state "$SESSION:cursor-dim-idle")" = empty ] \
  || fail "a fully dim idle Cursor placeholder must read empty"
pass "cursor composer: a fully dim placeholder reads empty"

open_dimrun_pane cursor-dim-typed "$LAB/bin/cursor-agent" 'Add a follow-up' typed
[ "$(fm_tmux_composer_state "$SESSION:cursor-dim-typed")" = pending ] \
  || fail "typed text that matches the placeholder must stay pending"
pass "cursor composer: bright text matching the placeholder stays pending"

open_composer_pane cursor-typed "$LAB/bin/cursor-agent" 'half typed captain text' 0
[ "$(cursor_anchored_verdict "$SESSION:cursor-typed")" = unknown ] \
  || fail "the cursor-anchored source must be blind here too"
[ "$(fm_tmux_composer_state "$SESSION:cursor-typed")" = pending ] \
  || fail "real unsubmitted text in a Cursor composer must read pending, never empty; otherwise an escalation would merge with the captain's own half-typed line"
pass "cursor composer: real typed text still reads pending, so the injection guard holds"

# The SAME rendered screen, with only the foreground process identity changed.
open_composer_pane notcursor-idle "$LAB/bin/notcursor" 'Plan, search, build anything' 1
if fm_tmux_pane_is_cursor "$SESSION:notcursor-idle"; then
  fail "a pane running a non-Cursor binary must not be identified as Cursor"
fi
[ "$(fm_tmux_composer_state "$SESSION:notcursor-idle")" = unknown ] \
  || fail "the reclassification must be gated on Cursor's own process identity; the strict blank-cursor-row posture stays in force for every other harness"
pass "cursor composer: an identical screen stays unknown when the pane is not Cursor"

# A Cursor agent that exited leaves its rendered composer on screen while the
# foreground process becomes a plain shell. Typing an escalation there would run
# it as a shell command, so this must never read empty.
new_window cursor-exited bash -c "$(declare -f cursor_screen); LAB='$LAB'; cursor_screen 'Plan, search, build anything' 1; exec /bin/sh"
for _ in $(seq 1 100); do
  case "$("$REAL_TMUX" -L "$SOCKET" capture-pane -p -t "$SESSION:cursor-exited" 2>/dev/null)" in
    *'Plan, search, build anything'*) break ;;
  esac
  sleep 0.1
done
if fm_tmux_pane_is_cursor "$SESSION:cursor-exited"; then
  fail "a pane whose Cursor process exited must not still identify as Cursor"
fi
[ "$(fm_tmux_composer_state "$SESSION:cursor-exited")" != empty ] \
  || fail "a dead-shell pane still showing Cursor's composer must never read empty"
pass "cursor composer: a stale Cursor screen over a dead shell never reads empty"

# Command Code parks its terminal cursor below its footer and draws its own
# reverse-video cursor cell, with its placeholder in a truecolor too bright for
# the fleet-wide ghost ceiling (verified live, Command Code 1.74.1).
commandcode_screen() {  # <composer-row-kind idle|typed>
  local rule e
  e=$(printf '\033')
  rule=$(printf '\342\224\200%.0s' $(seq 1 40))
  printf '\n  done\n\n%s[38;2;138;148;168m%s\n' "$e" "$rule"
  if [ "$1" = idle ]; then
    printf '%s[39m\342\235\257 %s[7mA%s[0m%s[38;2;138;148;168msk your question...%s[39m\n' "$e" "$e" "$e" "$e" "$e"
  else
    printf '%s[39m\342\235\257 half typed captain text%s[7m %s[0m\n' "$e" "$e" "$e"
  fi
  printf '%s[38;2;138;148;168m%s\n%s[39m  ? for shortcuts\n\n\n' "$e" "$rule" "$e"
}
open_commandcode_pane() {  # <window> <binary> <idle|typed>
  local window=$1 binary=$2 kind=$3 i=0
  new_window "$window" bash -c "$(declare -f commandcode_screen); commandcode_screen '$kind'; exec '$binary' 900"
  while [ "$i" -lt 100 ]; do
    case "$("$REAL_TMUX" -L "$SOCKET" capture-pane -p -t "$SESSION:$window" 2>/dev/null)" in
      *'? for shortcuts'*) return 0 ;;
    esac
    sleep 0.1
    i=$((i + 1))
  done
  fail "pane $window never rendered its composer"
}

open_commandcode_pane cc-idle "$LAB/bin/command-code" idle
[ "$(cursor_anchored_verdict "$SESSION:cc-idle")" = unknown ] \
  || fail "the cursor-anchored source must be blind on a Command Code screen, or this case proves nothing about the fallback"
case "$(fm_tmux_composer_identity "$SESSION:cc-idle")" in
  commandcode$'\t'*) ;;
  *) fail "a pane whose foreground process is command-code must identify as Command Code" ;;
esac
[ "$(fm_tmux_composer_state "$SESSION:cc-idle")" = empty ] \
  || fail "an idle Command Code composer must read empty, or no steer can ever be delivered"
pass "commandcode composer: an idle pane reads empty although its cursor row is blind and its placeholder is bright"

open_commandcode_pane cc-typed "$LAB/bin/command-code" typed
[ "$(fm_tmux_composer_state "$SESSION:cc-typed")" = pending ] \
  || fail "real unsubmitted text in a Command Code composer must read pending"
pass "commandcode composer: typed text still reads pending"

# The SAME idle screen, with only the foreground process identity changed.
open_commandcode_pane cc-decoy "$LAB/bin/command-code-helper" idle
if fm_tmux_composer_identity "$SESSION:cc-decoy" >/dev/null; then
  fail "a pane running command-code-helper must not identify as Command Code"
fi
[ "$(fm_tmux_composer_state "$SESSION:cc-decoy")" = unknown ] \
  || fail "the reclassification and its ceiling must be gated on Command Code's own process identity"
pass "commandcode composer: an identical screen stays unknown when the pane is not Command Code"

# Hermes's default profile draws an unprefixed `❯` prompt under its native
# status rule (Hermes Agent 0.21.7). That row also matches the generic
# cursor-anchored shape, so a Hermes pane must be read by its identity-scoped
# classifier first: the native orange busy hint is not a draft, and a bare
# prompt without the status rule is not proven empty.
hermes_screen() {  # <rule|norule> <hint|draft|placeholder|bare>
  local e
  e=$(printf '\033')
  printf '\n  done\n\n'
  case "$1" in
    rule) printf ' \342\224\200 ready \342\224\202 model \342\224\202 1s\n' ;;
  esac
  case "$2" in
    hint) printf '\342\235\257 %s[38;5;231m%s[48;5;178mC%s[38;5;178m%s[49mtrl+C to interrupt\342\200\246%s[39m' "$e" "$e" "$e" "$e" "$e" ;;
    draft) printf '\342\235\257 real draft' ;;
    placeholder) printf '\342\235\257 %s[2mAsk me anything\342\200\246%s[0m' "$e" "$e" ;;
    bare) printf '\342\235\257 ' ;;
  esac
}
open_hermes_pane() {  # <window> <binary> <rule|norule> <row>
  local window=$1 binary=$2 rule=$3 row=$4 i=0
  new_window "$window" bash -c "$(declare -f hermes_screen); hermes_screen '$rule' '$row'; exec '$binary' 900"
  while [ "$i" -lt 100 ]; do
    case "$("$REAL_TMUX" -L "$SOCKET" capture-pane -p -t "$SESSION:$window" 2>/dev/null)" in
      *'❯'*) sleep 0.2; return 0 ;;
    esac
    sleep 0.1
    i=$((i + 1))
  done
  fail "pane $window never rendered its composer"
}

open_hermes_pane hm-busy "$LAB/bin/hermes" rule hint
case "$(fm_tmux_composer_identity "$SESSION:hm-busy")" in
  hermes$'\t'*) ;;
  *) fail "a pane whose foreground process is hermes must identify as Hermes" ;;
esac
[ "$(fm_tmux_composer_state "$SESSION:hm-busy")" = empty ] \
  || fail "Hermes's native busy hint on an unprefixed prompt must not read as a draft, or busy interrupts are refused"
open_hermes_pane hm-idle "$LAB/bin/hermes" rule placeholder
[ "$(fm_tmux_composer_state "$SESSION:hm-idle")" = empty ] \
  || fail "an idle unprefixed Hermes prompt beneath its status rule must read empty"
open_hermes_pane hm-draft "$LAB/bin/hermes" rule draft
[ "$(fm_tmux_composer_state "$SESSION:hm-draft")" = pending ] \
  || fail "a bright typed draft on an unprefixed Hermes prompt must read pending"
open_hermes_pane hm-norule "$LAB/bin/hermes" norule bare
[ "$(fm_tmux_composer_state "$SESSION:hm-norule")" = unknown ] \
  || fail "an unprefixed Hermes prompt without its native status rule must not be proven empty"
pass "hermes composer: an unprefixed default-profile prompt is read by Hermes identity before the generic cursor shape"

open_hermes_pane hm-decoy "$LAB/bin/hermes-helper" norule bare
if fm_tmux_composer_identity "$SESSION:hm-decoy" >/dev/null; then
  fail "a pane running hermes-helper must not identify as Hermes"
fi
[ "$(fm_tmux_composer_state "$SESSION:hm-decoy")" = "$(cursor_anchored_verdict "$SESSION:hm-decoy")" ] \
  || fail "a non-Hermes prompt pane must keep the generic cursor-anchored verdict"
pass "hermes composer: a non-Hermes prompt keeps the generic cursor-anchored verdict"

cleanup_all
trap - EXIT
