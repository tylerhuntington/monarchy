#!/usr/bin/env bash
# tests/fm-secondmate-lifecycle-e2e.test.sh - the happy-path secondmate operator
# flow, end to end, against one shared world:
#
#   seed -> spawn -> routed send -> backlog handoff -> recovery respawn -> teardown
#
# Each phase asserts the durable contracts the consolidation audit lists, so the
# many former positive unit tests (registry scope/charter/clone/mode, spawn meta,
# bare-window send, recovery respawn, teardown of an empty home, backlog handoff)
# collapse into one lifecycle. The path-boundary safety invariants and the
# lease-specific paths live in fm-secondmate-safety.test.sh.
#
# Coverage anchored here (must not regress):
#   - registry line records scope (from a filled charter brief) and project list
#   - charter is copied into the subhome
#   - remote-backed projects are cloned with their origin URL preserved
#   - a no-mistakes project is initialized (init + doctor) in the NEW subhome clone
#     and the parent project clone is never mutated (no write through a project)
#   - spawn meta records kind=secondmate, home=, and the project list; launch runs
#     in the subhome with the persistent charter and cleared operational overrides
#   - a bare `fm-<id>` send targets the window recorded in THIS home's meta
#   - backlog items move verbatim into the subhome and leave the main backlog
#   - recovery respawns from the durable registry + persistent home
#   - teardown removes meta and the registry route only after removing the home
set -u

# shellcheck source=tests/secondmate-helpers.sh disable=SC1091
. "$(dirname "${BASH_SOURCE[0]}")/secondmate-helpers.sh"

TMP_ROOT=$(fm_test_tmproot fm-secondmate-lifecycle)
export FM_BACKEND=tmux

HOME_DIR="$TMP_ROOT/main home"
SUB="$TMP_ROOT/design-home"
SUB_ABS=
FAKEBIN=
LOG="$TMP_ROOT/tmux.log"
PANE="$TMP_ROOT/pane.txt"
ALPHA_ORIGIN=
BETA_ORIGIN=

# --- shared world + seed ----------------------------------------------------
setup_world() {
  mkdir -p "$HOME_DIR/projects" "$HOME_DIR/data" "$HOME_DIR/state"
  fm_git_init_commit "$HOME_DIR/projects/alpha"
  fm_git_init_commit "$HOME_DIR/projects/beta"
  fm_git_init_commit "$HOME_DIR/projects/gamma"
  fm_git_add_origin "$HOME_DIR/projects/alpha" "$TMP_ROOT/remotes/alpha.git"
  fm_git_add_origin "$HOME_DIR/projects/beta" "$TMP_ROOT/remotes/beta.git"
  fm_git_add_origin "$HOME_DIR/projects/gamma" "$TMP_ROOT/remotes/gamma.git"
  cat > "$HOME_DIR/data/projects.md" <<EOF
- alpha [direct-PR +yolo] - alpha project (added 2026-06-22)
- beta [direct-PR] - beta project (added 2026-06-22)
- gamma - gamma project (added 2026-06-22)
EOF
  ALPHA_ORIGIN=$(git -C "$HOME_DIR/projects/alpha" remote get-url origin)
  BETA_ORIGIN=$(git -C "$HOME_DIR/projects/beta" remote get-url origin)

  # One combined fakebin: tmux + treehouse (spawn/send/teardown) and no-mistakes
  # (gamma initialization during seed).
  FAKEBIN=$(make_fake_tmux "$TMP_ROOT/fake")
  make_fake_no_mistakes "$TMP_ROOT/fake" >/dev/null

  # A filled charter brief whose routing scope differs from the charter summary,
  # so the registry must read the scope from the brief, not invent a generic one.
  FM_SECONDMATE_SCOPE='customer onboarding from brief' \
    scaffold_secondmate_charter "$HOME_DIR" design 'customer onboarding charter' alpha beta gamma \
    || fail "filled secondmate charter scaffold failed"
}

phase_seed() {
  local out
  out=$(PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" \
    "$ROOT/bin/fm-home-seed.sh" design "$SUB" alpha beta gamma) \
    || fail "seed failed"
  SUB_ABS=$(cd "$SUB" && pwd -P)

  assert_contains "$out" "home=$SUB_ABS" "seed did not report the subhome"
  assert_present "$SUB/.fm-secondmate-home" "seed did not mark the subhome"
  assert_present "$SUB/data/charter.md" "seed did not copy the charter into the subhome"
  assert_grep 'customer onboarding charter' "$SUB/data/charter.md" "charter body was not copied verbatim"

  # Projects cloned; remote-backed origins preserved.
  assert_present "$SUB/projects/alpha/.git" "alpha was not cloned"
  assert_present "$SUB/projects/beta/.git" "beta was not cloned"
  assert_present "$SUB/projects/gamma/.git" "gamma was not cloned"
  [ "$(git -C "$SUB/projects/alpha" remote get-url origin)" = "$ALPHA_ORIGIN" ] \
    || fail "alpha clone did not preserve its origin URL"
  [ "$(git -C "$SUB/projects/beta" remote get-url origin)" = "$BETA_ORIGIN" ] \
    || fail "direct-PR beta clone did not preserve its origin URL"

  # no-mistakes init runs in the NEW clone, never the parent project.
  assert_present "$SUB/projects/gamma/.no-mistakes-init" "no-mistakes project was not initialized in the subhome"
  assert_present "$SUB/projects/gamma/.no-mistakes-doctor" "no-mistakes project was not doctored in the subhome"
  assert_absent "$HOME_DIR/projects/gamma/.no-mistakes-init" "seed wrote no-mistakes state through the parent project"

  # Registry line: scope from the filled brief, project list, no legacy owns field.
  assert_grep '- design - customer onboarding charter' "$HOME_DIR/data/secondmates.md" "registry summary not from the charter"
  assert_grep 'scope: customer onboarding from brief' "$HOME_DIR/data/secondmates.md" "registry scope not from the filled brief"
  assert_grep 'projects: alpha, beta, gamma' "$HOME_DIR/data/secondmates.md" "registry did not record the project list"
  assert_no_grep 'owns:' "$HOME_DIR/data/secondmates.md" "registry used the legacy owns field"

  # Delivery modes preserved in the subhome registry; validation passes.
  [ "$(FM_HOME="$SUB" "$ROOT/bin/fm-project-mode.sh" alpha)" = "direct-PR on" ] \
    || fail "alpha delivery mode not preserved in the subhome"
  [ "$(FM_HOME="$SUB" "$ROOT/bin/fm-project-mode.sh" beta)" = "direct-PR off" ] \
    || fail "beta delivery mode not preserved in the subhome"
  FM_HOME="$HOME_DIR" "$ROOT/bin/fm-home-seed.sh" validate >/dev/null || fail "registry validation failed after seed"

  pass "seed: registry scope+projects, charter copied, clones+origins, no-mistakes init in subhome only"
}

phase_spawn() {
  : > "$LOG"
  PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_CONFIG_OVERRIDE="$HOME_DIR/parent-config" \
    FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-spawn.sh" design "$SUB" codex --secondmate >/dev/null \
    || fail "secondmate spawn failed"

  local meta="$HOME_DIR/state/design.meta"
  assert_grep 'kind=secondmate' "$meta" "spawn meta did not record kind=secondmate"
  assert_grep "home=$SUB_ABS" "$meta" "spawn meta did not record the subhome"
  assert_grep 'projects=alpha, beta, gamma' "$meta" "spawn meta did not record the project list"
  # Launch ran in the subhome, with the persistent charter and cleared overrides,
  # and never ran a project-style treehouse get.
  assert_grep "FM_HOME='$SUB_ABS'" "$LOG" "secondmate launch did not set FM_HOME to the subhome"
  assert_grep 'FM_ROOT_OVERRIDE= FM_STATE_OVERRIDE= FM_DATA_OVERRIDE= FM_PROJECTS_OVERRIDE=' "$LOG" "launch did not clear operational overrides"
  assert_grep 'FM_CONFIG_OVERRIDE=' "$LOG" "launch did not clear the config override"
  assert_grep "$SUB_ABS/data/charter.md" "$LOG" "launch did not use the persistent charter"
  assert_no_grep 'notify=' "$LOG" "secondmate codex launch included the parent turn-end notify hook"
  assert_no_grep 'turn-ended' "$LOG" "secondmate codex launch referenced a parent turn-ended signal"
  assert_no_grep 'treehouse get' "$LOG" "secondmate spawn ran a project treehouse get"
  pass "spawn: launches in the subhome with persistent charter, records routing meta"
}

phase_send() {
  : > "$LOG"
  printf '❯\n' > "$PANE"
  # The meta window (firstmate:fm-design) must win over a foreign same-named
  # window returned by list-windows. Include the recorded endpoint in the fake
  # inventory so the recovery-grade liveness check can verify it exists.
  PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_WINDOW="firstmate:fm-design
other-session:fm-design" \
    FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-send.sh" fm-design 'route this work' >/dev/null 2>&1 \
    || fail "fm-send failed for a bare firstmate window with home metadata"
  # design is a kind=secondmate target, so the durable inbox record carries the
  # from-firstmate marker and original payload. The terminal receives only the
  # constant doorbell, routed through this home's authoritative meta window.
  local record="$HOME_DIR/state/design.inbox/001.msg" body
  assert_present "$record" "send did not enqueue the secondmate request"
  body=$(bash -c '. "$1"; fm_task_inbox_body "$2"' _ "$ROOT/bin/fm-task-inbox-lib.sh" "$record")
  assert_contains "$body" '[fm-from-firstmate]' "the inbox request was not marked as from-firstmate"
  assert_contains "$body" 'route this work' "the original request text did not survive the marker"
  assert_grep 'send-keys -t firstmate:fm-design -l : Firstmate instruction waiting:' "$LOG" "send did not ring the window recorded in this home's meta"
  assert_no_grep 'route this work' "$LOG" "send typed the payload instead of only the doorbell"
  assert_no_grep 'send-keys -t other-session:fm-design' "$LOG" "send targeted a foreign same-named window"
  pass "send: a bare fm-<id> secondmate enqueues a marked request and rings the meta window"
}

phase_handoff() {
  # The move is delegated to `tasks-axi mv`; skip cleanly when it is absent (the
  # downstream recovery and teardown phases do not depend on this phase).
  if ! command -v tasks-axi >/dev/null 2>&1; then
    echo "skip: tasks-axi not found (backlog handoff delegates to it)"
    return 0
  fi
  cat > "$HOME_DIR/data/backlog.md" <<'EOF'
## In flight
- [ ] live-task - active work (repo: alpha, since 2026-06-20)

## Queued
- [ ] feat-x - add feature x (repo: alpha)
- [ ] feat-y - add feature y (repo: beta) blocked-by: feat-x - waits
- [ ] bug-z - fix bug z (repo: gamma)

## Done
- [x] old-task - shipped thing - local main (merged 2026-06-19)
EOF
  local out before
  out=$(PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" \
    FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-backlog-handoff.sh" design feat-x feat-y) \
    || fail "handoff failed for in-scope items"
  assert_contains "$out" "handed off 2 item(s) to design" "handoff did not report the moved items"

  assert_no_grep 'feat-x' "$HOME_DIR/data/backlog.md" "feat-x was not removed from the main backlog"
  assert_no_grep 'feat-y' "$HOME_DIR/data/backlog.md" "feat-y was not removed from the main backlog"
  assert_grep 'bug-z' "$HOME_DIR/data/backlog.md" "out-of-scope bug-z was wrongly removed"
  assert_grep 'live-task' "$HOME_DIR/data/backlog.md" "in-flight item was wrongly removed"

  assert_grep '- [ ] feat-x - add feature x (repo: alpha)' "$SUB/data/backlog.md" "feat-x did not arrive verbatim"
  assert_grep '- [ ] feat-y - add feature y (repo: beta) blocked-by: feat-x - waits' "$SUB/data/backlog.md" "feat-y line not preserved verbatim"
  awk '/^## Queued/{q=1;next} /^## /{q=0} q && /feat-x/{found=1} END{exit found?0:1}' "$SUB/data/backlog.md" \
    || fail "feat-x did not land under the Queued section"

  # Idempotent: a second handoff neither errors nor duplicates, and leaves main alone.
  before=$(cat "$HOME_DIR/data/backlog.md")
  PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" \
    FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-backlog-handoff.sh" design feat-x feat-y >/dev/null 2>&1 \
    || fail "idempotent re-run failed"
  [ "$(grep -cF -- '- [ ] feat-x - add feature x (repo: alpha)' "$SUB/data/backlog.md")" -eq 1 ] \
    || fail "idempotent re-run duplicated feat-x in the subhome backlog"
  [ "$before" = "$(cat "$HOME_DIR/data/backlog.md")" ] || fail "idempotent re-run mutated the main backlog"
  pass "handoff: in-scope items move verbatim, out-of-scope stays, idempotent"
}

phase_recovery() {
  # Simulate a restart after the endpoint exited: remove the fake window and
  # drop the live meta, then respawn from the registry + persistent home (no
  # explicit home argument).
  PATH="$FAKEBIN:$PATH" FM_FAKE_TMUX_LOG="$LOG" \
    tmux kill-window -t firstmate:fm-design >/dev/null \
    || fail "could not retire the fake endpoint before recovery"
  rm -f "$HOME_DIR/state/design.meta"
  PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-spawn.sh" design "echo relaunch" --secondmate >/dev/null 2>&1 \
    || fail "recovery respawn failed"
  local meta="$HOME_DIR/state/design.meta"
  assert_grep "home=$SUB_ABS" "$meta" "respawn did not preserve the persistent home from the registry"
  assert_grep 'projects=alpha, beta, gamma' "$meta" "respawn did not preserve the project list from the registry"
  assert_grep 'window=firstmate:fm-design' "$meta" "respawn did not reconstruct the direct-report window"
  pass "recovery: respawns from the durable registry and persistent home"
}

phase_teardown() {
  local teardown_out corr rec leftover leftover_rec other_corr
  corr=$(FM_HOME="$HOME_DIR" bash -c '
    . "$1"
    fm_pending_reply_create "$2" "$2/state" design "New routed work is in your backlog."
  ' _ "$ROOT/bin/fm-pending-reply-lib.sh" "$HOME_DIR") \
    || fail "could not seed receiver wake retirement state"
  rec="$HOME_DIR/state/pending-replies/$corr"
  leftover=$(FM_HOME="$HOME_DIR" bash -c '
    . "$1"
    fm_pending_reply_create "$2" "$2/state" design "Earlier routed ask that already resolved."
  ' _ "$ROOT/bin/fm-pending-reply-lib.sh" "$HOME_DIR") \
    || fail "could not seed leftover resolved pending-reply"
  leftover_rec="$HOME_DIR/state/pending-replies/$leftover"
  # Settle every parent pending-reply for this mate (earlier send/handoff
  # phases leave open records) so non-forced retirement mirrors a clean
  # captain-approved close rather than hitting the unresolved-reply refuse.
  FM_HOME="$HOME_DIR" bash -c '
    . "$1"
    state="$2/state"
    for rec in "$state/pending-replies"/*; do
      [ -f "$rec" ] || continue
      [ "$(fm_pending_reply_get "$rec" task_id)" = design ] || continue
      fm_pending_reply_set "$rec" phase resolved
      fm_pending_reply_set "$rec" delivered_epoch 1
    done
  ' _ "$ROOT/bin/fm-pending-reply-lib.sh" "$HOME_DIR" \
    || fail "could not settle pending-replies before retirement"
  mkdir -p "$TMP_ROOT/external-pending"
  printf 'task_id=design\nphase=resolved\n' > "$TMP_ROOT/external-pending/escape"
  mv "$HOME_DIR/state/pending-replies" "$HOME_DIR/state/pending-replies.safe"
  ln -s "$TMP_ROOT/external-pending" "$HOME_DIR/state/pending-replies"
  if PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-teardown.sh" design >/dev/null 2>&1; then
    fail "local retirement accepted a symlinked pending-replies directory"
  fi
  assert_present "$SUB" "unsafe pending-replies retirement removed the secondmate home"
  assert_present "$HOME_DIR/state/design.meta" "unsafe pending-replies retirement removed parent metadata"
  assert_grep '- design ' "$HOME_DIR/data/secondmates.md" \
    "unsafe pending-replies retirement removed the registry route"
  assert_present "$TMP_ROOT/external-pending/escape" \
    "unsafe local retirement removed an external pending reply"
  rm -f "$HOME_DIR/state/pending-replies"
  mv "$HOME_DIR/state/pending-replies.safe" "$HOME_DIR/state/pending-replies"
  mkdir -p "$HOME_DIR/state/pending-replies/.delivery-confirmed-.."
  mkdir -p "$TMP_ROOT/escape"
  touch "$TMP_ROOT/escape/pwned"
  printf 'task_id=design\nphase=resolved\ncorr_id=../../../../../escape/pwned\n' \
    > "$HOME_DIR/state/pending-replies/aaaaaaaaaaaaaaaa"
  if PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-teardown.sh" design >/dev/null 2>&1; then
    fail "local retirement accepted a pending-reply with unsafe corr_id"
  fi
  assert_present "$SUB" "unsafe corr_id retirement removed the secondmate home"
  assert_present "$HOME_DIR/state/design.meta" "unsafe corr_id retirement removed parent metadata"
  assert_grep '- design ' "$HOME_DIR/data/secondmates.md" \
    "unsafe corr_id retirement removed the registry route"
  assert_present "$TMP_ROOT/escape/pwned" \
    "unsafe corr_id cleanup deleted outside pending-replies"
  rm -rf "$HOME_DIR/state/pending-replies/.delivery-confirmed-.."
  rm -f "$HOME_DIR/state/pending-replies/aaaaaaaaaaaaaaaa"
  other_corr=bbbbbbbbbbbbbbbb
  printf 'task_id=other\nphase=resolved\ncorr_id=%s\n' "$other_corr" \
    > "$HOME_DIR/state/pending-replies/$other_corr"
  : > "$HOME_DIR/state/pending-replies/.delivery-confirmed-$other_corr"
  printf 'task_id=design\nphase=resolved\ncorr_id=%s\n' "$other_corr" \
    > "$HOME_DIR/state/pending-replies/aaaaaaaaaaaaaaaa"
  if PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-teardown.sh" design >/dev/null 2>&1; then
    fail "local retirement accepted a pending-reply with mismatched corr_id"
  fi
  assert_present "$SUB" "mismatched corr_id retirement removed the secondmate home"
  assert_present "$HOME_DIR/state/design.meta" "mismatched corr_id retirement removed parent metadata"
  assert_grep '- design ' "$HOME_DIR/data/secondmates.md" \
    "mismatched corr_id retirement removed the registry route"
  assert_present "$HOME_DIR/state/pending-replies/$other_corr" \
    "mismatched corr_id cleanup deleted another task's pending reply"
  assert_present "$HOME_DIR/state/pending-replies/.delivery-confirmed-$other_corr" \
    "mismatched corr_id cleanup deleted another task's delivery confirmation"
  rm -f "$HOME_DIR/state/pending-replies/aaaaaaaaaaaaaaaa" \
    "$HOME_DIR/state/pending-replies/$other_corr" \
    "$HOME_DIR/state/pending-replies/.delivery-confirmed-$other_corr"
  printf 'confirmed:%s\n' "$corr" > "$HOME_DIR/state/.backlog-handoff-design.wake-pending"
  printf '%s\tattempt\n' "$(date +%s)" > "$HOME_DIR/state/.secondmate-relaunch-design"
  printf '%s\tdead\n' "$(date +%s)" > "$HOME_DIR/state/.secondmate-relaunch-bound-design"
  : > "$LOG"
  teardown_out=$(PATH="$FAKEBIN:$PATH" FM_HOME="$HOME_DIR" FM_FAKE_TMUX_LOG="$LOG" FM_FAKE_TMUX_CAPTURE="$PANE" \
    "$ROOT/bin/fm-teardown.sh" design 2>&1) \
    || fail "teardown failed for the empty secondmate home: $teardown_out"
  printf '%s\n' "$teardown_out" | grep -F 'Backlog:' >/dev/null \
    && fail "secondmate teardown emitted a main-backlog completion reminder"
  assert_absent "$SUB" "teardown did not remove the retired secondmate home"
  assert_absent "$HOME_DIR/state/design.meta" "teardown did not clear the parent meta"
  assert_absent "$HOME_DIR/state/.backlog-handoff-design.wake-pending" \
    "teardown left receiver wake state that could poison a replacement route"
  assert_absent "$rec" "teardown left the retired receiver wake correlation"
  assert_absent "$HOME_DIR/state/.secondmate-relaunch-design" \
    "teardown left the relaunch ledger a same-id replacement would inherit"
  assert_absent "$HOME_DIR/state/.secondmate-relaunch-bound-design" \
    "teardown left the relaunch park marker a same-id replacement would inherit"
  assert_absent "$HOME_DIR/state/.secondmate-liveness-design.lock" \
    "teardown left the liveness lock it took to retire relaunch state"
  assert_absent "$leftover_rec" "teardown left a resolved pending-reply for the retired secondmate"
  assert_no_grep '- design ' "$HOME_DIR/data/secondmates.md" "teardown did not remove the registry route"
  # The parent's source projects are untouched (no write through a parent home).
  assert_present "$HOME_DIR/projects/alpha" "teardown disturbed a parent project"
  pass "teardown: removes the home, then clears meta and the registry route"
}

setup_world
phase_seed
phase_spawn
phase_send
phase_handoff
phase_recovery
phase_teardown
