#!/usr/bin/env bash
# Tests for the secondmate-vs-crewmate harness split, the optional model/effort
# tokens config/secondmate-harness carries alongside the harness, and the
# primary->secondmate inherited local-material propagation.
#
# Three capabilities are under test:
#   A) Harness split. config/secondmate-harness sets the harness the PRIMARY uses
#      to launch SECONDMATE agents, independent of config/crew-harness (the
#      crewmate harness). fm-harness.sh secondmate resolves the fallback chain
#      config/secondmate-harness -> config/crew-harness -> own; an absent or
#      "default" secondmate-harness behaves exactly as the crew harness did before
#      this knob existed (full backward-compat). fm-spawn.sh resolves a secondmate
#      launch through that mode, durably (every respawn re-resolves), while an
#      explicit per-spawn harness arg still wins.
#   B) Inheritance. The primary pushes a declared, extensible set of LOCAL
#      (gitignored) config items - config/crew-dispatch.json, config/crew-harness,
#      config/backlog-backend, config/backend, config/herdr-presentation-spaces,
#      config/startup-memory-budget, config/trace-context, and
#      config/supervision-host-off -
#      down into each secondmate home's config/, so the secondmate's OWN crewmates,
#      dispatch profiles, backlog backend, runtime-backend default, Herdr
#      presentation choice, startup-memory budget, and trace context inherit the
#      primary's settings. For config/herdr-presentation-spaces, an absent
#      primary file and an absent destination file both mean the same
#      unconfigured default, so the generic absence mirror converges that item
#      without deciding its release-dependent floor.
#      It is primary-authoritative
#      (re-pushed at secondmate spawn, on the bootstrap secondmate sweep, and by
#      config push).
#      config/secondmate-harness is deliberately NOT inherited (secondmates do
#      not spawn secondmates). After a successful push that changes allowlisted
#      config under an already-running home, a literal-content reread instruction
#      is written to the secondmate home and only its pointer is sent via the
#      routed secondmate path (exact destination bytes, no summaries); unchanged
#      config sends nothing unless a previous send failure is pending.

#   C) Model/effort pin. config/secondmate-harness may carry optional model and
#      effort tokens after the harness ("<harness> [<model>] [<effort>]"), read by
#      fm-harness.sh secondmate-model / secondmate-effort. A bare harness-only
#      line (today's format) yields empty model/effort - full backward-compat.
#      fm-spawn.sh populates MODEL/EFFORT from those tokens for a --secondmate
#      spawn only when the harness also resolves from that file, so the pin is
#      durable across every respawn while explicit per-spawn harness/model/effort
#      flags still win.
#   D) Per-mate override. A "mate <secondmate-id>: <harness> [<model>] [<effort>]"
#      line in config/secondmate-harness replaces the default line for exactly
#      that id, so a mate with its own pin cannot be migrated by a later change
#      to the default pin. A file without mate lines resolves byte-for-byte as
#      before, and a malformed line is refused with its line number rather than
#      skipped.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
# shellcheck source=/dev/null
. "$ROOT/bin/fm-ff-lib.sh"
# shellcheck source=/dev/null
. "$ROOT/bin/fm-config-inherit-lib.sh"

# The harness-detection cases below fake `ps` so process ancestry is fully
# controlled, but bin/fm-harness.sh also reads verified ENV markers. A suite run
# from inside one of those harnesses inherits its marker, and it wins over
# everything these cases set up wherever ancestry is silent. Drop the ambient
# markers so what this suite asserts does not depend on which harness it was
# launched from; every case states the marker it means to test.
unset CLAUDECODE PI_CODING_AGENT FM_PI_HARNESS GROK_AGENT CURSOR_AGENT CURSOR_INVOKED_AS

BASE_PATH=${FM_TEST_BASE_PATH:-/usr/bin:/bin:/usr/sbin:/sbin}
fm_git_identity fmtest fmtest@example.com
TMP_ROOT=$(fm_test_tmproot fm-secondmate-harness)
export FM_BACKEND=tmux

# Every claude launch pre-registers workspace trust for the directory it starts
# in, and for a secondmate that directory is the home (bin/fm-claude-trust.sh).
# Several cases here resolve claude, so every spawn below pins a throwaway HOME
# with an empty CLAUDE_CONFIG_DIR and puts node on the spawn's PATH; without the
# first, this suite would write the developer's real ~/.claude.json.
# Dropping the ambient markers is only half the isolation: a structural ancestor
# outranks a marker, so a case that PINS detect_own with CLAUDECODE=1 also has to
# blind the ancestry walk, or the harness this suite was launched from answers
# instead of the pin. BLIND_BIN goes AFTER a case's own fakebin in PATH, so a
# fixture that deliberately supplies its own ps or a harness-named ancestor keeps
# it (tests/fm-harness-precedence.test.sh owns the precedence boundary itself).
BLIND_BIN=$(fm_fakebin "$TMP_ROOT/blind-ancestry")
fm_fake_blind_ancestry "$BLIND_BIN"

# ===========================================================================
# A) fm-harness.sh secondmate resolution + fallback (deterministic detect_own)
# ===========================================================================
# detect_own is pinned to claude via CLAUDECODE=1 over a blinded ancestry walk so
# the "fall through to own" cases are reproducible on any host harness. Each row sets crew-harness / secondmate-harness in a
# fresh config dir (a literal '-' means leave the file absent) and asserts BOTH
# the secondmate resolution AND that crew resolution is unchanged (backward-compat).
#   <label>^<crew-harness>^<secondmate-harness>^<expect-secondmate>^<expect-crew>
test_harness_resolution() {
  local label crew sm exp_sm exp_crew case_dir cfg got_sm got_crew n
  n=0
  while IFS='^' read -r label crew sm exp_sm exp_crew; do
    [ -n "$label" ] || continue
    n=$((n + 1))
    case_dir="$TMP_ROOT/harness-$n"
    cfg="$case_dir/config"
    mkdir -p "$cfg"
    [ "$crew" = "-" ] || printf '%s\n' "$crew" > "$cfg/crew-harness"
    [ "$sm" = "-" ] || printf '%s\n' "$sm" > "$cfg/secondmate-harness"
    got_sm=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate)
    got_crew=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" crew)
    [ "$got_sm" = "$exp_sm" ] || fail "$label: secondmate resolved '$got_sm', expected '$exp_sm'"
    [ "$got_crew" = "$exp_crew" ] || fail "$label: crew resolved '$got_crew', expected '$exp_crew'"
  done <<'ROWS'
both absent -> own (backward-compat)^-^-^claude^claude
crew set, secondmate absent -> crew (backward-compat)^codex^-^codex^codex
crew set, secondmate set -> secondmate wins, crew untouched^codex^grok^grok^codex
crew absent, secondmate set -> secondmate value, crew own^-^grok^grok^claude
signed Pi wrapper remains a distinct secondmate value^codex^pi-signed^pi-signed^codex
secondmate=default defers to crew^codex^default^codex^codex
crew=default resolves to own, secondmate follows^default^-^claude^claude
secondmate=default with crew absent -> own^-^default^claude^claude
ROWS
  pass "A1 fm-harness.sh secondmate resolves the fallback chain; crew mode unchanged"
}

test_cursor_marker_detection() {
  local dir fakebin got
  dir="$TMP_ROOT/cursor-marker"
  fakebin=$(fm_fakebin "$dir")
  cat > "$fakebin/ps" <<'SH'
#!/usr/bin/env bash
case "$*" in
  *'ppid='*) printf '%s\n' 1 ;;
  *) printf '%s\n' bash ;;
esac
SH
  chmod +x "$fakebin/ps"
  got=$(env -u CLAUDECODE -u PI_CODING_AGENT -u GROK_AGENT \
    PATH="$fakebin:$BASE_PATH" CURSOR_INVOKED_AS=cursor-agent "$ROOT/bin/fm-harness.sh")
  [ "$got" = cursor ] || fail "Cursor's exact launcher marker resolved '$got', expected cursor"
  got=$(env -u CLAUDECODE -u PI_CODING_AGENT -u GROK_AGENT \
    PATH="$fakebin:$BASE_PATH" CURSOR_INVOKED_AS=cursor "$ROOT/bin/fm-harness.sh")
  [ "$got" != cursor ] || fail "an inexact Cursor marker value was accepted as Cursor Agent CLI"
  pass "fm-harness detects only Cursor Agent CLI's exact invocation marker"
}

# ===========================================================================
# C) fm-harness.sh secondmate-model / secondmate-effort token resolution
# ===========================================================================
# config/secondmate-harness holds "<harness> [<model>] [<effort>]" on one line.
# A bare harness (today's format) must yield empty model/effort - the
# backward-compat requirement. The file-line field uses \n for an embedded
# newline (expanded via printf '%b') so a row can express a multi-line file; the
# literal token ABSENT skips creating the file entirely.
#   <label>^<file-line-or-ABSENT>^<expect-harness>^<expect-model>^<expect-effort>
test_secondmate_model_effort_tokens() {
  local label line exp_harness exp_model exp_effort case_dir cfg got_h got_m got_e n
  n=0
  while IFS='^' read -r label line exp_harness exp_model exp_effort; do
    [ -n "$label" ] || continue
    n=$((n + 1))
    case_dir="$TMP_ROOT/tokens-$n"
    cfg="$case_dir/config"
    mkdir -p "$cfg"
    [ "$line" = ABSENT ] || printf '%b\n' "$line" > "$cfg/secondmate-harness"
    got_h=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate)
    got_m=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate-model)
    got_e=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate-effort)
    [ "$got_h" = "$exp_harness" ] || fail "$label: harness resolved '$got_h', expected '$exp_harness'"
    [ "$got_m" = "$exp_model" ] || fail "$label: model resolved '$got_m', expected '$exp_model'"
    [ "$got_e" = "$exp_effort" ] || fail "$label: effort resolved '$got_e', expected '$exp_effort'"
  done <<'ROWS'
absent file -> own harness, empty model/effort^ABSENT^claude^^
bare harness only -> empty model/effort (backward-compat)^claude^claude^^
harness + model -> model only^claude opus^claude^opus^
harness + model + effort -> both^claude opus high^claude^opus^high
signed Pi wrapper + model + effort preserves every token^pi-signed openai-codex/gpt-5.6-sol max^pi-signed^openai-codex/gpt-5.6-sol^max
default harness token -> falls back to crew, empty model/effort^default^claude^^
extra whitespace between tokens is tolerated^grok   grok-4    xhigh^grok^grok-4^xhigh
leading/trailing blank lines and a comment are skipped^# a comment\n\nclaude opus low\n^claude^opus^low
ROWS
  pass "C1 fm-harness.sh secondmate-model/secondmate-effort resolve the optional tokens; bare harness stays empty (backward-compat)"
}

# ===========================================================================
# D) Per-mate override lines in config/secondmate-harness
# ===========================================================================
# A "mate <secondmate-id>: <harness> [<model>] [<effort>]" line replaces the
# default line for exactly that id, so one mate cannot silently inherit another
# mate's runtime when the default pin moves. A file with no mate lines must
# resolve exactly as it always did, both for a caller that passes an id and for
# one that does not.
#   <label>^<file-lines, \n for a newline, ABSENT for no file>^<id>^<exp-harness>^<exp-model>^<exp-effort>
test_secondmate_per_mate_override_lines() {
  local label file id exp_harness exp_model exp_effort case_dir cfg got_h got_m got_e n
  n=0
  while IFS='^' read -r label file id exp_harness exp_model exp_effort; do
    [ -n "$label" ] || continue
    n=$((n + 1))
    case_dir="$TMP_ROOT/permate-$n"
    cfg="$case_dir/config"
    mkdir -p "$cfg"
    [ "$file" = ABSENT ] || printf '%b\n' "$file" > "$cfg/secondmate-harness"
    got_h=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate "$id")
    got_m=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate-model "$id")
    got_e=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" "$ROOT/bin/fm-harness.sh" secondmate-effort "$id")
    [ "$got_h" = "$exp_harness" ] || fail "$label: harness resolved '$got_h', expected '$exp_harness'"
    [ "$got_m" = "$exp_model" ] || fail "$label: model resolved '$got_m', expected '$exp_model'"
    [ "$got_e" = "$exp_effort" ] || fail "$label: effort resolved '$got_e', expected '$exp_effort'"
  done <<'ROWS'
default-only file with an id resolves the default (backward-compat)^pi model-a xhigh^alpha^pi^model-a^xhigh
default-only file with no id resolves the default (backward-compat)^pi model-a xhigh^^pi^model-a^xhigh
legacy file ignores a second default line^pi model-a xhigh\ngrok model-b low^alpha^pi^model-a^xhigh
legacy file ignores extra tokens^pi model-a xhigh extra^alpha^pi^model-a^xhigh
legacy file ignores trailing malformed text without an override^pi model-a xhigh\nmate: grok model-b low^alpha^pi^model-a^xhigh
legacy default fallback ignores later lines and extra tokens^default ignored high extra\ngrok model-b low^alpha^claude^^
mate line wins for that exact id^pi def-m xhigh\nmate alpha: claude opus max^alpha^claude^opus^max
mate line leaves every other id on the default^pi def-m xhigh\nmate alpha: claude opus max^beta^pi^def-m^xhigh
mate line is ignored when no id is passed^pi def-m xhigh\nmate alpha: claude opus max^^pi^def-m^xhigh
harness-only mate line yields empty model and effort^pi def-m xhigh\nmate alpha: grok^alpha^grok^^
mate line listed above the default line is honored^mate alpha: muse m1 low\npi def-m xhigh^alpha^muse^m1^low
mate line whose harness is default defers to the crew chain^claude opus high\nmate alpha: default^alpha^claude^^
comments and blank lines stay legal between the lines^# pinned by the captain\n\n  \npi def-m xhigh\n\n# exception\nmate alpha: grok g1 max^alpha^grok^g1^max
override with no default line governs its own id^mate alpha: grok g1 max^alpha^grok^g1^max
id with no override and no default line falls through to own^mate alpha: grok g1 max^beta^claude^^
ROWS
  pass "D1 fm-harness.sh honors a mate override line for its id and changes nothing else"
}

# Malformed pin config is an actionable error, never a fallback: every read verb
# must refuse with the line number and print no token on stdout, so a mistyped
# override cannot land a mate on the default runtime in silence.
test_secondmate_malformed_pin_refuses_with_line_number() {
  local label file case_dir cfg out got_stdout rc verb id n
  n=0
  while IFS='^' read -r label file; do
    [ -n "$label" ] || continue
    n=$((n + 1))
    case_dir="$TMP_ROOT/badpin-$n"
    cfg="$case_dir/config"
    mkdir -p "$cfg"
    printf '%b\n' "$file" > "$cfg/secondmate-harness"
    for id in alpha beta ''; do
    for verb in secondmate secondmate-model secondmate-effort; do
      out=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" \
        "$ROOT/bin/fm-harness.sh" "$verb" "$id" 2>&1); rc=$?
      [ "$rc" -ne 0 ] || fail "$label: fm-harness.sh $verb accepted the malformed pin: $out"
      assert_contains "$out" "config/secondmate-harness line " \
        "$label: fm-harness.sh $verb refused without naming the offending line"
      got_stdout=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" \
        "$ROOT/bin/fm-harness.sh" "$verb" "$id" 2>/dev/null)
      [ -z "$got_stdout" ] \
        || fail "$label: a refused pin must print no token on stdout, got '$got_stdout'"
    done
    done
  done <<'ROWS'
duplicate override for the same mate^pi def-m xhigh\nmate alpha: grok g1 max\nmate alpha: muse m2 low
unknown line that is not the default and not an override^pi def-m xhigh\nmate alpha: grok\npi def-m low
mate keyword with no id^pi def-m xhigh\nmate alpha: grok\nmate: grok g1 max
mate id containing a space^pi def-m xhigh\nmate alpha: grok\nmate an alpha: grok
override with no tokens after the colon^pi def-m xhigh\nmate alpha:
override with too many tokens^pi def-m xhigh\nmate alpha: grok g1 max extra
default line with too many tokens^pi def-m xhigh extra\nmate alpha: grok
malformed mate with no default line^mate alpha: claude opus high\nmate : grok
malformed mate keyword with no default line^mate alpha: claude opus high\nmate: grok
invalid mate id with no default line^mate alpha: claude opus high\nmate bad/id: grok
ROWS
  pass "D2 malformed config/secondmate-harness refuses with its line number on every read verb"
}

# The opt-in scope is the whole compatibility promise of this grammar: a file
# that declares no "mate <id>:" line keeps the documented legacy rule - the
# first non-empty, non-comment line is parsed and the rest is ignored. Nothing
# in such a file may refuse, including content that the strict, declaring-file
# rules would reject if it sat next to a mate line.
test_secondmate_legacy_pin_file_is_never_refused() {
  local label file case_dir cfg out err rc verb id n
  n=0
  while IFS='^' read -r label file; do
    [ -n "$label" ] || continue
    n=$((n + 1))
    case_dir="$TMP_ROOT/legacypin-$n"
    cfg="$case_dir/config"
    mkdir -p "$cfg"
    printf '%b\n' "$file" > "$cfg/secondmate-harness"
    for id in alpha ''; do
      for verb in secondmate secondmate-model secondmate-effort; do
        out=$(PATH="$BLIND_BIN:$BASE_PATH" CLAUDECODE=1 FM_CONFIG_OVERRIDE="$cfg" \
          "$ROOT/bin/fm-harness.sh" "$verb" "$id" 2>"$case_dir/err"); rc=$?
        err=$(cat "$case_dir/err")
        [ "$rc" -eq 0 ] \
          || fail "$label: fm-harness.sh $verb refused a file that declares no mate line: $err"
        [ -z "$err" ] \
          || fail "$label: fm-harness.sh $verb complained about a legacy file: $err"
      done
    done
  done <<'ROWS'
legacy file with a second default line^pi model-a xhigh\ngrok model-b low
legacy file with a fourth token^pi model-a xhigh extra
legacy file with a second default line and a fourth token^pi model-a xhigh extra\ngrok model-b low
legacy file with a mate keyword and no id^pi model-a xhigh\nmate: grok g1 max
legacy file with a mate id containing a space^pi model-a xhigh\nmate an alpha: grok
legacy file with a mate line that names no id^pi model-a xhigh\nmate : grok
legacy file with comments and blank lines^# captain note\n\npi model-a xhigh\n\ngrok model-b low
legacy file whose default line is the word default^default\npi model-a xhigh
ROWS
  pass "D3 a config/secondmate-harness that declares no mate line is never refused"
}

# ===========================================================================
# A/C) pi-signed process identity and shared Pi marker behavior
# ===========================================================================
test_pi_signed_detection_and_session_lock_identity() {
  local dir fakebin got
  dir="$TMP_ROOT/pi-signed-identity"
  fakebin=$(fm_fakebin "$dir")
  cat > "$fakebin/ps" <<'SH'
#!/usr/bin/env bash
set -u
field= pid=
while [ "$#" -gt 0 ]; do
  case "$1" in
    -o) field=$2; shift 2 ;;
    -p) pid=$2; shift 2 ;;
    *) shift ;;
  esac
done
case "$pid:$field:${FM_TEST_SIGNED_SHAPE:-exact}" in
  100:comm=:*) printf '%s\n' '/test/Pi.app/bin/pi' ;;
  100:args=:*) printf '%s\n' 'Pi' ;;
  100:ppid=:*) printf '%s\n' 200 ;;
  200:comm=:exact) printf '%s\n' '/opt/test/bin/pi-signed' ;;
  200:args=:exact) printf '%s\n' 'pi-signed --model test/model' ;;
  200:comm=:helper) printf '%s\n' '/opt/test/bin/pi-signed-helper' ;;
  200:args=:helper) printf '%s\n' 'pi-signed-helper' ;;
  200:comm=:plain) printf '%s\n' '/bin/zsh' ;;
  200:args=:plain) printf '%s\n' 'zsh' ;;
  200:ppid=:*) printf '%s\n' 1 ;;
  *:comm=:*) printf '%s\n' bash ;;
  *:args=:*) printf '%s\n' bash ;;
  *:ppid=:*) printf '%s\n' 100 ;;
esac
SH
  chmod +x "$fakebin/ps"

  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "unmarked shared signed-wrapper ancestry resolved '$got', expected pi"
  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true FM_PI_HARNESS=pi-signed "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi-signed ] || fail "selected signed wrapper resolved '$got', expected pi-signed"
  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true FM_PI_HARNESS=pi "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "selected plain Pi resolved '$got', expected pi"
  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true FM_PI_HARNESS=pi-signed-helper "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "inexact signed selection marker resolved '$got', expected pi"
  got=$(env -u CLAUDECODE -u GROK_AGENT -u PI_CODING_AGENT PATH="$fakebin:$BASE_PATH" FM_PI_HARNESS=pi-signed "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "signed selection marker without Pi's family marker resolved '$got', expected pi"
  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true FM_TEST_SIGNED_SHAPE=plain "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "plain Pi marker resolved '$got', expected pi"
  got=$(env -u CLAUDECODE -u GROK_AGENT PATH="$fakebin:$BASE_PATH" PI_CODING_AGENT=true FM_TEST_SIGNED_SHAPE=helper "$ROOT/bin/fm-harness.sh")
  [ "$got" = pi ] || fail "unrelated pi-signed-helper ancestry resolved '$got', expected pi"

  got=$(PATH="$fakebin:$BASE_PATH" bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; fm_harness_ancestry_pid' "$ROOT")
  [ "$got" = 100 ] || fail "session-lock ancestry selected '$got', expected the inner Pi engine pid 100"
  PATH="$fakebin:$BASE_PATH" bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; kill() { return 0; }; fm_harness_pid_alive 200' "$ROOT" \
    || fail "session-lock liveness rejected exact pi-signed holder"
  if PATH="$fakebin:$BASE_PATH" FM_TEST_SIGNED_SHAPE=helper bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; kill() { return 0; }; fm_harness_pid_alive 200' "$ROOT"; then
    fail "session-lock liveness accepted unrelated pi-signed-helper"
  fi

  pass "pi-signed identity: authoritative launch selection distinguishes shared wrapper ancestry"
}

test_dash_leading_process_names_are_basename_operands() {
  local dir fakebin got err status
  dir="$TMP_ROOT/dash-leading-process-names"
  fakebin=$(fm_fakebin "$dir")
  cat > "$fakebin/ps" <<'SH'
#!/usr/bin/env bash
set -u
field= pid=
while [ "$#" -gt 0 ]; do
  case "$1" in
    -o) field=$2; shift 2 ;;
    -p) pid=$2; shift 2 ;;
    *) shift ;;
  esac
done
[ -n "${FM_TEST_PS_LOG:-}" ] && printf '%s:%s\n' "$pid" "$field" >> "$FM_TEST_PS_LOG"
case "$pid:$field" in
  4242:comm=) printf '%s\n' '/opt/test/bin/codex' ;;
  4242:args=) printf '%s\n' 'codex' ;;
  4242:ppid=) printf '%s\n' 1 ;;
  5252:comm=) if [ -n "${FM_TEST_PS_LIVENESS_PROBE:-}" ]; then printf '%s\n' '-codex'; else printf '%s\n' '-zsh'; fi ;;
  5252:args=) if [ -n "${FM_TEST_PS_LIVENESS_PROBE:-}" ]; then printf '%s\n' '-codex'; else printf '%s\n' '-zsh'; fi ;;
  5252:ppid=) printf '%s\n' 4242 ;;
  *:comm=) printf '%s\n' '-zsh' ;;
  *:args=) printf '%s\n' '-zsh' ;;
  *:ppid=) printf '%s\n' "${FM_TEST_PS_PARENT:-4242}" ;;
esac
SH
  chmod +x "$fakebin/ps"

  err="$dir/fm-harness.err"
  got=$(env -u CLAUDECODE -u PI_CODING_AGENT -u GROK_AGENT \
    PATH="$fakebin:$BASE_PATH" "$ROOT/bin/fm-harness.sh" 2>"$err")
  [ "$got" = codex ] || fail "dash-leading shell ancestry resolved '$got', expected codex"
  [ ! -s "$err" ] || fail "fm-harness wrote basename option noise for literal -zsh: $(cat "$err")"

  err="$dir/fm-session-lock-ancestry.err"
  got=$(PATH="$fakebin:$BASE_PATH" bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; fm_harness_ancestry_pid' "$ROOT" 2>"$err")
  [ "$got" = 4242 ] || fail "session-lock dash-leading ancestry selected '$got', expected pid 4242"
  [ ! -s "$err" ] || fail "session-lock ancestry wrote basename option noise for literal -zsh: $(cat "$err")"

  # Force the collision: pid 5252 is a real ancestor of the caller. Its
  # -codex label belongs to the liveness probe only, so the walk must pass
  # through it as an ordinary shell and still select 4242.
  err="$dir/fm-session-lock-ancestry-collision.err"
  collision_log="$dir/fm-session-lock-ancestry-collision.log"
  got=$(FM_TEST_PS_PARENT=5252 FM_TEST_PS_LOG="$collision_log" PATH="$fakebin:$BASE_PATH" bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; fm_harness_ancestry_pid' "$ROOT" 2>"$err")
  [ "$got" = 4242 ] || fail "session-lock ancestry with pid 5252 as a real ancestor selected '$got', expected pid 4242"
  assert_contains "$(cat "$collision_log")" "5252:" \
    "session-lock collision ancestry did not query pid 5252"
  [ ! -s "$err" ] || fail "session-lock collision ancestry wrote noise: $(cat "$err")"

  err="$dir/fm-session-lock-alive.err"
  FM_TEST_PS_LIVENESS_PROBE=1 PATH="$fakebin:$BASE_PATH" bash -c \
    '. "$0/bin/fm-session-lock-lib.sh"; kill() { return 0; }; fm_harness_pid_alive 5252' \
    "$ROOT" 2>"$err"; status=$?
  expect_code 0 "$status" "session-lock liveness should accept literal -codex as a harness process name"
  [ ! -s "$err" ] || fail "session-lock liveness wrote basename option noise for literal -codex: $(cat "$err")"

  pass "harness identity: dash-leading ps command names are basename operands, not options"
}

# ===========================================================================
# B) propagate_inheritable_config unit behavior
# ===========================================================================
test_propagate_lib() {
  local d src dest home m1 m2 outside stdout stderr guard_repo err_text
  d="$TMP_ROOT/prop-lib"
  src="$d/src"
  home="$d/home1"
  dest="$home/config"
  mkdir -p "$src" "$dest" "$home/state"

  # 1. present source is copied
  printf '{"default":{"harness":"codex"}}\n' > "$src/crew-dispatch.json"
  printf 'codex\n' > "$src/crew-harness"
  printf 'manual\n' > "$src/backlog-backend"
  printf 'tmux\n' > "$src/backend"
  : > "$src/herdr-presentation-spaces"
  : > "$src/trace-context"
  printf 'claude=claudeAgent_claude_proxy\ncodex=codex\n' > "$src/t3code-instances"
  stdout="$d/clean-copy.out"
  stderr="$d/clean-copy.err"
  propagate_inheritable_config "$src" "$dest" >"$stdout" 2>"$stderr" || fail "propagate returned non-zero"
  [ ! -s "$stdout" ] || fail "clean copy wrote to stdout"
  [ ! -s "$stderr" ] || fail "clean copy wrote to stderr"
  [ "$(cat "$dest/crew-dispatch.json")" = '{"default":{"harness":"codex"}}' ] || fail "crew-dispatch.json not propagated"
  [ "$(cat "$dest/crew-harness")" = codex ] || fail "crew-harness not propagated"
  [ "$(cat "$dest/backlog-backend")" = manual ] || fail "backlog-backend not propagated"
  [ "$(cat "$dest/backend")" = tmux ] || fail "backend not propagated"
  [ -f "$dest/herdr-presentation-spaces" ] || fail "herdr-presentation-spaces not propagated"
  [ "$(cat "$dest/t3code-instances")" = "$(printf 'claude=claudeAgent_claude_proxy\ncodex=codex')" ] || fail "t3code-instances not propagated"
  printf 'herdr\n' > "$dest/backend"
  propagate_inheritable_config "$src" "$dest"
  [ "$(cat "$dest/backend")" = tmux ] || fail "primary backend did not overwrite a divergent destination"
  [ -f "$dest/trace-context" ] || fail "trace-context not propagated by the default inheritable set"

  # 2. idempotent: an unchanged re-run does not churn the mtime
  m1=$(date -r "$dest/crew-harness" +%s 2>/dev/null || stat -c %Y "$dest/crew-harness")
  sleep 1
  stdout="$d/unchanged.out"
  stderr="$d/unchanged.err"
  propagate_inheritable_config "$src" "$dest" >"$stdout" 2>"$stderr"
  [ ! -s "$stdout" ] || fail "unchanged propagation wrote to stdout"
  [ ! -s "$stderr" ] || fail "unchanged propagation wrote to stderr"
  m2=$(date -r "$dest/crew-harness" +%s 2>/dev/null || stat -c %Y "$dest/crew-harness")
  [ "$m1" = "$m2" ] || fail "idempotent re-run churned mtime ($m1 -> $m2)"

  # 3. a changed source value converges downstream
  printf '{"default":{"harness":"claude"}}\n' > "$src/crew-dispatch.json"
  printf 'claude\n' > "$src/crew-harness"
  printf 'tasks-axi\n' > "$src/backlog-backend"
  printf 'zellij\n' > "$src/backend"
  printf 'claude=claudeAgent_epplerdev\n' > "$src/t3code-instances"
  propagate_inheritable_config "$src" "$dest"
  [ "$(cat "$dest/crew-dispatch.json")" = '{"default":{"harness":"claude"}}' ] || fail "changed dispatch profile did not converge"
  [ "$(cat "$dest/crew-harness")" = claude ] || fail "changed value did not converge"
  [ "$(cat "$dest/backlog-backend")" = tasks-axi ] || fail "changed backlog backend did not converge"
  [ "$(cat "$dest/backend")" = zellij ] || fail "changed backend did not converge"
  [ "$(cat "$dest/t3code-instances")" = claude=claudeAgent_epplerdev ] || fail "changed t3code-instances did not converge"

  outside="$d/outside-target"
  rm -f "$dest/crew-harness" "$outside"
  printf 'outside\n' > "$outside"
  ln -s "$outside" "$dest/crew-harness"
  printf 'pi\n' > "$src/crew-harness"
  propagate_inheritable_config "$src" "$dest"
  [ ! -L "$dest/crew-harness" ] || fail "destination symlink was not replaced"
  [ "$(cat "$dest/crew-harness")" = pi ] || fail "destination symlink replacement has wrong content"
  [ "$(cat "$outside")" = outside ] || fail "destination symlink target was overwritten"

  # 4. removing the source mirrors absence downstream (primary-authoritative)
  printf 'herdr\n' > "$dest/backend"
  rm -f "$src/crew-dispatch.json" "$src/crew-harness" "$src/backlog-backend" \
    "$src/backend" "$src/herdr-presentation-spaces" "$src/trace-context" "$src/t3code-instances"
  propagate_inheritable_config "$src" "$dest"
  [ -e "$dest/crew-dispatch.json" ] && fail "dispatch profile absence not mirrored downstream"
  [ -e "$dest/crew-harness" ] && fail "absence not mirrored downstream"
  [ -e "$dest/backlog-backend" ] && fail "backlog-backend absence not mirrored downstream"
  [ -e "$dest/backend" ] && fail "backend absence not mirrored downstream"
  [ -e "$dest/herdr-presentation-spaces" ] && fail "herdr-presentation-spaces absence not mirrored downstream"
  [ -e "$dest/trace-context" ] && fail "trace-context absence not mirrored downstream"
  [ -e "$dest/t3code-instances" ] && fail "t3code-instances absence not mirrored downstream"

  rm -f "$dest/crew-harness"
  ln -s "$d/missing-target" "$dest/crew-harness"
  propagate_inheritable_config "$src" "$dest"
  [ -L "$dest/crew-harness" ] && fail "broken destination symlink not removed on absence mirror"

  mkdir -p "$dest/crew-harness"
  stderr="$d/remove-error.err"
  if propagate_inheritable_config "$src" "$dest" 2>"$stderr"; then
    fail "failed absence mirror returned success"
  fi
  assert_contains "$(cat "$stderr")" "fm-config-inherit: error: failed to remove crew-harness" \
    "remove error did not emit a stderr diagnostic"
  [ -d "$dest/crew-harness" ] || fail "failed absence mirror removed the wrong path"
  rm -rf "$dest/crew-harness"

  # 5. secondmate-harness is never inherited; backend still is
  printf 'grok\n' > "$src/secondmate-harness"
  printf '{"default":{"harness":"codex"}}\n' > "$src/crew-dispatch.json"
  printf 'codex\n' > "$src/crew-harness"
  printf 'manual\n' > "$src/backlog-backend"
  printf 'herdr\n' > "$src/backend"
  rm -rf "$d/home2"
  mkdir -p "$d/home2/config" "$d/home2/state"
  propagate_inheritable_config "$src" "$d/home2/config"
  [ -e "$d/home2/config/secondmate-harness" ] && fail "secondmate-harness was inherited (must not be)"
  [ "$(cat "$d/home2/config/crew-dispatch.json")" = '{"default":{"harness":"codex"}}' ] || fail "crew-dispatch.json not propagated alongside"
  [ "$(cat "$d/home2/config/crew-harness")" = codex ] || fail "crew-harness not propagated alongside"
  [ "$(cat "$d/home2/config/backlog-backend")" = manual ] || fail "backlog-backend not propagated alongside"
  [ "$(cat "$d/home2/config/backend")" = herdr ] || fail "backend not propagated alongside"

  # 5b. the supervision-host opt-out is inherited and primary-authoritative,
  # while each home's engine line stays its own: the primary's off reaches the
  # secondmate and the real gate reads that home as off on a Claude primary
  # despite its own engine line; clearing the primary's off converges it back on.
  printf 'claude sonnet\n' > "$src/supervision-host"
  printf 'default haiku\n' > "$d/home2/config/supervision-host"
  : > "$src/supervision-host-off"
  propagate_inheritable_config "$src" "$d/home2/config"
  [ -f "$d/home2/config/supervision-host-off" ] || fail "a primary's supervision-host-off was not inherited"
  if bash "$ROOT/bin/fm-supervision-engine-lib.sh" enabled "$d/home2/config" claude; then
    fail "a secondmate that inherited the primary's opt-out still runs the supervision host"
  fi
  rm -f "$src/supervision-host-off"
  propagate_inheritable_config "$src" "$d/home2/config"
  [ -e "$d/home2/config/supervision-host-off" ] && fail "clearing the primary's supervision-host-off was not mirrored downstream"
  bash "$ROOT/bin/fm-supervision-engine-lib.sh" enabled "$d/home2/config" claude \
    || fail "a secondmate did not converge back on once the primary cleared its opt-out"
  [ "$(cat "$d/home2/config/supervision-host" 2>/dev/null)" = 'default haiku' ] \
    || fail "a secondmate's own supervision-host engine line was changed by convergence"
  rm -f "$src/supervision-host"

  # 6. nothing to propagate -> destination dir is never created (a true no-op)
  rm -rf "$d/src3" "$d/dest3"
  mkdir -p "$d/src3"
  # Keep backend out of the empty-source case by clearing it from src3 only.
  propagate_inheritable_config "$d/src3" "$d/dest3/config"
  [ -e "$d/dest3/config" ] && fail "empty-source propagation created a destination dir"

  # 7. a git worktree that does not ignore an inherited item gets a visible
  # stderr warning and a skip, not a silent miss.
  guard_repo="$d/guard-repo"
  git init -q -b main "$guard_repo"
  printf 'config/crew-harness\nconfig/backlog-backend\n' > "$guard_repo/.gitignore"
  printf 'guard\n' > "$guard_repo/README.md"
  git -C "$guard_repo" add -A
  git -C "$guard_repo" commit -qm guard
  printf '{"default":{"harness":"grok"}}\n' > "$src/crew-dispatch.json"
  stdout="$d/guard-skip.out"
  stderr="$d/guard-skip.err"
  FM_INHERITABLE_CONFIG=crew-dispatch.json propagate_inheritable_config "$src" "$guard_repo/config" >"$stdout" 2>"$stderr" \
    || fail "guard skip should not make propagation fail"
  [ ! -s "$stdout" ] || fail "guard skip wrote to stdout"
  err_text=$(cat "$stderr")
  assert_contains "$err_text" "fm-config-inherit: warning: skipped crew-dispatch.json" \
    "guard skip did not emit a stderr warning"
  [ ! -e "$guard_repo/config/crew-dispatch.json" ] || fail "guard skip still copied the unignored item"

  pass "B1 propagate_inheritable_config: copy, idempotence, convergence, absence-mirror, exclusion, no-op, skip diagnostics"
}

# ===========================================================================
# B/A integration: a secondmate spawn resolves the secondmate harness and
# propagates the crew harness into the home's config.
# ===========================================================================

# A tmux stub that accepts every subcommand and prints nothing, so no window
# pre-exists and the spawn proceeds to write its meta. Echoes the fakebin dir.
make_noop_tmux() {
  local dir=$1 fakebin="$1/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/tmux" <<'SH'
#!/usr/bin/env bash
window_file="$(dirname "$0")/.spawn-window"
case "${1:-}" in
  display-message) printf 'firstmate\n' ;;
  list-windows) [ ! -s "$window_file" ] || cat "$window_file" ;;
  new-window)
    name=
    previous=
    for arg in "$@"; do
      [ "$previous" = -n ] && name=$arg
      previous=$arg
    done
    printf '%s\n' "$name" > "$window_file"
    ;;
  kill-window) : > "$window_file" ;;
esac
exit 0
SH
  chmod +x "$fakebin/tmux"
  # BASE_PATH deliberately omits the developer's node, which the trust
  # registration below needs, so link the real one in rather than presenting a
  # node-less spawn host no real fleet member looks like.
  ln -sf "$(command -v node)" "$fakebin/node"
  printf '%s\n' "$fakebin"
}

# A minimal seeded secondmate home (validate_firstmate_home_for_spawn needs the
# seed marker, AGENTS.md, bin/, and a charter to launch). config/ is intentionally
# left absent so the spawn's propagation is what creates it.
make_seeded_home() {
  local home=$1 id=$2
  mkdir -p "$home/bin" "$home/data"
  printf '# Firstmate\n' > "$home/AGENTS.md"
  printf '%s\n' "$id" > "$home/.fm-secondmate-home"
  printf 'charter\n' > "$home/data/charter.md"
  printf '%s\n' 'projects/' 'state/' 'data/' 'config/' '.no-mistakes/' > "$home/.gitignore"
  git -C "$home" init -q -b main
}

# spawn_secondmate <world> <id> <home> [explicit-harness]
# Runs fm-spawn.sh in secondmate mode. FM_ROOT is the real repo (so fm-harness.sh
# resolves), the primary config dir is <world>/home/config, and CLAUDECODE over a
# blinded ancestry walk pins detect_own. stderr is discarded (the local-HEAD ff sync harmlessly skips a
# non-worktree home). Inspect <world>/home/state/<id>.meta and <home>/config after.
spawn_secondmate() {
  local world=$1 id=$2 home=$3 harness=${4:-} fakebin
  mkdir -p "$world/home/state" "$world/home/data"
  fakebin=$(make_noop_tmux "$world/tmux-$id")
  # An empty harness must contribute zero args, not an empty positional; build the
  # arg list explicitly so the optional harness is omitted cleanly.
  local spawn_args=("$id" "$home")
  [ -n "$harness" ] && spawn_args+=("$harness")
  spawn_args+=(--secondmate)
  PATH="$fakebin:$BLIND_BIN:$BASE_PATH" TMUX='' CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$world/home" HOME="$world/home/user-home" CLAUDE_CONFIG_DIR='' \
    FM_STATE_OVERRIDE="$world/home/state" FM_DATA_OVERRIDE="$world/home/data" \
    FM_PROJECTS_OVERRIDE="$world/home/projects" FM_CONFIG_OVERRIDE="$world/home/config" \
    FM_SPAWN_NO_GUARD=1 \
    "$ROOT/bin/fm-spawn.sh" "${spawn_args[@]}" >/dev/null 2>&1 || true
}

meta_harness() { grep '^harness=' "$1" 2>/dev/null | tail -1 | cut -d= -f2-; }

# Split active: crew-harness=claude + secondmate-harness=codex. The secondmate
# AGENT launches on codex; its own crewmates inherit claude; secondmate-harness
# does not flow into the home.
test_spawn_split_and_inherit() {
  local w sm meta
  w="$TMP_ROOT/spawn-split"
  sm="$w/sm"
  mkdir -p "$w/home/config"
  printf '{"default":{"harness":"claude","model":"haiku","effort":"low"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'claude\n' > "$w/home/config/crew-harness"
  printf 'codex\n' > "$w/home/config/secondmate-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  printf 'zellij\n' > "$w/home/config/backend"
  : > "$w/home/config/supervision-host-off"
  make_seeded_home "$sm" sm

  spawn_secondmate "$w" sm "$sm"

  meta="$w/home/state/sm.meta"
  [ -f "$meta" ] || fail "split: no meta written"
  [ "$(meta_harness "$meta")" = codex ] \
    || fail "split: secondmate launched on '$(meta_harness "$meta")', expected codex"
  [ "$(cat "$sm/config/crew-harness" 2>/dev/null)" = claude ] \
    || fail "split: home crew-harness not inherited as claude (got '$(cat "$sm/config/crew-harness" 2>/dev/null)')"
  [ "$(cat "$sm/config/crew-dispatch.json" 2>/dev/null)" = '{"default":{"harness":"claude","model":"haiku","effort":"low"}}' ] \
    || fail "split: home crew-dispatch.json not inherited"
  [ "$(cat "$sm/config/backlog-backend" 2>/dev/null)" = manual ] \
    || fail "split: home backlog-backend not inherited as manual"
  [ "$(cat "$sm/config/backend" 2>/dev/null)" = zellij ] \
    || fail "split: home backend not inherited as zellij"
  [ -e "$sm/config/secondmate-harness" ] \
    && fail "split: secondmate-harness leaked into the secondmate home"
  [ -f "$sm/config/supervision-host-off" ] \
    || fail "split: home supervision-host-off not inherited"
  if bash "$ROOT/bin/fm-supervision-engine-lib.sh" enabled "$sm/config" claude; then
    fail "split: a secondmate spawned under an opted-out primary still runs the supervision host"
  fi
  pass "B2 spawn: secondmate runs the secondmate harness; its home inherits declared config"
}

# Backward-compat: secondmate-harness absent -> the secondmate launches on the
# crew harness, exactly as before this knob existed, and that crew value is the
# one inherited.
test_spawn_backward_compat_crew_fallback() {
  local w sm meta
  w="$TMP_ROOT/spawn-compat"
  sm="$w/sm"
  mkdir -p "$w/home/config"
  printf 'codex\n' > "$w/home/config/crew-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate "$w" sm "$sm"

  meta="$w/home/state/sm.meta"
  [ "$(meta_harness "$meta")" = codex ] \
    || fail "compat: secondmate launched on '$(meta_harness "$meta")', expected the crew harness codex"
  [ "$(cat "$sm/config/crew-harness" 2>/dev/null)" = codex ] \
    || fail "compat: home crew-harness not inherited as codex"
  pass "B3 spawn: an absent secondmate-harness falls back to the crew harness (backward-compat)"
}

# Bare backward-compat: no config at all. The secondmate falls through to its own
# harness (claude here), and with no inheritable file the home is left untouched -
# no config/ side effects.
test_spawn_bare_backward_compat() {
  local w sm meta
  w="$TMP_ROOT/spawn-bare"
  sm="$w/sm"
  make_seeded_home "$sm" sm

  spawn_secondmate "$w" sm "$sm"

  meta="$w/home/state/sm.meta"
  [ "$(meta_harness "$meta")" = claude ] \
    || fail "bare: secondmate launched on '$(meta_harness "$meta")', expected own harness claude"
  [ -e "$sm/config/crew-dispatch.json" ] && fail "bare: an unset primary still created a home crew-dispatch.json"
  [ -e "$sm/config/crew-harness" ] && fail "bare: an unset primary still created a home crew-harness"
  pass "B4 spawn: no config at all -> own harness and no propagation side effects"
}

# An explicit per-spawn harness arg wins over config/secondmate-harness.
test_spawn_explicit_harness_wins() {
  local w sm meta
  w="$TMP_ROOT/spawn-explicit"
  sm="$w/sm"
  mkdir -p "$w/home/config"
  printf 'codex\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate "$w" sm "$sm" claude

  meta="$w/home/state/sm.meta"
  [ "$(meta_harness "$meta")" = claude ] \
    || fail "explicit: launched on '$(meta_harness "$meta")', expected explicit claude over config codex"
  pass "B5 spawn: an explicit per-spawn harness arg overrides config/secondmate-harness"
}

# The unverified-adapter guard holds on the resolved secondmate path: an unknown
# config/secondmate-harness aborts the spawn (no meta written) and names the source.
test_spawn_unverified_secondmate_harness_refused() {
  local w sm fakebin err rc
  w="$TMP_ROOT/spawn-unverified"
  sm="$w/sm"
  mkdir -p "$w/home/config" "$w/home/state"
  printf 'bogus\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm
  fakebin=$(make_noop_tmux "$w/tmux")
  err="$w/spawn.err"
  rc=0
  PATH="$fakebin:$BASE_PATH" TMUX='' CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$w/home" HOME="$w/home/user-home" CLAUDE_CONFIG_DIR='' \
    FM_STATE_OVERRIDE="$w/home/state" FM_DATA_OVERRIDE="$w/home/data" \
    FM_PROJECTS_OVERRIDE="$w/home/projects" FM_CONFIG_OVERRIDE="$w/home/config" \
    FM_SPAWN_NO_GUARD=1 \
    "$ROOT/bin/fm-spawn.sh" sm "$sm" --secondmate >/dev/null 2>"$err" || rc=$?

  [ "$rc" -ne 0 ] || fail "unverified: spawn should have failed"
  assert_contains "$(cat "$err")" "no launch template for harness 'bogus'" \
    "unverified: error names the rejected harness"
  assert_contains "$(cat "$err")" "config/secondmate-harness" \
    "unverified: error names the secondmate-harness source"
  [ -e "$w/home/state/sm.meta" ] && fail "unverified: a meta was written despite the abort"
  pass "B6 spawn: an unverified resolved secondmate harness is refused (guard intact)"
}

test_spawn_cursor_secondmate_launches_with_its_primary_contract() {
  local w sm fakebin launchlog launch meta rc
  w="$TMP_ROOT/spawn-cursor-secondmate"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config" "$w/home/state" "$w/home/data" "$w/home/projects"
  printf 'cursor\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm
  fakebin=$(make_launch_capturing_tmux "$w/tmux")
  : > "$launchlog"
  rc=0
  PATH="$fakebin:$BASE_PATH" TMUX='' CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$w/home" HOME="$w/home/user-home" CLAUDE_CONFIG_DIR='' \
    FM_STATE_OVERRIDE="$w/home/state" FM_DATA_OVERRIDE="$w/home/data" \
    FM_PROJECTS_OVERRIDE="$w/home/projects" FM_CONFIG_OVERRIDE="$w/home/config" \
    FM_SPAWN_NO_GUARD=1 FM_FAKE_LAUNCH_LOG="$launchlog" FM_FAKE_PANE_PATH="$sm" \
    "$ROOT/bin/fm-spawn.sh" sm "$sm" --secondmate >/dev/null 2>&1 || rc=$?

  [ "$rc" -eq 0 ] || {
    echo "skip: cursor executable not resolvable in this environment, so the launch could not be built"
    return
  }
  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = cursor ] || fail "a cursor secondmate must record its own harness"
  [ "$(meta_field "$meta" kind)" = secondmate ] || fail "a cursor secondmate must record kind=secondmate"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "--trust" \
    "a cursor secondmate must launch with --trust, or none of its project hooks load and its home has no supervision at all"
  assert_contains "$launch" "--workspace" \
    "a cursor secondmate must be pinned to its own home as the workspace"
  assert_contains "$launch" "FM_SUPERVISION_MODEL=autoarm" \
    "cursor's stop-hook park runs the watcher only between turns, so its home must inherit the autoarm model"
  pass "Cursor is accepted for secondmates and launches with the contract its park needs"
}

# ===========================================================================
# C integration: config/secondmate-harness's optional model/effort tokens thread
# into the secondmate launch command and meta, durably and without a new file.
# ===========================================================================

meta_field() { grep "^$2=" "$1" 2>/dev/null | tail -1 | cut -d= -f2-; }

# A tmux stub that behaves like make_noop_tmux but also captures the literal
# `send-keys -l <cmd>` launch command into FM_FAKE_LAUNCH_LOG, mirroring the
# capture technique in fm-spawn-dispatch-profile.test.sh so the constructed
# launch command (not just meta) can be asserted on. Also answers the
# `#{pane_current_path}` probe from FM_FAKE_PANE_PATH so this same stub works
# for a crew/scout (non-secondmate) spawn's treehouse-worktree wait loop.
make_launch_capturing_tmux() {
  local dir=$1 fakebin="$1/fakebin"
  mkdir -p "$fakebin"
  cat > "$fakebin/tmux" <<'SH'
#!/usr/bin/env bash
set -u
case "$*" in
  *"#{pane_current_path}"*) printf '%s\n' "${FM_FAKE_PANE_PATH:-}"; exit 0 ;;
esac
window_file="$(dirname "$0")/.spawn-window"
case "${1:-}" in
  display-message) printf 'firstmate\n'; exit 0 ;;
  list-windows) [ ! -s "$window_file" ] || cat "$window_file"; exit 0 ;;
  new-window)
    name=
    previous=
    for arg in "$@"; do
      [ "$previous" = -n ] && name=$arg
      previous=$arg
    done
    printf '%s\n' "$name" > "$window_file"
    exit 0 ;;
  kill-window) : > "$window_file"; exit 0 ;;
  has-session|new-session) exit 0 ;;
  send-keys)
    if [ -n "${FM_FAKE_LAUNCH_LOG:-}" ]; then
      prev=
      for a in "$@"; do
        if [ "$prev" = "-l" ]; then
          case "$a" in
            ". '"*"'") staged=${a#". '"}; staged=${staged%"'"}; [ ! -f "$staged" ] || a=$(cat "$staged") ;;
          esac
          printf '%s\n' "$a" >> "$FM_FAKE_LAUNCH_LOG"
        fi
        prev=$a
      done
    fi
    exit 0
    ;;
esac
exit 0
SH
  chmod +x "$fakebin/tmux"
  fm_fake_exit0 "$fakebin" pi
  # BASE_PATH deliberately omits the developer's node, which the trust
  # registration below needs, so link the real one in rather than presenting a
  # node-less spawn host no real fleet member looks like.
  ln -sf "$(command -v node)" "$fakebin/node"
  printf '%s\n' "$fakebin"
}

# The --add-dir grant a Claude secondmate launch carries between its
# permission flag and --settings: only the PARENT home's state/<id>.inbox,
# real-path resolved the way the spawn's claude_add_dirs_flag resolves it.
# Prints a trailing space so callers can drop it straight into an expected
# command.
sm_claude_add_dir() {  # <world> <id>
  local real
  real=$(cd "$1/home/state" && pwd -P)
  printf "%s " "--add-dir '$real/$2.inbox'"
}

# The parent-state settings file a Claude secondmate launch passes to --settings.
sm_claude_settings() {  # <world> <id>
  local real
  real=$(cd "$1/home/state" && pwd -P)
  printf '%s' "$real/$2.claude-settings.json"
}

# spawn_secondmate_capture <world> <id> <home> <launchlog> [extra fm-spawn.sh args...]
# Same shape as spawn_secondmate but captures the launch command into <launchlog>
# and does not discard stderr, so callers can assert on both.
spawn_secondmate_capture() {
  local world=$1 id=$2 home=$3 launchlog=$4 fakebin
  shift 4
  mkdir -p "$world/home/state" "$world/home/data"
  fakebin=$(make_launch_capturing_tmux "$world/tmux-$id")
  : > "$launchlog"
  PATH="$fakebin:$BLIND_BIN:$BASE_PATH" TMUX='' CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$world/home" HOME="$world/home/user-home" CLAUDE_CONFIG_DIR='' \
    FM_STATE_OVERRIDE="$world/home/state" FM_DATA_OVERRIDE="$world/home/data" \
    FM_PROJECTS_OVERRIDE="$world/home/projects" FM_CONFIG_OVERRIDE="$world/home/config" \
    FM_SPAWN_NO_GUARD=1 FM_FAKE_LAUNCH_LOG="$launchlog" \
    "$ROOT/bin/fm-spawn.sh" "$id" "$home" "$@" --secondmate
}

test_spawn_backend_precedence_over_inherited_config() {
  local w sm meta launchlog out status
  w="$TMP_ROOT/spawn-backend-env-precedence"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'herdr\n' > "$w/home/config/backend"
  make_seeded_home "$sm" sm

  out=$(FM_BACKEND=tmux spawn_secondmate_capture \
    "$w" sm "$sm" "$launchlog" 2>&1); status=$?
  expect_code 0 "$status" \
    "FM_BACKEND=tmux should beat inherited config/backend=herdr"$'\n'"$out"

  meta="$w/home/state/sm.meta"
  [ "$(cat "$sm/config/backend")" = herdr ] \
    || fail "backend precedence fixture did not inherit config/backend=herdr"
  assert_no_regex '^backend=' "$meta" \
    "FM_BACKEND=tmux did not beat inherited config/backend=herdr"
  pass "B5b spawn: FM_BACKEND wins over inherited config/backend"
}

test_spawn_explicit_backend_precedence_over_env_and_inherited_config() {
  local w sm meta launchlog out status
  w="$TMP_ROOT/spawn-backend-flag-precedence"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'herdr\n' > "$w/home/config/backend"
  make_seeded_home "$sm" sm

  out=$(FM_BACKEND=zellij spawn_secondmate_capture \
    "$w" sm "$sm" "$launchlog" --backend tmux 2>&1); status=$?
  expect_code 0 "$status" \
    "explicit --backend tmux should beat FM_BACKEND=zellij and inherited config/backend=herdr"$'\n'"$out"

  meta="$w/home/state/sm.meta"
  [ "$(cat "$sm/config/backend")" = herdr ] \
    || fail "explicit backend precedence fixture did not inherit config/backend=herdr"
  assert_no_regex '^backend=' "$meta" \
    "explicit --backend tmux did not beat FM_BACKEND=zellij and inherited config/backend=herdr"
  pass "B5c spawn: explicit --backend wins over FM_BACKEND and inherited config/backend"
}

# A bare "<harness>" secondmate-harness file (today's format) must launch with
# NO --model/--effort flag at all, and meta must keep recording model=default,
# effort=default - the core backward-compat requirement of the new format.
test_spawn_bare_harness_no_model_effort_flag() {
  local w sm meta launchlog launch out status
  w="$TMP_ROOT/spawn-bare-tokens"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  out=$(spawn_secondmate_capture "$w" sm "$sm" "$launchlog" 2>&1); status=$?
  expect_code 0 "$status" "bare-harness secondmate spawn should succeed"

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" model)" = default ] || fail "bare-tokens: meta model not default (got '$(meta_field "$meta" model)')"
  [ "$(meta_field "$meta" effort)" = default ] || fail "bare-tokens: meta effort not default (got '$(meta_field "$meta" effort)')"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "CLAUDE_CODE_SEND_FEEDBACK=0 claude" \
    "bare-tokens: Claude secondmate launch did not disable feedback drafts"
  assert_not_contains "$launch" "--model" "bare-tokens: launch must not carry a --model flag"
  assert_not_contains "$launch" "--effort" "bare-tokens: launch must not carry an --effort flag"
  pass "C2 spawn: a bare harness-only secondmate-harness file launches with no model/effort flag (backward-compat)"
}

# "<harness> <model>" durably threads --model into the secondmate launch and
# records it in meta, with no --effort flag (no effort token supplied).
test_spawn_secondmate_harness_model_token() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-model-token"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = claude ] || fail "model-token: meta harness not claude"
  [ "$(meta_field "$meta" model)" = opus ] || fail "model-token: meta model not opus (got '$(meta_field "$meta" model)')"
  [ "$(meta_field "$meta" effort)" = default ] || fail "model-token: meta effort not default (got '$(meta_field "$meta" effort)')"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "claude --dangerously-skip-permissions $(sm_claude_add_dir "$w" sm)--settings '$(sm_claude_settings "$w" sm)' --model 'opus'" \
    "model-token: launch did not carry --model opus"
  jq -e '.feedbackDrafts == "off" and .attribution.commit == "" and .attribution.pr == "" and .attribution.sessionUrl == false and .hooks.UserPromptSubmit' \
    "$(sm_claude_settings "$w" sm)" >/dev/null \
    || fail "model-token: the --settings file did not carry the session keys and busy hooks"
  assert_not_contains "$launch" "--effort" "model-token: launch must not carry an --effort flag"
  pass "C3 spawn: config/secondmate-harness's model token threads --model into the launch and meta"
}

# "<harness> <model> <effort>" threads both flags into the launch and meta.
test_spawn_secondmate_harness_model_and_effort_tokens() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-model-effort-tokens"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" model)" = opus ] || fail "model-effort-tokens: meta model not opus"
  [ "$(meta_field "$meta" effort)" = high ] || fail "model-effort-tokens: meta effort not high (got '$(meta_field "$meta" effort)')"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "claude --dangerously-skip-permissions $(sm_claude_add_dir "$w" sm)--settings '$(sm_claude_settings "$w" sm)' --model 'opus' --effort 'high'" \
    "model-effort-tokens: launch did not carry both --model opus and --effort high"
  pass "C4 spawn: config/secondmate-harness's model+effort tokens thread into the launch and meta"
}

# A pin file the captain wrote before the override grammar existed - a second
# default line, a fourth token, anything else after the first line - must still
# launch a secondmate exactly as it did then: the first non-empty, non-comment
# line supplies the runtime and the rest of the file is ignored, never a
# refusal. This is the spawn half of the opt-in scope.
test_spawn_secondmate_with_a_legacy_pin_file_uses_the_first_line() {
  local w sm meta launchlog launch out status
  w="$TMP_ROOT/spawn-legacy-pin"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high extra\ngrok other-model low\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  out=$(spawn_secondmate_capture "$w" sm "$sm" "$launchlog" 2>&1); status=$?
  expect_code 0 "$status" "a legacy pin file must not refuse a secondmate spawn"$'\n'"$out"

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = claude ] || fail "legacy-pin: meta harness not claude"
  [ "$(meta_field "$meta" model)" = opus ] || fail "legacy-pin: meta model not opus (got '$(meta_field "$meta" model)')"
  [ "$(meta_field "$meta" effort)" = high ] || fail "legacy-pin: meta effort not high (got '$(meta_field "$meta" effort)')"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "--model 'opus' --effort 'high'" \
    "legacy-pin: the launch did not carry the first line's tokens"
  assert_not_contains "$launch" "extra" \
    "legacy-pin: the fourth token of the first line must not reach the launch"
  pass "C10 spawn: a legacy secondmate-harness file still launches on its first line (opt-in scope)"
}

# The other half of the same scope: a file that DOES declare an override is
# validated as a whole, so a malformed one refuses the spawn loudly instead of
# quietly launching the mate onto the default runtime.
test_spawn_secondmate_with_a_malformed_declared_pin_refuses() {
  local w sm out status
  w="$TMP_ROOT/spawn-bad-declared-pin"
  sm="$w/sm"
  mkdir -p "$w/home/config"
  printf 'claude opus high\nmate sm: claude opus max\nmate sm: grok other-model low\n' \
    > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  out=$(spawn_secondmate_capture "$w" sm "$sm" "$w/launch.log" 2>&1); status=$?
  [ "$status" -ne 0 ] || fail "a malformed declared pin must refuse the spawn"$'\n'"$out"
  assert_contains "$out" "config/secondmate-harness line 3" \
    "the refusal must name the offending line of the pin file"
  [ ! -f "$w/home/state/sm.meta" ] \
    || fail "a refused spawn must not publish a mate record"
  pass "C11 spawn: a declared pin file that is malformed refuses the spawn with its line number"
}

# Precedence: an explicit per-spawn --model overrides the file's model token.
test_spawn_explicit_model_overrides_secondmate_harness_token() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-explicit-model"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" --model sonnet >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" model)" = sonnet ] \
    || fail "explicit-model: meta model not sonnet (got '$(meta_field "$meta" model)'), explicit flag did not win over file token"
  [ "$(meta_field "$meta" effort)" = high ] || fail "explicit-model: file's effort token should still apply"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "--model 'sonnet'" "explicit-model: launch did not use the explicit --model"
  assert_not_contains "$launch" "--model 'opus'" "explicit-model: launch leaked the file's model token"
  pass "C5 spawn: an explicit --model overrides config/secondmate-harness's model token; the file's effort token still applies"
}

# Precedence: an explicit per-spawn --effort overrides the file's effort token.
test_spawn_explicit_effort_overrides_secondmate_harness_token() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-explicit-effort"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" --effort low >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" model)" = opus ] || fail "explicit-effort: file's model token should still apply"
  [ "$(meta_field "$meta" effort)" = low ] \
    || fail "explicit-effort: meta effort not low (got '$(meta_field "$meta" effort)'), explicit flag did not win over file token"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "--effort 'low'" "explicit-effort: launch did not use the explicit --effort"
  assert_not_contains "$launch" "--effort 'high'" "explicit-effort: launch leaked the file's effort token"
  pass "C6 spawn: an explicit --effort overrides config/secondmate-harness's effort token; the file's model token still applies"
}

test_spawn_explicit_harness_does_not_inherit_secondmate_harness_tokens() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-explicit-harness-no-tokens"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" --harness codex >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = codex ] || fail "explicit-harness-no-tokens: meta harness not codex"
  [ "$(meta_field "$meta" model)" = default ] || fail "explicit-harness-no-tokens: meta model should stay default"
  [ "$(meta_field "$meta" effort)" = default ] || fail "explicit-harness-no-tokens: meta effort should stay default"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "codex --dangerously-bypass-approvals-and-sandbox" \
    "explicit-harness-no-tokens: launch did not use Codex bypass flag"
  assert_not_contains "$launch" "--model" "explicit-harness-no-tokens: launch must not carry a --model flag"
  assert_not_contains "$launch" "model_reasoning_effort" \
    "explicit-harness-no-tokens: launch must not carry a codex effort flag"
  pass "C7 spawn: an explicit --harness starts with clean model/effort defaults"
}

test_spawn_explicit_harness_uses_explicit_profile_axes() {
  local w sm meta launchlog launch
  w="$TMP_ROOT/spawn-explicit-harness-explicit-axes"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus high\n' > "$w/home/config/secondmate-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" --harness codex --model gpt-5.5 --effort xhigh >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = codex ] || fail "explicit-harness-explicit-axes: meta harness not codex"
  [ "$(meta_field "$meta" model)" = gpt-5.5 ] || fail "explicit-harness-explicit-axes: meta model did not use explicit value"
  [ "$(meta_field "$meta" effort)" = xhigh ] || fail "explicit-harness-explicit-axes: meta effort did not use explicit value"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "--model 'gpt-5.5'" \
    "explicit-harness-explicit-axes: launch did not use the explicit --model"
  assert_contains "$launch" "-c 'model_reasoning_effort=\"xhigh\"'" \
    "explicit-harness-explicit-axes: launch did not use the explicit --effort"
  assert_not_contains "$launch" "--model 'opus'" \
    "explicit-harness-explicit-axes: launch leaked the file's model token"
  assert_not_contains "$launch" "model_reasoning_effort=\"high\"" \
    "explicit-harness-explicit-axes: launch leaked the file's effort token"
  pass "C8 spawn: an explicit --harness still honors explicit model/effort flags"
}

test_spawned_secondmate_uses_its_harness_supervision_model() {
  local harness expected w sm launchlog launch fakebin out
  for harness in codex claude; do
    w="$TMP_ROOT/spawn-supervision-model-$harness"
    sm="$w/sm"
    launchlog="$w/launch.log"
    mkdir -p "$w/home/config"
    printf '%s\n' "$harness" > "$w/home/config/secondmate-harness"
    make_seeded_home "$sm" sm
    spawn_secondmate_capture "$w" sm "$sm" "$launchlog" >/dev/null 2>&1
    fm_write_meta "$sm/state/task.meta" "window=firstmate:fm-task" "kind=ship"
    touch "$sm/state/.last-watcher-beat"
    fakebin="$w/tmux-sm/fakebin"
    # Point the guard at the fixture home, not at whatever checkout this suite
    # happens to be running from. The guard also reports a tangled primary
    # checkout, so without this the branch a contributor is working on decides
    # whether this assertion passes.
    cat > "$fakebin/$harness" <<SH
#!/usr/bin/env bash
FM_ROOT_OVERRIDE="$sm" "$ROOT/bin/fm-guard.sh"
SH
    chmod +x "$fakebin/$harness"
    launch=$(cat "$launchlog")
    out=$(PATH="$fakebin:$BASE_PATH" CLAUDECODE=1 bash -c "$launch" 2>&1)
    case "$harness" in
      codex)
        expected='WATCHER DOWN - SUPERVISION IS OFF'
        assert_contains "$out" "$expected" \
          "Codex secondmate inherited Claude auto-arm despite its persistent watcher model"
        ;;
      claude)
        [ -z "$out" ] \
          || fail "Claude secondmate with a fresh beacon should use auto-arm supervision, got: $out"
        ;;
    esac
  done
  pass "C9 spawn: secondmate launch pins supervision to its own harness"
}

# The harness fallback chain (secondmate-harness -> crew-harness -> own) still
# resolves correctly with no model/effort tokens anywhere in the chain, and a
# crew/scout (non-secondmate) launch is entirely unaffected by this feature: no
# model/effort is invented for it even though its own project has no profile set.
test_spawn_fallback_chain_and_crew_scout_unaffected() {
  local w sm meta home proj wt fakebin launchlog id launch
  w="$TMP_ROOT/spawn-fallback-and-crew"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'codex\n' > "$w/home/config/crew-harness"
  make_seeded_home "$sm" sm

  spawn_secondmate_capture "$w" sm "$sm" "$launchlog" >/dev/null 2>&1

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = codex ] \
    || fail "fallback: secondmate harness did not fall back to crew-harness codex"
  [ "$(meta_field "$meta" model)" = default ] || fail "fallback: meta model should stay default with no tokens anywhere"
  [ "$(meta_field "$meta" effort)" = default ] || fail "fallback: meta effort should stay default with no tokens anywhere"

  # Crew/scout launch: same crew-harness config, no --secondmate. Must resolve
  # the crew harness and record no model/effort - this codepath must never read
  # config/secondmate-harness's tokens at all.
  id="crew-unaffected-z1"
  home="$w/home"
  proj="$w/crew-project"
  wt="$w/crew-wt"
  fakebin=$(make_launch_capturing_tmux "$w/tmux-crew")
  fm_git_worktree "$proj" "$wt" "wt-crew"
  mkdir -p "$home/data/$id" "$home/projects" "$home/state"
  cat > "$home/data/$id/brief.md" <<'EOF'
# Task
## Captain's intent
Exercise an ordinary crew launch.

## Firstmate spec
Verify secondmate harness settings do not affect it.
EOF
  : > "$launchlog"
  PATH="$fakebin:$BASE_PATH" TMUX="fake,1,0" CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$home" \
    FM_STATE_OVERRIDE="$home/state" FM_DATA_OVERRIDE="$home/data" \
    FM_PROJECTS_OVERRIDE="$home/projects" FM_CONFIG_OVERRIDE="$home/config" \
    FM_SPAWN_NO_GUARD=1 FM_FAKE_PANE_PATH="$wt" FM_FAKE_LAUNCH_LOG="$launchlog" \
    "$ROOT/bin/fm-spawn.sh" "$id" "$proj" --mode no-mistakes --yolo off >/dev/null 2>&1
  meta="$home/state/$id.meta"
  [ "$(meta_field "$meta" kind)" = ship ] || fail "crew-unaffected: expected an ordinary ship task"
  [ "$(meta_field "$meta" harness)" = codex ] || fail "crew-unaffected: crew harness resolution changed"
  [ "$(meta_field "$meta" model)" = default ] || fail "crew-unaffected: crew task must not invent a model"
  [ "$(meta_field "$meta" effort)" = default ] || fail "crew-unaffected: crew task must not invent an effort"
  launch=$(cat "$launchlog")
  assert_not_contains "$launch" "--model" "crew-unaffected: crew launch must not carry a --model flag"
  assert_not_contains "$launch" "--effort" "crew-unaffected: crew launch must not carry an --effort flag"
  pass "C9 spawn: the harness fallback chain still resolves with no tokens; crew/scout launches are unaffected by this feature"
}

# ===========================================================================
# B integration: spawn, bootstrap, and config push propagate inherited local
# material and keep it converged on the primary (independent of tracked-file ff
# status).
# ===========================================================================

# A PRIMARY firstmate repo on main with one commit + a home dir, mirroring the
# real gitignore (config/crew-harness ignored, so a propagated value never dirties
# the secondmate worktree on a later sweep). Echoes the world dir.
new_world() {
  local name=$1 dispatch_ignore=${2:-yes} w
  w="$TMP_ROOT/$name"
  mkdir -p "$w/home/state" "$w/home/data" "$w/home/config"
  touch "$w/home/state/.last-watcher-beat"
  git init -q -b main "$w/main"
  {
    printf 'projects/\nstate/\ndata/\n.no-mistakes/\n'
    [ "$dispatch_ignore" = no ] || printf 'config/crew-dispatch.json\n'
    printf 'config/crew-harness\nconfig/secondmate-harness\nconfig/backlog-backend\n'
    printf 'config/backend\nconfig/herdr-presentation-spaces\nconfig/startup-memory-budget\n'
    printf 'config/claude-permission-mode\nconfig/codex-approval-mode\n'
  } > "$w/main/.gitignore"
  printf 'v1\n' > "$w/main/AGENTS.md"
  printf 'r1\n' > "$w/main/README.md"
  mkdir -p "$w/main/bin"
  printf 'echo a\n' > "$w/main/bin/tool.sh"
  git -C "$w/main" add -A
  git -C "$w/main" commit -qm c1
  printf '%s\n' "$w"
}

record_live_watcher_fixture() {
  local home=$1 identity
  identity=$(FM_STATE_OVERRIDE="$home/state" bash -c '. "$1"; fm_pid_identity "$2"' _ \
    "$ROOT/bin/fm-wake-lib.sh" "$$") || fail "could not identify the live watcher fixture"
  mkdir "$home/state/.watch.lock"
  printf '%s\n' "$$" > "$home/state/.watch.lock/pid"
  printf '%s\n' "$home" > "$home/state/.watch.lock/fm-home"
  printf '%s\n' "$ROOT/bin/fm-watch.sh" > "$home/state/.watch.lock/watcher-path"
  printf '%s\n' "$identity" > "$home/state/.watch.lock/pid-identity"
  touch "$home/state/.last-watcher-beat"
}

# A live secondmate home as a DETACHED worktree of the primary at <commit>, with
# its seed marker and a live kind=secondmate meta.
add_sm_worktree() {
  local w=$1 id=$2 commit=$3
  git -C "$w/main" worktree add -q --detach "$w/$id" "$commit"
  printf '%s\n' "$id" > "$w/$id/.fm-secondmate-home"
  {
    printf 'window=firstmate:fm-%s\n' "$id"
    printf 'kind=secondmate\n'
    printf 'home=%s/%s\n' "$w" "$id"
  } > "$w/home/state/$id.meta"
}

make_fake_toolchain() {
  local dir=$1 fakebin
  fakebin="$dir/fakebin"
  mkdir -p "$fakebin"
  fm_fake_exit0 "$fakebin" node chrome-devtools-axi
  fm_fake_version_tool "$fakebin" lavish-axi FM_FAKE_LAVISH_AXI_VERSION 0.1.80
  cat > "$fakebin/gh-axi" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --version ]; then
  printf '%s\n' '0.1.29'
  exit 0
fi
exit 0
SH
  chmod +x "$fakebin/gh-axi"
  # tmux fake supports fm-send's composer-verified submit path and optional
  # FM_FAKE_TMUX_LOG / FM_FAKE_TMUX_FAIL_LITERAL for reread-nudge assertions.
  cat > "$fakebin/tmux" <<'SH'
#!/usr/bin/env bash
if [ -n "${FM_FAKE_TMUX_LOG:-}" ]; then
  printf '%s\n' "$*" >> "$FM_FAKE_TMUX_LOG"
fi
case "$*" in
  list-windows*)
    sed -n 's/^window=[^:]*://p' "${FM_HOME:?}"/state/*.meta
    exit 0
    ;;
  *display-message*'#{pane_current_command}'*) printf '%s\n' codex; exit 0 ;;
  *display-message*'#{pane_id}'*) printf '%s\n' '%1'; exit 0 ;;
  *display-message*'#{cursor_y}'*) printf '%s\n' 0; exit 0 ;;
  *capture-pane*) printf '❯\n'; exit 0 ;;
  *'send-keys'*' -l '*)
    [ "${FM_FAKE_TMUX_FAIL_LITERAL:-0}" = 1 ] && exit 1
    exit 0
    ;;
  *send-keys*)
    [ "${FM_FAKE_TMUX_FAIL_LITERAL:-0}" = 1 ] && exit 1
    exit 0
    ;;
esac
exit 0
SH
  chmod +x "$fakebin/tmux"
  cat > "$fakebin/gh" <<'SH'
#!/usr/bin/env bash
exit 0
SH
  chmod +x "$fakebin/gh"
  cat > "$fakebin/treehouse" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = get ] && [ "${2:-}" = --help ]; then
  printf '%s\n' 'Usage: treehouse get [--lease]'
fi
exit 0
SH
  chmod +x "$fakebin/treehouse"
  cat > "$fakebin/no-mistakes" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --version ]; then
  printf '%s\n' 'no-mistakes version v1.46.0 (fake)'
  exit 0
fi
exit 0
SH
  chmod +x "$fakebin/no-mistakes"
  cat > "$fakebin/tasks-axi" <<'SH'
#!/usr/bin/env bash
case "${1:-} ${2:-}" in
  "--version ") printf '%s\n' '0.2.6' ;;
  "update --help") printf '%s\n' 'usage: tasks-axi update <id> [flags]' '  --archive-body' ;;
  "mv --help") printf '%s\n' 'usage: tasks-axi mv <id> [<id>...] --to <path-or-dir>' ;;
esac
exit 0
SH
  chmod +x "$fakebin/tasks-axi"
  cat > "$fakebin/quota-axi" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = --version ]; then
  printf '%s\n' '0.1.51'
  exit 0
fi
exit 0
SH
  chmod +x "$fakebin/quota-axi"
  printf '%s\n' "$fakebin"
}

run_bootstrap() {
  local w=$1 fakebin log=${2:-}
  fakebin=$(make_fake_toolchain "$w")
  if [ -n "$log" ]; then
    PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
      FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
      "$ROOT/bin/fm-bootstrap.sh" 2>/dev/null
  else
    PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
      FM_SEND_SETTLE=0 "$ROOT/bin/fm-bootstrap.sh" 2>/dev/null
  fi
}

run_config_push() {
  local w=$1 fakebin log=${2:-}
  fakebin=$(make_fake_toolchain "$w")
  if [ -n "$log" ]; then
    PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
      FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
      "$ROOT/bin/fm-config-push.sh"
  else
    PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
      FM_SEND_SETTLE=0 \
      "$ROOT/bin/fm-config-push.sh"
  fi
}

# Config-reread pointers now ride fm-send's durable steering inbox: the typed
# channel carries only the constant doorbell, while each pointer message is a
# sequenced record under the parent state's <task>.inbox/. Print every recorded
# steer body in sequence order (one line per pointer-only message), read
# through the production owner so no format knowledge is duplicated here.
inbox_stream() {  # <parent-state-dir> <task-id>
  local rec
  for rec in "$1/$2.inbox"/*.msg; do
    [ -e "$rec" ] || continue
    bash -c '. "$1"; fm_task_inbox_body "$2"' _ "$ROOT/bin/fm-task-inbox-lib.sh" "$rec"
    printf '\n'
  done
}

reread_instruction_path() {
  local home=$1 state path latest=
  state="$(cd "$home/state" && pwd -P)"
  for path in "$state"/.fm-inherited-config-reread.*; do
    case "$path" in
      *.pending) continue ;;
    esac
    [ -f "$path" ] && [ ! -L "$path" ] || continue
    latest="$path"
  done
  [ -n "$latest" ] || return 1
  printf '%s\n' "$latest"
}

reread_pending_path() {
  printf '%s.pending\n' "$(reread_instruction_path "$1")"
}

reread_retry_stage_path() {
  local home=$1 id=$2 retry_dir path latest=
  retry_dir="$home/state/.fm-inherited-config-reread-retry/$id"
  for path in "$retry_dir"/.fm-inherited-config-reread.*; do
    [ -f "$path" ] && [ ! -L "$path" ] || continue
    latest="$path"
  done
  [ -n "$latest" ] || return 1
  printf '%s\n' "$latest"
}

reread_retry_report_path() {
  local home=$1 id=$2 retry_dir path latest=
  retry_dir="$home/state/.fm-inherited-config-reread-retry/$id"
  for path in "$retry_dir"/.fm-inherited-config-reread.*.report; do
    [ -f "$path" ] && [ ! -L "$path" ] || continue
    latest="$path"
  done
  [ -n "$latest" ] || return 1
  printf '%s\n' "$latest"
}

reread_mode() {
  if [ "$(uname)" = Darwin ]; then
    stat -f %Lp "$1"
  else
    stat -c %a "$1"
  fi
}

assert_no_reread_instructions() {
  local home=$1 state path
  state="$home/state"
  for path in "$state"/.fm-inherited-config-reread.*; do
    case "$path" in
      *.pending) continue ;;
    esac
    [ -f "$path" ] || [ -L "$path" ] || continue
    fail "unexpected config reread instruction: $path"
  done
}

assert_no_reread_pending() {
  local home=$1 state path
  state="$home/state"
  for path in "$state"/.fm-inherited-config-reread.*.pending; do
    [ -e "$path" ] || [ -L "$path" ] || continue
    fail "unexpected pending config reread marker: $path"
  done
}

assert_no_reread_retry_stages() {
  local home=$1 id=$2 retry_dir path
  retry_dir="$home/state/.fm-inherited-config-reread-retry/$id"
  for path in "$retry_dir"/.fm-inherited-config-reread.*; do
    [ -e "$path" ] || [ -L "$path" ] || continue
    fail "unexpected staged config reread retry: $path"
  done
}

# The sweep pushes the primary's declared inherited config into a live home,
# re-converges it when the primary changes it, and mirrors absence when the
# primary clears it - all while never inheriting secondmate-harness.
test_bootstrap_sweep_propagates_and_reconverges() {
  local w c1
  w=$(new_world boot-prop)
  c1=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$c1"

  # Initial push: primary crew-harness=codex, secondmate-harness=grok (must NOT flow).
  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  printf 'tmux\n' > "$w/home/config/backend"
  : > "$w/home/config/trace-context"
  printf 'grok\n' > "$w/home/config/secondmate-harness"
  run_bootstrap "$w" >/dev/null
  [ "$(cat "$w/sm/config/crew-harness" 2>/dev/null)" = codex ] \
    || fail "sweep: crew-harness not pushed into the live home"
  [ "$(cat "$w/sm/config/crew-dispatch.json" 2>/dev/null)" = '{"default":{"harness":"codex"}}' ] \
    || fail "sweep: crew-dispatch.json not pushed into the live home"
  [ "$(cat "$w/sm/config/backlog-backend" 2>/dev/null)" = manual ] \
    || fail "sweep: backlog-backend not pushed into the live home"
  [ "$(cat "$w/sm/config/backend" 2>/dev/null)" = tmux ] \
    || fail "sweep: backend not pushed into the live home"
  [ ! -e "$w/sm/config/trace-context" ] \
    || fail "sweep: trace-context changed a legacy live home before relaunch"
  [ -e "$w/sm/config/secondmate-harness" ] \
    && fail "sweep: secondmate-harness was inherited (must not be)"

  # Re-converge: primary changes inherited config values; the home follows on the next sweep.
  printf '{"default":{"harness":"claude"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'claude\n' > "$w/home/config/crew-harness"
  printf 'tasks-axi\n' > "$w/home/config/backlog-backend"
  printf 'zellij\n' > "$w/home/config/backend"
  run_bootstrap "$w" >/dev/null
  [ "$(cat "$w/sm/config/crew-harness" 2>/dev/null)" = claude ] \
    || fail "sweep: home did not re-converge to the primary's new crew-harness"
  [ "$(cat "$w/sm/config/crew-dispatch.json" 2>/dev/null)" = '{"default":{"harness":"claude"}}' ] \
    || fail "sweep: home did not re-converge to the primary's new crew-dispatch.json"
  [ "$(cat "$w/sm/config/backlog-backend" 2>/dev/null)" = tasks-axi ] \
    || fail "sweep: home did not re-converge to the primary's new backlog-backend"
  [ "$(cat "$w/sm/config/backend" 2>/dev/null)" = zellij ] \
    || fail "sweep: home did not re-converge to the primary's new backend"

  # Mirror absence: primary clears inherited config; the home's copies are removed.
  rm -f "$w/home/config/crew-dispatch.json" "$w/home/config/crew-harness" \
    "$w/home/config/backlog-backend" "$w/home/config/backend"
  run_bootstrap "$w" >/dev/null
  [ -e "$w/sm/config/crew-dispatch.json" ] \
    && fail "sweep: home crew-dispatch.json not removed after the primary cleared it"
  [ -e "$w/sm/config/crew-harness" ] \
    && fail "sweep: home crew-harness not removed after the primary cleared it"
  [ -e "$w/sm/config/backlog-backend" ] \
    && fail "sweep: home backlog-backend not removed after the primary cleared it"
  [ -e "$w/sm/config/backend" ] \
    && fail "sweep: home backend not removed after the primary cleared it"
  pass "B7 bootstrap sweep pushes, re-converges, and mirrors absence; never inherits secondmate-harness"
}

# Convergence is independent of the tracked-files fast-forward: a home already
# current on tracked files still receives a config change.
test_bootstrap_sweep_propagates_when_tracked_current() {
  local w head
  w=$(new_world boot-prop-current)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"   # already on the primary's HEAD (ff is a no-op)

  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  printf 'tmux\n' > "$w/home/config/backend"
  run_bootstrap "$w" >/dev/null
  [ "$(cat "$w/sm/config/crew-dispatch.json" 2>/dev/null)" = '{"default":{"harness":"codex"}}' ] \
    || fail "crew-dispatch.json did not propagate to a tracked-current home"
  [ "$(cat "$w/sm/config/crew-harness" 2>/dev/null)" = codex ] \
    || fail "config did not propagate to a tracked-current home"
  [ "$(cat "$w/sm/config/backlog-backend" 2>/dev/null)" = manual ] \
    || fail "backlog-backend did not propagate to a tracked-current home"
  [ "$(cat "$w/sm/config/backend" 2>/dev/null)" = tmux ] \
    || fail "backend did not propagate to a tracked-current home"
  pass "B8 bootstrap sweep propagates config even when the home's tracked files are already current"
}

test_bootstrap_sweep_defers_dispatch_on_stale_unignored_home() {
  local w out status
  w=$(new_world boot-stale-dispatch no)
  add_sm_worktree "$w" sm "$(git -C "$w/main" rev-parse HEAD)"
  printf 'local divergence\n' >> "$w/sm/README.md"
  git -C "$w/sm" add README.md
  git -C "$w/sm" commit -qm local
  printf 'config/crew-dispatch.json\n' >> "$w/main/.gitignore"
  git -C "$w/main" add .gitignore
  git -C "$w/main" commit -qm c2

  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  out=$(run_bootstrap "$w")

  assert_contains "$out" "SECONDMATE_SYNC: secondmate sm: skipped: diverged from" \
    "stale dispatch: expected fast-forward skip"
  [ ! -e "$w/sm/config/crew-dispatch.json" ] \
    || fail "stale dispatch: crew-dispatch.json was copied before the home ignored it"
  [ "$(cat "$w/sm/config/crew-harness" 2>/dev/null)" = codex ] \
    || fail "stale dispatch: existing ignored config stopped propagating"
  [ "$(cat "$w/sm/config/backlog-backend" 2>/dev/null)" = manual ] \
    || fail "stale dispatch: backlog backend stopped propagating"
  status=$(git -C "$w/sm" status --porcelain -- config/crew-dispatch.json)
  [ -z "$status" ] || fail "stale dispatch: crew-dispatch.json dirtied the home: $status"
  pass "B9 bootstrap sweep defers new inherited config until the home ignores it"
}

# The primary bootstrap always materializes the startup-memory default, so an
# otherwise empty inherited surface converges that one visible value while
# ordinary tracked-file fast-forward behavior remains unchanged.
test_bootstrap_sweep_materializes_and_inherits_memory_default() {
  local w c1
  w=$(new_world boot-noop)
  c1=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$c1"
  # Advance the primary so the sweep has a real fast-forward to perform.
  printf 'v2\n' > "$w/main/AGENTS.md"
  git -C "$w/main" add -A
  git -C "$w/main" commit -qm c2
  local head
  head=$(git -C "$w/main" rev-parse HEAD)

  run_bootstrap "$w" >/dev/null

  [ -e "$w/sm/config/crew-dispatch.json" ] && fail "default-only sweep created a home crew-dispatch.json"
  [ -e "$w/sm/config/crew-harness" ] && fail "default-only sweep created a home crew-harness"
  [ -e "$w/sm/config/backend" ] && fail "default-only sweep created a home backend"
  [ "$(cat "$w/home/config/startup-memory-budget")" = 7500 ] \
    || fail "primary bootstrap did not materialize the startup-memory default"
  [ "$(cat "$w/sm/config/startup-memory-budget")" = 7500 ] \
    || fail "default-only sweep did not converge startup-memory-budget"
  [ "$(git -C "$w/sm" rev-parse HEAD)" = "$head" ] \
    || fail "default-only sweep did not still fast-forward the tracked files"
  pass "B10 bootstrap sweep materializes and inherits the startup-memory default while fast-forwarding"
}

# config/backend: present and absent primary state converges exactly.
# config/claude-permission-mode=auto reaches a Claude SECONDMATE launch too: the
# same template swap as a crewmate, with model/effort untouched.
test_spawn_secondmate_claude_permission_mode_auto() {
  local w sm meta launchlog launch out status
  w="$TMP_ROOT/spawn-claude-permmode"
  sm="$w/sm"
  launchlog="$w/launch.log"
  mkdir -p "$w/home/config"
  printf 'claude opus\n' > "$w/home/config/secondmate-harness"
  printf 'auto\n' > "$w/home/config/claude-permission-mode"
  make_seeded_home "$sm" sm

  out=$(spawn_secondmate_capture "$w" sm "$sm" "$launchlog" 2>&1); status=$?
  expect_code 0 "$status" "claude secondmate spawn under claude-permission-mode=auto should succeed"

  meta="$w/home/state/sm.meta"
  [ "$(meta_field "$meta" harness)" = claude ] || fail "permmode: meta harness not claude"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "claude --permission-mode auto $(sm_claude_add_dir "$w" sm)--settings '$(sm_claude_settings "$w" sm)' --model 'opus'" \
    "permmode: secondmate launch did not swap the permission flag while keeping --model"
  assert_not_contains "$launch" "--dangerously-skip-permissions" "permmode: secondmate launch must not request bypass mode"
  pass "C2b spawn: config/claude-permission-mode=auto reaches a Claude secondmate launch"
}

# A second mate's steering inbox lives in the PARENT home's
# state/<id>.inbox - outside the mate's own working directory - so an
# auto-mode Claude Code (2.1.257+) parks on its one-time "Allow reads outside
# the working directories?" question the first time the mate file-tool reads
# a steer, and a "Block" answer recorded anywhere on the machine would refuse
# the same read even under bypass. Drive the real emitted launch through a
# claude stub that models that working-directory gate, under both permission
# modes: the parent inbox must resolve inside the pane cwd or an --add-dir.
test_spawn_secondmate_claude_grants_parent_inbox_dir() {
  local w sm launchlog launch reqs fakebin out status eval_out eval_rc
  for mode in auto bypass; do
    w="$TMP_ROOT/spawn-claude-adddir-$mode"
    sm="$w/sm"
    launchlog="$w/launch.log"
    mkdir -p "$w/home/config" "$w/home/state" "$w/home/data"
    printf 'claude\n' > "$w/home/config/secondmate-harness"
    printf '%s\n' "$mode" > "$w/home/config/claude-permission-mode"
    make_seeded_home "$sm" sm

    fakebin=$(make_launch_capturing_tmux "$w/tmux")
    fm_fake_claude_outside_read_gate "$fakebin"
    : > "$launchlog"
    out=$(
      PATH="$fakebin:$BLIND_BIN:$BASE_PATH" TMUX='' CLAUDECODE=1 \
        FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$w/home" HOME="$w/home/user-home" CLAUDE_CONFIG_DIR='' \
        FM_STATE_OVERRIDE="$w/home/state" FM_DATA_OVERRIDE="$w/home/data" \
        FM_PROJECTS_OVERRIDE="$w/home/projects" FM_CONFIG_OVERRIDE="$w/home/config" \
        FM_SPAWN_NO_GUARD=1 FM_FAKE_LAUNCH_LOG="$launchlog" \
        "$ROOT/bin/fm-spawn.sh" sm "$sm" --secondmate 2>&1
    )
    status=$?
    expect_code 0 "$status" "claude secondmate spawn under $mode should succeed"$'\n'"$out"
    launch=$(cat "$launchlog")

    reqs="$w/channel-requirements.txt"
    printf '%s\n' "$w/home/state/sm.inbox" > "$reqs"
    eval_out=$(fm_eval_launch "$launch" "$sm" "$fakebin" "FM_FAKE_CLAUDE_REQUIREMENTS=$reqs" 2>&1)
    eval_rc=$?
    [ "$eval_rc" -eq 0 ] \
      || fail "claude secondmate launch under $mode would hit the outside-read gate on its parent inbox"$'\n'"$eval_out"
  done
  pass "claude secondmate launches cover the parent-home steering inbox in auto and bypass modes"
}

test_approval_mode_inheritance_present_and_absent() {
  local w head out err status setting fallback
  w=$(new_world permmode-inherit)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config"
  err="$w/permmode-inherit.err"

  for setting in claude-permission-mode codex-approval-mode; do
    if [ "$setting" = claude-permission-mode ]; then fallback=auto; else fallback=approve-for-me; fi
    printf '%s\n' "$fallback" > "$w/sm/config/$setting"
    out=$(run_config_push "$w" 2>"$err"); status=$?
    expect_code 0 "$status" "$setting primary-absent push should succeed"
    [ ! -e "$w/sm/config/$setting" ] || fail "$setting local fallback survived primary absence"

    printf 'bypass\n' > "$w/home/config/$setting"
    out=$(run_config_push "$w" 2>"$err"); status=$?
    expect_code 0 "$status" "$setting present push should succeed"
    assert_contains "$out" "$setting: pushed" "present value should report pushed"
    [ "$(cat "$w/sm/config/$setting")" = bypass ] || fail "$setting explicit primary did not win"

    rm -f "$w/home/config/$setting"
    out=$(run_config_push "$w" 2>"$err"); status=$?
    expect_code 0 "$status" "$setting absence push should succeed"
    [ ! -e "$w/sm/config/$setting" ] || fail "$setting inherited value survived primary absence"
  done
  pass "B12c approval modes follow primary values and primary absence"
}

test_backend_inheritance_present_and_absent() {
  local w head out err status instruction
  w=$(new_world backend-inherit)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"

  printf 'tmux\n' > "$w/home/config/backend"
  err="$w/backend-inherit.err"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "backend present push should succeed"
  assert_contains "$out" "backend: pushed" "backend present value should report pushed"
  [ "$(cat "$w/sm/config/backend")" = tmux ] || fail "backend present value not pushed"
  instruction=$(reread_instruction_path "$w/sm") || fail "backend present reread instruction missing"
  assert_contains "$(cat "$instruction")" $'-----BEGIN config/backend-----\ntmux\n-----END config/backend-----' \
    "backend present reread must include exact bytes"

  printf 'herdr\n' > "$w/sm/config/backend"
  printf 'zellij\n' > "$w/home/config/backend"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "backend changed push should succeed"
  assert_contains "$out" "backend: pushed" "backend changed value should report pushed"
  [ "$(cat "$w/sm/config/backend")" = zellij ] \
    || fail "primary backend did not overwrite the divergent destination"

  rm -f "$w/home/config/backend"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "backend absence push should succeed"
  assert_contains "$out" "backend: pushed - mirrored primary absence" "backend should mirror primary absence"
  [ -e "$w/sm/config/backend" ] && fail "backend not removed on primary absence"
  instruction=$(reread_instruction_path "$w/sm") || fail "backend absence reread instruction missing"
  assert_contains "$(cat "$instruction")" $'-----BEGIN config/backend-----\nABSENT\n-----END config/backend-----' \
    "backend absence reread must use ABSENT token"
  pass "B12b backend inheritance: present values and primary absence converge exactly"
}

# config/herdr-presentation-spaces has an unconfigured default, so this item's
# convergence is asserted through the preference the spawn gate actually reads
# in the destination home, not through file presence alone: mirroring the primary's
# absence must converge a secondmate to the same unconfigured default rather
# than turning its projection off. The Herdr version floor that decides what
# that default resolves to is a property of the running release, not of
# inheritance, so it is pinned in tests/fm-backend-herdr.test.sh instead.
sm_presentation_verdict() {  # <config-dir> -> on|off
  bash -c '
    . "$0/bin/backends/herdr.sh"
    case "$(fm_backend_herdr_presentation_preference "$1")" in
      off) printf "off\n" ;;
      *) printf "on\n" ;;
    esac
  ' "$ROOT" "$1" 2>/dev/null
}

test_presentation_inheritance_default_on_and_opt_out() {
  local w head out err status verdict
  w=$(new_world presentation-inherit)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  err="$w/presentation-inherit.err"

  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "presentation default push should succeed"
  [ -e "$w/sm/config/herdr-presentation-spaces" ] \
    && fail "primary default must not write an opt-out downstream"
  verdict=$(sm_presentation_verdict "$w/sm/config")
  [ "$verdict" = on ] || fail "primary default left the secondmate projection $verdict"

  mkdir -p "$w/sm/config"
  printf 'off\n' > "$w/sm/config/herdr-presentation-spaces"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "presentation reconverge push should succeed"
  assert_contains "$out" "herdr-presentation-spaces: pushed - mirrored primary absence" \
    "a local secondmate opt-out should reconverge on the primary default"
  verdict=$(sm_presentation_verdict "$w/sm/config")
  [ "$verdict" = on ] || fail "primary default did not reconverge a locally opted-out secondmate ($verdict)"

  printf 'off\n' > "$w/home/config/herdr-presentation-spaces"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "presentation opt-out push should succeed"
  assert_contains "$out" "herdr-presentation-spaces: pushed" "explicit opt-out should report pushed"
  verdict=$(sm_presentation_verdict "$w/sm/config")
  [ "$verdict" = off ] || fail "explicit primary opt-out left the secondmate projection $verdict"

  : > "$w/home/config/herdr-presentation-spaces"
  out=$(run_config_push "$w" 2>"$err"); status=$?
  expect_code 0 "$status" "presentation legacy opt-in push should succeed"
  verdict=$(sm_presentation_verdict "$w/sm/config")
  [ "$verdict" = on ] || fail "a legacy primary opt-in file left the secondmate projection $verdict"
  pass "B12c presentation inheritance: the primary default converges on, and only an explicit opt-out propagates off"
}

test_bootstrap_sweep_surfaces_config_propagation_failure() {
  local w c1 out fail_line
  w=$(new_world boot-prop-fail)
  c1=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$c1"
  mkdir -p "$w/sm/config/crew-harness"

  out=$(run_bootstrap "$w")

  fail_line=$(printf '%s\n' "$out" | grep '^SECONDMATE_SYNC: secondmate sm: skipped: inheritance failed' || true)
  [ -n "$fail_line" ] || fail "bootstrap did not surface inheritance propagation failure (got: $out)"
  [ -d "$w/sm/config/crew-harness" ] || fail "failed propagation removed the wrong path"
  pass "B11 bootstrap sweep surfaces config propagation failures"
}

test_bootstrap_rereads_after_partial_propagation() {
  local w head log out instruction pointer
  w=$(new_world boot-prop-partial)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'invalid shared header\n' > "$w/home/data/captain-shared.md"
  log="$w/boot-prop-partial.tmux.log"

  out=$(run_bootstrap "$w" "$log")
  assert_contains "$out" "SECONDMATE_SYNC: secondmate sm: skipped: inheritance failed" \
    "partial bootstrap propagation did not remain diagnostic"
  [ "$(cat "$w/sm/config/crew-dispatch.json")" = '{"default":{"harness":"codex"}}' ] \
    || fail "partial bootstrap propagation did not retain the completed config write"
  instruction=$(reread_instruction_path "$w/sm") || fail "partial bootstrap reread instruction missing"
  assert_present "$instruction" "partial bootstrap propagation did not write a reread instruction"
  pointer="CONFIG_REREAD: $(reread_instruction_path "$w/sm")"
  assert_contains "$(inbox_stream "$w/home/state" sm)" "$pointer" \
    "partial bootstrap propagation did not route the instruction pointer"
  pass "B11 bootstrap rereads completed config writes after partial propagation"
}

test_config_push_propagates_reports_without_ff_or_nudge() {
  local w c1 sm_real old_head out err status out2 tmp log instruction
  w=$(new_world config-push-basic)
  c1=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$c1"
  sm_real=$(cd "$w/sm" && pwd -P)
  printf -- '- sm - config push target (home: %s; scope: config; projects: alpha; added 2026-06-30)\n' "$sm_real" > "$w/home/data/secondmates.md"
  tmp="$w/home/state/sm.meta.tmp"
  grep -v '^home=' "$w/home/state/sm.meta" > "$tmp"
  mv "$tmp" "$w/home/state/sm.meta"

  printf 'v2\n' > "$w/main/AGENTS.md"
  git -C "$w/main" add AGENTS.md
  git -C "$w/main" commit -qm c2
  old_head=$(git -C "$w/sm" rev-parse HEAD)

  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  printf 'tmux\n' > "$w/home/config/backend"
  record_live_watcher_fixture "$w/home"
  : > "$w/home/config/trace-context"
  err="$w/config-push-basic.err"
  log="$w/config-push-basic.tmux.log"
  out=$(run_config_push "$w" "$log" 2>"$err"); status=$?

  expect_code 0 "$status" "config push should succeed"
  assert_contains "$out" "config-push: $w/home -> live secondmate homes" \
    "config push lacked the header"
  assert_contains "$out" "secondmate sm ($sm_real):" \
    "config push did not discover the live secondmate through registry fallback"
  assert_contains "$out" "crew-dispatch.json: pushed" \
    "config push did not report crew-dispatch as pushed"
  assert_contains "$out" "crew-harness: pushed" \
    "config push did not report crew-harness as pushed"
  assert_contains "$out" "backlog-backend: pushed" \
    "config push did not report backlog-backend as pushed"
  assert_contains "$out" "backend: pushed" \
    "config push did not report backend as pushed"
  assert_contains "$out" "trace-context: unchanged" \
    "live config push must report trace-context as session-scoped and unchanged"
  [ ! -e "$w/sm/config/trace-context" ] \
    || fail "live config push retroactively enabled trace context in a legacy secondmate home"
  assert_contains "$out" "config-reread: sent" \
    "config push with changed config must send a literal reread instruction"
  assert_not_contains "$out" "NUDGE_SECONDMATES" \
    "config push must not use the AGENTS.md instruction-surface nudge channel"
  [ "$(git -C "$w/sm" rev-parse HEAD)" = "$old_head" ] \
    || fail "config push fast-forwarded tracked files"
  [ "$(cat "$w/sm/config/backend")" = tmux ] || fail "config push did not write backend"
  instruction=$(reread_instruction_path "$w/sm") || fail "config-push reread instruction missing"
  assert_contains "$(cat "$instruction")" $'-----BEGIN config/backend-----\ntmux\n-----END config/backend-----' \
    "config-push reread must include exact backend bytes"
  [ ! -s "$err" ] || fail "clean config push wrote unexpected stderr: $(cat "$err")"
  assert_contains "$(inbox_stream "$w/home/state" sm)" "[fm-from-firstmate]" \
    "config reread must use the marked routed secondmate path"

  : > "$log"
  out2=$(run_config_push "$w" "$log" 2>"$err"); status=$?
  expect_code 0 "$status" "idempotent config push should succeed"
  assert_contains "$out2" "crew-dispatch.json: unchanged" \
    "idempotent config push did not report crew-dispatch as unchanged"
  assert_contains "$out2" "crew-harness: unchanged" \
    "idempotent config push did not report crew-harness as unchanged"
  assert_contains "$out2" "backlog-backend: unchanged" \
    "idempotent config push did not report backlog-backend as unchanged"
  assert_contains "$out2" "backend: unchanged" \
    "idempotent config push did not report backend as unchanged"
  assert_contains "$out2" "trace-context: unchanged" \
    "idempotent config push did not preserve session-scoped trace context"
  assert_not_contains "$out2" "config-reread: sent" \
    "unchanged config must not send a reread message"
  [ ! -s "$log" ] || fail "unchanged config push still invoked tmux send: $(cat "$log")"
  pass "B12 config-push propagates via shared live discovery, reports items, rereads on change only, and does not fast-forward"
}

test_config_push_reports_skips_dirty_and_invalid_home() {
  local w head out err status stale_real dirty_real bad_home err_text tmp
  w=$(new_world config-push-warnings)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" dirty "$head"
  add_sm_worktree "$w" stale "$head"
  dirty_real=$(cd "$w/dirty" && pwd -P)
  stale_real=$(cd "$w/stale" && pwd -P)

  printf 'local edit\n' >> "$w/dirty/README.md"
  tmp="$w/stale/.gitignore.tmp"
  grep -v '^config/crew-dispatch.json$' "$w/stale/.gitignore" > "$tmp"
  mv "$tmp" "$w/stale/.gitignore"

  bad_home="$w/not-secondmate"
  mkdir -p "$bad_home"
  {
    printf 'window=firstmate:fm-bad\n'
    printf 'kind=secondmate\n'
    printf 'home=%s\n' "$bad_home"
  } > "$w/home/state/bad.meta"

  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  err="$w/config-push-warnings.err"
  out=$(run_config_push "$w" 2>"$err"); status=$?

  expect_code 0 "$status" "warnings-only config push should exit zero"
  assert_contains "$out" "secondmate dirty ($dirty_real):" \
    "config push did not report dirty home"
  assert_contains "$out" "home: dirty working tree - local-material push continuing" \
    "config push did not surface dirty state"
  assert_contains "$out" "secondmate stale ($stale_real):" \
    "config push did not report stale home"
  assert_contains "$out" "crew-dispatch.json: skipped - destination does not allow inherited item" \
    "config push did not report non-allowing item skip"
  assert_contains "$out" "secondmate bad ($bad_home): skipped - unsafe home: not a seeded secondmate home" \
    "config push did not report invalid secondmate home"
  err_text=$(cat "$err")
  assert_contains "$err_text" "fm-config-inherit: warning: skipped crew-dispatch.json" \
    "config push did not inherit the lib's skip stderr warning"
  pass "B13 config-push reports dirty, non-allowing, and invalid homes without failing warnings-only runs"
}

test_config_push_exits_nonzero_on_copy_error() {
  local w head out err status sm_real err_text
  w=$(new_world config-push-error)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  sm_real=$(cd "$w/sm" && pwd -P)
  printf 'codex\n' > "$w/home/config/crew-harness"
  mkdir -p "$w/sm/config/crew-harness"

  err="$w/config-push-error.err"
  out=$(run_config_push "$w" 2>"$err"); status=$?

  expect_code 1 "$status" "copy-error config push should exit non-zero"
  assert_contains "$out" "secondmate sm ($sm_real):" \
    "config push error output missed the home"
  assert_contains "$out" "crew-harness: error - failed to copy" \
    "config push did not report the per-item copy error"
  err_text=$(cat "$err")
  assert_contains "$err_text" "fm-config-inherit: error: failed to copy crew-harness" \
    "copy error did not emit a stderr diagnostic"
  pass "B14 config-push exits nonzero on real propagation errors"
}

test_config_push_rereads_after_partial_propagation() {
  local w head log out err status instruction pointer
  w=$(new_world config-push-partial)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  printf '{"default":{"harness":"codex"}}\n' > "$w/home/config/crew-dispatch.json"
  printf 'invalid shared header\n' > "$w/home/data/captain-shared.md"
  log="$w/config-push-partial.tmux.log"
  err="$w/config-push-partial.err"

  out=$(run_config_push "$w" "$log" 2>"$err"); status=$?
  expect_code 1 "$status" "partial propagation should remain non-zero"
  assert_contains "$out" "crew-dispatch.json: pushed" \
    "partial propagation did not report the completed config item"
  assert_contains "$out" "data/captain-shared.md: error" \
    "partial propagation did not report the failed shared item"
  assert_contains "$out" "config-reread: sent" \
    "partial propagation lost the completed config reread"
  [ "$(cat "$w/sm/config/crew-dispatch.json")" = '{"default":{"harness":"codex"}}' ] \
    || fail "partial propagation did not retain the completed config write"
  instruction=$(reread_instruction_path "$w/sm") || fail "partial propagation reread instruction missing"
  assert_present "$instruction" "partial propagation did not write a reread instruction"
  pointer="CONFIG_REREAD: $(reread_instruction_path "$w/sm")"
  assert_contains "$(inbox_stream "$w/home/state" sm)" "$pointer" \
    "partial propagation did not route the instruction pointer"
  pass "B14 config-push rereads completed config writes after partial propagation"
}

# ---------------------------------------------------------------------------
# Literal-content config reread nudge (post-propagation live-agent wake)
# ---------------------------------------------------------------------------

shared_captain_header_for_tests() {
  cat <<'EOF'
# Shared captain preferences

This file is main-authoritative in the main firstmate home.
In secondmate homes it is read-only in secondmate homes and must not be edited there.
Route new captain-preference discoveries to the main firstmate through marked status or a document pointer.
EOF
}

# End-user-aligned reproduction of the pre-fix gap, then the fixed behavior:
# two live homes start with different stale config subsets; after push each is
# updated and each live agent receives only its own changed-content instruction.
test_config_reread_per_home_changed_sets_and_exact_bytes() {
  local w head log out err status instr_a instr_b multiline_json pointer
  w=$(new_world config-reread-per-home)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" alpha "$head"
  add_sm_worktree "$w" beta "$head"
  mkdir -p "$w/alpha/config" "$w/beta/config" "$w/alpha/state" "$w/beta/state"

  # alpha is stale on harness + backlog; beta is stale on multiline dispatch only.
  printf 'pi\n' > "$w/alpha/config/crew-harness"
  printf 'tasks-axi\n' > "$w/alpha/config/backlog-backend"
  printf '{"default":{"harness":"old"}}\n' > "$w/beta/config/crew-dispatch.json"

  multiline_json=$(printf '{\n  "default": {\n    "harness": "grok",\n    "model": "grok-4.5"\n  },\n  "rules": [\n    {"when": "news", "use": {"harness": "grok"}}\n  ]\n}\n')
  printf '%s' "$multiline_json" > "$w/home/config/crew-dispatch.json"
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'manual\n' > "$w/home/config/backlog-backend"
  printf 'tmux\n' > "$w/home/config/backend"
  {
    shared_captain_header_for_tests
    printf '%s\n' "shared secret preference body that must never appear in a config reread"
  } > "$w/home/data/captain-shared.md"

  record_live_watcher_fixture "$w/home"
  log="$w/config-reread-per-home.tmux.log"
  err="$w/config-reread-per-home.err"
  out=$(run_config_push "$w" "$log" 2>"$err"); status=$?
  expect_code 0 "$status" "per-home reread config push should succeed"
  [ ! -s "$err" ] || fail "unexpected stderr: $(cat "$err")"

  # Destination bytes converged per home.
  cmp -s "$w/home/config/crew-dispatch.json" "$w/alpha/config/crew-dispatch.json" \
    || fail "alpha did not receive multiline dispatch"
  cmp -s "$w/home/config/crew-dispatch.json" "$w/beta/config/crew-dispatch.json" \
    || fail "beta did not receive multiline dispatch"
  [ "$(cat "$w/alpha/config/crew-harness")" = codex ] || fail "alpha harness not updated"
  [ "$(cat "$w/alpha/config/backlog-backend")" = manual ] || fail "alpha backlog-backend not updated"
  [ "$(cat "$w/alpha/config/backend")" = tmux ] || fail "alpha backend not updated"

  instr_a=$(reread_instruction_path "$w/alpha") || fail "alpha instruction missing after config push"
  instr_b=$(reread_instruction_path "$w/beta") || fail "beta instruction missing after config push"
  assert_present "$instr_a" "alpha should receive a config-reread instruction file"
  assert_present "$instr_b" "beta should receive a config-reread instruction file"
  [ "$(reread_mode "$instr_a")" = 600 ] || fail "alpha instruction is not private"
  [ "$(reread_mode "$instr_b")" = 600 ] || fail "beta instruction is not private"

  # Deterministic allowlist path order and exact destination bytes for alpha
  # (allowlisted config items were missing/stale and therefore pushed).
  assert_grep "These inherited config files changed" "$instr_a" "alpha framing missing"
  assert_grep "defaults/rules" "$instr_a" "alpha must preserve agent judgment framing"
  assert_contains "$(cat "$instr_a")" "config/crew-dispatch.json" "alpha missing dispatch path"
  assert_contains "$(cat "$instr_a")" "config/crew-harness" "alpha missing harness path"
  assert_contains "$(cat "$instr_a")" "config/backlog-backend" "alpha missing backlog path"
  assert_contains "$(cat "$instr_a")" "config/backend" "alpha missing backend path"
  # Path order follows FM_INHERITABLE_CONFIG.
  awk '
    /config\/crew-dispatch\.json/ { d=NR }
    /config\/crew-harness/ { h=NR }
    /config\/backlog-backend/ { b=NR }
    /config\/backend/ && !/backlog-backend/ { k=NR }
    END {
      if (!(d && h && b && k && d < h && h < b && b < k)) exit 1
    }
  ' "$instr_a" || fail "alpha instruction path order is not deterministic allowlist order"

  # Exact multiline JSON appears byte-for-byte between delimiters.
  assert_contains "$(cat "$instr_a")" "$multiline_json" \
    "alpha instruction must include exact multiline dispatch bytes"
  assert_contains "$(cat "$instr_a")" $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "alpha instruction must include exact harness scalar bytes"
  assert_contains "$(cat "$instr_a")" $'-----BEGIN config/backlog-backend-----\nmanual\n-----END config/backlog-backend-----' \
    "alpha instruction must include exact backlog-backend scalar bytes"
  assert_contains "$(cat "$instr_a")" $'-----BEGIN config/backend-----\ntmux\n-----END config/backend-----' \
    "alpha instruction must include exact backend scalar bytes"

  # No parsed/effective summary, no SHA, no captain-shared dump.
  assert_not_contains "$(cat "$instr_a")" "Default worker" "must not emit parsed worker summary"
  assert_not_contains "$(cat "$instr_a")" "sha" "must not emit sha tokens"
  assert_not_contains "$(cat "$instr_a")" "SHA" "must not emit SHA tokens"
  assert_not_contains "$(cat "$instr_a")" "captain-shared" "captain-shared path must not appear"
  assert_not_contains "$(cat "$instr_a")" "shared secret preference body" \
    "captain-shared content must never be inlined"
  assert_not_contains "$(cat "$instr_b")" "shared secret preference body" \
    "beta must not inline captain-shared either"

  # Beta started with only dispatch stale; harness/backlog were absent on both
  # sides for beta... wait: primary has harness+backlog, beta lacked them, so
  # they are also pushed. Seed beta with matching harness/backlog so only
  # dispatch changes for beta - re-run a focused unit of the write helper below.
  # For this push, beta was missing harness and backlog too, so all three push.
  # Prove isolation by comparing that neither instruction references the other's
  # pre-push stale unique value.
  assert_not_contains "$(cat "$instr_a")" '"harness":"old"' \
    "alpha must not receive beta's pre-push stale dispatch"
  assert_not_contains "$(cat "$instr_b")" $'pi\n' \
    "beta instruction must not leak alpha-only stale harness bytes as a standalone scalar block incorrectly"

  # Routed send used the from-firstmate marker and carried only the pointer,
  # read from alpha's durable steer records (the typed channel now carries only
  # the constant doorbell, which never inlines message content).
  pointer="CONFIG_REREAD: $(reread_instruction_path "$w/alpha")"
  assert_contains "$(inbox_stream "$w/home/state" alpha)" "[fm-from-firstmate]" "reread send must be marked"
  assert_contains "$(inbox_stream "$w/home/state" alpha)" "$pointer" "reread send must point to the durable instruction file"
  assert_not_contains "$(inbox_stream "$w/home/state" alpha)" '"harness": "grok"' "sent message must not inline multiline JSON"
  assert_not_contains "$(inbox_stream "$w/home/state" alpha)" "Default worker" "sent message must not summarize"
  assert_not_contains "$(cat "$log")" '"harness": "grok"' "the typed doorbell must not inline multiline JSON"
  pass "B15 config reread is per-home, exact-byte, ordered, and pointer-only"
}

test_config_reread_isolation_and_absent_and_send_failure() {
  local w head log out out2 err status status2 instr_a instr_b report retry_log retry_out retry_status retry_pointer
  local first_instr first_copy second_instr second_pointer
  w=$(new_world config-reread-absent)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" alpha "$head"
  add_sm_worktree "$w" beta "$head"
  mkdir -p "$w/alpha/config" "$w/beta/config" "$w/alpha/state" "$w/beta/state"

  # alpha: only harness will change (dispatch+backlog already match primary absence).
  # beta: only dispatch will change.
  printf 'old-harness\n' > "$w/alpha/config/crew-harness"
  printf '{"stale":true}\n' > "$w/beta/config/crew-dispatch.json"
  # Primary has only crew-harness set; dispatch and backlog absent.
  printf 'codex\n' > "$w/home/config/crew-harness"
  rm -f "$w/home/config/crew-dispatch.json" "$w/home/config/backlog-backend"

  log="$w/config-reread-absent.tmux.log"
  err="$w/config-reread-absent.err"
  out=$(run_config_push "$w" "$log" 2>"$err"); status=$?
  expect_code 0 "$status" "absent-mirror reread push should succeed"

  instr_a=$(reread_instruction_path "$w/alpha") || fail "alpha instruction missing after config push"
  instr_b=$(reread_instruction_path "$w/beta") || fail "beta instruction missing after config push"
  assert_present "$instr_a" "alpha instruction missing after harness change"
  assert_present "$instr_b" "beta instruction missing after dispatch removal"

  # alpha changed harness only.
  assert_contains "$(cat "$instr_a")" "config/crew-harness" "alpha should mention harness"
  assert_contains "$(cat "$instr_a")" $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "alpha harness block exact"
  assert_not_contains "$(cat "$instr_a")" "config/crew-dispatch.json" \
    "alpha must not list unchanged/absent-both dispatch"
  assert_not_contains "$(cat "$instr_a")" "config/backlog-backend" \
    "alpha must not list unchanged/absent-both backlog"
  assert_not_contains "$(cat "$instr_a")" '{"stale":true}' \
    "alpha must not receive beta's changed dispatch content"

  # beta: dispatch mirrored to ABSENT (and harness is also newly pushed from primary).
  assert_contains "$(cat "$instr_b")" "config/crew-dispatch.json" "beta should mention dispatch"
  assert_contains "$(cat "$instr_b")" $'-----BEGIN config/crew-dispatch.json-----\nABSENT\n-----END config/crew-dispatch.json-----' \
    "beta must represent removal as ABSENT"
  assert_not_contains "$(cat "$instr_b")" "old-harness" \
    "beta must not receive alpha's pre-push stale harness content"
  # Pure ABSENT + unchanged isolation via the write helper (no second inheritance path).
  report="$w/absent-only.report"
  {
    printf '%s\n' $'crew-dispatch.json\tpushed\tmirrored primary absence'
    printf '%s\n' $'crew-harness\tunchanged\t'
    printf '%s\n' $'backlog-backend\tunchanged\t'
    printf '%s\n' $'backend\tunchanged\t'
    printf '%s\n' $'data/captain-shared.md\tpushed\t'
  } > "$report"
  rm -f "$w/beta/config/crew-dispatch.json"
  fm_config_write_reread_instruction "$w/beta" "$report" "$w/beta/state/.fm-inherited-config-reread-absent" \
    || fail "ABSENT instruction write failed"
  assert_contains "$(cat "$w/beta/state/.fm-inherited-config-reread-absent")" \
    $'-----BEGIN config/crew-dispatch.json-----\nABSENT\n-----END config/crew-dispatch.json-----' \
    "helper ABSENT representation"
  assert_not_contains "$(cat "$w/beta/state/.fm-inherited-config-reread-absent")" "captain-shared" \
    "helper must ignore captain-shared even when report says pushed"
  assert_not_contains "$(cat "$w/beta/state/.fm-inherited-config-reread-absent")" "config/crew-harness" \
    "helper must omit unchanged items"

  # Send failure becomes a retryable diagnostic and non-zero exit. On the
  # inbox plane the real local failure is an unwritable steer record (a
  # keystroke failure alone no longer fails a durably enqueued pointer), so
  # replace each inbox dir with a plain file that blocks the enqueue.
  rm -rf "$w/home/state/alpha.inbox" "$w/home/state/beta.inbox"
  : > "$w/home/state/alpha.inbox"
  : > "$w/home/state/beta.inbox"
  printf 'claude\n' > "$w/home/config/crew-harness"
  err="$w/config-reread-send-fail.err"
  out=$(PATH="$(make_fake_toolchain "$w"):$BASE_PATH" \
    FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" FM_SEND_SETTLE=0 \
    "$ROOT/bin/fm-config-push.sh" 2>"$err"); status=$?
  expect_code 1 "$status" "send failure should make config-push exit non-zero"
  assert_contains "$out" "CONFIG_REREAD: secondmate" "send failure diagnostic missing"
  assert_contains "$out" "send failed" "send failure must say send failed"
  assert_not_contains "$out" "config-reread: sent" \
    "must not claim reread landed when send failed"
  first_instr=$(reread_instruction_path "$w/alpha") || fail "alpha failed-send instruction missing"
  first_copy="$w/alpha/first-reread-generation.copy"
  cp "$first_instr" "$first_copy"
  assert_present "$(reread_pending_path "$w/alpha")" \
    "alpha send failure did not record a retry marker"
  assert_present "$(reread_pending_path "$w/beta")" \
    "beta send failure did not record a retry marker"

  # A later changed push publishes a distinct generation without overwriting
  # the failed generation, then an unchanged push retries both pointers.
  printf 'pi\n' > "$w/home/config/crew-harness"
  err="$w/config-reread-send-fail-second.err"
  out2=$(PATH="$(make_fake_toolchain "$w"):$BASE_PATH" \
    FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" FM_SEND_SETTLE=0 \
    "$ROOT/bin/fm-config-push.sh" 2>"$err"); status2=$?
  expect_code 1 "$status2" "second send failure should make config-push exit non-zero"
  assert_not_contains "$out2" "config-reread: sent" \
    "second send failure must not claim reread delivery"
  second_instr=$(reread_instruction_path "$w/alpha") || fail "alpha second generation missing"
  [ "$first_instr" != "$second_instr" ] || fail "successive pushes reused the same generation path"
  cmp -s "$first_copy" "$first_instr" || fail "later push overwrote the earlier generation bytes"
  second_pointer="CONFIG_REREAD: $second_instr"
  assert_present "$(reread_pending_path "$w/alpha")" \
    "alpha second generation did not remain pending"

  # A normal later push retries the durable pointers even though propagation is
  # unchanged, then clears every marker after delivery succeeds.
  rm -f "$w/home/state/alpha.inbox" "$w/home/state/beta.inbox"
  retry_log="$w/config-reread-send-retry.tmux.log"
  retry_out=$(run_config_push "$w" "$retry_log" 2>"$err"); retry_status=$?
  expect_code 0 "$retry_status" "send failure should be retryable"
  assert_contains "$retry_out" "config-reread: sent" \
    "retry should report the reread as sent"
  retry_pointer="CONFIG_REREAD: $(reread_instruction_path "$w/beta")"
  assert_contains "$(inbox_stream "$w/home/state" beta)" "$retry_pointer" \
    "retry did not resend the durable pointer"
  assert_contains "$(inbox_stream "$w/home/state" alpha)" "CONFIG_REREAD: $first_instr" \
    "retry did not resend the first pending generation"
  assert_contains "$(inbox_stream "$w/home/state" alpha)" "$second_pointer" \
    "retry did not resend the second pending generation"
  assert_no_reread_pending "$w/alpha"
  assert_no_reread_pending "$w/beta"
  pass "B16 config reread isolation, ABSENT, generation safety, send failure, and retry"
}

test_config_reread_publication_failure_retries_exact_generation() {
  local w head fakebin real_mv alpha_state out status stage log instr retry_out retry_status
  w=$(new_world config-reread-publication-retry)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" alpha "$head"
  mkdir -p "$w/alpha/config" "$w/alpha/state"
  printf 'old\n' > "$w/alpha/config/crew-harness"
  printf 'codex\n' > "$w/home/config/crew-harness"

  fakebin=$(make_fake_toolchain "$w")
  real_mv=$(command -v mv)
  alpha_state=$(cd "$w/alpha/state" && pwd -P)
  cat > "$fakebin/mv" <<SH
#!/usr/bin/env bash
case "\$*" in
  *"$alpha_state/.fm-inherited-config-reread."*) exit 1 ;;
esac
exec "$real_mv" "\$@"
SH
  chmod +x "$fakebin/mv"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 "$ROOT/bin/fm-config-push.sh" 2>&1); status=$?
  expect_code 1 "$status" "publication failure should remain diagnostic"
  assert_contains "$out" "CONFIG_REREAD: secondmate" "publication failure diagnostic missing"
  assert_not_contains "$out" "config-reread: sent" \
    "publication failure must not claim reread delivery"
  [ "$(cat "$w/alpha/config/crew-harness")" = codex ] \
    || fail "publication failure did not retain the completed config write"
  stage=$(reread_retry_stage_path "$w/home" alpha) \
    || fail "publication failure did not retain an exact retry generation"
  assert_contains "$(cat "$stage")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "retry generation did not retain exact destination bytes"
  assert_no_reread_instructions "$w/alpha"

  rm -f "$fakebin/mv"
  log="$w/config-reread-publication-retry.tmux.log"
  retry_out=$(run_config_push "$w" "$log" 2>/dev/null); retry_status=$?
  expect_code 0 "$retry_status" "publication failure should retry on an unchanged push"
  assert_contains "$retry_out" "config-reread: sent" \
    "successful publication retry should report delivery"
  instr=$(reread_instruction_path "$w/alpha") \
    || fail "publication retry did not publish an instruction"
  assert_contains "$(inbox_stream "$w/home/state" alpha)" "CONFIG_REREAD: $instr" \
    "publication retry did not send the durable pointer"
  assert_no_reread_retry_stages "$w/home" alpha
  pass "B20 config reread publication failures retain exact generations for retry"
}

test_config_reread_write_failure_retains_exact_retry_generation() {
  local w head fakebin real_mv retry_dir out status stage_path log retry_out retry_status instr
  local old_instr new_instr
  w=$(new_world config-reread-write-retry)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'old\n' > "$w/sm/config/crew-harness"
  printf 'codex\n' > "$w/home/config/crew-harness"
  fakebin=$(make_fake_toolchain "$w")
  real_mv=$(command -v mv)
  mkdir -p "$w/home/state/.fm-inherited-config-reread-retry/sm"
  retry_dir=$(cd "$w/home/state/.fm-inherited-config-reread-retry/sm" && pwd -P)
  cat > "$fakebin/mv" <<SH
#!/usr/bin/env bash
target=
for arg in "\$@"; do target="\$arg"; done
case "\$target" in
  *"$retry_dir"/.fm-inherited-config-reread.*)
    case "\$target" in
      *.exact) ;;
      *) exit 1 ;;
    esac
    ;;
esac
exec "$real_mv" "\$@"
SH
  chmod +x "$fakebin/mv"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 "$ROOT/bin/fm-config-push.sh" 2>&1); status=$?
  expect_code 1 "$status" "instruction-write failure should remain diagnostic"
  assert_contains "$out" "retained exact retry generation" \
    "instruction-write failure did not retain exact retry bytes"
  stage_path=$(reread_retry_stage_path "$w/home" sm) \
    || fail "instruction-write failure did not leave a durable exact generation"
  assert_contains "$(cat "$stage_path")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "instruction-write failure did not retain the original exact bytes"
  printf 'changed-before-retry\n' > "$w/home/config/crew-harness"
  rm -f "$fakebin/mv"
  log="$w/config-reread-write-retry.tmux.log"
  retry_out=$(run_config_push "$w" "$log" 2>/dev/null); retry_status=$?
  expect_code 0 "$retry_status" "a later changed push should retry an instruction-write failure"
  assert_contains "$retry_out" "config-reread: sent" \
    "later changed push did not deliver the retained exact generation"
  old_instr=$(inbox_stream "$w/home/state" sm | grep 'CONFIG_REREAD:' | head -n 1 | sed 's/.*CONFIG_REREAD: //')
  new_instr=$(inbox_stream "$w/home/state" sm | grep 'CONFIG_REREAD:' | tail -n 1 | sed 's/.*CONFIG_REREAD: //')
  [ -n "$old_instr" ] && [ -n "$new_instr" ] && [ "$old_instr" != "$new_instr" ] \
    || fail "later changed push did not deliver both generations"
  instr="$old_instr"
  assert_contains "$(cat "$instr")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "exact retry delivery did not preserve the original destination bytes"
  assert_contains "$(cat "$new_instr")" "changed-before-retry" \
    "later changed push did not deliver its new destination bytes"
  assert_no_reread_retry_stages "$w/home" sm
  pass "B21 config reread instruction-write failures retain exact retry generations"
}

test_config_reread_exact_temp_survives_adoption_failure() {
  local w head fakebin real_mv real_cp retry_dir out status stage_path log retry_out retry_status
  local old_instr new_instr
  w=$(new_world config-reread-exact-temp-fallback)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'old\n' > "$w/sm/config/crew-harness"
  printf 'codex\n' > "$w/home/config/crew-harness"
  fakebin=$(make_fake_toolchain "$w")
  real_mv=$(command -v mv)
  real_cp=$(command -v cp)
  mkdir -p "$w/home/state/.fm-inherited-config-reread-retry/sm"
  retry_dir=$(cd "$w/home/state/.fm-inherited-config-reread-retry/sm" && pwd -P)
  cat > "$fakebin/mv" <<SH
#!/usr/bin/env bash
target=
for arg in "\$@"; do target="\$arg"; done
case "\$target" in
  *"$retry_dir"/.fm-inherited-config-reread.*) exit 1 ;;
esac
exec "$real_mv" "\$@"
SH
  chmod +x "$fakebin/mv"
  cat > "$fakebin/cp" <<SH
#!/usr/bin/env bash
target=
for arg in "\$@"; do target="\$arg"; done
case "\$target" in
  *"$retry_dir"/.fm-inherited-config-reread.*) exit 1 ;;
esac
exec "$real_cp" "\$@"
SH
  chmod +x "$fakebin/cp"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 "$ROOT/bin/fm-config-push.sh" 2>&1); status=$?
  expect_code 1 "$status" "exact temporary fallback failure should remain diagnostic"
  assert_contains "$out" "retained exact retry temporary" \
    "exact temporary fallback failure did not retain the immutable bytes"
  stage_path=$(reread_retry_stage_path "$w/home" sm) \
    || fail "exact temporary fallback failure lost its retry artifact"
  case "$stage_path" in
    *.tmp.*) : ;;
    *) fail "exact temporary fallback retained an unexpected artifact: $stage_path" ;;
  esac
  [ ! -e "$stage_path.report" ] \
    || fail "exact temporary fallback created a lossy retry report"
  assert_contains "$(cat "$stage_path")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "exact temporary fallback did not preserve the original bytes"
  printf 'changed-before-retry\n' > "$w/home/config/crew-harness"
  rm -f "$fakebin/mv" "$fakebin/cp"
  log="$w/config-reread-exact-temp-fallback.tmux.log"
  retry_out=$(run_config_push "$w" "$log" 2>/dev/null); retry_status=$?
  expect_code 0 "$retry_status" "later push should deliver retained exact temporary bytes"
  old_instr=$(inbox_stream "$w/home/state" sm | grep 'CONFIG_REREAD:' | head -n 1 | sed 's/.*CONFIG_REREAD: //')
  new_instr=$(inbox_stream "$w/home/state" sm | grep 'CONFIG_REREAD:' | tail -n 1 | sed 's/.*CONFIG_REREAD: //')
  [ -n "$old_instr" ] && [ -n "$new_instr" ] && [ "$old_instr" != "$new_instr" ] \
    || fail "later push did not deliver both exact generations"
  assert_contains "$(cat "$old_instr")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "later push rebuilt the retained temporary from newer bytes"
  assert_contains "$(cat "$new_instr")" "changed-before-retry" \
    "later push did not deliver the new destination bytes"
  assert_no_reread_retry_stages "$w/home" sm
  pass "B21 config reread preserves exact bytes when temporary adoption also fails"
}

test_config_reread_serializes_concurrent_pushes() {
  local w head fakebin marker entered log first_out second_out first_pid first_status second_status
  local first_instr second_instr first_line second_line
  w=$(new_world config-reread-serialized-pushes)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'old\n' > "$w/sm/config/crew-harness"
  printf 'one\n' > "$w/home/config/crew-harness"

  fakebin=$(make_fake_toolchain "$w")
  mv "$fakebin/tmux" "$fakebin/tmux.real"
  marker="$w/first-send.marker"
  entered="$w/first-send.entered"
  log="$w/config-reread-serialized.tmux.log"
  cat > "$fakebin/tmux" <<SH
#!/usr/bin/env bash
case "\$*" in
  *send-keys*)
    if (set -o noclobber; : > "$marker") 2>/dev/null; then
      : > "$entered"
      sleep 1
    fi
    ;;
esac
exec "$fakebin/tmux.real" "\$@"
SH
  chmod +x "$fakebin/tmux"

  first_out="$w/first-push.out"
  (
    PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
      FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
      "$ROOT/bin/fm-config-push.sh" > "$first_out" 2>&1
  ) &
  first_pid=$!
  # The loop leaves as soon as the push reaches its first send, so a generous
  # bound costs nothing on a fast host; a slow one needs several seconds.
  for _ in $(seq 1 1500); do
    [ -e "$entered" ] && break
    sleep 0.02
  done
  [ -e "$entered" ] || fail "first config push did not reach pointer delivery"
  first_instr=$(reread_instruction_path "$w/sm") \
    || fail "first concurrent push did not publish its generation"
  printf 'two\n' > "$w/home/config/crew-harness"
  second_out="$w/second-push.out"
  PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
    "$ROOT/bin/fm-config-push.sh" > "$second_out" 2>&1
  second_status=$?
  wait "$first_pid"; first_status=$?
  expect_code 0 "$first_status" "first serialized config push failed"
  expect_code 0 "$second_status" "second serialized config push failed"
  second_instr=$(reread_instruction_path "$w/sm") \
    || fail "second concurrent push did not publish its generation"
  [ "$first_instr" != "$second_instr" ] || fail "concurrent pushes reused a generation"
  [ "$(cat "$w/sm/config/crew-harness")" = two ] \
    || fail "concurrent pushes did not converge the latest config bytes"
  # Delivery order is now the durable enqueue order: the steering-inbox
  # sequence numbers are the serialization evidence the typed log used to be.
  first_line=$(inbox_stream "$w/home/state" sm | grep -n -F "CONFIG_REREAD: $first_instr" | head -n 1 | cut -d: -f1)
  second_line=$(inbox_stream "$w/home/state" sm | grep -n -F "CONFIG_REREAD: $second_instr" | head -n 1 | cut -d: -f1)
  [ -n "$first_line" ] && [ -n "$second_line" ] && [ "$first_line" -lt "$second_line" ] \
    || fail "concurrent pushes delivered generations out of order"
  pass "B21 config reread serializes concurrent propagation and delivery"
}

test_config_reread_full_retry_queue_drains_before_new_push() {
  local w head retry_dir path n fakebin log out status pointer_count
  w=$(new_world config-reread-full-queue)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'old\n' > "$w/sm/config/crew-harness"
  printf 'new\n' > "$w/home/config/crew-harness"
  retry_dir="$w/home/state/.fm-inherited-config-reread-retry/sm"
  mkdir -p "$retry_dir"
  for n in $(seq -w 1 16); do
    path="$retry_dir/.fm-inherited-config-reread.20260721T000000.$n"
    printf 'generation-%s\n' "$n" > "$path"
    chmod 0600 "$path"
  done
  fakebin=$(make_fake_toolchain "$w")
  log="$w/config-reread-full-queue.tmux.log"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
    "$ROOT/bin/fm-config-push.sh" 2>&1); status=$?
  expect_code 0 "$status" "a full retry queue should drain before a new push"
  assert_contains "$out" "config-reread: sent" \
    "a new config generation was not delivered after retry draining"
  [ "$(cat "$w/sm/config/crew-harness")" = new ] \
    || fail "the new config generation did not propagate after retry draining"
  assert_no_reread_retry_stages "$w/home" sm
  pointer_count=$(inbox_stream "$w/home/state" sm | grep -c 'CONFIG_REREAD:' || true)
  [ "$pointer_count" -ge 17 ] \
    || fail "full retry queue did not deliver all pending generations before the new one"
  pass "B22 full config reread retry queues drain before new publication"
}

test_config_reread_cleanup_runs_after_mixed_delivery_failure() {
  local w head fakebin state_real fail_path path n report out status count
  w=$(new_world config-reread-mixed-delivery)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/state"
  state_real=$(cd "$w/sm/state" && pwd -P)
  fail_path="$state_real/.fm-inherited-config-reread.9999-fail"
  for n in $(seq -w 1 18); do
    path="$state_real/.fm-inherited-config-reread.00$n"
    printf 'generation-%s\n' "$n" > "$path"
    chmod 0600 "$path"
  done
  printf 'failed-generation\n' > "$fail_path"
  chmod 0600 "$fail_path"
  for path in "$state_real"/.fm-inherited-config-reread.*; do
    fm_config_reread_mark_pending "$path" "$path.pending" \
      || fail "could not mark mixed-delivery generation pending"
  done
  fakebin=$(make_fake_toolchain "$w")
  # Fail only the .9999-fail generation's delivery, at the layer that can now
  # fail: the durable inbox enqueue. The staged steer record carries that
  # generation's pointer path in its body, so a content-matching mv wrapper
  # rejects exactly that one atomic publish and nothing else.
  real_mv=$(command -v mv)
  cat > "$fakebin/mv" <<SH
#!/usr/bin/env bash
if [ -f "\${1:-}" ] && grep -q '\.9999-fail' "\${1:-}" 2>/dev/null; then
  exit 1
fi
exec "$real_mv" "\$@"
SH
  chmod +x "$fakebin/mv"
  report="$w/empty-reread.report"
  : > "$report"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 fm_config_send_reread_nudge sm "$w/sm" "$report" 2>&1); status=$?
  expect_code 1 "$status" "mixed delivery failure should remain diagnostic"
  assert_contains "$out" "CONFIG_REREAD: secondmate sm: send failed" \
    "mixed delivery failure diagnostic missing"
  count=0
  for path in "$state_real"/.fm-inherited-config-reread.*; do
    case "$path" in
      *.pending) continue ;;
    esac
    [ -f "$path" ] && [ ! -L "$path" ] || continue
    [ ! -e "$path.pending" ] || continue
    count=$((count + 1))
  done
  [ "$count" = 16 ] || fail "mixed delivery failure skipped bounded sent-history cleanup (count=$count)"
  assert_present "$fail_path.pending" "failed generation lost its retry marker"
  pass "B23 mixed config reread delivery failures still bound sent history"
}

test_config_reread_stops_after_failed_generation() {
  local w fakebin state_real old new report log out status
  w=$(new_world config-reread-order)
  mkdir -p "$w/sm/state"
  state_real=$(cd "$w/sm/state" && pwd -P)
  old="$state_real/.fm-inherited-config-reread.0000-fail"
  new="$state_real/.fm-inherited-config-reread.0001-new"
  printf 'old-generation\n' > "$old"
  printf 'new-generation\n' > "$new"
  chmod 0600 "$old" "$new"
  fm_config_reread_mark_pending "$old" "$old.pending" \
    || fail "could not mark older generation pending"
  fm_config_reread_mark_pending "$new" "$new.pending" \
    || fail "could not mark newer generation pending"
  fakebin=$(make_fake_toolchain "$w")
  mv "$fakebin/tmux" "$fakebin/tmux.real"
  cat > "$fakebin/tmux" <<SH
#!/usr/bin/env bash
case "\$*" in
  *send-keys*'.0000-fail'*) exit 1 ;;
esac
exec "$fakebin/tmux.real" "\$@"
SH
  chmod +x "$fakebin/tmux"
  report="$w/empty-reread.report"
  : > "$report"
  log="$w/config-reread-order.tmux.log"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$ROOT" \
    FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
    fm_config_send_reread_nudge sm "$w/sm" "$report" 2>&1); status=$?
  expect_code 1 "$status" "an older failed generation should remain diagnostic"
  assert_contains "$out" "CONFIG_REREAD: secondmate sm: send failed" \
    "older generation failure diagnostic missing"
  assert_not_contains "$(cat "$log" 2>/dev/null || true)" ".0001-new" \
    "newer generation was delivered after an older failure"
  assert_present "$old.pending" "older failed generation lost its retry marker"
  assert_present "$new.pending" "newer generation was sent after an older failure"
  pass "B26 config reread delivery stops after the oldest failed generation"
}

test_bootstrap_detect_only_does_not_create_state() {
  local w fakebin detect_state out status
  w=$(new_world bootstrap-detect-only)
  detect_state="$w/detect-state"
  fakebin=$(make_fake_toolchain "$w")
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_STATE_OVERRIDE="$detect_state" FM_BOOTSTRAP_DETECT_ONLY=1 \
    "$ROOT/bin/fm-bootstrap.sh" 2>&1); status=$?
  expect_code 0 "$status" "detect-only bootstrap should succeed"
  [ ! -e "$detect_state" ] || fail "detect-only bootstrap created its state directory"
  pass "B24 bootstrap detect-only mode remains filesystem read-only"
}

test_config_reread_skips_when_unchanged_and_reads_after_push() {
  local w head log out err status report instr n path pending_instruction count
  w=$(new_world config-reread-after-push)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"

  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'codex\n' > "$w/sm/config/crew-harness"
  log="$w/config-reread-unchanged.tmux.log"
  out=$(run_config_push "$w" "$log" 2>/dev/null); status=$?
  expect_code 0 "$status" "unchanged push should succeed"
  assert_not_contains "$out" "config-reread: sent" "no reread when nothing changed"
  [ ! -s "$log" ] || fail "unchanged push still sent text: $(cat "$log")"
  assert_no_reread_instructions "$w/sm"

  # Prove instruction bytes are taken from destination after write: if we only
  # read the primary source, a post-copy destination mutation would not matter.
  # Here we call the write helper after planting distinct dest bytes and a
  # pushed report line.
  printf '%s' 'destination-post-write' > "$w/sm/config/crew-harness"
  printf 'primary-source-only\n' > "$w/home/config/crew-harness"
  report="$w/after-push.report"
  printf '%s\n' $'crew-harness\tpushed\t' > "$report"
  instr="$w/sm/state/.fm-inherited-config-reread-dest"
  fm_config_write_reread_instruction "$w/sm" "$report" "$instr" \
    || fail "destination-byte instruction write failed"
  assert_contains "$(cat "$instr")" "destination-post-write" \
    "instruction must use destination post-write bytes"
  assert_contains "$(cat "$instr")" $'destination-post-write-----END config/crew-harness-----' \
    "instruction must not append a byte to a non-newline-terminated destination"
  assert_not_contains "$(cat "$instr")" "primary-source-only" \
    "instruction must not fall back to primary source bytes"
  : > "$w/sm/config/crew-harness"
  fm_config_write_reread_instruction "$w/sm" "$report" "$instr" \
    || fail "empty destination instruction write failed"
  assert_contains "$(cat "$instr")" $'-----BEGIN config/crew-harness-----
-----END config/crew-harness-----' \
    "instruction must represent an empty destination without a synthetic byte"
  pending_instruction="$w/sm/state/.fm-inherited-config-reread.20260721T000000.01"
  printf '%s\n' generation > "$pending_instruction"
  fm_config_reread_mark_pending "$pending_instruction" "$pending_instruction.pending" \
    || fail "could not create bounded-lifecycle pending marker"
  for n in $(seq -w 2 18); do
    path="$w/sm/state/.fm-inherited-config-reread.20260721T000000.$n"
    printf '%s\n' generation > "$path"
    chmod 0600 "$path"
  done
  fm_config_reread_cleanup_sent "$w/sm"
  count=0
  for path in "$w/sm/state"/.fm-inherited-config-reread.*; do
    case "$path" in
      *.pending) continue ;;
    esac
    [ -f "$path" ] && [ ! -L "$path" ] || continue
    [ ! -e "$path.pending" ] || continue
    count=$((count + 1))
  done
  [ "$count" = 16 ] || fail "sent reread generations were not bounded"
  assert_present "$pending_instruction" "cleanup deleted a pending reread generation"
  assert_present "$pending_instruction.pending" "cleanup deleted a pending reread marker"
  pass "B17 config reread skips unchanged homes and reads destination post-write bytes"
}

test_config_reread_bootstrap_path_and_spawn_flexibility() {
  local w head log out fakebin sm launchlog launch instr report stale
  w=$(new_world config-reread-bootstrap)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'old\n' > "$w/sm/config/crew-harness"
  printf 'codex\n' > "$w/home/config/crew-harness"

  fakebin=$(make_fake_toolchain "$w")
  log="$w/bootstrap-reread.tmux.log"
  out=$(PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
    "$ROOT/bin/fm-bootstrap.sh" 2>/dev/null)
  [ "$(cat "$w/sm/config/crew-harness")" = codex ] || fail "bootstrap did not push harness"
  instr=$(reread_instruction_path "$w/sm") || fail "bootstrap reread instruction missing"
  assert_present "$instr" "bootstrap must write a config reread instruction when config changed"
  assert_contains "$(inbox_stream "$w/home/state" sm)" "[fm-from-firstmate]" \
    "bootstrap config reread must use routed secondmate send"
  assert_contains "$(cat "$instr")" \
    $'-----BEGIN config/crew-harness-----\ncodex\n-----END config/crew-harness-----' \
    "bootstrap instruction must carry exact post-write harness bytes"

  # fm-spawn still permits a conscious explicit runtime outside the config
  # (defaults/rules only - never harden spawn against deliberate choice).
  w=$(new_world config-reread-spawn-flex)
  printf 'codex\n' > "$w/home/config/crew-harness"
  printf 'codex\n' > "$w/home/config/secondmate-harness"
  sm="$w/sm-flex"
  make_seeded_home "$sm" sm-flex
  mkdir -p "$sm/state"
  report="$sm/state/stale-reread.report"
  printf '%s\n' $'crew-harness\tpushed\t' > "$report"
  stale="$sm/state/.fm-inherited-config-reread.spawn-stale"
  fm_config_write_reread_instruction "$sm" "$report" "$stale" \
    || fail "could not create spawn stale reread generation"
  fm_config_reread_mark_pending "$stale" "$stale.pending" \
    || fail "could not create spawn stale reread marker"
  launchlog="$w/spawn-flex.launch.log"
  spawn_secondmate_capture "$w" sm-flex "$sm" "$launchlog" --harness pi >/dev/null 2>&1
  assert_no_reread_pending "$sm"
  assert_no_reread_instructions "$sm"
  launch=$(cat "$launchlog")
  assert_contains "$launch" "pi" \
    "explicit --harness pi must still win over configured codex defaults"
  pass "B18 bootstrap config reread path works; spawn flexibility remains defaults-only"
}

test_bootstrap_respawns_before_config_reread() {
  local w head fakebin log report stale
  w=$(new_world config-reread-respawn-order)
  head=$(git -C "$w/main" rev-parse HEAD)
  add_sm_worktree "$w" sm "$head"
  mkdir -p "$w/sm/config" "$w/sm/state"
  printf 'harness=codex\n' >> "$w/home/state/sm.meta"
  printf '%s' old > "$w/sm/config/crew-harness"
  printf '%s' codex > "$w/home/config/crew-harness"
  report="$w/sm/state/stale-reread.report"
  printf '%s\n' $'crew-harness\tpushed\t' > "$report"
  stale="$w/sm/state/.fm-inherited-config-reread.stale-generation"
  fm_config_write_reread_instruction "$w/sm" "$report" "$stale" \
    || fail "could not create stale reread generation"
  fm_config_reread_mark_pending "$stale" "$stale.pending" \
    || fail "could not create stale reread marker"
  log="$w/config-reread-respawn-order.log"

cat > "$w/main/bin/fm-spawn.sh" <<SH
#!/usr/bin/env bash
. '$w/main/bin/fm-config-inherit-lib.sh'
printf '%s' spawn >> '$log'
printf '%s' codex > '$w/sm/config/crew-harness'
printf '%s\n' 7500 > '$w/sm/config/startup-memory-budget'
SH
  chmod +x "$w/main/bin/fm-spawn.sh"
  fakebin=$(make_fake_toolchain "$w")
  cat > "$fakebin/tmux" <<SH
#!/usr/bin/env bash
case "\$*" in
  *display-message*'#{pane_current_command}'*) printf '%s' zsh ;;
  *display-message*'#{pane_id}'*) printf '%s' '%1' ;;
  *display-message*'#{cursor_y}'*) printf '%s' 0 ;;
  *capture-pane*) printf '❯\n'
    ;;
  *send-keys*) printf '%s' send-keys >> '$log' ;;
esac
SH
  chmod +x "$fakebin/tmux"
  PATH="$fakebin:$BASE_PATH" FM_HOME="$w/home" FM_ROOT_OVERRIDE="$w/main" \
    FM_SEND_SETTLE=0 FM_FAKE_TMUX_LOG="$log" \
    "$ROOT/bin/fm-bootstrap.sh" >/dev/null 2>&1
  assert_contains "$(cat "$log")" "spawn" \
    "bootstrap did not respawn the dead secondmate"
  assert_not_contains "$(cat "$log")" "send-keys" \
    "bootstrap nudged a secondmate before its respawn completed"
  assert_present "$stale" "bootstrap removed the stale generation before relaunch handling"
  assert_present "$stale.pending" "bootstrap removed the stale marker before relaunch handling"
  fm_config_reread_discard_pending "$w/sm" || fail "could not clean respawn test generation"
  assert_no_reread_pending "$w/sm"
  assert_no_reread_instructions "$w/sm"
  pass "B19 bootstrap respawns before inherited-config reread"
}

test_spawn_quarantines_pending_rereads_on_cleanup_failure() {
  local w sm report stale fakebin real_rm out status launchlog quarantine_root quarantined_count
  local quarantine_dirs before_quarantine_dirs after_quarantine_dirs n dir
  w=$(new_world config-reread-spawn-quarantine)
  sm="$w/sm"
  mkdir -p "$w/home/config"
  printf 'codex\n' > "$w/home/config/crew-harness"
  make_seeded_home "$sm" sm
  mkdir -p "$sm/state"
  report="$sm/state/stale-reread.report"
  printf '%s\n' $'crew-harness\tpushed\t' > "$report"
  stale="$sm/state/.fm-inherited-config-reread.spawn-stale"
  fm_config_write_reread_instruction "$sm" "$report" "$stale" \
    || fail "could not create pending spawn reread generation"
  fm_config_reread_mark_pending "$stale" "$stale.pending" \
    || fail "could not mark pending spawn reread generation"
  quarantine_root="$sm/state/.fm-inherited-config-reread-quarantine"
  mkdir -p "$quarantine_root"
  for n in $(seq -w 1 16); do
    dir="$quarantine_root/generation.old$n"
    mkdir -p "$dir"
    printf 'old-quarantine-%s\n' "$n" > "$dir/snapshot"
    printf 'hidden-quarantine-%s\n' "$n" > "$dir/.hidden-snapshot"
  done
  fakebin=$(make_launch_capturing_tmux "$w/tmux-spawn-quarantine")
  real_rm=$(command -v rm)
  cat > "$fakebin/rm" <<SH
#!/usr/bin/env bash
case "\$*" in
  *'.fm-inherited-config-reread.'*) exit 1 ;;
esac
exec "$real_rm" "\$@"
SH
  chmod +x "$fakebin/rm"
  launchlog="$w/spawn-quarantine.launch.log"
  out=$(PATH="$fakebin:$BASE_PATH" TMUX='' CLAUDECODE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_HOME="$w/home" HOME="$w/home/user-home" CLAUDE_CONFIG_DIR='' \
    FM_STATE_OVERRIDE="$w/home/state" FM_DATA_OVERRIDE="$w/home/data" \
    FM_PROJECTS_OVERRIDE="$w/home/projects" FM_CONFIG_OVERRIDE="$w/home/config" \
    FM_SPAWN_NO_GUARD=1 FM_FAKE_LAUNCH_LOG="$launchlog" \
    "$ROOT/bin/fm-spawn.sh" sm "$sm" --secondmate 2>&1); status=$?
  expect_code 0 "$status" "spawn should remain available after reread cleanup failure"
  assert_contains "$out" "CONFIG_REREAD: secondmate sm: quarantined pre-relaunch generations" \
    "spawn cleanup failure did not emit a CONFIG_REREAD quarantine diagnostic"
  assert_no_reread_pending "$sm"
  assert_no_reread_instructions "$sm"
  assert_present "$quarantine_root" "spawn cleanup failure did not create a quarantine directory"
  quarantined_count=$(find "$quarantine_root" -type f | wc -l | tr -d ' ')
  [ "$quarantined_count" -ge 2 ] \
    || fail "spawn cleanup failure did not quarantine both generation artifacts"
  quarantine_dirs=0
  for dir in "$quarantine_root"/generation.*; do
    [ -d "$dir" ] && [ ! -L "$dir" ] || continue
    quarantine_dirs=$((quarantine_dirs + 1))
  done
  [ "$quarantine_dirs" -le 16 ] \
    || fail "spawn cleanup failure exceeded bounded quarantine history ($quarantine_dirs)"
  before_quarantine_dirs=$quarantine_dirs
  fm_config_reread_quarantine_pending "$sm" sm "$w/home" || true
  after_quarantine_dirs=0
  for dir in "$quarantine_root"/generation.*; do
    [ -d "$dir" ] && [ ! -L "$dir" ] || continue
    after_quarantine_dirs=$((after_quarantine_dirs + 1))
  done
  [ "$after_quarantine_dirs" = "$before_quarantine_dirs" ] \
    || fail "empty quarantine cleanup created an extra generation directory"
  assert_not_contains "$(cat "$launchlog")" "CONFIG_REREAD:" \
    "spawn cleanup failure left a stale reread pointer eligible for delivery"
  pass "B25 spawn quarantines stale rereads without blocking relaunch"
}

test_harness_resolution
test_cursor_marker_detection
test_secondmate_model_effort_tokens
test_secondmate_per_mate_override_lines
test_secondmate_malformed_pin_refuses_with_line_number
test_secondmate_legacy_pin_file_is_never_refused
test_pi_signed_detection_and_session_lock_identity
test_dash_leading_process_names_are_basename_operands
test_propagate_lib
test_spawn_split_and_inherit
test_spawn_backward_compat_crew_fallback
test_spawn_bare_backward_compat
test_spawn_explicit_harness_wins
test_spawn_unverified_secondmate_harness_refused
test_spawn_cursor_secondmate_launches_with_its_primary_contract
test_spawn_backend_precedence_over_inherited_config
test_spawn_explicit_backend_precedence_over_env_and_inherited_config
test_spawn_bare_harness_no_model_effort_flag
test_spawn_secondmate_harness_model_token
test_spawn_secondmate_harness_model_and_effort_tokens
test_spawn_secondmate_with_a_legacy_pin_file_uses_the_first_line
test_spawn_secondmate_with_a_malformed_declared_pin_refuses
test_spawn_explicit_model_overrides_secondmate_harness_token
test_spawn_explicit_effort_overrides_secondmate_harness_token
test_spawn_explicit_harness_does_not_inherit_secondmate_harness_tokens
test_spawn_explicit_harness_uses_explicit_profile_axes
test_spawned_secondmate_uses_its_harness_supervision_model
test_spawn_fallback_chain_and_crew_scout_unaffected
test_bootstrap_sweep_propagates_and_reconverges
test_bootstrap_sweep_propagates_when_tracked_current
test_bootstrap_sweep_defers_dispatch_on_stale_unignored_home
test_bootstrap_sweep_materializes_and_inherits_memory_default
test_backend_inheritance_present_and_absent
test_spawn_secondmate_claude_permission_mode_auto
test_spawn_secondmate_claude_grants_parent_inbox_dir
test_approval_mode_inheritance_present_and_absent
test_presentation_inheritance_default_on_and_opt_out
test_bootstrap_sweep_surfaces_config_propagation_failure
test_bootstrap_rereads_after_partial_propagation
test_config_push_propagates_reports_without_ff_or_nudge
test_config_push_reports_skips_dirty_and_invalid_home
test_config_push_exits_nonzero_on_copy_error
test_config_push_rereads_after_partial_propagation
test_config_reread_per_home_changed_sets_and_exact_bytes
test_config_reread_isolation_and_absent_and_send_failure
test_config_reread_publication_failure_retries_exact_generation
test_config_reread_write_failure_retains_exact_retry_generation
test_config_reread_exact_temp_survives_adoption_failure
test_config_reread_serializes_concurrent_pushes
test_config_reread_full_retry_queue_drains_before_new_push
test_config_reread_cleanup_runs_after_mixed_delivery_failure
test_config_reread_stops_after_failed_generation
test_config_reread_skips_when_unchanged_and_reads_after_push
test_config_reread_bootstrap_path_and_spawn_flexibility
test_bootstrap_respawns_before_config_reread
test_spawn_quarantines_pending_rereads_on_cleanup_failure
test_bootstrap_detect_only_does_not_create_state

echo "# all fm-secondmate-harness tests passed"
