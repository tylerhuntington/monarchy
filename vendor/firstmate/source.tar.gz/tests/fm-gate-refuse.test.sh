#!/usr/bin/env bash
# Behavior tests for the no-mistakes GATE-agent fleet-lifecycle refusal.
#
# A confused no-mistakes gate agent runs inside a firstmate checkout, adopts the
# captain identity from AGENTS.md, and reaches for fm-spawn/fm-send/fm-teardown.
# bin/fm-gate-refuse-lib.sh is the firstmate capability-removal half: sourced at
# the top of those three entrypoints and called before any fleet mutation, it
# fails closed on either of two independent signals:
#   1. NO_MISTAKES_GATE set in the environment (the marker no-mistakes stamps);
#   2. the current worktree's git-common-dir resolves under a no-mistakes gate
#      repo (.../.no-mistakes/repos/*.git) - the unspoofable backstop, which
#      still refuses even if the marker was tampered/unset.
# A normal firstmate session (real primary, real crew worktree) has NEITHER
# signal and is completely unaffected.
#
# The one authorized exception is a disposable LAB home: bin/fm-lab-home.sh
# stamps a marker file only on a fresh empty dir, and inside a gate context the
# refusal lets a lifecycle call proceed only when FM_HOME is a marked lab home
# used through its stock layout (any FM_*_OVERRIDE relocation stays refused).
# The helper legs below cover the admit/refuse contract; teardown additionally
# proves the admit end-to-end through a real entrypoint.
#
# Each entrypoint is exercised in three scenarios, isolating exactly ONE signal:
#   - env-marker refuse : neutral cwd + NO_MISTAKES_GATE set      -> exit 3, no mutation
#   - path-backstop refuse: gate-worktree cwd + marker UNSET      -> exit 3, no mutation
#   - no-regression      : neutral cwd + marker UNSET             -> succeeds, no gate error
# The marker is UNSET explicitly in the no-regression/backstop runs (env -u) and
# those runs stand in a controlled NON-gate repo, so the suite is hermetic even
# when it is itself executed inside the real no-mistakes gate (whose process has
# NO_MISTAKES_GATE=1 and a gate-worktree cwd).
#
# Finally, assert firstmate's TRACKED .no-mistakes.yaml parses and sets
# disable_project_settings: true (the trusted-only opt-out that neutralizes gate
# agents' project instructions on the no-mistakes side).
set -u

# shellcheck source=tests/fixtures.sh
. "$(dirname "${BASH_SOURCE[0]}")/fixtures.sh"

GATE_LIB="$ROOT/bin/fm-gate-refuse-lib.sh"
LABHOME="$ROOT/bin/fm-lab-home.sh"
SPAWN="$ROOT/bin/fm-spawn.sh"
SEND="$ROOT/bin/fm-send.sh"
TEARDOWN="$ROOT/bin/fm-teardown.sh"

TMP=$(fm_test_tmproot fm-gate-refuse)
fm_git_identity fmtest fmtest@example.invalid

# The env marker's exact stderr fragment (the primary signal).
ENV_MSG='NO_MISTAKES_GATE set'
# The git-common-dir backstop's exact stderr fragment (the unspoofable signal).
PATH_MSG='no-mistakes gate worktree'

# --- shared fixtures --------------------------------------------------------

# make_gate_worktree <root> -> echoes a worktree whose git-common-dir is
# <root>/.no-mistakes/repos/<id>.git, reproducing no-mistakes' gate topology
# (<NM_HOME>/repos/<id>.git + <NM_HOME>/worktrees/<id>/<run>).
make_gate_worktree() {
  local root=$1 id=016d88035d58 run=01KXC3SD5NZYMERGDS68Z1C8ER seed
  mkdir -p "$root/.no-mistakes/repos"
  git init -q --bare "$root/origin.git"
  seed=$(mktemp -d "$TMP/gate-seed.XXXXXX")
  git init -q -b main "$seed"
  git -C "$seed" commit -q --allow-empty -m init
  git -C "$seed" push -q "$root/origin.git" HEAD:refs/heads/main
  rm -rf "$seed"
  git clone -q --bare "$root/origin.git" "$root/.no-mistakes/repos/$id.git"
  git -C "$root/.no-mistakes/repos/$id.git" worktree add --detach \
    "$root/.no-mistakes/worktrees/$id/$run" main >/dev/null 2>&1
  printf '%s\n' "$root/.no-mistakes/worktrees/$id/$run"
}

# make_normal_repo <dir> -> echoes a plain (non-gate) git repo to stand in for a
# normal primary/crew checkout: its git-common-dir is <dir>/.git, never a gate.
make_normal_repo() {
  local dir=$1
  git init -q -b main "$dir"
  git -C "$dir" commit -q --allow-empty -m init
  printf '%s\n' "$dir"
}

GATE_WT=$(make_gate_worktree "$TMP/gate")
NORMAL_CWD=$(make_normal_repo "$TMP/normal-cwd")

# --- the shared helper, tested directly -------------------------------------

# run_guard_lib <cwd> [set|empty] : from <cwd>, source the lib and call the guard under
# set -eu in a subshell (proving set -eu safety). NO_MISTAKES_GATE is unset first;
# a literal "set" second argument re-exports it, so callers pick the signal under
# test. Echoes combined output; the guard's exit is the caller's $?.
run_guard_lib() {
  local cwd=$1 marker=${2:-unset}
  (
    cd "$cwd" || exit 111
    unset NO_MISTAKES_GATE FM_GATE_REFUSE_BYPASS
    case "$marker" in
      set) export NO_MISTAKES_GATE=1 ;;
      empty) export NO_MISTAKES_GATE= ;;
    esac
    set -eu
    # shellcheck source=/dev/null
    . "$GATE_LIB"
    fm_refuse_if_gate_agent
  ) 2>&1
}

test_helper_env_marker_refuses() {
  local out rc
  out=$(run_guard_lib "$NORMAL_CWD" set); rc=$?
  expect_code 3 "$rc" "helper: env marker must exit 3"
  assert_contains "$out" "$ENV_MSG" "helper: env-marker refusal message"
  pass "fm-gate-refuse-lib: refuses when NO_MISTAKES_GATE is set"
}

test_helper_empty_env_marker_refuses() {
  local out rc
  out=$(run_guard_lib "$NORMAL_CWD" empty); rc=$?
  expect_code 3 "$rc" "helper: empty env marker must exit 3"
  assert_contains "$out" "$ENV_MSG" "helper: empty env-marker refusal message"
  pass "fm-gate-refuse-lib: refuses when NO_MISTAKES_GATE is set empty"
}

test_helper_path_backstop_refuses() {
  local out rc
  # Marker UNSET: only the git-common-dir backstop can fire here.
  out=$(run_guard_lib "$GATE_WT"); rc=$?
  expect_code 3 "$rc" "helper: gate worktree must exit 3 even with the marker unset"
  assert_contains "$out" "$PATH_MSG" "helper: path-backstop refusal message"
  assert_not_contains "$out" "$ENV_MSG" "helper: backstop must not be attributed to the env marker"
  pass "fm-gate-refuse-lib: refuses from a gate worktree via git-common-dir (marker unset)"
}

test_helper_normal_is_noop() {
  local out rc
  out=$(run_guard_lib "$NORMAL_CWD"); rc=$?
  expect_code 0 "$rc" "helper: a normal session (neither signal) must not refuse"
  [ -z "$out" ] || fail "helper: normal session printed output: $out"
  pass "fm-gate-refuse-lib: no-op for a normal session (neither signal, set -eu clean)"
}

# --- disposable lab homes ----------------------------------------------------

# run_guard_lib_home <cwd> <home> [ASSIGN...] -> combined output : like
# run_guard_lib but with FM_HOME=<home>; extra ASSIGN args carry the gate
# signal (NO_MISTAKES_GATE=1) or an override to exercise the stock-layout
# requirement. All FM_*_OVERRIDE vars are unset first so the suite stays
# hermetic inside a real gate.
run_guard_lib_home() {
  local cwd=$1 home=$2; shift 2
  # shellcheck disable=SC2016 # $1/$2 expand in the child shell, not here.
  env -u NO_MISTAKES_GATE -u FM_GATE_REFUSE_BYPASS \
      -u FM_ROOT_OVERRIDE -u FM_STATE_OVERRIDE -u FM_DATA_OVERRIDE \
      -u FM_PROJECTS_OVERRIDE -u FM_CONFIG_OVERRIDE \
      FM_HOME="$home" "$@" \
      bash -c 'cd "$1" || exit 111; set -eu; . "$2"; fm_refuse_if_gate_agent' \
      _ "$cwd" "$GATE_LIB" 2>&1
}

test_helper_lab_home_admits() {
  local lab plain out rc value name dir
  lab=$("$LABHOME" create "$TMP/lab-home") || fail "lab-home create failed"
  plain="$TMP/plain-home"; mkdir -p "$plain"

  # gate + marked lab home -> permitted (env signal; the path backstop shares
  # the same fm_is_gate_agent gate).
  out=$(run_guard_lib_home "$NORMAL_CWD" "$lab" NO_MISTAKES_GATE=1); rc=$?
  expect_code 0 "$rc" "helper: gate + marked lab home must be permitted"
  assert_contains "$out" "lab home" "helper: lab permit should name the lab home"

  # gate + unmarked home -> refused.
  out=$(run_guard_lib_home "$NORMAL_CWD" "$plain" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "helper: gate + unmarked home must still refuse"
  assert_contains "$out" "$ENV_MSG" "helper: unmarked-home refusal message"

  # Production Pi supplies the tracked root and the stock state/config paths.
  out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1 \
    FM_ROOT_OVERRIDE="$ROOT" FM_STATE_OVERRIDE="$lab/state" FM_CONFIG_OVERRIDE="$lab/config"); rc=$?
  expect_code 0 "$rc" "helper: production branch paths in a marked lab must be permitted"

  for name in FM_ROOT_OVERRIDE FM_STATE_OVERRIDE FM_CONFIG_OVERRIDE; do
    for value in "$plain" "$lab/../plain-home" "$lab/state/.."; do
      out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1 "$name=$value"); rc=$?
      expect_code 3 "$rc" "helper: relocated or noncanonical $name must refuse"
    done
  done
  for name in FM_DATA_OVERRIDE FM_PROJECTS_OVERRIDE FM_UNKNOWN_OVERRIDE; do
    out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1 "$name=$lab/data"); rc=$?
    expect_code 3 "$rc" "helper: unsupported $name must refuse"
  done
  ln -s "$lab" "$TMP/lab-alias"
  for value in "$TMP/lab-alias" "$lab/."; do
    out=$(run_guard_lib_home "$GATE_WT" "$value" NO_MISTAKES_GATE=1 FM_ROOT_OVERRIDE="$ROOT"); rc=$?
    expect_code 3 "$rc" "helper: noncanonical home must refuse"
  done
  for dir in state config data projects; do
    mv "$lab/$dir" "$lab/$dir.saved"
    ln -s "$plain" "$lab/$dir"
    out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1 FM_ROOT_OVERRIDE="$ROOT"); rc=$?
    expect_code 3 "$rc" "helper: symlinked stock $dir must refuse"
    rm "$lab/$dir"
    mv "$lab/$dir.saved" "$lab/$dir"
  done
  mv "$lab/.fm-lab-home" "$lab/marker.saved"
  ln -s "$lab/marker.saved" "$lab/.fm-lab-home"
  out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "helper: symlinked lab identity must refuse"
  rm "$lab/.fm-lab-home"
  printf 'invalid lab identity\n' > "$lab/.fm-lab-home"
  out=$(run_guard_lib_home "$GATE_WT" "$lab" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "helper: invalid lab identity must refuse"
  mv "$lab/marker.saved" "$lab/.fm-lab-home"

  # no gate signal + lab home -> still a normal no-op.
  out=$(run_guard_lib_home "$NORMAL_CWD" "$lab"); rc=$?
  expect_code 0 "$rc" "helper: lab home outside a gate must not refuse"
  pass "fm-gate-refuse-lib: production lab paths permitted; relocated paths and invalid identities refused"
}

test_lab_home_private_tmux_socket_survives_deep_paths() {
  local root=$TMP/deep lab socket_dir ready socket_path depth=0
  local real_tmux
  real_tmux=$(command -v tmux) || fail "tmux is required for the lab socket behavioral test"
  while [ "${#root}" -le 150 ]; do
    root="$root/long-directory-segment"
    depth=$((depth + 1))
  done
  mkdir -p "$root"
  lab="$root/lab-home"
  lab=$("$LABHOME" create "$lab") || fail "could not create lab home under a long path"
  socket_dir=$("$LABHOME" tmux-dir "$lab") || fail "could not create the lab's private tmux directory"
  socket_path="$socket_dir/tmux-$(id -u)/fm-lab"
  ready="$lab/state/primary-started"
  [ "${#lab}" -gt 120 ] || fail "lab path was not deliberately long enough"
  [ "${#socket_path}" -lt 60 ] || fail "tmux socket path is not short: $socket_path"
  local mode owner
  case "$(uname -s)" in
    Darwin) mode=$(stat -f '%Lp' "$socket_dir"); owner=$(stat -f '%u' "$socket_dir") ;;
    *) mode=$(stat -c '%a' "$socket_dir"); owner=$(stat -c '%u' "$socket_dir") ;;
  esac
  [ "$mode" = 700 ] || fail "private tmux directory mode is not 0700"
  [ "$owner" = "$(id -u)" ] || fail "private tmux directory is not owned by the current user"
  [ "${socket_dir#/tmp/fml.}" != "$socket_dir" ] || fail "socket directory is not under the short /tmp/fml prefix"

  cleanup_deep_lab() {
    # The explicit socket, only while it exists: TMUX_TMPDIR alone falls back
    # to /tmp/tmux-<uid> once the private directory is gone.
    [ ! -S "$socket_path" ] || "$real_tmux" -S "$socket_path" kill-server >/dev/null 2>&1 || true
    "$LABHOME" teardown "$lab" >/dev/null 2>&1 || true
    fm_test_cleanup
  }
  trap cleanup_deep_lab EXIT
  # shellcheck disable=SC2016 # The fake primary expands $1 in its own sh process.
  env TMUX_TMPDIR="$socket_dir" "$real_tmux" -L fm-lab -f /dev/null new-session -d -s primary \
    /bin/sh -c 'printf started > "$1"; exec sleep 60' sh "$ready" \
    || fail "tmux could not start the fake primary through the lab socket"
  [ -S "$socket_path" ] || fail "tmux did not create its socket in the private short directory"
  local attempts=0
  while [ ! -f "$ready" ] && [ "$attempts" -lt 20 ]; do sleep 0.05; attempts=$((attempts + 1)); done
  [ -f "$ready" ] || fail "fake primary did not start"
  "$real_tmux" -S "$socket_path" has-session -t primary \
    || fail "primary session is not reachable through the lab socket"
  if "$LABHOME" teardown "$lab" >/dev/null 2>&1; then
    fail "lab teardown removed the directory while its server was running"
  fi
  [ -d "$socket_dir" ] || fail "refused active-server teardown removed the socket directory"
  "$real_tmux" -S "$socket_path" kill-server \
    || fail "could not stop the isolated lab tmux server"
  mkdir -p "$TMP/failing-tmux-bin"
  printf '#!/bin/sh\necho "tmux: probe failed" >&2\nexit 1\n' > "$TMP/failing-tmux-bin/tmux"
  chmod +x "$TMP/failing-tmux-bin/tmux"
  if PATH="$TMP/failing-tmux-bin:$PATH" "$LABHOME" teardown "$lab" >/dev/null 2>&1; then
    fail "lab teardown removed the directory when its tmux probe failed"
  fi
  [ -d "$socket_dir" ] || fail "failed-probe teardown removed the socket directory"
  "$LABHOME" teardown "$lab" || fail "lab tmux directory teardown failed"
  [ ! -e "$socket_dir" ] || fail "lab teardown left the private tmux directory behind"
  trap fm_test_cleanup EXIT
  pass "fm-lab-home: a primary starts on a private short tmux socket from a long lab path and teardown removes it"
}

test_lab_home_helper() {
  local lab populated unlistable newline out rc
  # create on an absent path mints the marker and the stock layout.
  lab=$("$LABHOME" create "$TMP/lab-new"); rc=$?
  expect_code 0 "$rc" "lab-home: create must succeed on a fresh path"
  assert_present "$lab/.fm-lab-home" "lab-home: create must write the marker"
  for d in state data config projects; do
    [ -d "$lab/$d" ] || fail "lab-home: missing stock dir $d"
  done
  out=$("$LABHOME" create "$lab" 2>&1); rc=$?
  [ "$rc" -ne 0 ] || fail "lab-home: create on an existing lab home must refuse"
  # refuses a populated dir and leaves it unmarked.
  populated="$TMP/populated"; mkdir -p "$populated/state"; echo x > "$populated/state/x.meta"
  out=$("$LABHOME" create "$populated" 2>&1); rc=$?
  [ "$rc" -ne 0 ] || fail "lab-home: create on a populated dir must refuse"
  assert_absent "$populated/.fm-lab-home" "lab-home: refused create must not write the marker"
  # refuses a populated dir it cannot list, rather than reading it as empty.
  unlistable="$TMP/unlistable"; mkdir -p "$unlistable/state"; chmod 300 "$unlistable"
  out=$("$LABHOME" create "$unlistable" 2>&1); rc=$?
  chmod 700 "$unlistable"
  [ "$rc" -ne 0 ] || fail "lab-home: create on an unlistable dir must refuse"
  assert_absent "$unlistable/.fm-lab-home" "lab-home: unlistable create must not write the marker"
  # refuses a dir whose only entry has a newline-only name.
  newline="$TMP/newline-entry"; mkdir -p "$newline/"$'\n'
  out=$("$LABHOME" create "$newline" 2>&1); rc=$?
  [ "$rc" -ne 0 ] || fail "lab-home: create on a dir holding a newline-named entry must refuse"
  assert_absent "$newline/.fm-lab-home" "lab-home: newline-entry create must not write the marker"
  pass "fm-lab-home: create mints marked stock homes only on fresh empty dirs; anything else is refused"
}

# --- fm-spawn ---------------------------------------------------------------

# run_spawn <cwd> <home> <id> <proj> <pane> <fakebin> [ASSIGN...] -> combined output
# Gate-refuse cases must cd into a controlled cwd and drop both refusal signals
# so the suite stays hermetic when it itself runs inside a real gate worktree.
run_spawn() {
  local cwd=$1 home=$2 id=$3 proj=$4 pane=$5 fakebin=$6; shift 6
  fm_test_spawn_brief "$home" "$id" brief
  ( cd "$cwd" && env -u NO_MISTAKES_GATE -u FM_GATE_REFUSE_BYPASS \
      FM_ROOT_OVERRIDE='' FM_HOME="$home" \
      FM_STATE_OVERRIDE="$home/state" FM_DATA_OVERRIDE="$home/data" \
      FM_PROJECTS_OVERRIDE="$home/projects" FM_CONFIG_OVERRIDE="$home/config" \
      FM_SPAWN_NO_GUARD=1 FM_FAKE_PANE_PATH="$pane" TMUX=fake,1,0 \
      PATH="$fakebin:$PATH" "$@" \
      "$SPAWN" "$id" "$proj" codex --mode no-mistakes --yolo off ) 2>&1
}

test_spawn_refuses_and_admits() {
  local home proj fakebin wt out rc
  home="$TMP/spawn-home"; mkdir -p "$home/data"
  proj=$(make_normal_repo "$TMP/spawn-proj")
  fm_git_add_origin "$proj" "$TMP/spawn-origin.git"
  fakebin=$(make_spawn_fakebin "$TMP/spawn-fake")
  wt="$TMP/spawn-wt"
  git -C "$proj" worktree add -q --detach "$wt" >/dev/null 2>&1

  # env-marker refuse: neutral cwd, marker set.
  out=$(run_spawn "$NORMAL_CWD" "$home" spawn-envmark "$proj" "$wt" "$fakebin" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "spawn: NO_MISTAKES_GATE must refuse"
  assert_contains "$out" "$ENV_MSG" "spawn: env-marker refusal message"
  assert_absent "$home/state/spawn-envmark.meta" "spawn: refused env-marker launch must not record meta"

  # path-backstop refuse: gate-worktree cwd, marker UNSET.
  out=$(run_spawn "$GATE_WT" "$home" spawn-backstop "$proj" "$wt" "$fakebin"); rc=$?
  expect_code 3 "$rc" "spawn: gate-worktree cwd must refuse with the marker unset"
  assert_contains "$out" "$PATH_MSG" "spawn: path-backstop refusal message"
  assert_absent "$home/state/spawn-backstop.meta" "spawn: refused backstop launch must not record meta"

  # no-regression: neutral cwd, marker UNSET, genuine isolated worktree.
  out=$(run_spawn "$NORMAL_CWD" "$home" spawn-ok "$proj" "$wt" "$fakebin"); rc=$?
  expect_code 0 "$rc" "spawn: a normal session must still spawn"
  assert_contains "$out" "spawned spawn-ok" "spawn: normal launch should report success"
  assert_not_contains "$out" "$ENV_MSG" "spawn: normal launch must not print the gate refusal"
  assert_not_contains "$out" "$PATH_MSG" "spawn: normal launch must not print the backstop refusal"
  assert_present "$home/state/spawn-ok.meta" "spawn: normal launch should record meta"
  pass "fm-spawn: refuses on marker and gate-worktree backstop; a normal crew spawn is unaffected"
}

# --- fm-send ----------------------------------------------------------------

# A fake tmux that logs send-keys to FM_TMUX_LOG and reports live endpoints
# (mirrors tests/fm-send-strict), so a successful send is observable and a
# refused one leaves an empty log (proving no message was typed).
make_send_fakebin() {
  local dir=$1 fakebin
  fakebin=$(fm_fakebin "$dir")
  cat > "$fakebin/tmux" <<'SH'
#!/usr/bin/env bash
set -u
case "${1:-}" in
  send-keys)
    shift; literal=0; target=
    while [ $# -gt 0 ]; do
      case "$1" in
        -t) target=$2; shift 2 ;;
        -l) literal=1; shift ;;
        *) break ;;
      esac
    done
    printf 'send-keys target=%s literal=%s arg=%s\n' "$target" "$literal" "${1:-}" >> "$FM_TMUX_LOG"
    exit 0 ;;
  display-message)
    for a in "$@"; do case "$a" in *cursor_y*) printf '1\n'; exit 0 ;; esac; done
    printf '%%1\n'; exit 0 ;;
  capture-pane) printf '╭────╮\n│    │\n╰────╯\n'; exit 0 ;;
  list-windows) printf 'fm-lane-ok\n'; exit 0 ;;
esac
exit 0
SH
  chmod +x "$fakebin/tmux"
  printf '#!/usr/bin/env bash\nexit 0\n' > "$fakebin/sleep"
  chmod +x "$fakebin/sleep"
  printf '%s\n' "$fakebin"
}

# run_send <cwd> <home> <fakebin> <log> <target> <text> [ASSIGN...] -> combined output
run_send() {
  local cwd=$1 home=$2 fakebin=$3 log=$4 target=$5 text=$6; shift 6
  ( cd "$cwd" && env -u NO_MISTAKES_GATE -u FM_GATE_REFUSE_BYPASS \
      "PATH=$fakebin:$PATH" "FM_HOME=$home" "FM_ROOT_OVERRIDE=$home" \
      "FM_TMUX_LOG=$log" "FM_SEND_SETTLE=0" "$@" \
      "$SEND" "$target" "$text" ) 2>&1
}

test_send_refuses_and_admits() {
  local home fakebin log out rc
  home="$TMP/send-home"; mkdir -p "$home/state"
  fakebin=$(make_send_fakebin "$TMP/send-fake")
  log="$TMP/send-tmux.log"
  fm_write_meta "$home/state/lane-ok.meta" "window=sess:fm-lane-ok" "kind=ship" "harness=codex"

  # env-marker refuse.
  : > "$log"
  out=$(run_send "$NORMAL_CWD" "$home" "$fakebin" "$log" fm-lane-ok "hello captain" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "send: NO_MISTAKES_GATE must refuse"
  assert_contains "$out" "$ENV_MSG" "send: env-marker refusal message"
  [ ! -s "$log" ] || fail "send: refused env-marker send still typed to the endpoint"$'\n'"$(cat "$log")"

  # path-backstop refuse (marker UNSET).
  : > "$log"
  out=$(run_send "$GATE_WT" "$home" "$fakebin" "$log" fm-lane-ok "hello captain"); rc=$?
  expect_code 3 "$rc" "send: gate-worktree cwd must refuse with the marker unset"
  assert_contains "$out" "$PATH_MSG" "send: path-backstop refusal message"
  [ ! -s "$log" ] || fail "send: refused backstop send still typed to the endpoint"$'\n'"$(cat "$log")"

  # no-regression.
  : > "$log"
  out=$(run_send "$NORMAL_CWD" "$home" "$fakebin" "$log" fm-lane-ok "hello captain"); rc=$?
  expect_code 0 "$rc" "send: a normal session must still send"
  assert_not_contains "$out" "$ENV_MSG" "send: normal send must not print the gate refusal"
  assert_not_contains "$out" "$PATH_MSG" "send: normal send must not print the backstop refusal"
  [ "$(bash -c '. "$1"; fm_task_inbox_body "$2"' _ "$ROOT/bin/fm-task-inbox-lib.sh" \
      "$home/state/lane-ok.inbox/001.msg")" = "hello captain" ] \
    || fail "send: normal steer was not durably enqueued"
  assert_not_contains "$(cat "$log")" "literal=1 arg=hello captain" \
    "send: normal steer payload must not be typed"
  assert_contains "$(cat "$log")" "target=sess:fm-lane-ok literal=1 arg=: Firstmate instruction waiting" \
    "send: normal steer should ring the durable inbox doorbell"
  pass "fm-send: refuses on marker and gate-worktree backstop; a normal steer uses the inbox"
}

# --- fm-teardown ------------------------------------------------------------

# make_teardown_case <name> -> echoes a case dir holding a LANDED no-mistakes ship
# task (HEAD reachable from origin), so a normal teardown genuinely succeeds and a
# refused one leaves the task untouched (mirrors tests/fm-teardown make_case).
make_teardown_case() {
  local name=$1 case_dir fakebin t
  case_dir="$TMP/$name"; fakebin="$case_dir/fakebin"
  mkdir -p "$case_dir/state" "$case_dir/config" "$case_dir/data" "$fakebin"
  for t in treehouse tmux; do
    printf '#!/usr/bin/env bash\nexit 0\n' > "$fakebin/$t"
    chmod +x "$fakebin/$t"
  done
  cat > "$fakebin/gh-axi" <<'SH'
#!/usr/bin/env bash
case "${1:-} ${2:-}" in
  "pr list") printf '%s\n' "count: 0 (showing first 0)" "pull_requests[]: []"; exit 0 ;;
  "pr view") echo "error: pull request not found" >&2; exit 1 ;;
esac
exit 0
SH
  cat > "$fakebin/gh" <<'SH'
#!/usr/bin/env bash
case "${1:-} ${2:-}" in
  "pr view") echo "error: pull request not found" >&2; exit 1 ;;
esac
exit 0
SH
  chmod +x "$fakebin/gh-axi" "$fakebin/gh"
  git init -q --bare "$case_dir/origin.git"
  git -C "$case_dir/origin.git" symbolic-ref HEAD refs/heads/main
  git clone -q "$case_dir/origin.git" "$case_dir/_seed" 2>/dev/null
  git -C "$case_dir/_seed" commit -q --allow-empty -m "origin baseline"
  git -C "$case_dir/_seed" push -q origin main
  rm -rf "$case_dir/_seed"
  git clone -q "$case_dir/origin.git" "$case_dir/project"
  git -C "$case_dir/project" remote set-head origin main 2>/dev/null || true
  git -C "$case_dir/project" worktree add -q -b fm/task-x1 "$case_dir/wt" main
  git -C "$case_dir/wt" commit -q --allow-empty -m "shippable work"
  git -C "$case_dir/wt" push -q origin fm/task-x1
  git -C "$case_dir/project" fetch -q origin
  fm_write_meta "$case_dir/state/task-x1.meta" \
    "window=firstmate:fm-task-x1" "endpoint_task_id=task-x1" \
    "worktree=$case_dir/wt" "project=$case_dir/project" \
    "kind=ship" "mode=no-mistakes" "spawn_gen=spawn-gate-refuse-task-x1"
  touch "$case_dir/state/.last-watcher-beat"
  printf '%s\n' "$case_dir"
}

# run_teardown <cwd> <case_dir> [ASSIGN...] -> combined output
run_teardown() {
  local cwd=$1 case_dir=$2; shift 2
  ( cd "$cwd" && env -u NO_MISTAKES_GATE -u FM_GATE_REFUSE_BYPASS \
      "FM_ROOT_OVERRIDE=$ROOT" "FM_STATE_OVERRIDE=$case_dir/state" \
      "FM_DATA_OVERRIDE=$case_dir/data" "FM_CONFIG_OVERRIDE=$case_dir/config" \
      "PATH=$case_dir/fakebin:$PATH" "$@" \
      "$TEARDOWN" task-x1 ) 2>&1
}

# run_teardown_lab <cwd> <case_dir> [ASSIGN...] -> combined output
# Lab-home counterpart of run_teardown: FM_HOME=<case_dir>, no FM_*_OVERRIDE.
run_teardown_lab() {
  local cwd=$1 case_dir=$2; shift 2
  ( cd "$cwd" && env -u NO_MISTAKES_GATE -u FM_GATE_REFUSE_BYPASS \
      "FM_HOME=$case_dir" \
      "PATH=$case_dir/fakebin:$PATH" "$@" \
      "$TEARDOWN" task-x1 ) 2>&1
}

# make_teardown_lab_case <name> -> echoes a marked lab case dir holding the same
# landed task as make_teardown_case (the marker is stamped while the dir is
# still empty, then the fixture populates it).
make_teardown_lab_case() {
  local name=$1
  "$LABHOME" create "$TMP/$name" >/dev/null || return 1
  make_teardown_case "$name"
}

test_teardown_refuses_and_admits() {
  local case_dir out rc

  # env-marker refuse: a genuinely-landed task is still refused; nothing is torn down.
  case_dir=$(make_teardown_case teardown-envmark)
  out=$(run_teardown "$NORMAL_CWD" "$case_dir" NO_MISTAKES_GATE=1); rc=$?
  expect_code 3 "$rc" "teardown: NO_MISTAKES_GATE must refuse"
  assert_contains "$out" "$ENV_MSG" "teardown: env-marker refusal message"
  assert_present "$case_dir/state/task-x1.meta" "teardown: refused env-marker teardown must leave the task"

  # path-backstop refuse (marker UNSET).
  case_dir=$(make_teardown_case teardown-backstop)
  out=$(run_teardown "$GATE_WT" "$case_dir"); rc=$?
  expect_code 3 "$rc" "teardown: gate-worktree cwd must refuse with the marker unset"
  assert_contains "$out" "$PATH_MSG" "teardown: path-backstop refusal message"
  assert_present "$case_dir/state/task-x1.meta" "teardown: refused backstop teardown must leave the task"

  # no-regression: a normal session tears down the landed task.
  case_dir=$(make_teardown_case teardown-ok)
  out=$(run_teardown "$NORMAL_CWD" "$case_dir"); rc=$?
  expect_code 0 "$rc" "teardown: a normal session must still tear down landed work"
  assert_not_contains "$out" "$ENV_MSG" "teardown: normal teardown must not print the gate refusal"
  assert_not_contains "$out" "$PATH_MSG" "teardown: normal teardown must not print the backstop refusal"
  assert_not_contains "$out" "REFUSED" "teardown: normal teardown of landed work must not refuse"

  # lab-home admit: gate context + FM_HOME=marked lab home -> tears down.
  case_dir=$(make_teardown_lab_case teardown-lab)
  out=$(run_teardown_lab "$GATE_WT" "$case_dir"); rc=$?
  expect_code 0 "$rc" "teardown: gate + marked lab home must tear down landed work"
  assert_absent "$case_dir/state/task-x1.meta" "teardown: lab teardown should remove the task record"

  # regression: a home reached through a symlinked spelling must not
  # self-collide in the slot-ownership scan - the canonical root home and the
  # textual state dir resolve to the same record by identity, not path bytes.
  case_dir=$(make_teardown_case teardown-symlink)
  ln -s "$case_dir" "$TMP/teardown-symlinked"
  out=$(run_teardown_lab "$NORMAL_CWD" "$TMP/teardown-symlinked"); rc=$?
  expect_code 0 "$rc" "teardown: a symlinked home spelling must not self-collide"
  assert_absent "$case_dir/state/task-x1.meta" "teardown: symlinked-home teardown should remove the task"
  pass "fm-teardown: refuses on marker and gate-worktree backstop; a normal teardown is unaffected"
}

test_helper_env_marker_refuses
test_helper_empty_env_marker_refuses
test_helper_path_backstop_refuses
test_helper_normal_is_noop
test_helper_lab_home_admits
test_lab_home_helper
test_lab_home_private_tmux_socket_survives_deep_paths
test_spawn_refuses_and_admits
test_send_refuses_and_admits
test_teardown_refuses_and_admits
