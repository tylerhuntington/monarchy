#!/usr/bin/env bash
# Behavior tests for bin/fm-dod-lib.sh's named-head reachability gate on ship
# done: acceptance (issue 4768). The gate must test the commit the worker names,
# not merely that some remote-tracking branch exists or moved.
set -u

# shellcheck source=tests/lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib.sh"
# shellcheck source=bin/fm-dod-lib.sh
. "$ROOT/bin/fm-dod-lib.sh"

TMP_ROOT=$(fm_test_tmproot fm-dod-lib)
fm_git_identity fmtest fmtest@example.invalid

accept_done() {  # <kind> <mode> <worktree> <project> <line> [<state> <id> <meta>]
  fm_dod_accept_ship_done "$@"
}

write_merge_marker() {  # <state> <id> <provider> <host> <path> <number>
  printf '%s\n' fm-pr-poll-merge-notified-v1 "$3" "$4" "$5" "$6" > "$1/$2.pr-poll-merge-notified"
  chmod 600 "$1/$2.pr-poll-merge-notified"
}

test_scout_done_is_not_gated() {
  local repo wt
  repo="$TMP_ROOT/scout-repo"
  wt="$TMP_ROOT/scout-wt"
  fm_git_worktree "$repo" "$wt" fm/scout
  git -C "$wt" commit -q --allow-empty -m 'only in the disposable copy'
  accept_done scout no-mistakes "$wt" "$repo" 'done: report written' \
    || fail "scout done: must not require named-head reachability outside the copy"
  pass "scout done: is not gated"
}

test_unpushed_ship_done_is_refused() {
  local repo wt sha reason rc
  repo="$TMP_ROOT/unpushed-repo"
  wt="$TMP_ROOT/unpushed-wt"
  fm_git_worktree "$repo" "$wt" fm/unpushed
  git -C "$wt" commit -q --allow-empty -m 'fix only in the worktree'
  sha=$(git -C "$wt" rev-parse HEAD)
  reason=$(accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/1 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "unpushed ship done: was accepted (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "unpushed refusal did not name the commit: $reason" ;;
  esac
  pass "unpushed ship done: is refused"
}

test_remote_containing_named_head_is_accepted() {
  local repo wt sha
  repo="$TMP_ROOT/pushed-repo"
  wt="$TMP_ROOT/pushed-wt"
  fm_git_worktree "$repo" "$wt" fm/pushed
  git -C "$wt" commit -q --allow-empty -m 'fix on the branch'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" update-ref refs/remotes/origin/fm/pushed "$sha"
  accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/2 checks green" \
    || fail "named head on a remote-tracking ref was refused"
  pass "named head on a remote-tracking ref is accepted"
}

test_gate_mirror_only_named_head_is_refused() {
  local repo wt sha reason rc
  repo="$TMP_ROOT/mirror-repo"
  wt="$TMP_ROOT/mirror-wt"
  fm_git_worktree "$repo" "$wt" fm/mirror
  git -C "$wt" commit -q --allow-empty -m 'fix pushed only to the local gate'
  sha=$(git -C "$wt" rev-parse HEAD)
  # The local no-mistakes gate mirror lives on this machine, so a head that
  # only reached it has not left the machine.
  git -C "$wt" update-ref refs/remotes/no-mistakes/fm/mirror "$sha"
  reason=$(accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/4 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "named head only on the no-mistakes gate mirror was accepted (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "gate-mirror refusal did not name the commit: $reason" ;;
  esac
  # A refresh fetches origin, which does not hold the head, and never counts
  # the mirror, so the refusal stands with no refresh failure to report.
  reason=$(FM_DOD_REFRESH_REMOTES=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/4 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "named head only on the gate mirror was accepted after a refresh (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "gate-mirror refusal after a refresh changed its reason: $reason" ;;
  esac
  git -C "$wt" update-ref refs/remotes/origin/fm/mirror "$sha"
  accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/4 checks green" >/dev/null \
    || fail "named head on origin beside the gate mirror was refused"
  pass "named head only on the no-mistakes gate mirror is refused, even after a refresh; on origin it is accepted"
}

test_head_pushed_from_gate_clone_is_accepted_after_refresh() {
  local repo wt origin sha reason rc
  repo="$TMP_ROOT/gate-push-repo"
  wt="$TMP_ROOT/gate-push-wt"
  origin="$repo.origin.git"
  fm_git_worktree "$repo" "$wt" fm/gate-push
  git -C "$wt" commit -q --allow-empty -m 'fix the pipeline pushed from its gate clone'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" update-ref refs/remotes/no-mistakes/fm/gate-push "$sha"
  # The pipeline pushes from its own gate clone, so origin holds the head while
  # neither the copy nor the project clone has fetched it.
  git -C "$origin" fetch -q "$wt" "fm/gate-push:refs/heads/fm/gate-push"
  [ "$(git -C "$origin" rev-parse refs/heads/fm/gate-push)" = "$sha" ] \
    || fail "fixture: origin does not hold the gate clone's push"
  ! git -C "$wt" rev-parse -q --verify refs/remotes/origin/fm/gate-push >/dev/null \
    || fail "fixture: the copy already tracks origin's branch"
  reason=$(accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/5 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "a caller that does not refresh accepted an unfetched head (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "unfetched refusal without a refresh did not name the commit: $reason" ;;
  esac
  ! git -C "$wt" rev-parse -q --verify refs/remotes/origin/fm/gate-push >/dev/null \
    || fail "a caller that does not refresh fetched anyway"
  FM_DOD_REFRESH_REMOTES=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/5 checks green" >/dev/null \
    || fail "head origin holds through the gate clone was refused after a refresh"
  [ "$(git -C "$wt" rev-parse refs/remotes/origin/fm/gate-push)" = "$sha" ] \
    || fail "the refresh did not leave origin's head in the copy's refs"
  accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/5 checks green" >/dev/null \
    || fail "a caller that does not refresh refused the head a refresh already fetched"
  pass "head origin holds through the gate clone is accepted after a refresh, and later reads see it"
}

test_passed_refresh_deadline_refuses_with_last_known_refs() {
  local repo wt origin sha reason rc
  repo="$TMP_ROOT/deadline-passed-repo"
  wt="$TMP_ROOT/deadline-passed-wt"
  origin="$repo.origin.git"
  fm_git_worktree "$repo" "$wt" fm/deadline-passed
  git -C "$wt" commit -q --allow-empty -m 'fix origin holds while the copy has not fetched it'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$origin" fetch -q "$wt" "fm/deadline-passed:refs/heads/fm/deadline-passed"
  reason=$(FM_DOD_REFRESH_REMOTES=1 FM_DOD_REFRESH_DEADLINE=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/8 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "a head was accepted although the refresh deadline had passed (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy; could not refresh remote: origin, so this verdict used the last-known refs"*) ;;
    *) fail "a refusal past the refresh deadline did not say it used the last-known refs: $reason" ;;
  esac
  ! git -C "$wt" rev-parse -q --verify refs/remotes/origin/fm/deadline-passed >/dev/null \
    || fail "a refresh past its deadline fetched anyway"
  pass "past the refresh deadline nothing is fetched and the refusal says it used the last-known refs"
}

test_separate_project_clone_is_refreshed() {
  local repo wt origin sha reason rc
  repo="$TMP_ROOT/separate-project-repo"
  wt="$TMP_ROOT/separate-project-wt"
  origin="$repo.origin.git"
  fm_git_init_commit "$repo"
  fm_git_add_origin "$repo" "$origin"
  # The copy is a repository of its own whose only remote is the project clone,
  # so only a refresh of the project clone reaches the origin holding the head.
  git clone -q "$repo" "$wt"
  git -C "$wt" checkout -q -b fm/separate
  git -C "$wt" commit -q --allow-empty -m 'fix the pipeline pushed from its gate clone'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$origin" fetch -q "$wt" "fm/separate:refs/heads/fm/separate"
  [ "$(git -C "$wt" rev-parse --path-format=absolute --git-common-dir)" != \
    "$(git -C "$repo" rev-parse --path-format=absolute --git-common-dir)" ] \
    || fail "fixture: the copy shares the project clone's git directory"
  reason=$(accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/7 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "a caller that does not refresh accepted an unfetched head (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "unfetched refusal without a refresh did not name the commit: $reason" ;;
  esac
  FM_DOD_REFRESH_REMOTES=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/7 checks green" >/dev/null \
    || fail "head the project clone's origin holds was refused after a refresh"
  [ "$(git -C "$repo" rev-parse refs/remotes/origin/fm/separate)" = "$sha" ] \
    || fail "the refresh did not fetch the project clone's origin"
  ! git -C "$wt" rev-parse -q --verify refs/remotes/origin/fm/separate >/dev/null \
    || fail "fixture: the copy's own remote held the head"
  pass "a project clone with its own git directory is refreshed too, and its origin's head is accepted"
}

test_failed_refresh_refuses_with_last_known_refs() {
  local repo wt sha reason rc
  repo="$TMP_ROOT/refresh-fail-repo"
  wt="$TMP_ROOT/refresh-fail-wt"
  fm_git_worktree "$repo" "$wt" fm/refresh-fail
  git -C "$wt" commit -q --allow-empty -m 'fix behind an unreachable remote'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$repo" remote set-url origin "file://$TMP_ROOT/refresh-fail-missing.git"
  reason=$(FM_DOD_REFRESH_REMOTES=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/6 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "named head was accepted although the refresh failed (exit $rc)"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy; could not refresh remote: origin, so this verdict used the last-known refs"*) ;;
    *) fail "failed-refresh refusal did not say it used the last-known refs: $reason" ;;
  esac
  [ "$(printf '%s\n' "$reason" | wc -l | tr -d ' ')" = 1 ] \
    || fail "failed-refresh refusal is not one line: $reason"
  pass "a failed refresh still refuses and says the verdict used the last-known refs"
}

test_remote_hanging_before_origin_leaves_origin_its_refresh() {
  local repo wt origin fakebin sha start
  repo="$TMP_ROOT/hang-first-repo"
  wt="$TMP_ROOT/hang-first-wt"
  origin="$repo.origin.git"
  fakebin="$TMP_ROOT/hang-first-bin"
  fm_git_worktree "$repo" "$wt" fm/hang-first
  git -C "$wt" commit -q --allow-empty -m 'fix the pipeline pushed from its gate clone'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$origin" fetch -q "$wt" "fm/hang-first:refs/heads/fm/hang-first"
  # backup sorts before origin and never answers a fetch.
  mkdir -p "$fakebin"
  printf '%s\n' '#!/bin/sh' 'exec sleep 30' > "$fakebin/git-remote-hang"
  chmod +x "$fakebin/git-remote-hang"
  git -C "$repo" remote add backup hang::backup
  [ "$(git -C "$wt" remote | head -1)" = backup ] \
    || fail "fixture: the hanging remote is not listed before origin"
  FM_DOD_REFRESH_FAILED=
  start=$(date +%s)
  PATH="$fakebin:$PATH" FM_DOD_REFRESH_REMOTES=1 FM_DOD_REFRESH_DEADLINE=$((start + 4)) \
    accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/9 checks green" >/dev/null \
    || fail "a remote hanging before origin under a short refresh deadline kept origin's head from being accepted"
  [ "$(git -C "$wt" rev-parse refs/remotes/origin/fm/hang-first)" = "$sha" ] \
    || fail "origin was not fetched behind a remote that hangs"
  [ "$FM_DOD_REFRESH_FAILED" = backup ] \
    || fail "the hanging remote was not named as not refreshed: '$FM_DOD_REFRESH_FAILED'"
  [ "$(date +%s)" -le $((start + 6)) ] || fail "the refresh outlived its deadline"
  pass "a remote that hangs and sorts before origin cannot take origin's refresh; origin's head is accepted and the hanging remote is named"
}

test_hanging_copy_remote_leaves_the_project_clone_its_refresh() {
  local repo wt origin fakebin sha reason rc start
  repo="$TMP_ROOT/copy-hang-repo"
  wt="$TMP_ROOT/copy-hang-wt"
  origin="$repo.origin.git"
  fakebin="$TMP_ROOT/copy-hang-bin"
  fm_git_init_commit "$repo"
  fm_git_add_origin "$repo" "$origin"
  # A standalone copy whose origin is the project clone and whose second remote
  # never answers a fetch; only the project clone's origin holds the head.
  git clone -q "$repo" "$wt"
  git -C "$wt" checkout -q -b fm/copy-hang
  git -C "$wt" commit -q --allow-empty -m 'fix the pipeline pushed from its gate clone'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$origin" fetch -q "$wt" "fm/copy-hang:refs/heads/fm/copy-hang"
  mkdir -p "$fakebin"
  printf '%s\n' '#!/bin/sh' 'exec sleep 30' > "$fakebin/git-remote-hang"
  chmod +x "$fakebin/git-remote-hang"
  git -C "$wt" remote add fork hang::fork
  [ "$(git -C "$wt" rev-parse --path-format=absolute --git-common-dir)" != \
    "$(git -C "$repo" rev-parse --path-format=absolute --git-common-dir)" ] \
    || fail "fixture: the copy shares the project clone's git directory"
  reason=$(FM_DOD_REFRESH_REMOTES=1 FM_DOD_REFRESH_DEADLINE=1 accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/10 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "a head was accepted although the refresh deadline had passed (exit $rc)"
  case "$reason" in
    *"could not refresh remote: origin, fork, origin (project clone), so this verdict used the last-known refs"*) ;;
    *) fail "the refusal did not tell the copy's remotes from the project clone's: $reason" ;;
  esac
  FM_DOD_REFRESH_FAILED=
  start=$(date +%s)
  PATH="$fakebin:$PATH" FM_DOD_REFRESH_REMOTES=1 FM_DOD_REFRESH_DEADLINE=$((start + 6)) \
    accept_done ship no-mistakes "$wt" "$repo" "done: PR https://gitlab.example.test/g/r/-/merge_requests/10 checks green" >/dev/null \
    || fail "a hanging remote in the copy kept the project clone's origin head from being accepted"
  [ "$(git -C "$repo" rev-parse refs/remotes/origin/fm/copy-hang)" = "$sha" ] \
    || fail "the project clone's origin was not fetched behind the copy's hanging remote"
  [ "$FM_DOD_REFRESH_FAILED" = fork ] \
    || fail "the hanging remote was not named as not refreshed: '$FM_DOD_REFRESH_FAILED'"
  [ "$(date +%s)" -le $((start + 8)) ] || fail "the refresh outlived its deadline"
  pass "a hanging remote in a standalone copy cannot take the project clone's refresh; its origin's head is accepted and failed remotes name their repository"
}

test_local_only_branch_beside_gate_mirror_is_accepted() {
  local repo wt sha
  repo="$TMP_ROOT/mirror-local-repo"
  wt="$TMP_ROOT/mirror-local-wt"
  fm_git_worktree "$repo" "$wt" fm/mirror-local
  git -C "$wt" commit -q --allow-empty -m 'local-only work also on the gate'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" update-ref refs/remotes/no-mistakes/fm/mirror-local "$sha"
  accept_done ship local-only "$wt" "$repo" "done: ready in branch fm/mirror-local" >/dev/null \
    || fail "local-only named branch in the project clone was refused beside a gate mirror ref"
  pass "local-only named branch stays reachable when the gate mirror also holds it"
}

test_moved_branch_without_named_head_is_refused() {
  local repo wt main_sha fix_sha reason rc
  repo="$TMP_ROOT/moved-repo"
  wt="$TMP_ROOT/moved-wt"
  fm_git_worktree "$repo" "$wt" fm/moved
  main_sha=$(git -C "$repo" rev-parse main)
  git -C "$wt" commit -q --allow-empty -m 'the actual fix'
  fix_sha=$(git -C "$wt" rev-parse HEAD)
  # The fork branch exists and moved, but only to a merge of the default
  # branch: reachability of that branch is not reachability of the named head.
  git -C "$wt" update-ref refs/remotes/origin/fm/moved "$main_sha"
  reason=$(accept_done ship no-mistakes "$wt" "$repo" "done: PR https://example.test/o/r/pull/3 checks green")
  rc=$?
  [ "$rc" -eq 1 ] || fail "moved remote branch without the named head was accepted"
  case "$reason" in
    *"named head $fix_sha is unreachable outside the worker copy") ;;
    *) fail "moved-branch refusal did not name the fix commit: $reason" ;;
  esac
  pass "a moved remote branch that lacks the named head is refused"
}

test_no_mistakes_prevalidation_done_is_not_gated() {
  local repo wt
  repo="$TMP_ROOT/preval-repo"
  wt="$TMP_ROOT/preval-wt"
  fm_git_worktree "$repo" "$wt" fm/preval
  git -C "$wt" commit -q --allow-empty -m 'only in the disposable copy'
  accept_done ship no-mistakes "$wt" "$repo" 'done: implementation complete' \
    || fail "no-mistakes pre-validation done: must not require named-head reachability"
  pass "no-mistakes pre-validation done: is not gated"
}

test_local_only_linked_branch_is_accepted() {
  local repo wt
  repo="$TMP_ROOT/local-repo"
  wt="$TMP_ROOT/local-wt"
  fm_git_worktree "$repo" "$wt" fm/local
  git -C "$wt" commit -q --allow-empty -m 'local-only work'
  accept_done ship local-only "$wt" "$repo" "done: ready in branch fm/local" \
    || fail "local-only named branch in a linked worktree was refused"
  pass "local-only linked named branch is reachable from the project clone"
}

test_local_only_detached_head_is_refused() {
  local repo wt sha rc
  repo="$TMP_ROOT/detach-repo"
  wt="$TMP_ROOT/detach-wt"
  fm_git_worktree "$repo" "$wt" fm/detach
  git -C "$wt" commit -q --allow-empty -m 'detached only'
  sha=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" checkout -q --detach HEAD
  git -C "$wt" branch -q -D fm/detach
  accept_done ship local-only "$wt" "$repo" "done: ready in branch fm/detach" >/dev/null \
    && fail "detached local-only head whose branch was deleted was accepted"
  rc=0
  accept_done ship local-only "$wt" "$repo" "done: implementation complete" >/dev/null || rc=$?
  [ "$rc" -eq 1 ] || fail "detached local-only HEAD was accepted as done"
  pass "local-only detached HEAD only in the disposable copy is refused"
}

test_standalone_local_only_needs_project_ref() {
  local repo wt sha
  repo="$TMP_ROOT/stand-project"
  wt="$TMP_ROOT/stand-copy"
  fm_git_init_commit "$repo"
  git clone --quiet "$repo" "$wt"
  git -C "$wt" checkout -q -b fm/stand
  git -C "$wt" commit -q --allow-empty -m 'only in the standalone copy'
  sha=$(git -C "$wt" rev-parse HEAD)
  accept_done ship local-only "$wt" "$repo" "done: ready in branch fm/stand" >/dev/null \
    && fail "standalone local-only copy was accepted without the named head in the project clone"
  git -C "$repo" fetch -q "$wt" "fm/stand:fm/stand"
  [ "$(git -C "$repo" rev-parse fm/stand)" = "$sha" ] \
    || fail "project clone did not gain the named head"
  accept_done ship local-only "$wt" "$repo" "done: ready in branch fm/stand" \
    || fail "standalone local-only named head present in the project clone was refused"
  pass "standalone local-only done: requires the named head in the project clone"
}

test_free_text_sha_is_not_the_named_head() {
  local repo wt old new reason rc
  repo="$TMP_ROOT/hex-repo"
  wt="$TMP_ROOT/hex-wt"
  fm_git_worktree "$repo" "$wt" fm/hex
  old=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" update-ref refs/remotes/origin/main "$old"
  git -C "$wt" commit -q --allow-empty -m 'actual fix'
  new=$(git -C "$wt" rev-parse HEAD)
  reason=$(accept_done ship direct-PR "$wt" "$repo" "done: reverted $old and fixed the retry")
  rc=$?
  [ "$rc" -eq 1 ] || fail "free-text SHA on origin/main made an unpushed HEAD accept"
  case "$reason" in
    *"named head $new is unreachable outside the worker copy") ;;
    *) fail "free-text SHA scan still selected the old commit: $reason" ;;
  esac
  pass "a 40-hex token in the note is not the named head"
}

test_recorded_merged_pr_is_landed_after_prune() {
  local repo wt meta state
  repo="$TMP_ROOT/merged-repo"
  wt="$TMP_ROOT/merged-wt"
  state="$TMP_ROOT/merged-state"
  mkdir -p "$state"
  fm_git_worktree "$repo" "$wt" fm/merged
  git -C "$wt" commit -q --allow-empty -m 'fix, squash-merged and branch pruned'
  meta="$state/merged.meta"
  printf 'kind=ship\nmode=direct-PR\nworktree=%s\nproject=%s\npr=https://github.com/o/r/pull/7\n' \
    "$wt" "$repo" > "$meta"
  write_merge_marker "$state" merged github github.com o/r 7
  accept_done ship direct-PR "$wt" "$repo" "done: PR https://github.com/o/r/pull/7" "$state" merged "$meta" \
    || fail "recorded merged PR was refused after its remote-tracking ref was pruned"
  pass "a recorded merged PR satisfies the gate after prune"
}

test_merge_marker_binds_to_the_named_pr() {
  local repo wt meta state reason rc sha
  repo="$TMP_ROOT/bind-repo"
  wt="$TMP_ROOT/bind-wt"
  state="$TMP_ROOT/bind-state"
  mkdir -p "$state"
  fm_git_worktree "$repo" "$wt" fm/bind
  git -C "$wt" commit -q --allow-empty -m 'second PR head, never pushed'
  sha=$(git -C "$wt" rev-parse HEAD)
  meta="$state/bind.meta"
  printf 'kind=ship\nmode=direct-PR\nworktree=%s\nproject=%s\npr=https://github.com/o/r/pull/7\n' \
    "$wt" "$repo" > "$meta"
  write_merge_marker "$state" bind github github.com o/r 7
  reason=$(accept_done ship direct-PR "$wt" "$repo" "done: PR https://github.com/o/r/pull/9" "$state" bind "$meta")
  rc=$?
  [ "$rc" -eq 1 ] || fail "merge of recorded PR 7 accepted an unpushed done naming PR 9"
  case "$reason" in
    *"named head $sha is unreachable outside the worker copy") ;;
    *) fail "PR 9 refusal did not name the unpushed head: $reason" ;;
  esac
  write_merge_marker "$state" bind github github.com other/r 7
  accept_done ship direct-PR "$wt" "$repo" "done: PR https://github.com/o/r/pull/7" "$state" bind "$meta" >/dev/null \
    && fail "merge marker for another repository's PR 7 was accepted"
  pass "the merged-PR short-circuit applies only to the recorded PR the done line names"
}

test_forge_recorded_head_is_accepted_without_local_object() {
  local repo wt meta state forge_head
  repo="$TMP_ROOT/forge-repo"
  wt="$TMP_ROOT/forge-wt"
  state="$TMP_ROOT/forge-state"
  mkdir -p "$state"
  fm_git_worktree "$repo" "$wt" fm/forge
  git -C "$wt" commit -q --allow-empty -m 'worker head, not pushed from this copy'
  # The pipeline's own commit: on the forge and in the gate repo, never
  # fetched into the worker clone.
  forge_head=0123456789abcdef0123456789abcdef01234567
  meta="$state/forge.meta"
  printf 'kind=ship\nmode=no-mistakes\nworktree=%s\nproject=%s\npr=https://github.com/o/r/pull/5\npr_head=%s\n' \
    "$wt" "$repo" "$forge_head" > "$meta"
  accept_done ship no-mistakes "$wt" "$repo" "done: PR https://github.com/o/r/pull/5 checks green" \
    "$state" forge "$meta" \
    || fail "forge-recorded pr_head the worker clone never fetched was refused"
  accept_done ship no-mistakes "$wt" "$repo" "done: PR https://github.com/o/r/pull/6 checks green" \
    "$state" forge "$meta" >/dev/null \
    && fail "pr_head recorded for PR 5 was accepted for a done naming PR 6"
  pass "a forge-recorded head for the named PR is accepted without a local object"
}

# A direct-PR worker pushes from its own copy: a commit made after the PR's
# recorded head, never pushed, is the named head and is refused.
test_direct_pr_recorded_head_does_not_cover_unpushed_commit() {
  local repo wt meta state pushed later reason rc
  repo="$TMP_ROOT/postopen-repo"
  wt="$TMP_ROOT/postopen-wt"
  state="$TMP_ROOT/postopen-state"
  mkdir -p "$state"
  fm_git_worktree "$repo" "$wt" fm/postopen
  git -C "$wt" commit -q --allow-empty -m 'pushed when the PR opened'
  pushed=$(git -C "$wt" rev-parse HEAD)
  git -C "$wt" update-ref refs/remotes/origin/fm/postopen "$pushed"
  git -C "$wt" commit -q --allow-empty -m 'the fix, only in the worktree'
  later=$(git -C "$wt" rev-parse HEAD)
  meta="$state/postopen.meta"
  printf 'kind=ship\nmode=direct-PR\nworktree=%s\nproject=%s\npr=https://github.com/o/r/pull/5\npr_head=%s\n' \
    "$wt" "$repo" "$pushed" > "$meta"
  reason=$(accept_done ship direct-PR "$wt" "$repo" "done: PR https://github.com/o/r/pull/5" "$state" postopen "$meta")
  rc=$?
  [ "$rc" -eq 1 ] || fail "direct-PR recorded pr_head accepted an unpushed later commit"
  case "$reason" in
    *"named head $later is unreachable outside the worker copy") ;;
    *) fail "direct-PR refusal did not name the unpushed commit: $reason" ;;
  esac
  pass "a direct-PR recorded head does not cover a later unpushed commit"
}

test_ci_ready_requires_pr_reference() {
  local note
  for note in \
    'paused: PROD deploy watch, checks green on TEST' \
    'paused: checks green on TEST, PROPERTIES watch' \
    'PR checks green' \
    'PR #12 checks pending'; do
    if fm_dod_note_reports_ci_ready "$note"; then
      fail "non-CI-ready note accepted: $note"
    fi
  done
  for note in \
    'PR https://github.com/o/r/pull/5 checks green' \
    'checks green: https://github.com/o/r/pull/5' \
    'PR #12 checks green' \
    'checks green: PR#12' \
    'https://gitlab.com/o/r/-/merge_requests/5 checks green' \
    'https://git.example.org/team/repo/pulls/12 checks green'; do
    fm_dod_note_reports_ci_ready "$note" \
      || fail "CI-ready PR reference rejected: $note"
  done
  pass "CI-ready notes require checks green and an actual PR reference"
}

test_ci_ready_variants_are_gated() {
  local repo wt line rc
  repo="$TMP_ROOT/variant-repo"
  wt="$TMP_ROOT/variant-wt"
  fm_git_worktree "$repo" "$wt" fm/variant
  git -C "$wt" commit -q --allow-empty -m 'only in the disposable copy'
  for line in \
    'done: PR https://github.com/o/r/pull/5 checks green, risk low' \
    'done: PR https://github.com/o/r/pull/5 - checks green' \
    'done: PR https://github.com/o/r/pull/5 checks green.' \
    'done: PR https://github.com/o/r/pull/5 (checks green)'; do
    rc=0
    accept_done ship no-mistakes "$wt" "$repo" "$line" >/dev/null || rc=$?
    [ "$rc" -eq 1 ] || fail "no-mistakes CI-ready variant skipped the gate: $line"
  done
  pass "no-mistakes CI-ready done: with extra text is gated"
}

test_keyed_and_spaced_done_lines_are_gated() {
  local repo wt line mode rc
  repo="$TMP_ROOT/keyed-repo"
  wt="$TMP_ROOT/keyed-wt"
  fm_git_worktree "$repo" "$wt" fm/keyed
  git -C "$wt" commit -q --allow-empty -m 'only in the disposable copy'
  for line in \
    'no-mistakes|done [key=fix]: PR https://github.com/o/r/pull/5 checks green' \
    'no-mistakes|done : PR https://github.com/o/r/pull/5 checks green' \
    'direct-PR|done [key=fix]: PR https://github.com/o/r/pull/5' \
    'direct-PR|done: [key=fix] PR https://github.com/o/r/pull/5'; do
    mode=${line%%|*}
    rc=0
    accept_done ship "$mode" "$wt" "$repo" "${line#*|}" >/dev/null || rc=$?
    [ "$rc" -eq 1 ] || fail "$mode done line skipped the gate: ${line#*|}"
  done
  pass "keyed and spaced ship done: lines are gated"
}

test_non_done_lines_are_not_gated() {
  local repo wt
  repo="$TMP_ROOT/nongate-repo"
  wt="$TMP_ROOT/nongate-wt"
  fm_git_worktree "$repo" "$wt" fm/nongate
  git -C "$wt" commit -q --allow-empty -m 'unpushed'
  accept_done ship no-mistakes "$wt" "$repo" 'working: still implementing' \
    || fail "working: line was gated"
  accept_done ship no-mistakes "$wt" "$repo" 'blocked: waiting on a credential' \
    || fail "blocked: line was gated"
  pass "non-done lines are not gated"
}

# Issue 3608: a legacy `# Task` body's provenance marker must be read the way
# bin/fm-brief-heading-lib.sh reads headings - outside fenced blocks and never
# from an indented example - or a fenced `Captain:` sample becomes the ship
# contract's intent while the real ask is dropped.
test_fenced_and_indented_captain_lines_are_not_intent() {
  local home id meta out status words
  home="$TMP_ROOT/fenced-home"
  mkdir -p "$home/state" "$home/data"
  words=$(fm_brief_marked_captain_words 'Investigate the promotion gate.

```markdown
Captain: This fenced example must not become intent.
[captain] Neither must this one.
```

~~~
Captain: Nor this tilde-fenced one.
~~~

    Captain: An indented example is not the ask either.
	[captain] Nor a tab-indented one.
Keep this Firstmate constraint out of captain intent.')
  assert_equals "" "$words" "fenced or indented Captain lines were extracted as authorized intent"

  words=$(fm_brief_marked_captain_words '```
Captain: fenced example
```
  [captain] Preserve the real ask after the fence closes.
````
Captain: a longer fence that a shorter closer must not end
```
Captain: still fenced
````')
  assert_equals "Preserve the real ask after the fence closes." "$words" \
    "the marker after a closed fence, or inside a longer fence, was misread"

  id=promote-fenced-captain
  meta="$home/state/$id.meta"
  printf 'window=fm-%s\nkind=scout\nworktree=/tmp/wt\n' "$id" > "$meta"
  mkdir -p "$home/data/$id"
  cat > "$home/data/$id/brief.md" <<'EOF'
# Task
Investigate the promotion gate.

```markdown
Captain: This fenced example must not become intent.
```

    Captain: An indented example is not the ask either.

# Setup
This is a SCOUT task: the deliverable is a written report, not a PR.
EOF
  out=$(FM_HOME="$home" FM_STATE_OVERRIDE="$home/state" "$ROOT/bin/fm-promote.sh" "$id" --mode direct-PR --yolo off 2>&1)
  status=$?
  [ "$status" -ne 0 ] || fail "promotion whose only Captain lines are fenced or indented examples should fail"
  assert_contains "$out" "has no provenance-marked Captain's intent" \
    "fenced-example promotion did not refuse like an unmarked legacy brief"
  assert_absent "$home/data/$id/ship-instructions.md" \
    "fenced-example promotion published a fenced sample as captain intent"
  assert_grep 'kind=scout' "$meta" "fenced-example promotion changed the task record"
  pass "fenced and indented Captain lines are not authorized intent"
}

# The draft check the DoD hands a worker must be the gh-axi path that rule 3 of
# every ship brief requires for GitHub operations, never raw gh (issue 5325).
test_pr_based_dod_draft_check_uses_gh_axi() {
  local mode out
  for mode in direct-PR no-mistakes; do
    out="$TMP_ROOT/dod-$mode.md"
    fm_dod_block "$mode" dod-draft-task > "$out"
    assert_no_grep 'gh pr view' "$out" "$mode: DoD must not document a raw gh draft check"
    # shellcheck disable=SC2016  # single quotes are deliberate: the backticks must stay literal
    assert_grep 'confirm it is not a draft (`gh-axi pr view <number>` must print `draft: no`' "$out" \
      "$mode: DoD must read the draft state through gh-axi"
  done
  pass "PR-based DoD draft check uses gh-axi"
}

# A scout spawned on a named base keeps that base through promotion: the ship
# instructions start from it and the PR targets it; local-only cannot carry it.
test_promotion_keeps_the_recorded_base_branch() {
  local home id meta out status mode
  home="$TMP_ROOT/promote-base-home"
  for mode in direct-PR local-only; do
    id="promote-base-$mode"
    meta="$home/state/$id.meta"
    mkdir -p "$home/state" "$home/data/$id"
    printf 'window=fm-%s\nkind=scout\nworktree=/tmp/wt\nbase_branch=feature/hub\n' "$id" > "$meta"
    cat > "$home/data/$id/brief.md" <<'EOF'
# Task
## Captain's intent
Fix the hub bug.

## Firstmate spec
Reproduce it first.

# Setup
You are in a disposable git worktree of proj, at a detached HEAD on a clean copy of its base branch.
Base branch: feature/hub
EOF
    out=$(FM_HOME="$home" FM_STATE_OVERRIDE="$home/state" "$ROOT/bin/fm-promote.sh" "$id" --mode "$mode" --yolo off 2>&1)
    status=$?
    if [ "$mode" = direct-PR ]; then
      expect_code 0 "$status" "promoting a scout with a recorded base should succeed"$'\n'"$out"
      # shellcheck disable=SC2016  # literal backticks in rendered prose must stay unexpanded
      assert_grep 'Return to a clean copy of the base branch `feature/hub`' "$home/data/$id/ship-instructions.md" \
        "promotion did not start the ship from the recorded base"
      # shellcheck disable=SC2016
      assert_grep 'against the base branch `feature/hub`' "$home/data/$id/ship-instructions.md" \
        "promotion did not target the PR at the recorded base"
      assert_grep 'base_branch=feature/hub' "$meta" "promotion dropped the recorded base"
    else
      [ "$status" -ne 0 ] || fail "promoting a based scout to local-only should be refused"
      assert_contains "$out" "mode=local-only" "the local-only promotion refusal did not explain itself"
      assert_grep 'kind=scout' "$meta" "a refused promotion changed the task record"
    fi
  done
  pass "promotion keeps a scout's recorded base branch and refuses local-only for it"
}

test_scout_done_is_not_gated
test_unpushed_ship_done_is_refused
test_no_mistakes_prevalidation_done_is_not_gated
test_remote_containing_named_head_is_accepted
test_gate_mirror_only_named_head_is_refused
test_head_pushed_from_gate_clone_is_accepted_after_refresh
test_separate_project_clone_is_refreshed
test_passed_refresh_deadline_refuses_with_last_known_refs
test_failed_refresh_refuses_with_last_known_refs
test_remote_hanging_before_origin_leaves_origin_its_refresh
test_hanging_copy_remote_leaves_the_project_clone_its_refresh
test_local_only_branch_beside_gate_mirror_is_accepted
test_moved_branch_without_named_head_is_refused
test_free_text_sha_is_not_the_named_head
test_recorded_merged_pr_is_landed_after_prune
test_merge_marker_binds_to_the_named_pr
test_forge_recorded_head_is_accepted_without_local_object
test_direct_pr_recorded_head_does_not_cover_unpushed_commit
test_ci_ready_requires_pr_reference
test_ci_ready_variants_are_gated
test_keyed_and_spaced_done_lines_are_gated
test_local_only_linked_branch_is_accepted
test_local_only_detached_head_is_refused
test_standalone_local_only_needs_project_ref
test_non_done_lines_are_not_gated
test_fenced_and_indented_captain_lines_are_not_intent
test_pr_based_dod_draft_check_uses_gh_axi
test_promotion_keeps_the_recorded_base_branch

# The launch role is the generated text a worker receives. It must keep the
# skill name, so a session that registers the skill loads it by name, and must
# name the skill file as the fallback for a session where the name does not
# resolve.
test_worker_role_names_skill_and_fallback_file() {
  local role_file path
  role_file="$TMP_ROOT/worker-role.txt"
  path="$ROOT/.agents/skills/firstmate-coding-guidelines/SKILL.md"
  [ -f "$path" ] || fail "Firstmate skill file is missing at $path"
  fm_brief_worker_role "$TMP_ROOT/state" upstream-4751 "$ROOT" >"$role_file"
  assert_grep "\`CONTRIBUTING.md\` and \`firstmate-coding-guidelines\` for Firstmate changes" "$role_file" \
    "worker role did not name the skill"
  assert_grep "If the \`firstmate-coding-guidelines\` skill name does not resolve in this session, read \`$path\` instead." "$role_file" \
    "worker role did not name the skill file as the fallback"
  assert_no_grep "Skill tool cannot resolve" "$role_file" \
    "worker role claims the Skill tool never resolves the skill"
  pass "worker role names the skill and its fallback skill file"
}

# forge=external: a review tool uploads its own snapshot, so nothing is pushed.
# The fixtures name an invented tool and an RFC 6761 reserved host only.
EXT_CFG="$TMP_ROOT/external-config"
mkdir -p "$EXT_CFG"
# shellcheck disable=SC2016 # Backticks are literal adapter text.
printf '%s\n' 'Run `review-tool upload --draft` and stop at a draft with checks green.' > "$EXT_CFG/external-review.md"

test_external_forge_is_direct_pr_only() {
  local out
  fm_forge_valid_for_mode external direct-PR test 2>/dev/null || fail "forge=external direct-PR was refused"
  out=$(fm_forge_valid_for_mode external no-mistakes test 2>&1) && fail "forge=external no-mistakes was accepted"
  assert_contains "$out" "ships direct-PR only for now" "the no-mistakes refusal did not say why"
  out=$(fm_forge_valid_for_mode external local-only test 2>&1) && fail "forge=external local-only was accepted"
  assert_contains "$out" "cannot ship mode=local-only" "the local-only refusal did not say why"
  out=$(fm_base_branch_valid release direct-PR external test 2>&1) && fail "a base branch was accepted on forge=external"
  pass "forge=external composes with direct-PR only and refuses a base branch"
}

test_external_rule_one_forbids_every_task_push() {
  local rule
  rule=$(CONFIG=$EXT_CFG fm_ship_rule_one direct-PR t1 fm/t1 external) || fail "external rule one did not render"
  assert_contains "$rule" "Never push to \`origin\`" "external rule one does not forbid the origin push"
  assert_contains "$rule" "never push your \`fm/t1\` branch or any \`fm/\`-prefixed branch to any remote" \
    "external rule one does not forbid the task-prefixed push"
  assert_not_contains "$rule" "push only your" "external rule one still invites a branch push"
  assert_not_contains "$rule" "personal backup remote" "external rule one offers a backup nobody configured"
  printf 'backup\n' > "$EXT_CFG/external-review-backup"
  rule=$(CONFIG=$EXT_CFG fm_ship_rule_one direct-PR t1 fm/t1 external) || fail "external rule one with a backup did not render"
  rm -f "$EXT_CFG/external-review-backup"
  assert_contains "$rule" "\`git push backup HEAD:refs/heads/backup/t1\`" "external rule one does not name the backup copy"
  pass "external rule one forbids origin and task-prefixed pushes and names only the backup copy"
}

test_external_dod_renders_the_adapter() {
  local dod out
  dod=$(CONFIG=$EXT_CFG fm_dod_block direct-PR t1 fm/t1 external) || fail "external DoD did not render"
  assert_contains "$dod" "Delivery contract: mode=direct-PR forge=external" "external DoD lacks its contract line"
  assert_contains "$dod" "done [at=<epoch>]: review {url} uploaded for review" "external DoD lacks the ready grammar"
  assert_contains "$dod" "## Review tool instructions (home configuration)" "external DoD lacks the adapter section"
  assert_contains "$dod" "review-tool upload --draft" "external DoD lacks the adapter body"
  assert_not_contains "$dod" "push your branch and open a PR" "external DoD still asks for a pushed PR"
  out=$(CONFIG="$TMP_ROOT/no-such-config" fm_dod_block direct-PR t1 fm/t1 external 2>&1) \
    && fail "external DoD rendered with no adapter"
  assert_contains "$out" "external-review.md" "the missing-adapter refusal did not name the file"
  pass "external DoD renders the contract, the review grammar, and the adapter, and refuses without one"
}

# A review-tool fixture: a worker copy, its meta recording forge=external, and
# optionally a backup remote. Sets EXT_WT, EXT_REPO, EXT_META.
external_fixture() {  # <name> [backup]
  local name=$1 backup=${2:-}
  EXT_REPO="$TMP_ROOT/$name-repo"
  EXT_WT="$TMP_ROOT/$name-wt"
  fm_git_worktree "$EXT_REPO" "$EXT_WT" "fm/$name"
  git -C "$EXT_WT" commit -q --allow-empty -m 'change only in the copy'
  EXT_META="$TMP_ROOT/$name.meta"
  if [ -n "$backup" ]; then
    fm_write_meta "$EXT_META" kind=ship mode=direct-PR forge=external backup_remote=backup backup_prefix=backup/
  else
    fm_write_meta "$EXT_META" kind=ship mode=direct-PR forge=external
  fi
}

ext_accept() {  # <line>
  CONFIG=$EXT_CFG fm_dod_accept_ship_done ship direct-PR "$EXT_WT" "$EXT_REPO" "$1" "$TMP_ROOT" ext "$EXT_META"
}

test_external_review_done_without_backup_is_accepted_on_the_url() {
  local reason
  external_fixture ext-nobackup
  ext_accept 'done [at=1]: review https://review.example.test/r/123 uploaded for review' \
    || fail "an external review done with HEAD only in the copy was refused with no backup recorded"
  reason=$(ext_accept 'done [at=1]: PR https://github.com/o/r/pull/1') && fail "a PR done on an external project was accepted"
  assert_contains "$reason" "never a PR" "the PR refusal did not point at the review grammar"
  for bad in 'http://review.example.test/r/1' 'https://review.example.test/r/1?x=1' \
    'https://review.example.test/r/1#c' 'https://github.com/o/r/pull/1'; do
    reason=$(ext_accept "done [at=1]: review $bad uploaded for review") && fail "review URL $bad was accepted"
  done
  printf '%s\n' '^https://review\.example\.test/r/[1-9][0-9]*$' > "$EXT_CFG/external-review-url"
  reason=$(ext_accept 'done [at=1]: review https://other.example.test/r/1 uploaded for review') \
    && fail "a review URL outside config/external-review-url was accepted"
  ext_accept 'done [at=1]: review https://review.example.test/r/7 uploaded for review' \
    || fail "a review URL matching config/external-review-url was refused"
  rm -f "$EXT_CFG/external-review-url"
  pass "external review done: accepted on a canonical URL alone without a backup; PR, non-https, query, fragment, forge, and pattern mismatches refused"
}

test_external_review_done_with_backup_needs_the_copy() {
  local reason sha
  external_fixture ext-backup backup
  sha=$(git -C "$EXT_WT" rev-parse HEAD)
  reason=$(ext_accept 'done [at=1]: review https://review.example.test/r/9 uploaded for review') \
    && fail "a backed-up external done was accepted before the copy existed"
  assert_contains "$reason" "not on the backup remote backup" "the backup refusal did not name the remote"
  git -C "$EXT_WT" update-ref refs/remotes/backup/fm/ext-backup "$sha"
  reason=$(ext_accept 'done [at=1]: review https://review.example.test/r/9 uploaded for review') \
    && fail "a copy outside the backup prefix satisfied the backup gate"
  git -C "$EXT_WT" update-ref refs/remotes/backup/backup/ext-backup "$sha"
  ext_accept 'done [at=1]: review https://review.example.test/r/9 uploaded for review' \
    || fail "a backed-up external done was refused once HEAD was on the backup namespace"
  pass "external review done with a backup: refused until HEAD is under refs/remotes/backup/backup/, then accepted"
}

test_external_forge_is_direct_pr_only
test_external_rule_one_forbids_every_task_push
test_external_dod_renders_the_adapter
test_external_review_done_without_backup_is_accepted_on_the_url
test_external_review_done_with_backup_needs_the_copy

test_worker_role_names_skill_and_fallback_file

echo "all fm-dod-lib tests passed"
