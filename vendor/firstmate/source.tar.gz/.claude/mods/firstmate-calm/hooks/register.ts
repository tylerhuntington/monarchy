// Firstmate Calm for Claude Code: the hooks module of the Calm mod, whose plugin name is `fm`.
//
// A Claude Code "mod" is a plugin whose behavior lives in one hooks module. Claude Code
// may load this module through its rollout flag or `CLAUDE_CODE_ENABLE_FUNCTION_HOOKS`,
// but every handler requires that environment variable to equal `1`, so rollout-only
// loading remains a complete no-op.
// The plugin carries no command, skill, agent, or classic hook of its own; the `/calm`
// command below exists only once this module has registered it. docs/calm.md owns the
// captain-facing contract and docs/calm-mode-feasibility.md the version-scoped evidence.
//
// This file is the only place the engine interface `$` is touched: the geometry lives
// in ../lib/fm-calm-working-ship-sprite.ts (shared with the Pi extension), the Raster
// packing in ../lib/fm-calm-ship-raster.ts, and every visibility decision in
// ../lib/fm-calm-presentation.ts, so the policy is testable under Node and the engine
// glue under `claude plugin test`. Nothing here rewrites a message: `ui.render` changes
// drawings and leaves the stored transcript, model context, and session storage alone.
//
// Presentation while Calm is on, sharing Pi Calm's goals where the mods API allows:
// the stock working row (`Spinner`) becomes the two-row sailboat, repainted through
// `$.ui.blit` on the sprite's own tick; `ToolUse`, `ToolResult`, and `ToolGroup` rows
// draw as zero-height boxes; a `UserMessage` whose text the canonical operational-input
// classifier recognizes, or a record-backed doorbell whose record holds a current
// envelope (read through `$.fs.read`, cached until Calm next invalidates its drawings),
// draws as zero height; an `AssistantMessage` block recorded as a mid-turn working note
// draws as zero height. Calm off returns every drawing to the
// engine. A toggle invalidates every hooked drawing, so rows already on screen redraw.
// The boat is painted in Claude Code's own theme colors: the family is read from the
// `theme` setting at load and re-read when a `config.set` changes it.
//
// Supervision notes, whether Calm is on or off, as Pi shows them regardless of Calm: a
// slow timer follows the outcome store's display tail copy and the supervision host's
// latch, and `$.ui.log` appends one dim line per new outcome or latch change, never
// sent to the model. The first tail copy a session sees, at `session.start` or later,
// replays the outcomes unread or unprocessed at `session.start` that this session has
// not already shown. The mod only reads the Firstmate home: the drain remains the one
// presenter that marks outcomes read.
// ../lib/fm-branch-notes.ts owns every line and which rows are due.
//
// Loading is lazy and cached within a session: a resumed transcript or a hot reload can
// draw restored rows before `session.start`, so every hook awaits that session's load of
// the per-home preference and restored working notes rather than trusting a stale "off".
// Each `session.start` clears presentation classifications and reloads the new session.
import type { EngineInterface, Register, RenderElement, RenderInput } from "claude-code";
import {
  CALM_WORKING_SHIP_TICK_MS,
  createCalmWorkingShipSprite,
} from "../lib/fm-calm-working-ship-sprite.ts";
import {
  CALM_SHIP_RASTER_KEY,
  CALM_SHIP_RASTER_PALETTES,
  calmShipPaletteFamily,
  calmShipRasterColumns,
  packCalmShipRasterCells,
  type CalmShipRasterPalette,
} from "../lib/fm-calm-ship-raster.ts";
import {
  calmPreferencePath,
  parseCalmPreference,
  classifyRestoredTranscript,
  recordIsOperational,
  serializeCalmPreference,
  stepTextIsWorkingNote,
  userTextIsOperational,
  userTextOperationalRecord,
  workingNoteKey,
} from "../lib/fm-calm-presentation.ts";
import {
  firstmateStateDirectory,
  hostHealthNote,
  newOutcomeNotes,
  parseHostHealth,
  parseOutcomeMarker,
  parseOutcomeTail,
  recordSessionShownThrough,
  replayOutcomeNotes,
  sessionShownThrough,
  type HostHealth,
} from "../lib/fm-branch-notes.ts";

/** The slash command the mod serves, the same name as Pi's `/calm`. */
const CALM_COMMAND = "calm";

// One module environment holds one Calm state; a hot reload starts a fresh one, the
// same as a new Pi extension lifetime.
let calm = false;
let preferencePath: string | undefined;
let activation: Promise<boolean> | undefined;
let loading: Promise<void> | undefined;
let ticker: { cancel(): void } | undefined;
const workingNotes = new Set<string>();
const finalReplies = new Set<string>();
// Each doorbell's record verdict, by record path. Records are immutable once published
// but pruned after seven days, so every invalidation drops the cache and rechecks.
const doorbellVerdicts = new Map<string, Promise<boolean>>();
const sprite = createCalmWorkingShipSprite();
let palette: CalmShipRasterPalette = CALM_SHIP_RASTER_PALETTES.light;
// Every Spinner site currently drawing the boat, by its requestId, with the mounted
// Raster size a blit must repeat exactly.
const sites = new Map<string, { columns: number; rows: number }>();
/** How often the supervision notes check the store's tail copy and the host's latch. */
const BRANCH_NOTES_POLL_MS = 3000;
/**
 * A file changed this recently may be replaced again within its timestamp's resolution
 * at the same size, so its size and time do not yet prove a later read unchanged.
 */
const SETTLED_MS = 5000;
/**
 * The mod's store key for the sequence each session has followed the store through:
 * Claude Code 2.1.283 keeps `$.ui.log` lines in the session and restores them on
 * `--continue`, so a resumed session replays only what it has not already shown.
 */
const BRANCH_NOTES_SHOWN_KEY = "supervision-notes-shown-through";
// What the notes have shown in this session; each `session.start` replaces it.
type NotesState = {
  state: string;
  tailStamp: string | undefined;
  healthStamp: string | undefined;
  lastSeen: number | undefined;
  cursor: number;
  processed: number;
  shown: number;
  health: HostHealth | undefined;
  sessionId: string | undefined;
  remembered: number | undefined;
};
let notes: NotesState | undefined;
let notesTimer: { cancel(): void } | undefined;
let notesPolling = false;

function isActivated($: EngineInterface): Promise<boolean> {
  if (activation === undefined) {
    activation = $.env.get("CLAUDE_CODE_ENABLE_FUNCTION_HOOKS").then(
      (value) => value === "1",
      () => false,
    );
  }
  return activation;
}

// A missing file is checked first because every rejected read or stat is an error in
// Claude Code's debug log, and the supervision notes look for absent files every tick.
async function readText($: EngineInterface, path: string): Promise<string | undefined> {
  try {
    if (!(await $.fs.exists(path))) return undefined;
    return await $.fs.read(path);
  } catch {
    return undefined;
  }
}

/** The `theme` setting's current value, or undefined when the menu cannot be read. */
async function readTheme($: EngineInterface): Promise<unknown> {
  try {
    return (await $.config.list()).find((row) => row.key === "theme")?.value;
  } catch {
    return undefined;
  }
}

async function load($: EngineInterface): Promise<void> {
  preferencePath = calmPreferencePath(
    {
      FM_HOME: await $.env.get("FM_HOME"),
      FM_ROOT_OVERRIDE: await $.env.get("FM_ROOT_OVERRIDE"),
      FM_CONFIG_OVERRIDE: await $.env.get("FM_CONFIG_OVERRIDE"),
    },
    $.plugin.root,
  );
  calm = parseCalmPreference(await readText($, preferencePath));
  palette = CALM_SHIP_RASTER_PALETTES[calmShipPaletteFamily(await readTheme($))];
  try {
    const restored = classifyRestoredTranscript(await $.session.messages());
    for (const note of restored.workingNotes) workingNotes.add(note);
    for (const reply of restored.finalReplies) finalReplies.add(reply);
  } catch {
    // A transcript that cannot be read leaves restored narration visible; nothing else changes.
  }
  if (ticker === undefined) {
    ticker = $.clock.every(CALM_WORKING_SHIP_TICK_MS, () => {
      void repaintShip($);
    });
  }
  invalidateDrawings($);
}

function ensureLoaded($: EngineInterface): Promise<void> {
  if (loading === undefined) loading = load($);
  return loading;
}

async function resetSession($: EngineInterface): Promise<void> {
  if (loading !== undefined) await loading.catch(() => undefined);
  calm = false;
  preferencePath = undefined;
  loading = undefined;
  workingNotes.clear();
  finalReplies.clear();
  doorbellVerdicts.clear();
  sites.clear();
  sprite.reset();
  palette = CALM_SHIP_RASTER_PALETTES.light;
  await ensureLoaded($);
}

/** Redraw every hooked drawing, rechecking each doorbell's record on its next drawing. */
function invalidateDrawings($: EngineInterface): void {
  doorbellVerdicts.clear();
  $.ui.invalidate("ui.render");
}

/** One scheduler tick: advance the sprite, then repaint every mounted boat in place. */
async function repaintShip($: EngineInterface): Promise<void> {
  if (!calm || sites.size === 0) return;
  sprite.tick();
  for (const [requestId, site] of sites) {
    const packed = packCalmShipRasterCells(sprite.frame(site.columns), site.columns, palette);
    const result = await $.ui.blit({
      requestId,
      key: CALM_SHIP_RASTER_KEY,
      cells: packed.cells,
      columns: site.columns,
      rows: site.rows,
    });
    // A denied blit means the site no longer shows this plugin's Raster (the turn
    // settled, or a resize redrew it); forget it until the next Spinner drawing.
    if (result.deny !== undefined && sites.get(requestId) === site) sites.delete(requestId);
  }
}

/** Whether a user row is a record-backed doorbell whose record holds a current envelope. */
function doorbellIsOperational($: EngineInterface, text: string): Promise<boolean> {
  const record = userTextOperationalRecord(text);
  if (record === undefined) return Promise.resolve(false);
  let verdict = doorbellVerdicts.get(record);
  if (verdict === undefined) {
    verdict = readText($, record).then(recordIsOperational);
    doorbellVerdicts.set(record, verdict);
  }
  return verdict;
}

/**
 * A file's text with the size and time it was read at, or undefined when it is missing or
 * unchanged. A file too recently changed has no stamp, so the next check reads it again.
 */
async function readIfChanged(
  $: EngineInterface,
  path: string,
  stamp: string | undefined,
): Promise<{ stamp: string | undefined; text: string } | undefined> {
  let current: string;
  let settled: boolean;
  try {
    if (!(await $.fs.exists(path))) return undefined;
    const stat = await $.fs.stat(path);
    current = `${stat.size}:${stat.mtimeMs}`;
    settled = (await $.clock.now()) - stat.mtimeMs >= SETTLED_MS;
  } catch {
    return undefined;
  }
  if (current === stamp) return undefined;
  const text = await readText($, path);
  return text === undefined ? undefined : { stamp: settled ? current : undefined, text };
}

/** Replay the due outcomes, then follow the store from its current tail. */
async function startNotes($: EngineInterface): Promise<void> {
  const state = firstmateStateDirectory(
    {
      FM_HOME: await $.env.get("FM_HOME"),
      FM_ROOT_OVERRIDE: await $.env.get("FM_ROOT_OVERRIDE"),
      FM_STATE_OVERRIDE: await $.env.get("FM_STATE_OVERRIDE"),
    },
    $.plugin.root,
  );
  const sessionId = await $.session.id().catch(() => undefined);
  const health = await readIfChanged($, `${state}/.supervision-host-health`, undefined);
  const current: NotesState = {
    state,
    tailStamp: undefined,
    healthStamp: health?.stamp,
    lastSeen: undefined,
    cursor: parseOutcomeMarker(await readText($, `${state}/.branch-outcomes-cursor`)),
    processed: parseOutcomeMarker(await readText($, `${state}/.branch-outcomes-processed`)),
    shown: sessionId === undefined ? 0 : sessionShownThrough(await readStored($), sessionId),
    health: parseHostHealth(health?.text),
    sessionId,
    remembered: undefined,
  };
  await followTail($, current);
  notes = current;
  if (notesTimer === undefined) {
    notesTimer = $.clock.every(BRANCH_NOTES_POLL_MS, () => {
      void pollNotes($);
    });
  }
}

/**
 * A line per outcome the tail copy gained. The first tail this session sees is the
 * startup replay, whether it existed at session start or appeared later, judged against
 * the read cursor and processed marker as they were at session start: a row read or
 * processed before then is never shown, and one the drain read since still is.
 */
async function followTail($: EngineInterface, current: NotesState): Promise<void> {
  const tail = await readIfChanged($, `${current.state}/.branch-outcomes-tail.jsonl`, current.tailStamp);
  if (tail === undefined) return;
  current.tailStamp = tail.stamp;
  const rows = parseOutcomeTail(tail.text);
  let lines: string[];
  if (current.lastSeen === undefined) {
    lines = replayOutcomeNotes(rows, current.cursor, current.processed, current.shown);
    current.lastSeen = rows[rows.length - 1]?.seq;
  } else {
    const fresh = newOutcomeNotes(rows, current.lastSeen);
    lines = fresh.lines;
    current.lastSeen = fresh.lastSeen;
  }
  for (const line of lines) $.ui.log(line);
  await rememberShown($, current);
}

async function readStored($: EngineInterface): Promise<unknown> {
  try {
    return await $.store.get(BRANCH_NOTES_SHOWN_KEY);
  } catch {
    return undefined;
  }
}

/** Record how far this session has followed the store, when that moved. */
async function rememberShown($: EngineInterface, current: NotesState): Promise<void> {
  if (current.sessionId === undefined || current.lastSeen === undefined || current.lastSeen === current.remembered) return;
  try {
    await $.store.set(
      BRANCH_NOTES_SHOWN_KEY,
      recordSessionShownThrough(await readStored($), current.sessionId, current.lastSeen),
    );
    current.remembered = current.lastSeen;
  } catch {
    // An unwritable store only means a later resume may replay a line again.
  }
}

/** One slow tick: a line per outcome appended since the last, and a latch change's note. */
async function pollNotes($: EngineInterface): Promise<void> {
  const current = notes;
  if (current === undefined || notesPolling) return;
  notesPolling = true;
  try {
    await followTail($, current);
    const health = await readIfChanged($, `${current.state}/.supervision-host-health`, current.healthStamp);
    if (health !== undefined) {
      current.healthStamp = health.stamp;
      const next = parseHostHealth(health.text);
      const note = hostHealthNote(current.health, next);
      if (next !== undefined) current.health = next;
      if (note !== undefined) $.ui.log(note);
    }
  } finally {
    notesPolling = false;
  }
}

/** A zero-height drawing: the row contributes nothing to the transcript's layout. */
function hiddenRow($: EngineInterface, e: RenderInput): RenderElement {
  const { Box } = $.ui.resolve(e);
  return Box({ display: "none" });
}

export const register: Register = (on) => {
  on("session.start", async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await resetSession($);
    // Notes that cannot start leave Calm and the transcript exactly as they were.
    await startNotes($).catch(() => undefined);
    await $.command.register({
      name: CALM_COMMAND,
      description: "Toggle Firstmate's Calm transcript presentation and working ship.",
    });
    return next(e);
  });

  on("command.run", { command: CALM_COMMAND }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    const active = !calm;
    // Persist before changing live presentation, so a failed write leaves the current
    // choice unchanged rather than claiming persistence.
    try {
      await $.fs.write(preferencePath ?? "", serializeCalmPreference(active));
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      $.ui.toast(`Calm unchanged: could not save ${preferencePath ?? "the preference"} (${reason})`);
      return {};
    }
    calm = active;
    if (!calm) sites.clear();
    invalidateDrawings($);
    $.ui.toast(active ? "Calm on" : "Calm off");
    // No `text`: the toggle leaves no output row in the transcript, as on Pi.
    return {};
  });

  // Follow a theme change: the next drawing and every later blit use the new family.
  on("config.set", { key: "theme" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    const result = await next(e);
    if (result.deny === undefined) {
      const chosen = CALM_SHIP_RASTER_PALETTES[calmShipPaletteFamily(result.value)];
      if (chosen !== palette) {
        palette = chosen;
        if (calm) invalidateDrawings($);
      }
    }
    return result;
  });

  // Record mid-turn narration as it streams: the text blocks of a model step that
  // stopped to call tools. Subagent steps never draw in the main transcript.
  on("turn.step", async function* ($, e, next) {
    if (!(await isActivated($))) {
      const untouched = next(e);
      for await (const chunk of untouched) yield chunk;
      return await untouched.result;
    }
    const stream = next(e);
    const blocks = new Map<number, string>();
    for await (const chunk of stream) {
      if (chunk.kind === "text") blocks.set(chunk.index, (blocks.get(chunk.index) ?? "") + chunk.text);
      yield chunk;
    }
    const result = await stream.result;
    if (e.agentId === undefined) {
      let changed = false;
      for (const text of [...blocks.values(), result.answer]) {
        const key = workingNoteKey(text);
        if (key === "") continue;
        if (stepTextIsWorkingNote(result, text)) {
          if (finalReplies.has(key) || workingNotes.has(key)) continue;
          workingNotes.add(key);
          changed = true;
        } else {
          if (!finalReplies.has(key)) {
            finalReplies.add(key);
            changed = true;
          }
          if (workingNotes.delete(key)) changed = true;
        }
      }
      if (changed && calm) invalidateDrawings($);
    }
    return result;
  });

  on("ui.render", { component: "Spinner" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    if (!calm || e.surface !== "terminal") {
      sites.delete(e.requestId);
      return next(e);
    }
    const columns = calmShipRasterColumns(e.viewport?.columns);
    const packed = packCalmShipRasterCells(sprite.frame(columns), columns, palette);
    sites.set(e.requestId, { columns, rows: packed.rows });
    const { Box, Raster } = $.ui.resolve(e);
    // One blank row above the boat keeps its sail off the highlighted prompt, since Calm hides the rows between.
    return Box({
      flexDirection: "column",
      paddingTop: 1,
      children: Raster({ key: CALM_SHIP_RASTER_KEY, columns, rows: packed.rows, cells: packed.cells }),
    });
  });

  on("ui.render", { component: "ToolUse" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    return calm ? hiddenRow($, e) : next(e);
  });
  on("ui.render", { component: "ToolResult" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    return calm ? hiddenRow($, e) : next(e);
  });
  on("ui.render", { component: "ToolGroup" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    return calm ? hiddenRow($, e) : next(e);
  });

  on("ui.render", { component: "UserMessage" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    if (!calm) return next(e);
    const operational =
      userTextIsOperational(e.props.text) || (await doorbellIsOperational($, e.props.text));
    return operational ? hiddenRow($, e) : next(e);
  });

  on("ui.render", { component: "AssistantMessage" }, async ($, e, next) => {
    if (!(await isActivated($))) return next(e);
    await ensureLoaded($);
    const key = workingNoteKey(e.props.text);
    return calm && workingNotes.has(key) && !finalReplies.has(key) ? hiddenRow($, e) : next(e);
  });
};
